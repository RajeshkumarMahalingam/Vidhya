from Selenium2Library import Selenium2Library
from selenium import webdriver
import time

class TestBrowser(Selenium2Library):
    dict = {}
    def opening_browser(self):
        self.open_browser('http://192.168.0.232/qabetabb15se/Backbone/admin/login.aspx', 'Chrome', None, False, None, None)
        cookieslist = self.get_cookies()
        print "before", cookieslist
        self.delete_all_cookies()
        cookieslist = self.get_cookies()
        print "after", cookieslist      
        time.sleep(10)
        self.browser = self._current_browser()
        self.dict['BROWSER'] = self._current_browser()
        print self.dict['BROWSER']
        print self._cache.current
        
    def opening_browser_new(self):
        driver = webdriver.Chrome(executable_path='D:\workspace\Automate_BB15_local\chromedriver.exe')
        print "1", driver
        driver.get('http://192.168.0.232/qabetabb15se/Backbone/admin/login.aspx')
        print "2", driver
        print self._cache.current
        self._cache.c
        
        #driver.delete_all_cookies()
        

TestBrowser().opening_browser()
#TestBrowser().opening_browser_new()

'''servername = "QASERVER\QABETA"
print servername
server = "Server="+servername+";"
print server'''


'''name = " White Blood cells"
print name[1:]'''