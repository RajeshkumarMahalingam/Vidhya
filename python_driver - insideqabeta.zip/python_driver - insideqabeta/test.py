import sys
from Selenium2Library import Selenium2Library
from Tkconstants import ACTIVE
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing


class InTheaterBooking(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OT_TheaterBooking")
    def surgeryfromdatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr[2]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr[2]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                print "exception occurs"
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def surgerytodatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr[2]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
                try:
                    count = 0
                    for i in range(1, 100):
                        i = str(i)
                        MinuteDisplayed = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+i+']')
                        if len(MinuteDisplayed)!=0:
                            print MinuteDisplayed
                            count = count + 1
                            i = int(i)
                            i = i + 1
                except ValueError:
                    print count
                    pass
                print "total number of test name:     ", count
                count = str(count)
                self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+count+']', 10, "active mins not visible")
                lastminutedisplayed = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+count+']')
                print lastminutedisplayed
                self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]', 10, "active mins not visible")
                activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
                print activemins
                if lastminutedisplayed != activemins:
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
                    time.sleep(2)
                else:
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/thead/tr/th[@class="next"]')
                    self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr[2]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
               try:
                try:
                    count = 0
                    for i in range(1, 100):
                        i = str(i)
                        MinuteDisplayed = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+i+']')
                        if len(MinuteDisplayed)!=0:
                            print MinuteDisplayed
                            count = count + 1
                            i = int(i)
                            i = i + 1
                except ValueError:
                    print count
                    pass
                print "total number of test name:     ", count
                count = str(count)
                self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+count+']', 10, "active mins not visible")
                lastminutedisplayed = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span['+count+']')
                print lastminutedisplayed
                self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
                activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                print activemins
                if lastminutedisplayed != activemins:
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
                    time.sleep(2)
                else:
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/thead/tr/th[@class="next"]')
                    self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
                    self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               except:
                pass
               '''self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
               print activemins
               self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
               time.sleep(2)'''
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['REGNO'] = "626453"
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Regno'], 10, 'Regno was not visible' )
        self.input_text(self.objects['OT_TheaterBooking_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_emergencybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_EmergencyBtn'], 10, 'emergency btn was not visible' )
        self.click_element(self.objects['OT_TheaterBooking_EmergencyBtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OT_TheaterBooking_Searchbtn'], 10, 'search btn was not enabled' )
        self.click_button(self.objects['OT_TheaterBooking_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_theaterbookingpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 10, 'Patient details not in grid')
        self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_theater(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Theater'], 10, 'theater details was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Theater'], "5")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_procedure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Procedure'], 10, 'procedure was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Procedure'], "3")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeonname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Surgeon'], 10, 'Surgeon name was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Surgeon'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_anesthesia(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Anesthesia'], 10, 'anesthesia was not visible' )
        self.select_from_list_by_label(self.objects['OT_TheaterBooking_Anesthesia'], "Yes")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeryclassification(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_SurgeryClassification'], 10, 'Surgery Classification was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_SurgeryClassification'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeryfromdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtsurfrmdate"]', 10, "surgery from date was not visible")
        date = self.d[r]['surgeryfromdate']
        self.surgeryfromdatepicker('xpath=//*[@id="txtsurfrmdate"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgerytodate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtsurtodate"]', 10, "surgery from date was not visible")
        date = self.d[r]['surgerytodate']
        self.surgerytodatepicker('xpath=//*[@id="txtsurtodate"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_TheaterBooking_Savebtn"], 15, "Save btn was not visible")
         self.click_button(self.objects["OT_TheaterBooking_Savebtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_TheaterBooking_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_TheaterBooking_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()


admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ot')
admin.FromConfigFile().loading_menu_of_link("//OT/ResultPrintoutPatsearch.aspx")
print "menu loaded"
InTheaterBooking().screenshotonfailure()
InTheaterBooking().selecting_the_frame()
InTheaterBooking().entering_regno()
InTheaterBooking().selecting_emergencybtn()
InTheaterBooking().selecting_searchbtn()
InTheaterBooking().entering_into_theaterbookingpage()
InTheaterBooking().selecting_theater()
InTheaterBooking().selecting_procedure()
InTheaterBooking().selecting_surgeonname()
InTheaterBooking().selecting_surgeryfromdate('1')
InTheaterBooking().selecting_surgerytodate('1')
InTheaterBooking().selecting_anesthesia()
InTheaterBooking().selecting_surgeryclassification()
InTheaterBooking().selecting_savebtn()
InTheaterBooking().getting_message()
InTheaterBooking().unselecting_the_frame()
admin.FromConfigFile().Logoff()

