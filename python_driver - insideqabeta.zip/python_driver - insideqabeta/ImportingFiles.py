# importing the modules
import os
import shutil

# Providing the folder path
print "start file uploading"
try:
    origin = r'D:\workspace\Automate_BB15_local'
    target = r'D:\FileUpload\to'
    # Fetching the list of all the files
    files = os.listdir(origin)
    # Fetching all the files to directory
    for file_name in files:
        shutil.copytree(origin, target)
    #shutil.copy(origin+file_name, target+file_name)
    print("Files are copied successfully")
except WindowsError:
    print("Files are copied along with windows error")
    pass
print "end file uploading"
#print os.listdir(r'D:\FileUpload\to')
FilesList = os.listdir(r'D:\FileUpload\to')
print FilesList
screenshotcount = str(FilesList).count('selenium-screenshot')
print str(FilesList).count('selenium-screenshot')
if screenshotcount > 3:
    upload_status = "files are uploaded successfully"
    print upload_status
#FileslistCount = FilesList.count
#print FileslistCount




