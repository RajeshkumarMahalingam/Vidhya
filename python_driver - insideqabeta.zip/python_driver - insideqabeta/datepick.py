import sys
from Selenium2Library import Selenium2Library
from Tkconstants import ACTIVE
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing


class InFumigationScheduleSearch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_FumigSchedSearch")
    def reopendatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                print "exception occurs"
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 10, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_fumigationschedulescreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]', 10, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_typeoffumigation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]', 10, error)
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_page_contains_element('xpath=//*[@id="cboFumtype"]', 10, "fumigation type was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboFumtype"]', '3')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reopendate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtReopenDt"]', 10, "fumigation reopen date was not visible")
        date = self.d[r]['reopendate']
        self.reopendatepicker('xpath=//*[@id="txtReopenDt"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def entering_approvedby(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtApprvby"]', 10, "approved by was not visible")
        self.input_text('xpath=//*[@id="txtApprvby"]', self.d[r]['approvedby'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="btnfumSave"]', 10, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 10, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser        

admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/Ward/tFumigationsearch.html")
print "menu loaded"
InFumigationScheduleSearch().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationScheduleSearch().screenshotonfailure()
InFumigationScheduleSearch().selecting_the_frame()
InFumigationScheduleSearch().selecting_department()
InFumigationScheduleSearch().entering_into_fumigationschedulescreen()
InFumigationScheduleSearch().selecting_typeoffumigation()
InFumigationScheduleSearch().selecting_reopendate('1')
InFumigationScheduleSearch().entering_approvedby('1')
InFumigationScheduleSearch().selecting_savebtn()
InFumigationScheduleSearch().getmessage_after_save()
InFumigationScheduleSearch().unselecting_the_frame()


