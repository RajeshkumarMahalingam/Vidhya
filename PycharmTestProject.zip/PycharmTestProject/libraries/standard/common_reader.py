import openpyxl
from openpyxl import load_workbook
from robot.libraries.BuiltIn import BuiltIn

class Capturing():
    d = {}
    objects = {}

    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')
    def data_off(self, sheet):
        self.d = {}
        r = 0
        wrkbk = load_workbook('./datas/Bb_datas.xlsx')
        sheet = wrkbk[sheet]
        number_of_rows = sheet.max_row
        number_of_columns = sheet.max_column
        while r <= number_of_rows - 2:
            r = r + 1
            self.d[r] = {}
            c = 1
            while c <= number_of_columns - 1:
                c = c + 1
                self.d[r][sheet.cell(row=1, column=c).value] = sheet.cell(row=(r + 1), column=c).value
        # print sheet
        # print self.d
        return self.d

    def backbone_objects(self):
        wb = openpyxl.load_workbook('./object_repository/objects.xlsx')
        ws = wb["obj"]
        for row in ws.rows:
            self.objects[row[0].value] = row[1].value
        return self.objects

Capturing().backbone_objects()