from robot.libraries.BuiltIn import BuiltIn
import common_reader
#from common_reader import Capturing
#import libraries.standard.common_reader as common


class FO_InOPNewRegistration:
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_OPNewReg")

    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')


    def driving_browser_and_url(self, url, browser):
        self.selib.create_webdriver(browser)
        self.selib.go_to(url)
        print('test')
        var1 = self.objects['FO_MenuList']
        print (var1)
        print(self.objects['Login_NewSession'])
        self.selib.wait_until_element_is_visible(self.objects['Login_NewSession'], timeout=30, error="Link not visible: #divNewSession")
        self.selib.maximize_browser_window()
        self.selib.click_element('xpath=//a[@href="#divNewSession"]')
        self.selib.set_selenium_implicit_wait("30 seconds")

    def logging(self, username, password):
        #r = int(r)
        #print (self.d[r]['username'])
        self.selib.input_text("id=newuname", username)
        self.selib.input_password("id=txtrepassword", password)
        self.selib.wait_until_element_is_visible("id=btnrelogin")
        self.selib.click_button("id=btnrelogin")

    def selecting_the_frame(self):
        self.selib.wait_until_element_is_visible("xpath=//*[@id='frmMainPage']")
        self.selib.select_frame("xpath=//*[@id='frmMainPage']")

    def select_department(self):
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboDepartment']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboDepartment']", "CARDIOLOGY")
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboDoctorUnit']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboDoctorUnit']", "BALAJI")

    def select_sal_name_gender_age_dob_marital_status_relation(self):
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboSal']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboSal']", "Mr")
        self.selib.input_text("xpath=//*[@id='txtLastName']", "Kumar")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboGender']", "Male")
        self.selib.input_text("xpath=//*[@id='txtAge']", "40")
        self.selib.input_text("xpath=//*[@id='txtDOB']", "27-06-1996")
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboMartialStatus']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboMartialStatus']", "Single")
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboRelation']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboRelation']", "Father")
        self.selib.input_text("xpath=//*[@id='txtRelationName']", "Govind")

    def enter_present_address_mobile_nationality_remarks(self):
        self.selib.input_text("xpath=//*[@id='txtPresentAddress']", "Boopathy Avenue")
        self.selib.input_text("xpath=//*[@id='txtMobile']", "8124329736")
        self.selib.wait_until_element_is_visible("xpath=//*[@id='cboNationality']")
        self.selib.select_from_list_by_label("xpath=//*[@id='cboNationality']", "INDIAN")
        self.selib.input_text("xpath=//*[@id='txtRemarks']", "Registration")

    def save_registration(self):
        self.selib.wait_until_element_is_visible("xpath=//*[@id='btnSave']")
        self.selib.click_element("xpath=//*[@id='btnSave']")
