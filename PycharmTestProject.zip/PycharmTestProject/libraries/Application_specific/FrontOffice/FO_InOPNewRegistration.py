from robot.libraries.BuiltIn import BuiltIn
import common_reader
from common_reader import Capturing
import time
import pyautogui
from random import randint


class FO_InOPNewRegistration:
    dict = common_reader.Capturing.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_OPNewReg")

    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')

    def screenshotonfailure(self):
        self.selib.set_selenium_implicit_wait(30)
        self.selib.register_keyword_to_run_on_failure('Capture Page Screenshot')

    def selecting_the_frame(self):
        self.selib.set_selenium_implicit_wait(30)
        self.selib.select_frame(self.objects["FO_MainFrame"])
        time.sleep(20)

    def selecting_department_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        self.selib._cache.current
        self.selib.handle_alert()
        self.selib.handle_alert_with_text()
        self.selib.driver




        r = int(r)
        self.selib.wait_until_page_contains_element(self.objects["FO_NewRegistration_Dept"], 20, "department was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"], self.d[r]["department"])
        
    def selecting_doctor_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 10, "doctor was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], self.d[r]["doctor"])
        #self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], "ss")
        # WF_21

    def selecting_unit_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 10, "doctor was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], self.d[r]["unit"])
        

    def selecting_patient_type_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.select_from_list_by_label(self.objects['FO_NewRegistration_PatType'], self.d[r]['patient_type'])
        

    def selecting_camp_name_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType_campname_click'], 10,
                                           'No text box is present')
        self.selib.click_element(self.objects['FO_NewRegistration_PatType_campname_click'])
        self.selib.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType__campname_text'], 10,
                                           'No text box is present')
        self.selib.input_text(self.objects['FO_NewRegistration_PatType__campname_text'], self.d[r]['camp_name'])
        time.sleep(2)
        pyautogui.hotkey('enter')
        

    def selecting_camp_no_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_enabled(self.objects['FO_NewRegistration_PatType_camp_patient_click'], 10,
                                           'element not enabled')
        self.selib.click_element(self.objects['FO_NewRegistration_PatType_camp_patient_click'])
        self.selib.input_text(self.objects['FO_NewRegistration_PatType_camp_patient_text'], self.dict['CAMP_REGNO'])
        pyautogui.hotkey('enter')
        

    def selecting_sal_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Sal"], 10, "sal was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"], self.d[r]["sal"])
        

    def entering_name_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        # Tempname = randint(100,999)
        # self.selib.input_text(self.objects["FO_NewRegistration_Name"],"Ganga "+str(Tempname))
        self.selib.input_text(self.objects["FO_NewRegistration_Name"], "TOSHIBA T")
        # self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        # self.selib.input_text(self.objects["FO_NewRegistration_Name"],self.d[r]["name"])
        

    def selecting_gender_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Gender"], 10, "gender was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"], self.d[r]["gender"])
        

    def entering_age_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Age"], 10, "age was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_Age"], self.d[r]["age"])
        

    def selecting_maritalstatus_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_MaritalStatus"], 10,
                                           "marital status was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"], self.d[r]["marital_status"])
        

    def selecting_relation(self):
        self.selib.set_selenium_implicit_wait(30)
        self.selib.select_from_list_by_index(self.objects['FO_patient_details_update_relation'], "1")
        

    def entering_relationname_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.input_text(self.objects['FO_patient_details_update_relationname'], self.d[r]['relname'])
        

    def entering_address_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Address"], 10, "address was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_Address"], self.d[r]["present_address"])
        

    def selecting_city_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_City"], 10, "city was not visible")
        self.selib.click_element(self.objects['FO_NewRegistration_City'])
        # time.sleep(2)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_City_Entry"], 10,
                                           "city entry was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_City_Entry"], self.d[r]["city"])
        self.selib.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        

    def entering_mobile_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        Tempmobile = randint(100, 999)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile no was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_Mobile"], "98800111" + str(Tempmobile))
        # self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        # self.selib.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        # print self.d[r]["opnewreg_mobile"]
        # print(len(self.d[r]["opnewreg_mobile"]))
        

    def selecting_nationality_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Nationality"], 10,
                                           "nationality was not visible")
        self.selib.select_from_list_by_label(self.objects["FO_NewRegistration_Nationality"], self.d[r]["nationality"])
        

    def entering_remarks_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Remarks"], 10, "remarks was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_Remarks"], self.d[r]["remarks"])
        

    def selecting_referraldoctor_with_data(self, r):
        self.selib.set_selenium_implicit_wait(30)
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor"], 10,
                                           "referral doctor was not visible")
        self.selib.click_element(self.objects["FO_NewRegistration_Referraldoctor"])
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor_Entry"], 10,
                                           "referral doctor was not visible")
        self.selib.input_text(self.objects["FO_NewRegistration_Referraldoctor_Entry"], self.d[r]["referraldoctor"])
        self.selib.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\09')
        pyautogui.hotkey('enter')
        

    def clicking_emailtextbox(self):
        self.selib.set_selenium_implicit_wait(30)
        self.selib.wait_until_element_is_visible(self.objects["FO_NewRegistration_Email"], 10, "email was not visible")
        self.selib.click_element(self.objects["FO_NewRegistration_Email"])
        

    def selecting_savebtn(self):
        self.selib.set_selenium_implicit_wait(30)
        time.sleep(1)
        self.selib.wait_until_element_is_enabled(self.objects["FO_NewRegistration_Save"], 10, "save btn was not visible")
        self.selib.click_button(self.objects["FO_NewRegistration_Save"])
        '''time.sleep(1)
        pyautogui.click(860,165)
        time.sleep(1)
        pyautogui.click(860,165)'''
        # self.selib._handle_alert(True)
        

    def fetching_regno(self):
        self.selib.set_selenium_implicit_wait(30)
        # time.sleep(2)
        self.selib.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
        self.msg = self.selib.get_text(self.objects['FO_NewRegistration_Message'])
        self.reg = ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
        self.dict['REGNO'] = self.reg
        self.dict['REGNO']
        print("Registered Reg number is", self.dict['REGNO'])
        

    def unselecting_the_frame(self):
        self.selib.set_selenium_implicit_wait(30)
        self.selib.unselect_frame()
        