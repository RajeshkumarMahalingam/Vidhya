from SeleniumLibrary import SeleniumLibrary
from SeleniumLibrary.base import keyword
import common_reader
from common_reader import Capturing
import admin
import time
import pyautogui
from random import randint
from selenium.webdriver.common.keys import Keys
import selenium.webdriver.remote.webdriver
from selenium import webdriver
from robot.libraries.BuiltIn import BuiltIn


class FO_InOPNewRegistration(SeleniumLibrary):
    dict = common_reader.Capturing.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_OPNewReg")

    @keyword
    def screenshotonfailure(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        print (self.dict['BROWSER'])
        print (self.driver)
        self.set_selenium_implicit_wait(30)
        self.register_keyword_to_run_on_failure('Capture Page Screenshot')
        self.dict['BROWSER'] = self.driver

    @keyword
    def selecting_the_frame(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        print ("inside frame")
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(10)
        self.dict['BROWSER'] = self.driver

    @keyword
    def selecting_department_with_data(self, r):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        r = int(r)
        print ("inside dept")
        print ("dept",self.objects["FO_NewRegistration_Dept"])
        print("dept data", self.d[r]["department"])
        self.wait_until_page_contains_element(self.objects["FO_NewRegistration_Dept"], 20,
                                                    "department was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"], self.d[r]["department"])
        self.dict['BROWSER'] = self.driver

    @keyword
    def selecting_doctor_with_data(self, r):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 10, "doctor was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], self.d[r]["doctor"])
        # self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], "ss")
        # WF_21

    @keyword
    def selecting_unit_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 10, "doctor was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"], self.d[r]["unit"])

    @keyword
    def selecting_patient_type_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.select_from_list_by_label(self.objects['FO_NewRegistration_PatType'], self.d[r]['patient_type'])

    @keyword
    def selecting_camp_name_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType_campname_click'], 10,
                                                 'No text box is present')
        self.click_element(self.objects['FO_NewRegistration_PatType_campname_click'])
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType__campname_text'], 10,
                                                 'No text box is present')
        self.input_text(self.objects['FO_NewRegistration_PatType__campname_text'], self.d[r]['camp_name'])
        time.sleep(2)
        pyautogui.hotkey('enter')

    @keyword
    def selecting_camp_no_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_PatType_camp_patient_click'], 10,
                                                 'element not enabled')
        self.click_element(self.objects['FO_NewRegistration_PatType_camp_patient_click'])
        self.input_text(self.objects['FO_NewRegistration_PatType_camp_patient_text'], self.dict['CAMP_REGNO'])
        pyautogui.hotkey('enter')

    @keyword
    def selecting_sal_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Sal"], 10, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"], self.d[r]["sal"])

    @keyword
    def entering_name_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        # Tempname = randint(100,999)
        # self.input_text(self.objects["FO_NewRegistration_Name"],"Ganga "+str(Tempname))
        self.input_text(self.objects["FO_NewRegistration_Name"], "TOSHIBA T")
        # self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        # self.input_text(self.objects["FO_NewRegistration_Name"],self.d[r]["name"])

    @keyword
    def selecting_gender_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Gender"], 10,
                                                 "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"], self.d[r]["gender"])

    @keyword
    def entering_age_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Age"], 10, "age was not visible")
        self.input_text(self.objects["FO_NewRegistration_Age"], self.d[r]["age"])

    @keyword
    def selecting_maritalstatus_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_MaritalStatus"], 10,
                                                 "marital status was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],
                                             self.d[r]["marital_status"])

    @keyword
    def selecting_relation(self):
        self.set_selenium_implicit_wait(30)
        self.select_from_list_by_index(self.objects['FO_patient_details_update_relation'], "1")

    @keyword
    def entering_relationname_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.input_text(self.objects['FO_patient_details_update_relationname'], self.d[r]['relname'])

    @keyword
    def entering_address_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Address"], 10,
                                                 "address was not visible")
        self.input_text(self.objects["FO_NewRegistration_Address"], self.d[r]["present_address"])

    @keyword
    def selecting_city_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City"], 10, "city was not visible")
        self.click_element(self.objects['FO_NewRegistration_City'])
        # time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City_Entry"], 10,
                                                 "city entry was not visible")
        self.input_text(self.objects["FO_NewRegistration_City_Entry"], self.d[r]["city"])
        self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')

    @keyword
    def entering_mobile_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        Tempmobile = randint(100, 999)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10,
                                                 "mobile no was not visible")
        self.input_text(self.objects["FO_NewRegistration_Mobile"], "98800111" + str(Tempmobile))
        # self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        # self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        # print self.d[r]["opnewreg_mobile"]
        # print(len(self.d[r]["opnewreg_mobile"]))

    @keyword
    def selecting_nationality_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Nationality"], 10,
                                                 "nationality was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Nationality"], self.d[r]["nationality"])

    @keyword
    def entering_remarks_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Remarks"], 10,
                                                 "remarks was not visible")
        self.input_text(self.objects["FO_NewRegistration_Remarks"], self.d[r]["remarks"])

    @keyword
    def selecting_referraldoctor_with_data(self, r):
        self.set_selenium_implicit_wait(30)
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor"], 10,
                                                 "referral doctor was not visible")
        self.click_element(self.objects["FO_NewRegistration_Referraldoctor"])
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor_Entry"], 10,
                                                 "referral doctor was not visible")
        self.input_text(self.objects["FO_NewRegistration_Referraldoctor_Entry"], self.d[r]["referraldoctor"])
        self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\09')
        pyautogui.hotkey('enter')

    @keyword
    def clicking_emailtextbox(self):
        self.set_selenium_implicit_wait(30)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Email"], 10, "email was not visible")
        self.click_element(self.objects["FO_NewRegistration_Email"])

    @keyword
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(30)
        time.sleep(1)
        self.wait_until_element_is_enabled(self.objects["FO_NewRegistration_Save"], 10,
                                                 "save btn was not visible")
        self.click_button(self.objects["FO_NewRegistration_Save"])
        '''time.sleep(1)
        pyautogui.click(860,165)
        time.sleep(1)
        pyautogui.click(860,165)'''
        # self._handle_alert(True)

    @keyword
    def fetching_regno(self):
        self.set_selenium_implicit_wait(30)
        # time.sleep(2)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
        self.msg = self.get_text(self.objects['FO_NewRegistration_Message'])
        self.reg = ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
        self.dict['REGNO'] = self.reg
        self.dict['REGNO']
        print("Registered Reg number is", self.dict['REGNO'])

    @keyword
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(30)
        self.unselect_frame()
