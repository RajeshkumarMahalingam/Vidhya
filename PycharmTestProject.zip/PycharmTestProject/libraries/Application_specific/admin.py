from SeleniumLibrary import SeleniumLibrary
from SeleniumLibrary.base import keyword
import openpyxl
import time
import pyautogui
from openpyxl import load_workbook
from robot.libraries.BuiltIn import BuiltIn
from webbrowser import Chrome
from selenium.webdriver.common.keys import Keys
import selenium.webdriver.remote.webdriver
from selenium import webdriver
#selenium.webdriver.remote.webdriver.WebDriver

class admin(SeleniumLibrary):
 i = 1
 j = 1
 k = 1
 l = 1
 temp = 0
 dict = {}  
 telement = ""

 @keyword
 def admin_screenshotonfailure(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.register_keyword_to_run_on_failure('admin.admin.Capture Page Screenshot')
        self.dict['BROWSER'] = self.driver

 @keyword
 def loading_menu_of_link_test(self, link):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        self.link = link
        y = len(self.link)
        for z in range(y):
            t = (self.link[z:z+1])
            if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
                flink = (self.link[z:])
                z = 0
                break
        z = z + 1
        wrkbk = load_workbook('./Config/Prerequsiteconfig.xlsx')
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2).value
          sm =  sheet.cell(row=(self.i),column=3).value
          mm = sheet.cell(row=(self.i),column=4).value
          wrkbk.close()
          i = 0
          break
        else:
         print ("Link does not exists in excel sheet")
        if tm is not None:
            print ("top menu is", tm)
            self.wait_until_element_is_visible('xpath=//*[@id="menulist"]', 30, 'Menu list is not loaded')
            self.mouse_over('xpath=//*[text()="'+tm+'"]/..')
            time.sleep(1)
            #
            if sm is not None:
                print ("sub menu is", sm)
                self.click_element('xpath=//*[text()="'+sm+'"]')
                time.sleep(1)
                #
                if mm is not None:
                    print ("main menu is",  mm)
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.click_element('xpath=//*[(text()="'+sm+'")]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    #
            else:
                if mm is not None:
                    print ("else part main menu is", mm)
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    time.sleep(1)
                    #
        else:
            print ("top menu not found")
        #
        self.dict['BROWSER'] = self.driver

 @keyword
 def loading_menu_of_link(self,link):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        self.i = 1
        self.temp = 0
        self.telement = ""
        self.link = link
        y = len(self.link)
        for z in range(y):
         t = (self.link[z:z+1])
         if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
          flink = (self.link[z:])
          print ("flink value")
          print (flink)
          z = 0
          break
         z = z + 1
        #Step 1 : Get Sub menu name and menu name from excel for the specified link
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        wrkbk = load_workbook('./Config/Prerequsiteconfig.xlsx')
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2)
          sm =  sheet.cell(row=(self.i),column=3)
          mm = sheet.cell(row=(self.i),column=4)
          print (tm)
          print (sm)
          print (mm)
          wrkbk.close()
          i = 0
          break
        else:
         print ("Link does not exists in excel sheet")
         i = 0
        #Step 2 : Load Menu
        while i <= 6 and flink == xllink:
         #i = i + 1
         self.temp = self.temp + 1
         x = str(self.temp)
         t1 = '"menulist"]/li['
         t2 = ']'
         x = t1 + x + t2 
         #time.sleep(1)
         telement = self._element_find('xpath=//*[@id='+x+'', True, False)
         time.sleep(1)
         #element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "myDynamicElement")) 
         if telement  is not None:
            time.sleep(1)
            if (telement.is_displayed()) == True:
             #time.sleep(2)
             self.mouse_over('xpath=//*[@id='+x+'')
             #time.sleep(1)
             if sm.value is not None:
              #time.sleep(2)
              selement = self._element_find('xpath=//*[(text()="'+sm.value+'")]', True, False)
              #print selement
              time.sleep(1)
              melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
              #print melement
              time.sleep(2)
              if selement is not None:
               #time.sleep(2)
               if (selement.is_displayed()) == True:
                #print "hello"
                self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                if melement is not None :
                  time.sleep(2)
                  if (melement.is_displayed()) == True:
                   self.click_element('xpath=//*[(text()="'+mm.value+'")]')
                   #time.sleep(5)
                   self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                   #time.sleep(3)
                   self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                   #pyautogui.moveRel(100, 100)
                   #return self.dict
                   break         
             elif sm.value is None:
                melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
                if melement is not None:
                     if (melement.is_displayed()) == True:
                      time.sleep(2)
                      self.click_element('xpath=//*[(text()="'+mm.value+'")]')
                      time.sleep(3)
                      self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                      #pyautogui.moveRel(0, 20)
                      #time.sleep(2) 
                      #pyautogui.moveRel(100, 100)
                      
                      #return self.dict
                      break
         else: 
              print ("top menu not found")
         i = i + 1
         self.dict['BROWSER'] = self.driver

 @keyword
 def driving_browser_and_url(self):
        self.set_selenium_implicit_wait(30)
        print ("inside driving brow")
        self.j = 1
        self.k = 1
        #Step 1 : Get browser which is marked as "1" from excell SHEET
        wrkbk = load_workbook('./Config/Prerequsiteconfig.xlsx')
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        sheet = wrkbk["browser_sheet"] 
        number_rows = sheet.max_row
        while self.j <= number_rows:
         self.j = self.j + 1
         if sheet.cell(row=(self.j),column=2).value == 1:
          bwr = sheet.cell(row=(self.j),column=1)
        #step 2 : Get Url which is marked as "1" from excell SHEET
        sheet = wrkbk["url_sheet"]
        number_rows = sheet.max_row
        while self.k <= number_rows:
         self.k = self.k + 1
         if sheet.cell(row=(self.k),column=2).value == 1:
          url = sheet.cell(row=(self.k),column=1)
          print (url.value)
          print (bwr.value)
          wrkbk.close()
        #step 3 : Launch browser and url
        #self.open_browser(''+url.value+'',''+bwr.value+'', None, False, None, None)
        self.create_webdriver(bwr.value)
        self.go_to(url.value)
        #newly added
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 50, 'relogin  button not visible')
        #newly commented
        #time.sleep(5)
        self.maximize_browser_window()
        print ("test")
        print ("self.driver",self.driver)
        self.browser = self.driver
        self.dict['BROWSER'] = self.driver
        print ("self.dict['BROWSER']", self.dict['BROWSER'])

 @keyword
 def logging(self,loginmod):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        print (self._drivers.current)
        #self.driver = self.dict['BROWSER']
        self.set_selenium_implicit_wait(30)
        self.l = 1
        #Step 1 : Get user name and password from excell for which module to login
        wrkbk = load_workbook('./Config/Prerequsiteconfig.xlsx')
        sheet = wrkbk["login_sheet"] 
        number_rows = sheet.max_row
        while self.l <= number_rows:
         self.l = self.l + 1
         if sheet.cell(row=(self.l),column=1).value == loginmod:
             user = sheet.cell(row=(self.l),column=2)
             pw =   sheet.cell(row=(self.l),column=3)
        #Step 2 : Login module with user name and password
        self.click_element('xpath=//a[@href="#divNewSession"]')
        #newly added
        self.wait_until_element_is_visible('xpath=//*[@id="newuname"]', 50, 'login button not visible')
        # newly commented
        #time.sleep(5)
        self.input_text('xpath=//*[@id="newuname"]',''+user.value+'')
        self.input_text('xpath=//*[@id="txtrepassword"]',''+pw.value+'')
        self.click_button('xpath=//*[@id="btnrelogin"]')
        #Newly commented
        #time.sleep(7)
        self.dict['BROWSER'] = self.driver

 @keyword
 def Logoff(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        self.unselect_frame()
        self.wait_until_element_is_visible('xpath=//*[@class="fa fa-power-off"]', 30, 'Log out was not visible')
        self.click_element('xpath=//*[@class="fa fa-power-off"]')
        self.wait_until_element_is_visible('id=uname', 30, 'Log out is not successful')
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 100, 'login button not visible')
        #time.sleep(2)
        self.dict['BROWSER'] = self.driver

 @keyword
 def zoom_out_page(self,times):
         self._drivers.current = self.dict['BROWSER']
         self.browser = self.driver
         times = int(times)
         x = 0
         for x in range(times):
             pyautogui.hotkey('ctrl', '-')
         self.dict['BROWSER'] = self.driver

 @keyword
 def zoom_in_page(self,times):
         self._drivers.current = self.dict['BROWSER']
         self.browser = self.driver
         times = int(times)
         x = 0
         for x in range(times):
             pyautogui.hotkey('ctrl', '+')
         self.dict['BROWSER'] = self.driver

 @keyword
 def Test_Teardown(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.set_selenium_implicit_wait(30)
        #self._cache.current = self.dict['BROWSER']
        #self.browser = self.driver
        #self.close_browser()
        self.close_all_browsers()

 @keyword
 def unselecting_the_frame(self):
        self._drivers.current = self.dict['BROWSER']
        self.browser = self.driver
        self.unselect_frame()
        self.dict['BROWSER'] = self.driver
        
