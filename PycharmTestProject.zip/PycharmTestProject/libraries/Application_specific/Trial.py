from SeleniumLibrary import SeleniumLibrary
from SeleniumLibrary.base import keyword

class Trial(SeleniumLibrary):
    @keyword
    def trial_test(self):
        print("test trial")

class TrialOne(SeleniumLibrary):
    @keyword
    def trial_testone(self):
        print("test trial one")
class TrialTwo(SeleniumLibrary):
    @keyword
    def trial_testtwo(self):
        print("test trial two")
    def trialone(self):
        self._b
