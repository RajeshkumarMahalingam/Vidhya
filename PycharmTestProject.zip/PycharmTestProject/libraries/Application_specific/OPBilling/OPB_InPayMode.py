from robot.libraries.BuiltIn import BuiltIn
import common_reader
from common_reader import Capturing
import time
import pyautogui


class OPB_InPayMode:
    dict = common_reader.Capturing.dict
    objects = common_reader.Capturing.objects

    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')

    def screenshotonfailure(self):
        self.selib.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        

    def selecting_paymode_link(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.wait_until_element_is_enabled(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.selib.click_link('xpath=//a[@id="paymentDetailLink"]')
        # self.click_element(self.objects['OPB_Paymode'])
        # time.sleep(3)
        

    def selecting_paymode_frame(self):
        self.selib.set_selenium_implicit_wait(5)
        # self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.selib.select_frame(self.objects['OPB_Paymode_Frame'])
        time.sleep(3)
        self.selib.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 10, 'Payment type page is not loaded')

    def selecting_paymenttype_save_button(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 10, 'cash details save was not visible')
        self.selib.click_button(self.objects['OPB_CashDetails_Save'])
        # time.sleep(2)
        #MSG1 = self.selib._handle_alert()
        #print (MSG1)
        #MSG1 = self.selib.get_alert_message()
        #print (MSG1)
        self.selib.handle_alert()

    def unselecting_the_frame(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.unselect_frame()
