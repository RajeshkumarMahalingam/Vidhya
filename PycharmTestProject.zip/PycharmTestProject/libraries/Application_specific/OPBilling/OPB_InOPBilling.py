from robot.libraries.BuiltIn import BuiltIn
import common_reader
from common_reader import Capturing
import time
import pyautogui
from random import randint

class OPB_InOPBilling:
    dict = common_reader.Capturing.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')
        
    def screenshotonfailure(self):
        self.selib.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        
    def selecting_opbilling_frame(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.selib.select_frame(self.objects['OPB_MainFrame'])
        self.selib.select_frame(self.objects['OPB_OpBilling_Tab1'])
        

    def entering_regno_with_data(self):
        # self.dict['REGNO'] = "627796"
        # time.sleep(2)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 10, "opbilling regno. was not visible")
        self.selib.click_element(self.objects['OPB_OpBilling_RegNo'])
        # time.sleep(2)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 10, "opbilling regno. was not visible")
        self.selib.input_text(self.objects["OPB_OpBilling_RegNo"], str(self.dict['REGNO']))
        # time.sleep(1)
        

    def clicking_search_button(self):
        # time.sleep(1)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OpBilling_Search'], 10, "opbilling search was not visible")
        self.selib.click_button(self.objects['OPB_OpBilling_Search'])
        # time.sleep(1)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceName'], 30,
                                           'OP billing page is not loaded')
        

    def selecting_servicename(self):
        self.selib.wait_until_page_contains_element('xpath=//*[@id="s2id_txtServiceName"]/a', 10,
                                              "service name was not visible")
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_lab_standard_service(self, r):
        r = int(r)
        self.dict['LAB_STANDARD_SERVICE'] = self.d[r]['Lab_standard_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        else:
            # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30,
                                               'searched standard service was not visible')
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['LAB_STANDARD_SERVICE']) + '"]', 30,
                                           'searched standard service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['LAB_STANDARD_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_diet_service(self, r):
        r = int(r)
        # time.sleep(3)
        self.dict['DIET_SERVICE'] = self.d[r]['diet_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        else:
            # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 15,
                                               'searched diet service was not visible')
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]', 15, 'searched diet service was not visible')
        # self.selib.click_element('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]')
        self.selib.wait_until_element_is_visible(
            'xpath=//*[@id="select2-drop"]//div[text()="' + str(self.dict['DIET_SERVICE']) + '"]', 15,
            'searched diet service was not visible')
        self.selib.click_element('xpath=//*[@id="select2-drop"]//div[text()="' + str(self.dict['DIET_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 15, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_lab_culture_service(self, r):
        r = int(r)
        # time.sleep(3)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        else:
            # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30,
                                               'searched culture service was not visible')
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['LAB_CULTURE_SERVICE']) + '"]', 30,
                                           'searched culture service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['LAB_CULTURE_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_lab_pathology_service(self, r):
        r = int(r)
        # time.sleep(3)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        else:
            # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30,
                                               'searched pathology service was not visible')
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['LAB_PATHOLOGY_SERVICE']) + '"]', 30,
                                           'searched pathology service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['LAB_PATHOLOGY_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_radiology_service(self, r):
        r = int(r)
        # time.sleep(3)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        else:
            # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30,
                                               'searched radiology service was not visible')
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['RADIOLOGY_SERVICE']) + '"]', 30,
                                           'searched radiology service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['RADIOLOGY_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_cardiology_service(self, r):
        r = int(r)
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        telement = self.selib.find_element('xpath=//*[@id="select2-drop"]//input')
        if telement is not None:
            if (telement.is_displayed()) == True:
                self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
            else:
                # self.selib.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
                self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
                time.sleep(1)
                self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30,
                                               'searched pathology service was not visible')
                self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['CARDIOLOGY_SERVICE']) + '"]', 30,
                                           'searched pathology service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['CARDIOLOGY_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        

    def adding_lab_peripheral_service(self, r):
        r = int(r)
        self.dict['LAB_PERIPHERAL_SERVICE'] = self.d[r]['Lab_peripheral_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        else:
            self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['LAB_PERIPHERAL_SERVICE']) + '"]',
                                               30, 'searched peripheral service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['LAB_PERIPHERAL_SERVICE']) + '"]', 30,
                                           'searched peripheral service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['LAB_PERIPHERAL_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        

    def adding_physio_service(self, r):
        r = int(r)
        self.dict['PHYSIO_SERVICE'] = self.d[r]['physio_service']
        if self.selib.is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        else:
            self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['PHYSIO_SERVICE']) + '"]', 30,
                                               'searched peripheral service was not visible')
            self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.selib.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        self.selib.wait_until_element_is_visible('xpath=//*[text()="' + str(self.dict['PHYSIO_SERVICE']) + '"]', 30,
                                           'searched peripheral service was not visible')
        self.selib.click_element('xpath=//*[text()="' + str(self.dict['PHYSIO_SERVICE']) + '"]')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.selib.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        

    def pressing_tabkey(self):
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30,
                                           'opbilling  service search was not visible')
        self.selib.press_key('xpath=//*[@id="s2id_autogen16_search"]', '\\09')
        # time.sleep(2)
        

    def entering_remarks(self, r):
        r = int(r)
        # time.sleep(3)
        self.selib.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 30, 'remarks was not visible')
        self.selib.input_text('xpath=//*[@id="txtRemarks"]', 'test')
        # time.sleep(1)
        

    def selecting_outstandingtab(self):
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding'], 10, "os tab was not visible")
        self.selib.click_element(self.objects['OPB_OPBilling_Outstanding'])
        

    def selecting_ossource(self):
        time.sleep(2)
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_cboOSSource"]/a', 10, "os source was not visible")
        self.selib.click_element('xpath=//*[@id="s2id_cboOSSource"]/a')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10,
                                           "os source name list was not visible")
        self.selib.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        # self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        # self.selib.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        

    def selecting_ossourcename(self):
        time.sleep(1)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_SourceName'], 10,
                                           "os source name was not visible")
        self.selib.click_element(self.objects['OPB_OPBilling_Outstanding_SourceName'])
        self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10,
                                           "os source name list was not visible")
        self.selib.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        

    def entering_osamount(self, r):
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Amount'], 10,
                                           "os amount was not visible")
        self.selib.clear_element_text(self.objects['OPB_OPBilling_Outstanding_Amount'])
        self.selib.input_text(self.objects['OPB_OPBilling_Outstanding_Amount'], str(self.d[r]['osamount']))
        

    def entering_osremarks(self, r):
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_remarks'], 10,
                                           "os remarks was not visible")
        self.selib.clear_element_text(self.objects['OPB_OPBilling_Outstanding_remarks'])
        self.selib.input_text(self.objects['OPB_OPBilling_Outstanding_remarks'], self.d[r]['osremarks'])
        

    def selecting_outstandingaddbtn(self):
        self.selib.wait_until_element_is_visible('xpath=//*[@id="divaddOSbApplybtn"]/a', 10, "os add btn was not visible")
        self.selib.click_element('xpath=//*[@id="divaddOSbApplybtn"]/a')
        # self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Add'], 10, "os add btn was not visible")
        # self.selib.click_button(self.objects['OPB_OPBilling_Outstanding_Add'])
        

    def selecting_concessiontab(self):
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession'], 10,
                                           "cs tab was not visible")
        self.selib.click_element(self.objects['OPB_OPBilling_Services_Concession'])
        

    def selecting_cssourcename(self):
        time.sleep(2)
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcSourceName"]/a', 10, "cs source was not visible")
        self.selib.click_element('xpath=//*[@id="s2id_cboConcSourceName"]/a')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10,
                                           "cs source name list was not visible")
        self.selib.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        # self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        # self.selib.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        

    def selecting_authorization(self):
        time.sleep(1)
        self.selib.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcAuthorization"]/a', 10,
                                           "cs authorization was not visible")
        self.selib.click_element('xpath=//*[@id="s2id_cboConcAuthorization"]/a')
        self.selib.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10,
                                           "cs authorization was not visible")
        self.selib.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        

    def entering_csamount(self, r):
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Amount'], 10,
                                           "os amount was not visible")
        self.selib.input_text(self.objects['OPB_OPBilling_Services_Concession_Amount'], str(self.d[r]['csamount']))
        

    def selecting_cstype(self, r):
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Type'], 10,
                                           "cs type was not visible")
        self.selib.select_from_list_by_label(self.objects['OPB_OPBilling_Services_Concession_Type'], self.d[r]['cstype'])
        

    def entering_csremarks(self, r):
        r = int(r)
        self.selib.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_remarks'], 10,
                                           "cs remarks was not visible")
        self.selib.clear_element_text(self.objects['OPB_OPBilling_Services_Concession_remarks'])
        self.selib.input_text(self.objects['OPB_OPBilling_Services_Concession_remarks'], self.d[r]['csremarks'])
        

    def selecting_concessionapplybtn(self):
        self.selib.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Concession_Apply'], 10,
                                           "cs apply btn was not visible")
        self.selib.click_button(self.objects['OPB_OPBilling_Services_Concession_Apply'])
        

    def selecting_paymode_link(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        # self.selib.click_link(self.objects['OPB_Paymode'])
        self.selib.click_button(self.objects['OPB_Paymode'])
        # time.sleep(3)
        

    def selecting_paymode_frame(self):
        self.selib.set_selenium_implicit_wait(5)
        # self.selib.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.selib.select_frame(self.objects['OPB_Paymode_Frame'])
        time.sleep(3)
        self.selib.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        

    def selecting_paymenttype_save_button(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.selib.click_button(self.objects['OPB_CashDetails_Save'])
        # time.sleep(2)
        MSG1 = self.selib.get_alert_message()
        print (MSG1)
        

    def selecting_opbilling_save_button(self):
        # time.sleep(2)
        self.selib.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Save'], 30,
                                           'op billing service save was not visible')
        self.selib.click_element(self.objects['OPB_OPBilling_Services_Save'])
        time.sleep(7)
        

    def selecting_doctor(self):
        self.selib.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 3, 'doctor list is not visible')
        self.selib.select_from_list_by_index('xpath=//*[@id="cboDoctor"]', '2')
        

    def unselecting_the_frame(self):
        self.selib.set_selenium_implicit_wait(5)
        self.selib.unselect_frame()
        