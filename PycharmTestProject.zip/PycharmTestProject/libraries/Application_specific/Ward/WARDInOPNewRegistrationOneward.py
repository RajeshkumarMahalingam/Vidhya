from robot.libraries.BuiltIn import BuiltIn
import common_reader
from common_reader import Capturing

class WARDInOPNewRegistrationOneward:
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_OPNewReg")

    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')

    def driving_browser_and_url(self, url, browser):
        self.selib.create_webdriver(browser)
        self.selib.go_to(url)
        self.selib.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', timeout=30, error="Link not visible: #divNewSession")
        self.selib.maximize_browser_window()
        self.selib.click_element('xpath=//a[@href="#divNewSession"]')
        self.selib.set_selenium_implicit_wait("30 seconds")

    def logging	(self, r):
        r = int(r)
        self.selib.input_text("id=newuname", self.d[r]['username'])
        self.selib.input_password("id=txtrepassword", self.d[r]['password'])
        self.selib.wait_until_element_is_visible("id=btnrelogin")
        self.selib.click_button("id=btnrelogin")
