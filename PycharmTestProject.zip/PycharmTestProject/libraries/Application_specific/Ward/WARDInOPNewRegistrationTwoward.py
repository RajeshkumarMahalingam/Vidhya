from robot.libraries.BuiltIn import BuiltIn
class WARDInOPNewRegistrationTwoward:
    def __init__(self):
        self.selib = BuiltIn().get_library_instance('SeleniumLibrary')

    def driving_browser_and_url(self, url, browser):
        self.selib.create_webdriver(browser)
        self.selib.go_to(url)
        self.selib.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', timeout=30, error="Link not visible: #divNewSession")
        self.selib.maximize_browser_window()
        self.selib.click_element('xpath=//a[@href="#divNewSession"]')
        self.selib.set_selenium_implicit_wait("30 seconds")

    def logging	(self, username, password):
        self.selib.input_text("id=newuname", username)
        self.selib.input_password("id=txtrepassword", password)
        self.selib.wait_until_element_is_visible("id=btnrelogin")
        self.selib.click_button("id=btnrelogin")