 
USe kmch_frontoffice
GO
IF EXISTS(select * from kmch_frontoffice.sys.objects where type='U' and name='mast_Patient')
BEGIN
Delete From kmch_frontoffice..mast_Patient
End
GO
IF EXISTS(select * from kmch_frontoffice.sys.objects where type='U' and name='Mast_op_admission')
BEGIN
Delete From kmch_frontoffice..Mast_op_admission
End
GO
IF EXISTS(select * from kmch_frontoffice.sys.objects where type='U' and name='Mast_OP_Admission_MHC_Speciality_Dept')
BEGIN
Delete From kmch_frontoffice..Mast_OP_Admission_MHC_Speciality_Dept
End
GO
IF EXISTS(select * from kmch_frontoffice.sys.objects where type='U' and name='Mast_Pat_Remarks')
BEGIN
Delete From kmch_frontoffice..Mast_Pat_Remarks
End
GO
IF EXISTS(select * from kmch_frontoffice.sys.objects where type='U' and name='Mast_Pat_Addr')
BEGIN
Delete From kmch_frontoffice..Mast_Pat_Addr
End

 