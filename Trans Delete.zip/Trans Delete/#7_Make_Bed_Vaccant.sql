USe kmch_frontoffice
Go
-- Make Occupied bed as vaccant

Update mast_bedmaster set boccstatus = 1
Update Mast_BedMaster set bBedStatus = 1