 

Use ASTIL_Asset 
Go
-- Tables Of Predefined Values , Masters and Settings
/*
Asset_Period
Mast_PendingAt
Asset_Grp_Rights
Mast_Water_Type
Mast_Asset_Grp
Mast_Compliance_Type
Asset_Zone
Mast_Units
Mast_Asset_Def
Asset_UserDept_Rights
Asset_IT_Info
Mast_Servicer
Mast_Asset_Sub_Def
Mast_Maintenance
Mast_Asset_Attach
Mast_Equipment
Asset_Category
AMS_Ctrl_Panel
Mast_Asset_Sub_Dtl
Mast_Water_Info
Mast_Compl_Certificate 
Mast_Placed_Loc 
*/
GO
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Maintenance')
BEGIN
Delete From Maintaince_Schedule
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='AstServ_Update')
BEGIN
Delete From AstServ_Update
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='PTS_Cons_Dtl')
BEGIN
Delete From PTS_Cons_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_CheckList_Dtl')
BEGIN
Delete From Asset_CheckList_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_CheckList')
BEGIN
Delete From Asset_CheckList
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Energy_Cons_Dtl')
BEGIN
Delete From Energy_Cons_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Energy_Type')
BEGIN
Delete From Mast_Energy_Type
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Condm_Dtl')
BEGIN
Delete From Asset_Condm_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Equip_Dtl')
BEGIN
Delete From Mast_Equip_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_PM_Schd_Dtl')
BEGIN
Delete From Asset_PM_Schd_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='AMS_Ctrl_GrpRunNo')
BEGIN
Delete From AMS_Ctrl_GrpRunNo
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Cont_Entry')
BEGIN
Delete From Mast_Cont_Entry
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Prev_Maintenace')
BEGIN
Delete From Prev_Maintenace
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Update_Log')
BEGIN
Delete From Asset_Update_Log
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='sysdiagrams')
BEGIN
Delete From sysdiagrams
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='tAMC_Preven')
BEGIN
Delete From tAMC_Preven
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_PayCheque_Dtl')
BEGIN
Delete From Asset_PayCheque_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Insurer')
BEGIN
Delete From Mast_Insurer
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='tMain_Schdle')
BEGIN
Delete From tMain_Schdle
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Water_Cons_Dtl')
BEGIN
Delete From Water_Cons_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Water_Cons_Hdr')
BEGIN
Delete From Water_Cons_Hdr
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Certif_Attach')
BEGIN
Delete From Mast_Certif_Attach
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Compl_Certif_Renewal_Dtl')
BEGIN
Delete From Compl_Certif_Renewal_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Repair_Dtl')
BEGIN
Delete From Asset_Repair_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Electric_Cons_Dtl')
BEGIN
Delete From Electric_Cons_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Condm_Req')
BEGIN
Delete From Asset_Condm_Req
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_GP_Dtl')
BEGIN
Delete From Asset_GP_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Example')
BEGIN
Delete From Example
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_AMC')
BEGIN
Delete From Asset_AMC
End 
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete From dtproperties
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Payment')
BEGIN
Delete From Asset_Payment
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Service_Dtl')
BEGIN
Delete From Asset_Service_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Cond_Resale_Dtl')
BEGIN
Delete From Cond_Resale_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Failure_InCharges')
BEGIN
Delete From Asset_Failure_InCharges
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Mast_Equipment_Grp')
BEGIN
Delete From Mast_Equipment_Grp
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Usage_Dtl')
BEGIN
Delete From Asset_Usage_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Failure_Req')
BEGIN
Delete From Asset_Failure_Req
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Failure_Dtl')
BEGIN
Delete From Asset_Failure_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Payment_Dtl')
BEGIN
Delete From Asset_Payment_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Prev_Maintenace_Dtl')
BEGIN
Delete From Prev_Maintenace_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Transfer')
BEGIN
Delete From Asset_Transfer
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Transfer_Dtl')
BEGIN
Delete From Asset_Transfer_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Insur_Claim')
BEGIN
Delete From Asset_Insur_Claim
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Maintenance_CallEntry')
BEGIN
Delete From Maintenance_CallEntry
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Temp_TriggerCnt')
BEGIN
Delete From Temp_TriggerCnt
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Maintenance_Schedule')
BEGIN
Delete From Maintenance_Schedule
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Temp_Trigger')
BEGIN
Delete From Temp_Trigger
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Energy_Cons')
BEGIN
Delete From Energy_Cons
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Boiler_Cons_Dtl')
BEGIN
Delete From Boiler_Cons_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='BIO_Control_Panel')
BEGIN
Delete From BIO_Control_Panel
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='Asset_Serv_Spare_Dtl')
BEGIN
Delete From Asset_Serv_Spare_Dtl
End
Go
IF EXISTS(select * from ASTIL_Asset.sys.objects where type='U' and name='BioMedical_ServiceCall')
BEGIN
Delete From BioMedical_ServiceCall
End

Go

USe ASTIL_BBJTS

Go
-- Tables Of Predefined Values , Masters and Settings
/*
Mast_Developer
Developer_Modules
Mast_BBModule
mast_Ctrl_Panel  
 Mast_SubCategory 
 Mast_Issue_Users
 Mast_Category
*/
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Mast_Module')
BEGIN
Delete from Mast_Module
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Issue_Attach')
BEGIN
Delete from Issue_Attach
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Temp_Trigger')
BEGIN
Delete from Temp_Trigger
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Temp_TriggerCnt')
BEGIN
Delete from Temp_TriggerCnt
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Mast_Client')
BEGIN
Delete from Mast_Client
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='UseCase_Dtl')
BEGIN
Delete from UseCase_Dtl
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='UseCase_Sub_Dtl')
BEGIN
Delete from UseCase_Sub_Dtl
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Functly_Doc_Dtl')
BEGIN
Delete from Functly_Doc_Dtl
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='BBModule_BugTrack')
BEGIN
Delete from BBModule_BugTrack
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Client_BBStatus_Detail')
BEGIN
Delete from Client_BBStatus_Detail
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Issue_Details')
BEGIN
Delete from Issue_Details
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Mast_Client_Modules')
BEGIN
Delete from Mast_Client_Modules
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Issue_Appr_Log')
BEGIN
Delete from Issue_Appr_Log 
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='BugTrack_Comments')
BEGIN
Delete from BugTrack_Comments 
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='iAssignTo_ReOpen_Log')
BEGIN
Delete from iAssignTo_ReOpen_Log 
End
Go
IF EXISTS(select * from ASTIL_BBJTS.sys.objects where type='U' and name='Issue_AssignTo_Dtl')
BEGIN
Delete from Issue_AssignTo_Dtl 
End
Go

Use ASTIL_Canteen
Go
-- Tables Of Predefined Values , Masters and Settings
/*
Dir_Cant_Bill_Report
Ctrl_Panel_Canteen
UOM
Item_Prices
Cant_Select_Dept
Mast_Items
Mast_Supplier
Mast_Item_Group
Mast_Company_info
Mast_Stores
CNT_Settings
Stock_Control_Reg_Report
Dept_Func_Bill_Report
Bill_Con_Dtl
*/
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CanteenStockAdjust_Log')
BEGIN
Delete from CanteenStockAdjust_Log
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Refund_Dtl')
BEGIN
Delete from Bill_Refund_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Printing')
BEGIN
Delete from Bill_Printing
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Cancel')
BEGIN
Delete from Bill_Cancel
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Current_Menus')
BEGIN
Delete from CNT_Current_Menus
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_ItemWastage')
BEGIN
Delete from CNT_ItemWastage
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='QuickBilling_Items')
BEGIN
Delete from QuickBilling_Items
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='PO_Dtl')
BEGIN
Delete from PO_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Dtl')
BEGIN
Delete from Bill_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='itemsed')
BEGIN
Delete from itemsed
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_DeptIssue_Limit')
BEGIN
Delete from CNT_DeptIssue_Limit
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_PaymentType')
BEGIN
Delete from Mast_PaymentType
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_PaymentSource')
BEGIN
Delete from Mast_PaymentSource
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='FLDSLIST')
BEGIN
Delete from FLDSLIST
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='GRN_Hdr')
BEGIN
Delete from GRN_Hdr
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Rept_Refund')
BEGIN
Delete from Bill_Rept_Refund
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_CreditLimit')
BEGIN
Delete from CNT_CreditLimit
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Canteen_Bill_Report')
BEGIN
Delete from Canteen_Bill_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='TABSLIST')
BEGIN
Delete from TABSLIST
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Employee_Report')
BEGIN
Delete from Employee_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_TB_AccHead')
BEGIN
Delete from Mast_TB_AccHead
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='ctrl_Item_Posting')
BEGIN
Delete from ctrl_Item_Posting
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='EmpBill_AutoPosting')
BEGIN
Delete from EmpBill_AutoPosting
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Purchase_Rtn')
BEGIN
Delete from CNT_Purchase_Rtn
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Canteen_Com')
BEGIN
Delete from Canteen_Com
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Cash')
BEGIN
Delete from Bill_Cash
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Purchase_Rtn_Dtl')
BEGIN
Delete from CNT_Purchase_Rtn_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_Supplier_Item')
BEGIN
Delete from Mast_Supplier_Item
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Stk_Request')
BEGIN
Delete from Stk_Request
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='GRN_Dtl')
BEGIN
Delete from GRN_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Billing_Dtl')
BEGIN
Delete from Item_Billing_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Batch_Adjustment')
BEGIN
Delete from Batch_Adjustment
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='stemp')
BEGIN
Delete from stemp
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Billing')
BEGIN
Delete from Item_Billing
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Outstanding')
BEGIN
Delete from Bill_Outstanding
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Header')
BEGIN
Delete from Bill_Header
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_Room_Tables')
BEGIN
Delete from Mast_Room_Tables
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_DayBook')
BEGIN
Delete from Mast_DayBook
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Item_Reservation')
BEGIN
Delete from CNT_Item_Reservation
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CanteenStock_Log')
BEGIN
Delete from CanteenStock_Log
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Running_Numbers')
BEGIN
Delete from Running_Numbers
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Outstanding_Tot')
BEGIN
Delete from Bill_Outstanding_Tot
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNTDaily_Production')
BEGIN
Delete from CNTDaily_Production
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Users_Stores')
BEGIN
Delete from CNT_Users_Stores
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CantStkLog_Report')
BEGIN
Delete from CantStkLog_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Stock')
BEGIN
Delete from Item_Stock
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='TB_Report')
BEGIN
Delete from TB_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Menu_Group')
BEGIN
Delete from Item_Menu_Group
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_Workers')
BEGIN
Delete from Mast_Workers
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='WorkerTypes')
BEGIN
Delete from WorkerTypes
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Production')
BEGIN
Delete from Item_Production
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_Pat_Misc_Req')
BEGIN
Delete from Mast_Pat_Misc_Req
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='EmpSelectFor_Free')
BEGIN
Delete from EmpSelectFor_Free
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Direct_Bill_Dtl')
BEGIN
Delete from Direct_Bill_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='PO_Hdr')
BEGIN
Delete from PO_Hdr
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNTItemTrans_Report')
BEGIN
Delete from CNTItemTrans_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Rept_Dtl')
BEGIN
Delete from Bill_Rept_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_PaymentMode')
BEGIN
Delete from Mast_PaymentMode
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Tax')
BEGIN
Delete from Item_Tax
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='CNT_Stores_Collection')
BEGIN
Delete from CNT_Stores_Collection
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Doctor_Payment_Email_Send')
BEGIN
Delete from Doctor_Payment_Email_Send
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Rtn_DebitNote')
BEGIN
Delete from Rtn_DebitNote
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Stk_Transfer_Note')
BEGIN
Delete from Stk_Transfer_Note
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Dept_Billing')
BEGIN
Delete from Dept_Billing
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Cancel_Dtl')
BEGIN
Delete from Bill_Cancel_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='StockAdjust_Log')
BEGIN
Delete from StockAdjust_Log
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Stk_Request_Dtl')
BEGIN
Delete from Stk_Request_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Menu_Times')
BEGIN
Delete from Menu_Times
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Stk_Transfer_Note_Dtl')
BEGIN
Delete from Stk_Transfer_Note_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Rept')
BEGIN
Delete from Bill_Rept
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Rtn_DebitNote_Dtl')
BEGIN
Delete from Rtn_DebitNote_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Emp_OSExport_Dtl')
BEGIN
Delete from Emp_OSExport_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Advance_Payment')
BEGIN
Delete from Advance_Payment
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Dept_Billing_Dtl')
BEGIN
Delete from Dept_Billing_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Production_Hdr')
BEGIN
Delete from Item_Production_Hdr
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Batch')
BEGIN
Delete from Item_Batch
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_daybook_cant')
BEGIN
Delete from Mast_daybook_cant
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Cummulative_Report')
BEGIN
Delete from Cummulative_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Mast_DayBook_chk')
BEGIN
Delete from Mast_DayBook_chk
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_OSPaid')
BEGIN
Delete from Bill_OSPaid
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Table_Serv_Bill_Report')
BEGIN
Delete from Table_Serv_Bill_Report
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_OutstandingDues')
BEGIN
Delete from Bill_OutstandingDues
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Direct_Billing')
BEGIN
Delete from Direct_Billing
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Stock_Ctrl_Register')
BEGIN
Delete from Stock_Ctrl_Register
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Payment_Terms')
BEGIN
Delete from Payment_Terms
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Voucher_Number')
BEGIN
Delete from Voucher_Number
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Item_Ordered')
BEGIN
Delete from Item_Ordered
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Concession')
BEGIN
Delete from Bill_Concession
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Concession_Adjust')
BEGIN
Delete from Bill_Concession_Adjust
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Astil_Canteen..Bill_Con_Dtl')
BEGIN
Delete from Astil_Canteen..Bill_Con_Dtl
End
Go
IF EXISTS(select * from ASTIL_Canteen.sys.objects where type='U' and name='Bill_Con_Dtl')
BEGIN
Delete From Bill_Con_Dtl
End
Go
Use ASTIL_Physiotherapy
Go
-- Tables Of Predefined Values , Masters and Settings
/*
PHYSIO_REPORT_CONTROL_PANEL
Mast_PhysioType
Control_Panel
*/
IF EXISTS(select * from ASTIL_Physiotherapy.sys.objects where type='U' and name='Physio_Order')
BEGIN
Delete from Physio_Order
End
Go
IF EXISTS(select * from ASTIL_Physiotherapy.sys.objects where type='U' and name='Physio_Order_Dtl')
BEGIN
Delete from Physio_Order_Dtl
End
Go
IF EXISTS(select * from ASTIL_Physiotherapy.sys.objects where type='U' and name='Physio_Order_Cancel')
BEGIN
Delete from Physio_Order_Cancel
End
Go
IF EXISTS(select * from ASTIL_Physiotherapy.sys.objects where type='U' and name='Physio_Request_AutoPost')
BEGIN
Delete from Physio_Request_AutoPost
End

Go

Use KMCH_Billing
Go
-- Tables Of Predefined Values , Masters and Settings
/*
Billing_Ledger_Total
Mast_TB_AccHead
Billing_Ascertain
Mast_Header
Mast_Transaction
Voucher_Number
Mast_Corp_Service_Template_Dtl
Voucher_Bill_Report
IP_PartToFinal_convert
Mast_Service_Rate
Mast_Service
Mast_Service_Pricing_Log
Mast_Corp_Service_Template
Mast_TB_Group
Mast_Header_Group
Mast_ConcessionSource
Ctrl_Panel_Canteen
Mast_BillType
Mast_Denomination
Mast_Concession_Header
IP_Part_Credit_Revert
Mast_Concession_Header_log
WeekDays
Mast_Corp_Service
Mast_PaymentMode
Mast_CardType
IP_Mast_Pack_Dtl
IP_Mast_Package_Dtl_Template
Mast_Pack_Dtl
Mast_Service_Type
Mast_Package
Mast_PaymentSource
Report_user_Access
Mast_Pricelist_Definition
Mast_Card_Rate
IP_Mast_Pack_Rate
IP_Mast_Package_Template
Bill_Surcharge
Mast_Income_Type
Mast_Service_Rate_Req
Mast_Card_Machine
Ctrl_Panel_Reports
Ctrl_RoundOff
IP_Mast_Package
Mast_PriceList
Mast_Doc_Deduction
MAST_CURRENCY_LOG
Mast_Fund_Donor_Ngo
Bill_Template_Master
Bill_Template_Dtl
Mast_OS_SourceName
User_Service_Rights
Mast_Doctor_Visit_Charge
User_Service_Rights_log
MAST_CURRENCY
Mast_Currency_Symbol
Mast_PriceList_Matrix
Mast_Conc_SourceName
Deposit_Refund_reports
Fund_Reports
TB_Reports
TDS_Reports
Denormalize_Reports
Concession_NewReports
IP_Mast_Pack_Template
 Months
Mast_PriceList_Group -> Not Necessary master but referred to price list master hence not deleted
Ctrl_Printing

mast_Doctor_Finance 
Mast_Doc_Header_Def -> Incentive Doc Masters - Doctor pay Def
Mast_Equipment_Service
Select * From Mast_Caution_Deposit_Expense - M
Select * From Mast_Advance_Type - M
Select * From Mast_Pack_Speciality_Doc_Dtl - M
Mast_TPA
Mast_Corp_Insurance_Map


*/
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Package_Bill_Header')
BEGIN
Delete From IP_Package_Bill_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='AsOnDate_Advance')
BEGIN
Delete From AsOnDate_Advance
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OS_Bill_Rept')
BEGIN
Delete From OS_Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_sample')
BEGIN
Delete From Mast_sample
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Tax')
BEGIN
Delete From Bill_Tax
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Pat_BillableBed')
BEGIN
Delete From IP_Pat_BillableBed
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Proposition_Value_LOG')
BEGIN
Delete From Proposition_Value_LOG
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Share_PreRequest')
BEGIN
Delete From Mast_Share_PreRequest
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Internal_Details')
BEGIN
Delete From Bill_Internal_Details
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Header')
BEGIN
Delete From IP_Part_Bill_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_PharmaSrcUpdate')
BEGIN
Delete From Bill_OS_PharmaSrcUpdate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Proportion')
BEGIN
Delete From Proportion
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Package_Bill_Dtl')
BEGIN
Delete From IP_Package_Bill_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_PrintType')
BEGIN
Delete From Bill_PrintType
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Outstanding_Payment')
BEGIN
Delete From IP_Bill_Outstanding_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Authorisation')
BEGIN
Delete From Mast_Authorisation
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doctor_Group')
BEGIN
Delete From Mast_Doctor_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Billing_Transaction')
BEGIN
Delete From Billing_Transaction
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Package_Bill_Hdr_Dtl')
BEGIN
Delete From IP_Package_Bill_Hdr_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_BillFlag')
BEGIN
Delete From Mast_BillFlag
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Collection_Hdr_Serv')
BEGIN
Delete From Doctor_Collection_Hdr_Serv
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Deposit_Reports')
BEGIN
Delete From OP_Deposit_Reports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Proportion')
BEGIN
Delete From Mast_Proportion
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Period')
BEGIN
Delete From Mast_Period
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payment_Email_Send')
BEGIN
Delete From Doctor_Payment_Email_Send
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payment')
BEGIN
Delete From Doctor_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_RTGS')
BEGIN
Delete From Bill_RTGS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Usage_Ngo')
BEGIN
Delete From Fund_Usage_Ngo
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Reports')
BEGIN
Delete From IP_Bill_Reports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Deposit_Refund_Req')
BEGIN
Delete From Deposit_Refund_Req
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Deposit_Transfer')
BEGIN
Delete From IP_Bill_Deposit_Transfer
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_User_Settlement')
BEGIN
Delete From Bill_User_Settlement
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Voucher_Payment_Image')
BEGIN
Delete From Voucher_Payment_Image
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Pharmacy_Debtors')
BEGIN
Delete From OP_Pharmacy_Debtors
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Estimate_Dtl')
BEGIN
Delete From Bill_Estimate_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Dtl')
BEGIN
Delete From IP_Part_Bill_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Preauth_Faxlog')
BEGIN
Delete From IP_Preauth_Faxlog
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Cons_Report')
BEGIN
Delete From IP_Cons_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OutStanding_Adjust')
BEGIN
Delete From Bill_OutStanding_Adjust
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Tax')
BEGIN
Delete From Mast_Tax
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Proportion_Dtl')
BEGIN
Delete From Proportion_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Doc_Fee')
BEGIN
Delete From Bill_Doc_Fee
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Corporate_Headerlist')
BEGIN
Delete From Corporate_Headerlist
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Con_Dtl')
BEGIN
Delete From IP_Part_Bill_Con_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='temp')
BEGIN
Delete From temp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Debtors_Deposit')
BEGIN
Delete From OP_Debtors_Deposit
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Preauth_Request')
BEGIN
Delete From IP_Preauth_Request
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Card_Holder')
BEGIN
Delete From Bill_Card_Holder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Cheque')
BEGIN
Delete From Bill_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_PatPackage_Dtl')
BEGIN
Delete From IP_PatPackage_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Periods')
BEGIN
Delete From Periods
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Discount_Cancel')
BEGIN
Delete From Bill_Discount_Cancel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Voucher_Payment')
BEGIN
Delete From Voucher_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Coll_Statement')
BEGIN
Delete From IP_Coll_Statement
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Rept')
BEGIN
Delete From Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Labour_Room_Job_Dtl')
BEGIN
Delete From Labour_Room_Job_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Coll_Group')
BEGIN
Delete From Mast_Coll_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Deduction_Dtl')
BEGIN
Delete From Doc_Deduction_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Con_Doc_Dtl_log')
BEGIN
Delete From IP_Bill_Con_Doc_Dtl_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Pat_Review')
BEGIN
Delete From Mast_Pat_Review
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_CGHS_Link')
BEGIN
Delete From Mast_Service_CGHS_Link
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Prv_Year_Collection')
BEGIN
Delete From Prv_Year_Collection
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Outstanding_Daywise')
BEGIN
Delete From IP_Bill_Outstanding_Daywise
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Revenue_Analysis')
BEGIN
Delete From Revenue_Analysis
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Procedures')
BEGIN
Delete From Mast_Doc_Procedures
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='A00061_Mast_Emp_Concession')
BEGIN
Delete From A00061_Mast_Emp_Concession
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OS_Followup')
BEGIN
Delete From IP_Bill_OS_Followup
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_MastReports')
BEGIN
Delete From IP_Bill_MastReports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Perform_Doctor')
BEGIN
Delete From Bill_Perform_Doctor
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='TB_Report')
BEGIN
Delete From TB_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Credit_Note_Dtl')
BEGIN
Delete From Credit_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Other_Center_Share_Holder_Conc')
BEGIN
Delete From Other_Center_Share_Holder_Conc
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Collection_Change_Entry')
BEGIN
Delete From Doctor_Collection_Change_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='deptcollection')
BEGIN
Delete From deptcollection
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Mast_Pack_Dtl_log')
BEGIN
Delete From IP_Mast_Pack_Dtl_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Con_Dtl_log')
BEGIN
Delete From IP_Bill_Con_Dtl_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Proposition_Value')
BEGIN
Delete From Proposition_Value
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Labour_Room_Job_Entry')
BEGIN
Delete From Labour_Room_Job_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete From dtproperties
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_cash_dtl')
BEGIN
Delete From Bill_cash_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Con_Doc_Dtl')
BEGIN
Delete From Bill_Con_Doc_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Concession_Adjust')
BEGIN
Delete From IP_Bill_Concession_Adjust
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Concession_Req')
BEGIN
Delete From IP_Bill_Concession_Req
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Service_Approval')
BEGIN
Delete From Bill_Service_Approval
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Entry')
BEGIN
Delete From Patient_Corporate_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='MastCorpEntry_Report')
BEGIN
Delete From MastCorpEntry_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_DemandDraft')
BEGIN
Delete From IP_Bill_DemandDraft
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Followup_Dtl')
BEGIN
Delete From Bill_OS_Followup_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Concession_Adjust')
BEGIN
Delete From Bill_Concession_Adjust
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_PreAuth_Dtl')
BEGIN
Delete From IP_TPA_PreAuth_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Cheque')
BEGIN
Delete From Fund_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Concession_Cancel')
BEGIN
Delete From IP_Bill_Concession_Cancel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Deposit_Refund')
BEGIN
Delete From IP_Deposit_Refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_CGHS')
BEGIN
Delete From Mast_Service_CGHS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Access_Rights')
BEGIN
Delete From Mast_Access_Rights
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OS_Dispatch_Dtl')
BEGIN
Delete From IP_Bill_OS_Dispatch_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Return_Cheque')
BEGIN
Delete From Fund_Return_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Header_New')
BEGIN
Delete From Mast_Header_New
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Letter_dtl')
BEGIN
Delete From Fund_Letter_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Ledger_Group')
BEGIN
Delete From Mast_Ledger_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Preauth_Updated_Log')
BEGIN
Delete From IP_Preauth_Updated_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_PreAuth')
BEGIN
Delete From IP_TPA_PreAuth
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Fund_Type')
BEGIN
Delete From Mast_Fund_Type
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Correction_log')
BEGIN
Delete From Bill_Correction_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Return_DD')
BEGIN
Delete From Fund_Return_DD
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_AutoPost_Log')
BEGIN
Delete From Mast_Service_AutoPost_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payment_Dtl')
BEGIN
Delete From Doctor_Payment_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='TempDocSer_Rep')
BEGIN
Delete From TempDocSer_Rep
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Share_Holder')
BEGIN
Delete From Mast_Share_Holder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Rept_Refund')
BEGIN
Delete From Bill_Rept_Refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Header_Value')
BEGIN
Delete From IP_Header_Value
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Credit')
BEGIN
Delete From Patient_Credit
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Equipment_Usage')
BEGIN
Delete From IP_Bill_Equipment_Usage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_DemandDraft')
BEGIN
Delete From Fund_DemandDraft
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Return')
BEGIN
Delete From Fund_Return
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Tax')
BEGIN
Delete From IP_Bill_Tax
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_TDS')
BEGIN
Delete From Mast_Doc_TDS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Query_Image')
BEGIN
Delete From IP_TPA_Query_Image
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='FollowUp_Template')
BEGIN
Delete From FollowUp_Template
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Voucher_Payment_Dtl')
BEGIN
Delete From Voucher_Payment_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Tax_Cancel')
BEGIN
Delete From IP_Bill_Tax_Cancel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Apply')
BEGIN
Delete From Fund_Apply
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Refer_Details')
BEGIN
Delete From Bill_Refer_Details
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Deduction_Entry')
BEGIN
Delete From Doc_Deduction_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_MailUsers')
BEGIN
Delete From Mast_MailUsers
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Deduction_Hdr')
BEGIN
Delete From Doc_Deduction_Hdr
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='CP_No_Of_Times')
BEGIN
Delete From CP_No_Of_Times
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Log')
BEGIN
Delete From Patient_Corporate_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_RestrictedService')
BEGIN
Delete From Mast_RestrictedService
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Concession_log')
BEGIN
Delete From IP_Bill_Concession_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='FixedProportion')
BEGIN
Delete From FixedProportion
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Cash_Dtl')
BEGIN
Delete From IP_Bill_Cash_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Credit_Note')
BEGIN
Delete From Credit_Note
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Corp_Bill_Report')
BEGIN
Delete From Corp_Bill_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Ordered_Doctor')
BEGIN
Delete From Bill_Ordered_Doctor
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Surcharge_Header')
BEGIN
Delete From Bill_Surcharge_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Sanction')
BEGIN
Delete From Fund_Sanction
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_Pricing_Log_CGHS')
BEGIN
Delete From Mast_Service_Pricing_Log_CGHS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Image')
BEGIN
Delete From Mast_Image
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Diet_Service_rate')
BEGIN
Delete From Mast_Diet_Service_rate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Tax_Revert')
BEGIN
Delete From IP_Bill_Tax_Revert
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Daily_Revenue')
BEGIN
Delete From Daily_Revenue
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OS_FollowUp_Reminder')
BEGIN
Delete From IP_Bill_OS_FollowUp_Reminder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_FutureRate')
BEGIN
Delete From Mast_Service_FutureRate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Incentives')
BEGIN
Delete From Doc_Incentives
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Return_Cash')
BEGIN
Delete From Fund_Return_Cash
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_Rate_CGHS')
BEGIN
Delete From Mast_Service_Rate_CGHS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Daily_Stat_Bed_Category')
BEGIN
Delete From Daily_Stat_Bed_Category
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OS_Followup_Dtl')
BEGIN
Delete From IP_Bill_OS_Followup_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Mast_Pack_Header')
BEGIN
Delete From IP_Mast_Pack_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='MAST_FO_HR_DEPT_MAPPING')
BEGIN
Delete From MAST_FO_HR_DEPT_MAPPING
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Deposit_Usage')
BEGIN
Delete From Bill_Deposit_Usage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Rtn_Source')
BEGIN
Delete From Fund_Rtn_Source
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Sign')
BEGIN
Delete From Mast_Doc_Sign
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Daily_Statistics')
BEGIN
Delete From Daily_Statistics
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Report_header')
BEGIN
Delete From Report_header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Procedure_Doc')
BEGIN
Delete From Procedure_Doc
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_tx_billing')
BEGIN
Delete From onc_tx_billing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Package_Analysis_Splitup')
BEGIN
Delete From Package_Analysis_Splitup
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Service_Qty')
BEGIN
Delete From Bill_Service_Qty
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Cash')
BEGIN
Delete From IP_Bill_Cash
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Cash')
BEGIN
Delete From Fund_Cash
End
Go

IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Visit_Type')
BEGIN
Delete From Mast_Doc_Visit_Type
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_tx_cycles')
BEGIN
Delete From onc_tx_cycles
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Cheque')
BEGIN
Delete From IP_Bill_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='corp_checklist_Entry')
BEGIN
Delete From corp_checklist_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='CP_Print')
BEGIN
Delete From CP_Print
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Con_Dtl')
BEGIN
Delete From IP_Bill_Con_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Refund_Dtl')
BEGIN
Delete From Refund_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Concession')
BEGIN
Delete From IP_Bill_Concession
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Debit_Note_Dtl')
BEGIN
Delete From Debit_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Card_Holder')
BEGIN
Delete From IP_Bill_Card_Holder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_PriceList_Corp_Group')
BEGIN
Delete From Mast_PriceList_Corp_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Library')
BEGIN
Delete From IP_Bill_Library
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Rept')
BEGIN
Delete From Fund_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_master_package_log')
BEGIN
Delete From onc_master_package_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_TDS_Certificate')
BEGIN
Delete From IP_Bill_TDS_Certificate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_package_Assign')
BEGIN
Delete From onc_package_Assign
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Payment_Dtl')
BEGIN
Delete From Doc_Payment_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_CheckList')
BEGIN
Delete From Mast_CheckList
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Deposit_Reports')
BEGIN
Delete From Deposit_Reports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_package_dtl')
BEGIN
Delete From onc_package_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Export_Tally')
BEGIN
Delete From Export_Tally
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Card_Holder')
BEGIN
Delete From Fund_Card_Holder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_TDS_Certificate_Dtl')
BEGIN
Delete From IP_Bill_TDS_Certificate_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Deposit_Usage')
BEGIN
Delete From IP_Bill_Deposit_Usage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_package_dtl_log')
BEGIN
Delete From onc_package_dtl_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_EFT')
BEGIN
Delete From Bill_EFT
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OS_Dispatch')
BEGIN
Delete From IP_Bill_OS_Dispatch
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Ctrl_Panel_Billing')
BEGIN
Delete From Ctrl_Panel_Billing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Discount_Dtl')
BEGIN
Delete From Bill_Discount_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_DayBook')
BEGIN
Delete From Mast_DayBook
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Settlement')
BEGIN
Delete From Bill_OS_Settlement
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_pat_feedback')
BEGIN
Delete From onc_pat_feedback
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Ctrl_Panel_Printing')
BEGIN
Delete From Ctrl_Panel_Printing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Rept_cash_dtl')
BEGIN
Delete From Rept_cash_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_pat_package_dtl')
BEGIN
Delete From onc_pat_package_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Corporate_CheckList')
BEGIN
Delete From Corporate_CheckList
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_pat_Reg')
BEGIN
Delete From onc_pat_Reg
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Service_Count')
BEGIN
Delete From Bill_Service_Count
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Corp_Header')
BEGIN
Delete From Mast_Corp_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Corresponding')
BEGIN
Delete From Fund_Corresponding
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_OutStanding_Adjust')
BEGIN
Delete From IP_Bill_OutStanding_Adjust
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Concession_Header_Priority')
BEGIN
Delete From Mast_Concession_Header_Priority
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_AdvIntimation')
BEGIN
Delete From IP_AdvIntimation
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Outstanding')
BEGIN
Delete From IP_Bill_Outstanding
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Con_Doc_Dtl')
BEGIN
Delete From IP_Bill_Con_Doc_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Header_log')
BEGIN
Delete From Header_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Tarrif_Report')
BEGIN
Delete From Tarrif_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Procedure_Entry')
BEGIN
Delete From Doc_Procedure_Entry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Header_27072016')
BEGIN
Delete From Mast_Header_27072016
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_E_Request')
BEGIN
Delete From Bill_E_Request
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Voucher_PayMent_Mode')
BEGIN
Delete From Voucher_PayMent_Mode
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Doc_Fee_Report')
BEGIN
Delete From Bill_Doc_Fee_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Incentive_Report')
BEGIN
Delete From Incentive_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Estimate_Hdr')
BEGIN
Delete From Bill_Estimate_Hdr
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='A00061_Mast_Emp_Outstanding')
BEGIN
Delete From A00061_Mast_Emp_Outstanding
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Pat_Credit')
BEGIN
Delete From IP_Pat_Credit
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_PriceList_FutureMatrix')
BEGIN
Delete From Mast_PriceList_FutureMatrix
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Ref_Cheque')
BEGIN
Delete From IP_Bill_Ref_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Con_Req_Dtl')
BEGIN
Delete From IP_Bill_Con_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Tax_Dtl')
BEGIN
Delete From IP_Bill_Tax_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_DemandDraft')
BEGIN
Delete From Bill_DemandDraft
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Dispatch_Dtl')
BEGIN
Delete From Bill_OS_Dispatch_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Ref_demandDraft')
BEGIN
Delete From IP_Bill_Ref_demandDraft
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Pat_Notes')
BEGIN
Delete From IP_Pat_Notes
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_FollowUp_Reminder')
BEGIN
Delete From Bill_OS_FollowUp_Reminder
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Canteen_Bill_Report')
BEGIN
Delete From Canteen_Bill_Report
End
Go

IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Followup')
BEGIN
Delete From Bill_OS_Followup
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Con_Dtl')
BEGIN
Delete From Bill_Con_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Cancel')
BEGIN
Delete From IP_Bill_Cancel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Advance_Payment')
BEGIN
Delete From Doc_Advance_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_CorporateEntry')
BEGIN
Delete From Mast_CorporateEntry
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Ref_Cheque')
BEGIN
Delete From Bill_Ref_Cheque
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Rept_Refund')
BEGIN
Delete From IP_Part_Bill_Rept_Refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Cancel_Dtl_NGO')
BEGIN
Delete From Fund_Cancel_Dtl_NGO
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Cutting_dtl')
BEGIN
Delete From IP_Bill_Cutting_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Mast_DayBook')
BEGIN
Delete From IP_Mast_DayBook
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_DietDel')
BEGIN
Delete From Mast_Service_DietDel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='DAYCARE_COUNTER')
BEGIN
Delete From DAYCARE_COUNTER
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Outstanding_Tot')
BEGIN
Delete From Bill_Outstanding_Tot
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Scheme')
BEGIN
Delete From Mast_Scheme
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_TDS')
BEGIN
Delete From Mast_TDS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_InsuranceCorpType')
BEGIN
Delete From Mast_InsuranceCorpType
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Scheme_Ser')
BEGIN
Delete From Mast_Scheme_Ser
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_OS_Conclimit')
BEGIN
Delete From Mast_OS_Conclimit
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Debit_Note')
BEGIN
Delete From Debit_Note
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Concession')
BEGIN
Delete From Bill_Concession
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_RoundOff')
BEGIN
Delete From Bill_RoundOff
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='collectionanalysis_Rpt')
BEGIN
Delete From collectionanalysis_Rpt
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='MAST_DAYCARE_COUNTER')
BEGIN
Delete From MAST_DAYCARE_COUNTER
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Preauth_RFDtl')
BEGIN
Delete From IP_Preauth_RFDtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_DeNormalize')
BEGIN
Delete From Bill_DeNormalize
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Mast_Pat_Misc_Req')
BEGIN
Delete From IP_Mast_Pat_Misc_Req
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Letter_Group')
BEGIN
Delete From IP_TPA_Letter_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Src_Change_Log')
BEGIN
Delete From Bill_Src_Change_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Physio_Order_Cancel')
BEGIN
Delete From Fund_Realised
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Ward_os_daywise')
BEGIN
Delete From Ward_os_daywise
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doctor_Incentive')
BEGIN
Delete From Mast_Doctor_Incentive
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Dtl_DeNormalize')
BEGIN
Delete From Bill_Dtl_DeNormalize
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Outstanding_Payment')
BEGIN
Delete From Bill_Outstanding_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Inc_Sharing')
BEGIN
Delete From Mast_Inc_Sharing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Pat_Link')
BEGIN
Delete From Mast_Pat_Link
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Doc_Fee')
BEGIN
Delete From IP_Bill_Doc_Fee
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Vendor_Group')
BEGIN
Delete From Mast_Vendor_Group
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Ref_demandDraft')
BEGIN
Delete From Bill_Ref_demandDraft
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Refund_Dtl')
BEGIN
Delete From IP_Part_Bill_Refund_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_Mast_Stage')
BEGIN
Delete From onc_Mast_Stage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Default_Price_List_Log')
BEGIN
Delete From Default_Price_List_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Refund_Dtl')
BEGIN
Delete From Bill_Refund_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_EFT')
BEGIN
Delete From IP_Bill_EFT
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OS_Deposit_Diff')
BEGIN
Delete From OS_Deposit_Diff
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Rept_Dtl')
BEGIN
Delete From Bill_Rept_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Dtl')
BEGIN
Delete From Bill_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_Mast_Activity')
BEGIN
Delete From onc_Mast_Activity
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Yr_Closing_Payment')
BEGIN
Delete From Yr_Closing_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Discdtchange')
BEGIN
Delete From IP_Bill_Discdtchange
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Header')
BEGIN
Delete From Bill_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='DAYCARE_SCHEDULE_DTL')
BEGIN
Delete From DAYCARE_SCHEDULE_DTL
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='sysdiagrams')
BEGIN
Delete From sysdiagrams
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Free_Service')
BEGIN
Delete From Mast_Free_Service
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_Mast_TreatingSite')
BEGIN
Delete From onc_Mast_TreatingSite
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_TDS_Certificate')
BEGIN
Delete From Bill_TDS_Certificate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Letter_Detail')
BEGIN
Delete From IP_TPA_Letter_Detail
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Printing')
BEGIN
Delete From Bill_Printing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_Mast_Tx')
BEGIN
Delete From onc_Mast_Tx
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='tmpOS')
BEGIN
Delete From tmpOS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='DAYCARE_SCHEDULE')
BEGIN
Delete From DAYCARE_SCHEDULE
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_AutoPost')
BEGIN
Delete From IP_AutoPost
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Advance_Payment')
BEGIN
Delete From Advance_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Review')
BEGIN
Delete From Doc_Review
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS')
BEGIN
Delete From Bill_OS
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='onc_master_package')
BEGIN
Delete From onc_master_package
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Dispatch')
BEGIN
Delete From Bill_OS_Dispatch
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Pat_Misc_Req')
BEGIN
Delete From Mast_Pat_Misc_Req
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Discount_Hdr')
BEGIN
Delete From Bill_Discount_Hdr
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_TDS_Certificate_Dtl')
BEGIN
Delete From Bill_TDS_Certificate_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Rept')
BEGIN
Delete From IP_Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_DocFee_Report')
BEGIN
Delete From IP_DocFee_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Auth_Dtl')
BEGIN
Delete From Mast_Auth_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='ip_tpa_approval_cancel')
BEGIN
Delete From ip_tpa_approval_cancel
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='MAst_Proportion_Charge')
BEGIN
Delete From MAst_Proportion_Charge
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Dispatch')
BEGIN
Delete From IP_TPA_Dispatch
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Doctor_Payment')
BEGIN
Delete From IP_Doctor_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Dept_Service_Billing')
BEGIN
Delete From Mast_Dept_Service_Billing
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_IP_Auth')
BEGIN
Delete From Mast_IP_Auth
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Deposit_Transfer')
BEGIN
Delete From Bill_Deposit_Transfer
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='MIS_Revenue_MthWise_Both')
BEGIN
Delete From MIS_Revenue_MthWise_Both
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Outstanding_20160401')
BEGIN
Delete From Bill_Outstanding_20160401
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Bill_Reports')
BEGIN
Delete From OP_Bill_Reports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Cheque_SourceName')
BEGIN
Delete From Cheque_SourceName
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Temp_Rept')
BEGIN
Delete From Temp_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Dtl_TEST')
BEGIN
Delete From IP_Bill_Dtl_TEST
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Cash')
BEGIN
Delete From Bill_Cash
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Pat_Review')
BEGIN
Delete From Mast_Doc_Pat_Review
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Cheque_Payment')
BEGIN
Delete From Cheque_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Cheque_Detail_Report')
BEGIN
Delete From Cheque_Detail_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Ref_Doc_Insentive')
BEGIN
Delete From Mast_Ref_Doc_Insentive
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='DashBoard_Dtl')
BEGIN
Delete From DashBoard_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Deposit_Refund_Dtl')
BEGIN
Delete From Deposit_Refund_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Dtl')
BEGIN
Delete From IP_Bill_Dtl
End
Go

IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Advance_Payment_log')
BEGIN
Delete From Advance_Payment_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Query_Dtl')
BEGIN
Delete From IP_TPA_Query_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Review')
BEGIN
Delete From Mast_Doc_Review
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Allowance')
BEGIN
Delete From Doctor_Allowance
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Cutting_dtl')
BEGIN
Delete From Bill_Cutting_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Payment_Terms')
BEGIN
Delete From Mast_Payment_Terms
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Editor')
BEGIN
Delete From IP_Bill_Editor
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Rept_PayDetails')
BEGIN
Delete From IP_Bill_Rept_PayDetails
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Concession')
BEGIN
Delete From IP_Part_Bill_Concession
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Wardwise_Os_Daywise')
BEGIN
Delete From IP_Wardwise_Os_Daywise
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Billing_Control')
BEGIN
Delete From Billing_Control
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Payment')
BEGIN
Delete From Doc_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Tally_Applicable_Billtype')
BEGIN
Delete From Tally_Applicable_Billtype
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Outstanding')
BEGIN
Delete From IP_Part_Bill_Outstanding
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Indemnity_Trans')
BEGIN
Delete From Doc_Indemnity_Trans
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Bill_debtors')
BEGIN
Delete From OP_Bill_debtors
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Preauth_Req_Dtl')
BEGIN
Delete From IP_Preauth_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='TempMonthColumns')
BEGIN
Delete From TempMonthColumns
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Report_Custom_Header')
BEGIN
Delete From Report_Custom_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='TB_ReportsIP')
BEGIN
Delete From TB_ReportsIP
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Rept')
BEGIN
Delete From IP_Part_Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Income_Report')
BEGIN
Delete From Income_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Payment')
BEGIN
Delete From Bill_OS_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Revenue_Report')
BEGIN
Delete From Revenue_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Refund_Dtl')
BEGIN
Delete From IP_Bill_Refund_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Cons_Report')
BEGIN
Delete From OP_Cons_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Receipt_ngo')
BEGIN
Delete From Fund_Receipt_ngo
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Preauth_Update_Log')
BEGIN
Delete From Preauth_Update_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Service_Log')
BEGIN
Delete From IP_Service_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_TPA_Approval')
BEGIN
Delete From IP_TPA_Approval
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Rept_Refund')
BEGIN
Delete From IP_Bill_Rept_Refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payment_Deduction')
BEGIN
Delete From Doctor_Payment_Deduction
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Indemnity')
BEGIN
Delete From Mast_Doc_Indemnity
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Doc_Fee_Dtl')
BEGIN
Delete From Bill_Doc_Fee_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Outstanding_Payment')
BEGIN
Delete From IP_Part_Bill_Outstanding_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_Rate_Log')
BEGIN
Delete From Mast_Service_Rate_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Revenue_Report_New')
BEGIN
Delete From Revenue_Report_New
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='corpEntry_test')
BEGIN
Delete From corpEntry_test
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Deposit_Transfer_New')
BEGIN
Delete From Bill_Deposit_Transfer_New
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Outstanding_AdvPayment')
BEGIN
Delete From IP_Bill_Outstanding_AdvPayment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Cash_Refund')
BEGIN
Delete From Bill_Cash_Refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Attachements')
BEGIN
Delete From Fund_Attachements
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Service_AutoPost')
BEGIN
Delete From Mast_Service_AutoPost
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Allocated_Hdr')
BEGIN
Delete From Mast_Doc_Allocated_Hdr
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_PatPackage_Log')
BEGIN
Delete From IP_PatPackage_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Fund_Cancel_NGO')
BEGIN
Delete From Fund_Cancel_NGO
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='BillDetails_Reports')
BEGIN
Delete From BillDetails_Reports
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_PaymentType')
BEGIN
Delete From Mast_PaymentType
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Outstanding_Tot')
BEGIN
Delete From IP_Bill_Outstanding_Tot
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Collection')
BEGIN
Delete From Doctor_Collection
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Incentive')
BEGIN
Delete From Mast_Doc_Incentive
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Header')
BEGIN
Delete From IP_Bill_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Cash_Receive_Dtl')
BEGIN
Delete From Bill_Cash_Receive_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Instrument_Bank')
BEGIN
Delete From Mast_Instrument_Bank
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Service_Post')
BEGIN
Delete From IP_Service_Post
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Referral_Doc_Payment')
BEGIN
Delete From Referral_Doc_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_PatPackage')
BEGIN
Delete From IP_PatPackage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_BadDebts')
BEGIN
Delete From Bill_BadDebts
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_PaymentType')
BEGIN
Delete From Mast_Doc_PaymentType
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='xDBA_MIS_TCS_Revenue')
BEGIN
Delete From xDBA_MIS_TCS_Revenue
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Advance_Rept')
BEGIN
Delete From Doc_Advance_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Advance_Payment')
BEGIN
Delete From IP_Advance_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_SrcUpdate')
BEGIN
Delete From Bill_OS_SrcUpdate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Review')
BEGIN
Delete From Mast_Review
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Tally_Transaction')
BEGIN
Delete From Mast_Tally_Transaction
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Outstanding')
BEGIN
Delete From Bill_Outstanding
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Service_AutoPost')
BEGIN
Delete From IP_Service_AutoPost
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doc_Payment_Header')
BEGIN
Delete From Doc_Payment_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Header_Def_Log')
BEGIN
Delete From Mast_Doc_Header_Def_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Concession_Service')
BEGIN
Delete From Mast_Concession_Service
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='deposit_refund')
BEGIN
Delete From deposit_refund
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Doc_Fee_Dtl')
BEGIN
Delete From IP_Bill_Doc_Fee_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Review_Dtl')
BEGIN
Delete From Mast_Doc_Review_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Corp_PriceList')
BEGIN
Delete From Mast_Corp_PriceList
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Excess_Usage')
BEGIN
delete from Bill_Excess_Usage
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Excess_Payment')
BEGIN
delete from Bill_Excess_Payment
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Concession_Req')
BEGIN
delete from IP_Part_Bill_Concession_Req
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Package_log')
BEGIN
delete from IP_Package_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Header_Approval')
BEGIN
delete from Bill_Header_Approval
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Dtl_Approval')
BEGIN
delete from Bill_Dtl_Approval
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Package_Dtl')
BEGIN
delete from Bill_Package_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Caution_Deposit_Expense_Entry')
BEGIN
delete from Caution_Deposit_Expense_Entry
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OS_Bill_Rept')
BEGIN
delete from OS_Bill_Rept
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='RCM_Insurance_Approval_Header')
BEGIN
delete from RCM_Insurance_Approval_Header
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='RCM_Insurance_Approval_Service_Detail')
BEGIN
delete from RCM_Insurance_Approval_Service_Detail
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_daybook_OpeningBalance')
BEGIN
delete from Mast_daybook_OpeningBalance
End

Go

IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='RevenueDaywise')
BEGIN
delete from RevenueDaywise
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='ER_Service_Log')
BEGIN
delete from ER_Service_Log
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OPBillcheck')
BEGIN
delete from OPBillcheck
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_PartToFinal_convert')
BEGIN
delete from IP_PartToFinal_convert
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='ER_Bill_Header')
BEGIN
delete from ER_Bill_Header
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='ER_Bill_Rept')
BEGIN
delete from ER_Bill_Rept
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Excess_Refund_Dtl')
BEGIN
delete from Excess_Refund_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Excess_refund')
BEGIN
delete from Excess_refund
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Loyalty_Points_Generation_Header_Dtl')
BEGIN
delete from Loyalty_Points_Generation_Header_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_BadDebts_Rept')
BEGIN
delete from Bill_BadDebts_Rept
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Loyalty_Points_Generation_Dtl')
BEGIN
delete from Loyalty_Points_Generation_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_BadDepbts_Payment')
BEGIN
delete from Bill_BadDepbts_Payment
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Loyalty_Points_Generation')
BEGIN
delete from Loyalty_Points_Generation
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OPIP_Tariff_Bill_Dtl')
BEGIN
delete from OPIP_Tariff_Bill_Dtl
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Loyalty_Points_Utilisation')
BEGIN
delete from Loyalty_Points_Utilisation
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Credit_Revert')
BEGIN
delete from IP_Part_Credit_Revert
End

Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Part_Bill_Con_Req_Dtl')
BEGIN
delete from IP_Part_Bill_Con_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Corp_Service_Insurance_Applicablity')
BEGIN
delete from Mast_Corp_Service_Insurance_Applicablity
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_ConvertToCredit')
BEGIN
delete from Bill_ConvertToCredit
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Entry_ConsultationDept')
BEGIN
delete from Patient_Corporate_Entry_ConsultationDept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Entry_HeaderList')
BEGIN
delete from Patient_Corporate_Entry_HeaderList
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Billing_File_Attach')
BEGIN
delete from Billing_File_Attach
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OS_Bill_Rept')
BEGIN
delete from OS_Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_User_Settlement_Physical_Cash_Dtl')
BEGIN
delete from Bill_User_Settlement_Physical_Cash_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_User_Settlement_Physical_Cash')
BEGIN
delete from Bill_User_Settlement_Physical_Cash
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Ason_dt_Advance_Dtl')
BEGIN
delete from Ason_dt_Advance_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_CorporateDefintion_Log')
BEGIN
delete from Mast_CorporateDefintion_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='labServiceTest')
BEGIN
delete from labServiceTest
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Advance_Surgery_Map_Dtl')
BEGIN
delete from Advance_Surgery_Map_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Advance_Surgery_Map')
BEGIN
delete from Advance_Surgery_Map
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='WardwiseOS_Package')
BEGIN
delete from WardwiseOS_Package
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Dtl2')
BEGIN
delete from Bill_Dtl2
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Header2')
BEGIN
delete from Bill_Header2
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Billing_HeaderSSMC')
BEGIN
delete from Billing_HeaderSSMC
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Rept_Header_dtl')
BEGIN
delete from IP_Bill_Rept_Header_dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Dtl_Headerwise')
BEGIN
delete from IP_Bill_Dtl_Headerwise
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Outstanding_Payment_Headerwise')
BEGIN
delete from Bill_Outstanding_Payment_Headerwise
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Payment_Data')
BEGIN
delete from Bill_OS_Payment_Data
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Loyalty_eWards_API')
BEGIN
delete from Loyalty_eWards_API
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Entry_Emp_Default_Corp')
BEGIN
delete from Patient_Corporate_Entry_Emp_Default_Corp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Credit_Log')
BEGIN
delete from Patient_Credit_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='corplog')
BEGIN
delete from corplog
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Credit_Log_BK')
BEGIN
delete from Patient_Credit_Log_BK
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Concession_Header_Discount_Log')
BEGIN
delete from Mast_Concession_Header_Discount_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Collection_Generation')
BEGIN
delete from Doctor_Collection_Generation
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='labRequestService')
BEGIN
delete from labRequestService
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_E_Request_Header')
BEGIN
delete from Bill_E_Request_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Statement')
BEGIN
delete from Bill_Statement
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Pat_Notes_Log')
BEGIN
delete from IP_Pat_Notes_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Performing_Doctor_Map')
BEGIN
delete from Performing_Doctor_Map
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OS_PartBill_Rept')
BEGIN
delete from OS_PartBill_Rept
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='SupplementaryBill_Temp')
BEGIN
delete from SupplementaryBill_Temp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_ServiceRateUpdate_Log')
BEGIN
delete from IP_ServiceRateUpdate_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Package_Rate_Dtl')
BEGIN
delete from OP_Package_Rate_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Package_Rate')
BEGIN
delete from OP_Package_Rate
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_OS_Payment_Data')
BEGIN
delete from Bill_OS_Payment_Data
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Credit_Log')
BEGIN
delete from Patient_Credit_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Patient_Corporate_Log')
BEGIN
delete from Patient_Corporate_Log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='RevenueReport_View_Report')
BEGIN
delete from RevenueReport_View_Report
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Package_Con_Dtl_Apportion')
BEGIN
delete from Bill_Package_Con_Dtl_Apportion
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Package_Con_Dtl_Apportion_Adjust')
BEGIN
delete from Bill_Package_Con_Dtl_Apportion_Adjust
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payout_Freeze_Dtl')
BEGIN
delete from Doctor_Payout_Freeze_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_Payout_Freeze_Header')
BEGIN
delete from Doctor_Payout_Freeze_Header
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='JsonPriceListRecordtemp')
BEGIN
delete from JsonPriceListRecordtemp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_Dtl_Qty')
BEGIN
delete from Bill_Dtl_Qty
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Bill_Dtl')
BEGIN
delete from IP_Bill_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Doctor_collection_CollectedRevnenu_PaymentDetails')
BEGIN
delete from Doctor_collection_CollectedRevnenu_PaymentDetails
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Voucher_Number_backup')
BEGIN
delete from Voucher_Number_backup
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Mast_Doc_Header_Def_temp')
BEGIN
delete from Mast_Doc_Header_Def_temp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Multi_Visit_Package_Bill_Dtl')
BEGIN
delete from OP_Multi_Visit_Package_Bill_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Multi_Visit_PatPackage_log')
BEGIN
delete from OP_Multi_Visit_PatPackage_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Multi_Visit_PatPackage_Dtl_log')
BEGIN
delete from OP_Multi_Visit_PatPackage_Dtl_log
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='OP_Multi_Visit_PatPackage_Dtl')
BEGIN
delete from OP_Multi_Visit_PatPackage_Dtl
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Bill_E_Request_TEST')
BEGIN
delete from Bill_E_Request_TEST
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Patient_Park')
BEGIN
delete from IP_Patient_Park
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Accrual_Revenue_Report_Table')
BEGIN
delete from Accrual_Revenue_Report_Table
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='IP_Service_Log_Temp')
BEGIN
delete from IP_Service_Log_Temp
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Accrual_Revenue_Report_Table_Task11088')
BEGIN
delete from Accrual_Revenue_Report_Table_Task11088
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='RevenueReport_View_tbl_Task11088')
BEGIN
delete from RevenueReport_View_tbl_Task11088
End
Go
IF EXISTS(select * from KMCH_Billing.sys.objects where type='U' and name='Test_os')
BEGIN
delete from Test_os
End
Go


Use Kmch_Cardiology
-- Tables Of Predefined Values , Masters and Settings
/*
CARD_REPORT_CONTROL_PANEL
Proc_Template_Name
Mast_Proc_Bio_Template
Mast_Proc
Control_Panel
Proc_Group
Mast_Proc_Impression

*/
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='UOM')
BEGIN
Delete from UOM
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Pat_ResultEntryImg')
BEGIN
Delete from Pat_ResultEntryImg
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Task_List_Dtl')
BEGIN
Delete from Task_List_Dtl
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Proc_Result')
BEGIN
Delete from Proc_Result
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='IP_TPA_Dispatch')
BEGIN
Delete from IP_TPA_Dispatch
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Mast_Equipment_Grp')
BEGIN
Delete from Mast_Equipment_Grp
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Mast_Proc_Alias')
BEGIN
Delete from Mast_Proc_Alias
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Mast_SubProc')
BEGIN
Delete from Mast_SubProc
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Proc_Result_Impression')
BEGIN
Delete from Proc_Result_Impression
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Proc_Result_Impression_Log')
BEGIN
Delete from Proc_Result_Impression_Log
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='DigitalSign_Dtl')
BEGIN
Delete from DigitalSign_Dtl
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Card_SMS_Log')
BEGIN
Delete from Card_SMS_Log
End
Go
IF EXISTS(select * from Kmch_Cardiology.sys.objects where type='U' and name='Proc_Result_Img')
BEGIN
Delete from Proc_Result_Img
End
Go
Use KMCH_Dietary
Go
-- Tables Of Predefined Values , Masters and Settings
/*
Mast_DietSession
DIET_REPORT_CONTROL_PANEL
Mast_LiquidDietSession
Diet_Fixed_Menu
Diet_Fix_Menu_Item
Proc_Group
Mast_Proc
Mast_LiquidDiet_Qty
Mast_CancelReason
Mast_SubProc
Control_Panel_Printing
Select * from Mast_PatVitals_Ranges - M
Select * from Mast_PatVitals_Rights - M
*/
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='A00061_Diet_Auto_Post')
BEGIN
Delete from A00061_Diet_Auto_Post
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Liquidhourly_Session')
BEGIN
Delete from Mast_Liquidhourly_Session
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_liquid_hrly')
BEGIN
Delete from Mast_liquid_hrly
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Counselling_Req')
BEGIN
Delete from Diet_Counselling_Req
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='iDiet_Counselling_Req')
BEGIN
Delete from iDiet_Counselling_Req
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Direct_DietOrder_Item')
BEGIN
Delete from Direct_DietOrder_Item
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Pat_Diet_Diagnostic')
BEGIN
Delete from Pat_Diet_Diagnostic
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Pat_Diet_Assessment')
BEGIN
Delete from Pat_Diet_Assessment
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Diet_Diagnostic')
BEGIN
Delete from Mast_Diet_Diagnostic
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Checked')
BEGIN
Delete from Diet_Checked
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_StickerLoc')
BEGIN
Delete from Mast_StickerLoc
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Request_Print_User')
BEGIN
Delete from Request_Print_User
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Disease')
BEGIN
Delete from Mast_Disease
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_State_Food')
BEGIN
Delete from Mast_State_Food
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Tax_Ctrl')
BEGIN
Delete from Diet_Tax_Ctrl
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Auto_Post_Log')
BEGIN
Delete from Diet_Auto_Post_Log
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='UOM')
BEGIN
Delete from UOM
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='BMI_Range')
BEGIN
Delete from BMI_Range
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Proc_Item')
BEGIN
Delete from Proc_Item
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Activity_Level')
BEGIN
Delete from Mast_Activity_Level
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='OPDiet_Order_dtl')
BEGIN
Delete from OPDiet_Order_dtl
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_TER_Reduction')
BEGIN
Delete from Mast_TER_Reduction
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Calories')
BEGIN
Delete from Mast_Calories
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Pat_Starvation_Diet')
BEGIN
Delete from Pat_Starvation_Diet
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_Calories_Template')
BEGIN
Delete from Mast_Calories_Template
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Pat_Starvation_Diet_Log')
BEGIN
Delete from Pat_Starvation_Diet_Log
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Pat_Reserve')
BEGIN
Delete from Diet_Pat_Reserve
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Mast_SessionClub')
BEGIN
Delete from Mast_SessionClub
End
Go
IF EXISTS(select * from KMCH_Dietary.sys.objects where type='U' and name='Diet_Chart')
BEGIN
Delete from Diet_Chart
End
Go

Use KMCH_EMR
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR')
BEGIN
Delete from EMR
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Allergy')
BEGIN
Delete from EMR_Allergy
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Emr_CardioTemplate')
BEGIN
Delete from Emr_CardioTemplate
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Diag_Dtl')
BEGIN
Delete from EMR_Diag_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Fam_Hist')
BEGIN
Delete from EMR_Fam_Hist
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_General_const')
BEGIN
Delete from EMR_General_const
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_HPI_Cardiac')
BEGIN
Delete from EMR_HPI_Cardiac
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ICD')
BEGIN
Delete from EMR_ICD
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Lab_const')
BEGIN
Delete from EMR_Lab_const
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_Diagnosis')
BEGIN
Delete from EMR_Pat_Diagnosis
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_Note_Template')
BEGIN
Delete from EMR_Pat_Note_Template
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Emr_Pat_Schedule')
BEGIN
Delete from Emr_Pat_Schedule
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Abdomen')
BEGIN
Delete from EMR_PE_Abdomen
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Breast')
BEGIN
Delete from EMR_PE_Breast
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Const')
BEGIN
Delete from EMR_PE_Const
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Diet_Chart')
BEGIN
Delete from EMR_PE_ENT
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Extremity')
BEGIN
Delete from EMR_PE_Extremity
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Eyes')
BEGIN
Delete from EMR_PE_Eyes
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Genitourinary')
BEGIN
Delete from EMR_PE_Genitourinary
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Head')
BEGIN
Delete from EMR_PE_Head
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Lymph')
BEGIN
Delete from EMR_PE_Lymph
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_musculoskeletal')
BEGIN
Delete from EMR_PE_musculoskeletal
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Neck')
BEGIN
Delete from EMR_PE_Neck
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Neuro')
BEGIN
Delete from EMR_PE_Neuro
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Pediatric')
BEGIN
Delete from EMR_PE_Pediatric
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Resp')
BEGIN
Delete from EMR_PE_Resp
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PE_Skin')
BEGIN
Delete from EMR_PE_Skin
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_PM_Hist')
BEGIN
Delete from EMR_PM_Hist
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Prescribe_Meds')
BEGIN
Delete from EMR_Prescribe_Meds
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Emr_Registration_Settings_Temp')
BEGIN
Delete from Emr_Registration_Settings_Temp
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Allergic')
BEGIN
Delete from EMR_ROS_Allergic
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Breast')
BEGIN
Delete from EMR_ROS_Breast
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_cardio')
BEGIN
Delete from EMR_ROS_cardio
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_const')
BEGIN
Delete from EMR_ROS_const
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Endo')
BEGIN
Delete from EMR_ROS_Endo
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_ENT')
BEGIN
Delete from EMR_ROS_ENT
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Eyes')
BEGIN
Delete from EMR_ROS_Eyes
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Gastro')
BEGIN
Delete from EMR_ROS_Gastro
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Gen')
BEGIN
Delete from EMR_ROS_Gen
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_head')
BEGIN
Delete from EMR_ROS_head
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Hem')
BEGIN
Delete from EMR_ROS_Hem
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Integum')
BEGIN
Delete from EMR_ROS_Integum
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Mus')
BEGIN
Delete from EMR_ROS_Mus
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Neuro')
BEGIN
Delete from EMR_ROS_Neuro
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Psy')
BEGIN
Delete from EMR_ROS_Psy
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Resp')
BEGIN
Delete from EMR_ROS_Resp
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Vital')
BEGIN
Delete from EMR_ROS_Vital
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_ROS_Vital_Txt')
BEGIN
Delete from EMR_ROS_Vital_Txt
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Soc_Hist')
BEGIN
Delete from EMR_Soc_Hist
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Emr_Surgtemplate')
BEGIN
Delete from Emr_Surgtemplate
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EmrPaediatricTemplate')
BEGIN
Delete from EmrPaediatricTemplate
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='ER_Assessment')
BEGIN
Delete from ER_Assessment
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='JSS_EMR')
BEGIN
Delete from JSS_EMR
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Mast_LetterService')
BEGIN
Delete from Mast_LetterService
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Card_Order')
BEGIN
Delete from MO_EMR_Card_Order
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Lab_Order')
BEGIN
Delete from MO_EMR_Lab_Order
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_Emr_Pres_Order')
BEGIN
Delete from MO_Emr_Pres_Order
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Rad_Order')
BEGIN
Delete from MO_EMR_Rad_Order
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Service_Order')
BEGIN
Delete from MO_EMR_Service_Order
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Discharge_Note')
BEGIN
Delete from Pat_Discharge_Note
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_EMR_Diagnosis')
BEGIN
Delete from Pat_EMR_Diagnosis
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Emr_Scan_Note')
BEGIN
Delete from Pat_Emr_Scan_Note
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_BabyChart')
BEGIN
Delete from Patient_BabyChart
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Emr_Note')
BEGIN
Delete from Patient_Emr_Note
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Movement')
BEGIN
Delete from Patient_Movement
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Vaccine')
BEGIN
Delete from Patient_Vaccine
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='ER_Assessment_Dtl')
BEGIN
Delete from ER_Assessment_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Card_Order_Dtl')
BEGIN
Delete from MO_EMR_Card_Order_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Lab_Order_Dtl')
BEGIN
Delete from MO_EMR_Lab_Order_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Rad_Order_Dtl')
BEGIN
Delete from MO_EMR_Rad_Order_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Discharge_Note_Dtl')
BEGIN
Delete from Pat_Discharge_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Discharge_Note_Grp_Dtl')
BEGIN
Delete from Pat_Discharge_Note_Grp_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Emr_Scan_Note_Dtl')
BEGIN
Delete from Pat_Emr_Scan_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Surgeries_Req_Dtl')
BEGIN
Delete from Pat_Surgeries_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Emr_Note_Dtl')
BEGIN
Delete from Patient_Emr_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Vaccine_Dtl')
BEGIN
Delete from Patient_Vaccine_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='MO_EMR_Service_Order_Dtl')
BEGIN
Delete from MO_EMR_Service_Order_Dtl
 End
 Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='DocPat_Appointment')
BEGIN
Delete from DocPat_Appointment
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Intake_Output')
BEGIN
Delete from EMR_Intake_Output
End
 Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History')
BEGIN
Delete from EMR_Pat_History
End
 Go
 IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History_Family')
BEGIN
Delete from EMR_Pat_History_Family
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History_PM')
BEGIN
Delete from EMR_Pat_History_PM  
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History_PS')
BEGIN
Delete from EMR_Pat_History_PS  
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History_Social')
BEGIN
Delete from EMR_Pat_History_Social  
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Chief_Complaints')
BEGIN
Delete from Pat_Chief_Complaints
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Discharge_Note_SignDtls')
BEGIN
Delete from Pat_Discharge_Note_SignDtls
End
Go 
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Home_Meds')
BEGIN
Delete from Pat_Home_Meds
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Surgeries_Req')
BEGIN
Delete from Pat_Surgeries_Req
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Patient_Emr_Note_Dtl_Update')
BEGIN
Delete from Patient_Emr_Note_Dtl_Update
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pres_MAR')
BEGIN
Delete from EMR_Pres_MAR
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History_Others')
BEGIN
Delete from EMR_Pat_History_Others
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='RCM_Insurance_EMRCheck_Dtl')
BEGIN
Delete from RCM_Insurance_EMRCheck_Dtl
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='RCM_Insurance_EMRCheck')
BEGIN
Delete from RCM_Insurance_EMRCheck
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='DMRScannedFile')
BEGIN
Delete from DMRScannedFile
End
Go
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMR_Pat_History')
BEGIN
Delete from EMR_Pat_History
End
Go 
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='EMRDashboardPatientDetails')
BEGIN
Delete from EMRDashboardPatientDetails
End
Go 
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Pat_Discharge_Note_Tags')
BEGIN
Delete from Pat_Discharge_Note_Tags
End
Go 
IF EXISTS(select * from KMCH_EMR.sys.objects where type='U' and name='Mast_Discharge_Summary_Note_Tags')
BEGIN
Delete from Mast_Discharge_Summary_Note_Tags
End
Go 

Use Kmch_Frontoffice
Go
-- Tables Of Predefined Values , Masters and Settings
/*
Mast_UserMenuDefinition
Mast_Role_Permission
Mast_Mod_Menu
Mast_Menu
Mast_Users
Mast_Icon
Log_DailyDashboard_Dtls
Mast_Role
Log_Details
Mast_Dept
Mast_Module
Ctrl_Panel_FrontOffice
Log_DailyDashboard_Error
Log_DailyDashboardPat_Posting
Reg_Page_Settings
INPATIENT_REPORT_CONTROL_PANEL
BBMRpt_CtrlPanel
Ward_Running_Nos
Voucher_Number
Mast_Relation
Running_Numbers
Mast_MenuType
Mast_Dept_Group
Mast_Menu_Group_Dtl
Mast_Dept_Type
Ward_Ctrl_Ordrhts
Mast_Incident_Loc
Cube_Report
Ward_Ctrl_RunNo
Mast_Incident_Nature
Log_DailyDashboard
Mast_Discharge_Type
Mast_Courtesy
A00061_MAST_CLASS
Ctrl_Panel
Mast_CaseSheet_Status
A00041_Voucher_Number
Mast_PaymentMode
Mast_Mrd_Case_Type
Control_Panel_Frontoffice
Mast_Blood_Component_Type
A00061_MAST_BOOKING_TYPE
A00061_MAST_SESSION
Mast_Birth_Weeks
Mast_IDProof_Type
Mast_CTS
Cube_Report_Server_Login
Mast_Dept_Category
Order_Grp
Mast_Reason
Mail_MessageBox
Mast_BB_CrossMatch_Type
Ctrl_Send_Pat
Mast_Death_Type
Cube_Report_Role_Match
Mast_BedShare_bedtype
Mast_Religion
Mast_BedShare_Dtl
Mast_Mrd_CheckList
Mast_Camp_Dtl
pMast_ReviewFee
Mast_Incineration
Mast_RHTyping
pMast_Pattype_Pricelist
Bill_User_Access
Mast_Refferal
ICD_Surgical_Procedure
BB_Donor_Registration
Mast_Doc_Appointment_Cancel_Reason
pMast_Pattype_Pricelist_Log
BB_Result_Name
Mast_Doc_Appointment_PatType
Mast_Proc_Appointment_PatType
Mast_Doc_Appointment_WorkPlan
Mast_Proc_Header_Appointment_WorkPlan
Mast_Alleged_Cause
Mast_Proc_Appointment_Schedule
Mast_Doc_Appointment_Schedule
Cube_Report_Filter_Value
Mast_Emp_Addr
Mast_DonorType
Mast_Camp
MRD_User_Rights
MastDay_UnitSchdule
Doctor_OPCount
Mast_Proc_Appointment_Skip
Mast_Maturity
Mast_RefTmpl_Hdr
Mast_Employee
Mast_Birth_Type
Mast_Corporate
Mast_Doc_Addr
Mast_RefTmpl
Mast_Corp_Type
Mast_DocSpec
Mast_Doc_OnDuty
Mast_User_Dept
MAST_MLC_TYPE
Mast_BldGrp
Log_DailyDashboard_Hdr
Ward_Ctrl_Panel
Mast_Bed_Category
History_Mast_BedMaster
Mast_BB_Compatablity
Mast_Bedmaster_Quota
Bed_AutoPost_Cotrol_Panel
Mast_Emp_Dependent
Mast_Dist
Mast_Doc_Qual
History_Mast_Doctor
Mast_Doctor_Unit_Dtl
Mast_BedMaster
Mast_Consult_Unit
Control_Panel_MRD
Mast_Doc_Header
mast_country
BloodBank_REPORT_CONTROL_PANEL
Mast_Doc_Appointment_Skip
Mast_Intercom
Mast_IPaddress
Mast_BB_Proc
Mast_BloodGroup
Mast_Blood_Bag_Type
Mast_Bedmaster_Quota_Log
Mast_BloodGroup_Type
BBMast_CtrlPanel
--Datetime
Mast_Ward
Mast_City
New_Dis_Temp
Mast_Donor_Association
MRD_Dept
Mast_BedType
Mast_Designation
Mast_Tmpl_Hdr
Mast_Doctor_Unit
Mast_Company_info
Control_Panel
IPaddress_Track
Mast_BB_Voucher_No
Mast_Log_User
Mast_Doctor
Mast_Location
Mast_Blood_Component
Mast_Prof
Mast_Speciality
Mast_Pat_CaseType
Mast_State
Mast_Qual
Tmpl_Hdr_Dtl
Mast_Compatibility
FO_Reg_Consultant_Fee_Fetch -- Fee seetings , only used in mgm
From Mast_FeedBack_Rating	 
From Mast_FeedBack_Tmpl_Dtl  
From Mast_FeedBack_Tmpl   
Mast_FeedBack_Type
Mast_Special_Blood_Treatment
Bed_AutoPost_Services
Consultant_Charge_Setting  
Mast_Loyalty_Card_Type  
Mast_Loyalty_Card_Category  
Ward_Ctrl_Pattype  
Mast_Loyalty_Card_Price_Matrix  
Mast_Loyalty_Card_Type_Member_Relation_Tag  
Mast_Loyalty_Card_Type_Member_Limit  
Mast_BB_CrossMatch_Type  
User Print Path
Mast_ICD_Chapter -> Icd Related
Mast_ICD_Group -> Icd Related
Mast_ICD_SubChapter -> Icd Related
ICD_10_CM -> Icd Related
ICD_Surgical_Procedure -> Icd Related
Mast_Dissum_Hdr_Image
Mast_Doc_Weekoff
Mast_Nationality
Nrsg_Mast_Type
Mast_Fumigant
Mast_Fumg_Type
Mast_Fumg_Preclean
BloodBank_Vitals_Lookup
*/
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_DI_Pending_Dtl')
BEGIN
Delete from IP_DI_Pending_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Card_Order_Cancel_Req_Dtl')
BEGIN
Delete from EMR_Card_Order_Cancel_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Neck')
BEGIN
Delete from EMR_PE_Neck
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='TempDocSer_Rep')
BEGIN
Delete from TempDocSer_Rep
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Report')
BEGIN
Delete from Report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00041_Control_Panel_Frontoffice')
BEGIN
Delete from A00041_Control_Panel_Frontoffice
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Rep_Appt')
BEGIN
Delete from Mast_Rep_Appt
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Diet_Return_Dtl')
BEGIN
Delete from EMR_Diet_Return_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Diet_Return')
BEGIN
Delete from EMR_Diet_Return
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Cross_Match_Override')
BEGIN
Delete from Blood_Cross_Match_Override
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Neuro')
BEGIN
Delete from EMR_PE_Neuro
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Bed_Daily_Status')
BEGIN
Delete from MIS_Bed_Daily_Status
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Diet_Dtl')
BEGIN
Delete from EMR_Diet_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Error_Track')
BEGIN
Delete from Error_Track
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Resp')
BEGIN
Delete from EMR_PE_Resp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Dissummary_Temp')
BEGIN
Delete from Dissummary_Temp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_Dept_Type')
BEGIN
Delete from MRD_Dept_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Order_Cancel_Req')
BEGIN
Delete from EMR_Order_Cancel_Req
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Pediatric')
BEGIN
Delete from EMR_PE_Pediatric
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pass_info')
BEGIN
Delete from Pass_info
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Order_Cancel_Req_Dtl')
BEGIN
Delete from EMR_Order_Cancel_Req_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='WardWise_Request_SVP1')
BEGIN
Delete from WardWise_Request_SVP1
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Session')
BEGIN
Delete from Mast_Session
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Rad_Order_Cancel_Req')
BEGIN
Delete from EMR_Rad_Order_Cancel_Req
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Diet_Grp')
BEGIN
Delete from Mast_Pat_Diet_Grp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Psychiatric')
BEGIN
Delete from EMR_PE_Psychiatric
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mail_Message')
BEGIN
Delete from Mail_Message
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Equip_Usage')
BEGIN
Delete from Mast_Equip_Usage
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Referal_Incentives_Dtl')
BEGIN
Delete from Referal_Incentives_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Tmpl_Dis_Summary')
BEGIN
Delete from Tmpl_Dis_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Rad_Order_Cancel_Req_Dtl')
BEGIN
Delete from EMR_Rad_Order_Cancel_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Psychiatric_Template')
BEGIN
Delete from EMR_PE_Psychiatric_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Cross_Match')
BEGIN
Delete from Blood_Cross_Match
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Place')
BEGIN
Delete from Mast_Place
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSDays')
BEGIN
Delete from Mast_TSDays
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBPat_Req_Issue_Dtl')
BEGIN
Delete from BBPat_Req_Issue_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Movement_Reg')
BEGIN
Delete from Mast_Pat_Movement_Reg
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_Summary_Orders')
BEGIN
Delete from Mast_Dis_Summary_Orders
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Head')
BEGIN
Delete from EMR_PE_Head
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Eyes')
BEGIN
Delete from EMR_PE_Eyes
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_RecommendType')
BEGIN
Delete from Mast_RecommendType
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Insur_Addr')
BEGIN
Delete from Mast_Pat_Insur_Addr
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSTimings')
BEGIN
Delete from Mast_TSTimings
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Insurance')
BEGIN
Delete from Mast_Pat_Insurance
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Genitourinary')
BEGIN
Delete from EMR_PE_Genitourinary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc')
BEGIN
Delete from Mast_Doc
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Hist')
BEGIN
Delete from Mast_Pat_Hist
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Lymph')
BEGIN
Delete from EMR_PE_Lymph
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Ctrl_Pharm')
BEGIN
Delete from Ward_Ctrl_Pharm
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Type')
BEGIN
Delete from Mast_Pat_Type
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Card_Order_Cancel_Req')
BEGIN
Delete from EMR_Card_Order_Cancel_Req
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_Summary_Temp')
BEGIN
Delete from Mast_Dis_Summary_Temp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='TempPatCumm_Rep')
BEGIN
Delete from TempPatCumm_Rep
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Room_Grp')
BEGIN
Delete from Mast_Room_Grp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='User_Access_Rights')
BEGIN
Delete from User_Access_Rights
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR')
BEGIN
Delete from EMR
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pending_List')
BEGIN
Delete from Mast_Pending_List
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Mobile')
BEGIN
Delete from Mast_Mobile
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Order_Dtl')
BEGIN
Delete from EMR_Order_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Const')
BEGIN
Delete from EMR_PE_Const
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Abdomen')
BEGIN
Delete from EMR_PE_Abdomen
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_doc_ifs')
BEGIN
Delete from Mast_doc_ifs
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Doctor_Visit_Log')
BEGIN
Delete from IP_Doctor_Visit_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Abdomen_Template')
BEGIN
Delete from EMR_PE_Abdomen_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Breast')
BEGIN
Delete from EMR_PE_Breast
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSTravelType')
BEGIN
Delete from Mast_TSTravelType
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='xDBA_Mast_IP_Admission_TCS')
BEGIN
Delete from xDBA_Mast_IP_Admission_TCS
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_ENT')
BEGIN
Delete from EMR_PE_ENT
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_report_SumHdr')
BEGIN
Delete from disch_summary_report_SumHdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Extremity')
BEGIN
Delete from EMR_PE_Extremity
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSStation')
BEGIN
Delete from Mast_TSStation
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_Review')
BEGIN
Delete from Doc_Review
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mrd_Rack_CaseSheet')
BEGIN
Delete from Mrd_Rack_CaseSheet
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Pres')
BEGIN
Delete from EMR_Pres
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='SMS_Detail_Log')
BEGIN
Delete from SMS_Detail_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Frontoffice_denormalize')
BEGIN
Delete from Frontoffice_denormalize
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Leaveday')
BEGIN
Delete from Mast_Leaveday
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BldGrp_Compatibility')
BEGIN
Delete from Mast_BldGrp_Compatibility
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mrd_Pat_CheckList_Dtl_Log')
BEGIN
Delete from Mrd_Pat_CheckList_Dtl_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Menu_Def_Table')
BEGIN
Delete from Mast_Menu_Def_Table
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Key_Reg')
BEGIN
Delete from Mast_Key_Reg
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSTravelName')
BEGIN
Delete from Mast_TSTravelName
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Mrd_Rack_No')
BEGIN
Delete from Mast_Mrd_Rack_No
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Menu_Table')
BEGIN
Delete from Mast_Menu_Table
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBFinanceYear')
BEGIN
Delete from BBFinanceYear
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Room_Type')
BEGIN
Delete from Mast_Room_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSATMCentre')
BEGIN
Delete from Mast_TSATMCentre
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Treatment_Doctor')
BEGIN
Delete from Mast_Treatment_Doctor
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Nursing_Param')
BEGIN
Delete from Mast_Nursing_Param
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pending_Msg_Recived')
BEGIN
Delete from Pending_Msg_Recived
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_UserMobile')
BEGIN
Delete from Mast_UserMobile
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Order_PreRequest')
BEGIN
Delete from EMR_Order_PreRequest
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSHeader')
BEGIN
Delete from Mast_TSHeader
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Allocated_Hdr')
BEGIN
Delete from Mast_Doc_Allocated_Hdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Treatment_Summary')
BEGIN
Delete from Mast_Treatment_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MO_EMR_Service_Order_Dtl')
BEGIN
Delete from Mast_DB_Store
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='SMS_Detail')
BEGIN
Delete from SMS_Detail
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Transfer_Log')
BEGIN
Delete from Bed_Transfer_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Order_ProcDef')
BEGIN
Delete from EMR_Order_ProcDef
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='WardWise_Request_SVP')
BEGIN
Delete from WardWise_Request_SVP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Sent_to_Patient')
BEGIN
Delete from Sent_to_Patient
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Bed_Allocation')
BEGIN
Delete from Mast_Pat_Bed_Allocation
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Ctrl_DissumHdr')
BEGIN
Delete from Ward_Ctrl_DissumHdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_SMSUserMobile')
BEGIN
Delete from Mast_SMSUserMobile
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='SummaryTest')
BEGIN
Delete from SummaryTest
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Reserve')
BEGIN
Delete from Pat_Reserve
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Lang')
BEGIN
Delete from Mast_Lang
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Meds')
BEGIN
Delete from EMR_Meds
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Discharge')
BEGIN
Delete from Mast_Pat_Discharge
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_TSTelephone')
BEGIN
Delete from Mast_TSTelephone
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Equip_Bill_Dtl')
BEGIN
Delete from Pat_Equip_Bill_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Leave_Register')
BEGIN
Delete from Mast_Leave_Register
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_report_Summary')
BEGIN
Delete from disch_summary_report_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='tblchk')
BEGIN
Delete from tblchk
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_PatOP_List')
BEGIN
Delete from Doc_PatOP_List
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_PhFacility')
BEGIN
Delete from Mast_PhFacility
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mast_moduleFuncQuery')
BEGIN
Delete from mast_moduleFuncQuery
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='tblchk1')
BEGIN
Delete from tblchk1
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_baby_Summary')
BEGIN
Delete from Mast_baby_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ICD')
BEGIN
Delete from EMR_ICD
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Group_Company')
BEGIN
Delete from Mast_Group_Company
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_FOCons')
BEGIN
Delete from MIS_Occ_Census_FOCons
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mast_service')
BEGIN
Delete from mast_service
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Gastro')
BEGIN
Delete from EMR_ROS_Gastro
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Patient_image_capture')
BEGIN
Delete from Patient_image_capture
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Dis_Corporate_Checklist')
BEGIN
Delete from Dis_Corporate_Checklist
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MAST_STATUS_IP')
BEGIN
Delete from MAST_STATUS_IP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Doctor_Schedule')
BEGIN
Delete from A00061_Doctor_Schedule
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Menu_Group')
BEGIN
Delete from Mast_Menu_Group
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BedType_Group')
BEGIN
Delete from Mast_BedType_Group
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mrd_Pat_CheckList_Dtl')
BEGIN
Delete from Mrd_Pat_CheckList_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Patient_Def_Services')
BEGIN
Delete from Patient_Def_Services
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Appr_Dtl')
BEGIN
Delete from Bed_Appr_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Card_Order_Dtl')
BEGIN
Delete from EMR_Card_Order_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Gen')
BEGIN
Delete from EMR_ROS_Gen
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='CTS_App_Dtl')
BEGIN
Delete from CTS_App_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Feedback')
BEGIN
Delete from Mast_Feedback
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mail_Message_Attach')
BEGIN
Delete from Mail_Message_Attach
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BedRecommend')
BEGIN
Delete from Mast_BedRecommend
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Day')
BEGIN
Delete from Mast_Day
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_IP_Doctor')
BEGIN
Delete from Mast_IP_Doctor
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Service_Orders')
BEGIN
Delete from Pat_Service_Orders
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Hem')
BEGIN
Delete from EMR_ROS_Hem
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Birth_Register')
BEGIN
Delete from Mast_Birth_Register
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='WardWise_Request_SVPsachin')
BEGIN
Delete from WardWise_Request_SVPsachin
End
Go

 
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mrd_Pat_CheckList')
BEGIN
Delete from Mrd_Pat_CheckList
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_DeNormalize_Search')
BEGIN
Delete from Pat_DeNormalize_Search
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='test1')
BEGIN
Delete from test1
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Mus')
BEGIN
Delete from EMR_ROS_Mus
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BedType_Group_Dtl')
BEGIN
Delete from Mast_BedType_Group_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Status')
BEGIN
Delete  from Status
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Neuro')
BEGIN
Delete from EMR_ROS_Neuro
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Revenue_Report')
BEGIN
Delete from Revenue_Report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Clean_Log')
BEGIN
Delete from Bed_Clean_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Review_Case_Sheet_Request')
BEGIN
Delete from Review_Case_Sheet_Request
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_UpdChk_Log')
BEGIN
Delete from Bed_UpdChk_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='WardOrders_Medlist_WrkTbl')
BEGIN
Delete from WardOrders_Medlist_WrkTbl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Vital_Allergy_Dtl')
BEGIN
Delete from Pat_Vital_Allergy_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='wardwise_request_svpTemp')
BEGIN
Delete from wardwise_request_svpTemp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Graph_Parameters')
BEGIN
Delete from Graph_Parameters
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Integum')
BEGIN
Delete from EMR_ROS_Integum
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Feedback_Header')
BEGIN
Delete from Feedback_Header
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='text2')
BEGIN
Delete from text2
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Rad_Order_Dtl')
BEGIN
Delete from EMR_Rad_Order_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BloodStock_Posting')
BEGIN
Delete from BloodStock_Posting
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_MedicalCerticate')
BEGIN
Delete from Mast_Patient_MedicalCerticate
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_Doctor')
BEGIN
Delete from Mast_Dis_Doctor
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='User_Log')
BEGIN
Delete from User_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Psy')
BEGIN
Delete from EMR_ROS_Psy
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Diet')
BEGIN
Delete from EMR_Diet
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Nurse_Notes')
BEGIN
Delete from Pat_Nurse_Notes
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MyPatientList')
BEGIN
Delete from MyPatientList
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Hist_Mast_Dis_Doctor')
BEGIN
Delete from Hist_Mast_Dis_Doctor
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ctrl_Log_Dtl')
BEGIN
Delete from Ctrl_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Leave')
BEGIN
Delete from Mast_Doc_Leave
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Hist_Mast_Dis_Summary')
BEGIN
Delete from Hist_Mast_Dis_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_musculoskeletal')
BEGIN
Delete from EMR_PE_musculoskeletal
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Equip_AutoPost')
BEGIN
Delete from Equip_AutoPost
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Skin')
BEGIN
Delete from EMR_PE_Skin
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_EquipPost')
BEGIN
Delete from IP_EquipPost
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='OTP_Detail')
BEGIN
Delete from OTP_Detail
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Symptom')
BEGIN
Delete from Mast_Symptom
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='opip_doctor_log')
BEGIN
Delete from opip_doctor_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dissummary_Attach')
BEGIN
Delete from Mast_Dissummary_Attach
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Sch_Doc')
BEGIN
Delete from Sch_Doc
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_AutoPost')
BEGIN
Delete from IP_AutoPost
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Skin_Template')
BEGIN
Delete from EMR_PE_Skin_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_MRD_DEPT_Match')
BEGIN
Delete from A00061_MRD_DEPT_Match
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_HealthCard_Settings')
BEGIN
Delete from Mast_HealthCard_Settings
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_report1')
BEGIN
Delete from disch_summary_report1
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='UserCompAccess_Track')
BEGIN
Delete from UserCompAccess_Track
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Temp_User_Definition')
BEGIN
Delete from Temp_User_Definition
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ctrl_Mast_Log_Dtl')
BEGIN
Delete from Ctrl_Mast_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_ReviewFile_Log')
BEGIN
Delete from MRD_ReviewFile_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ctrl_BP_Doctors')
BEGIN
Delete from Ctrl_BP_Doctors
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doctor_Room')
BEGIN
Delete from Mast_Doctor_Room
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Temp_Trigger')
BEGIN
Delete from Temp_Trigger
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Breast')
BEGIN
Delete from EMR_ROS_Breast
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_Summary')
BEGIN
Delete from Mast_Dis_Summary
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Secondary_ICD_Code_OP')
BEGIN
Delete from Secondary_ICD_Code_OP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Temp_TriggerCnt')
BEGIN
Delete from Temp_TriggerCnt
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Area')
BEGIN
Delete from Mast_Area
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_AutoPost_Billing')
BEGIN
Delete from Bed_AutoPost_Billing
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Voucher_Number_TS')
BEGIN
Delete from Voucher_Number_TS
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_ENT')
BEGIN
Delete from EMR_ROS_ENT
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_ICD_Surgical_Procedure_OP')
BEGIN
Delete from Pat_ICD_Surgical_Procedure_OP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Pres_Dtl')
BEGIN
Delete from EMR_Pres_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Incineration_Dtl')
BEGIN
Delete from Blood_Incineration_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_EmployeeTemp')
BEGIN
Delete from Mast_EmployeeTemp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Primary_ICD_Code_OP')
BEGIN
Delete from Primary_ICD_Code_OP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Room')
BEGIN
Delete from Mast_Room
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_AutoPost_Cotrol_Panel_log')
BEGIN
Delete from Bed_AutoPost_Cotrol_Panel_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Allergic')
BEGIN
Delete from EMR_ROS_Allergic
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Ward_Caste')
BEGIN
Delete from A00061_Ward_Caste
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_CompConvt_Dtl')
BEGIN
Delete from Blood_CompConvt_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_User_IPAddress')
BEGIN
Delete from Mast_User_IPAddress
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Appt')
BEGIN
Delete from Mast_Doc_Appt
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Dept_link')
BEGIN
Delete from Dept_link
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_OTNote')
BEGIN
Delete from Mast_Dis_OTNote
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='ward_sumtest')
BEGIN
Delete from ward_sumtest
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Cond_Resale_Dtl')
BEGIN
Delete from Cond_Resale_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Service_type')
BEGIN
Delete from Mast_Service_type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Endo')
BEGIN
Delete from EMR_ROS_Endo
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Taluk')
BEGIN
Delete from Mast_Taluk
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doctor_06082016')
BEGIN
Delete from Mast_Doctor_06082016
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Eyes')
BEGIN
Delete from EMR_ROS_Eyes
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mail_Message_User')
BEGIN
Delete from Mail_Message_User
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='pMast_ReviewFee_06082016')
BEGIN
Delete from pMast_ReviewFee_06082016
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Status_Dtl')
BEGIN
Delete from Ward_Status_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Template')
BEGIN
Delete from EMR_ROS_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Pat_Note_Template')
BEGIN
Delete from EMR_Pat_Note_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBUpload_Doc')
BEGIN
Delete from BBUpload_Doc
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS')
BEGIN
Delete from EMR_ROS
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_OP_CaseSheet_Track')
BEGIN
Delete from MRD_OP_CaseSheet_Track
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mail_Reminder')
BEGIN
Delete from Mail_Reminder
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_IP_Adm_Doctor')
BEGIN
Delete from A00061_IP_Adm_Doctor
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Treatment_Dtl')
BEGIN
Delete from Pat_Treatment_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Preliminary_ICD_Code_Insurance')
BEGIN
Delete from Preliminary_ICD_Code_Insurance
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doctime_allot')
BEGIN
Delete from Doctime_allot
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Request')
BEGIN
Delete from Bed_Request
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Orders')
BEGIN
Delete from EMR_Orders
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Pat_Discharge_Int')
BEGIN
Delete from IP_Pat_Discharge_Int
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doctor_Comp')
BEGIN
Delete from Mast_Doctor_Comp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='DocTime_Schedule')
BEGIN
Delete from DocTime_Schedule
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PM_Hist')
BEGIN
Delete from EMR_PM_Hist
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Intercom')
BEGIN
Delete from Intercom
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PM_Hist_Template')
BEGIN
Delete from EMR_PM_Hist_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Proc_Appointment')
BEGIN
Delete from Proc_Appointment
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_ICD_Surgical_Procedure')
BEGIN
Delete from Pat_ICD_Surgical_Procedure
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Treatment')
BEGIN
Delete from Pat_Treatment
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Record_Param_Dtl')
BEGIN
Delete from Pat_Record_Param_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Pat_Bed_Transfer')
BEGIN
Delete from IP_Pat_Bed_Transfer
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Sumn_Info')
BEGIN
Delete from Pat_Sumn_Info
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE')
BEGIN
Delete from EMR_PE
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Bedblock')
BEGIN
Delete from Mast_Pat_Bedblock
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_CaseSheet_Status_Dtl')
BEGIN
Delete from MRD_CaseSheet_Status_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Pat_Discharge')
BEGIN
Delete from IP_Pat_Discharge
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Card_Orders')
BEGIN
Delete from EMR_Card_Orders
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Enquries_reminder')
BEGIN
Delete from Enquries_reminder
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_PE_Template')
BEGIN
Delete from EMR_PE_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mannual_reg_Log')
BEGIN
Delete from Mannual_reg_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Emr_Meds_Dtl_1804')
BEGIN
Delete from Emr_Meds_Dtl_1804
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Incident_Report')
BEGIN
Delete from Incident_Report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Police_Station')
BEGIN
Delete from Mast_Police_Station
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Marital_Status')
BEGIN
Delete from Mast_Marital_Status
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BedStatus_Log')
BEGIN
Delete from Mast_BedStatus_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_role_permission_Old')
BEGIN
Delete from Mast_role_permission_Old
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Appt_Type')
BEGIN
Delete from Mast_Appt_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_CaseSheet_Track')
BEGIN
Delete from A00061_CaseSheet_Track
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Stock_Level_Check')
BEGIN
Delete from BB_Stock_Level_Check
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Orders_Consult')
BEGIN
Delete from Pat_Orders_Consult
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Company_Home_Menu')
BEGIN
Delete from Mast_Company_Home_Menu
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Drug_Frequency')
BEGIN
Delete from Ward_Drug_Frequency
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ctrl_Printing')
BEGIN
Delete from Ctrl_Printing
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='OPReview_Case_Sheet_Request')
BEGIN
Delete from OPReview_Case_Sheet_Request
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BedOccSt_Log')
BEGIN
Delete from Mast_BedOccSt_Log
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Referal_Incentives_Log')
BEGIN
Delete from Referal_Incentives_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Mode_commu')
BEGIN
Delete from Mast_Mode_commu
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Primary_ICD_Code')
BEGIN
Delete from Primary_ICD_Code
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census')
BEGIN
Delete from MIS_Occ_Census
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Secendary_ICD_Code')
BEGIN
Delete from Secendary_ICD_Code
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Online_UserRegisterLst')
BEGIN
Delete from Online_UserRegisterLst
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='OP_Block')
BEGIN
Delete from OP_Block
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='CTS_Req_Dtl')
BEGIN
Delete from CTS_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_ICDCODE')
BEGIN
Delete from disch_summary_ICDCODE
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Emr_Meds_Dtl')
BEGIN
Delete from Emr_Meds_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Company_User_Rights')
BEGIN
Delete from Mast_Company_User_Rights
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_Consult')
BEGIN
Delete from Doc_Consult
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Corp_Bed_Block_Dtl')
BEGIN
Delete from Mast_Corp_Bed_Block_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Temp_FO_ReviewCheck')
BEGIN
Delete from Temp_FO_ReviewCheck
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_IP_Cover_Dtl')
BEGIN
Delete from Mast_IP_Cover_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_cardio')
BEGIN
Delete from EMR_ROS_cardio
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_infection')
BEGIN
Delete from Mast_infection
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Birth_Info')
BEGIN
Delete from Ward_Birth_Info
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Donate_Dtl')
BEGIN
Delete from Blood_Donate_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Med_Issdtl')
BEGIN
Delete from Pat_Med_Issdtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='OutPatient_FeedBack')
BEGIN
Delete from OutPatient_FeedBack
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_const')
BEGIN
Delete from EMR_ROS_const
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='CTS_Emp')
BEGIN
Delete from CTS_Emp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='tmpward')
BEGIN
Delete from tmpward
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Corp_Bed_Block')
BEGIN
Delete from Mast_Corp_Bed_Block
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Doc_Trans')
BEGIN
Delete from IP_Doc_Trans
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_New')
BEGIN
Delete from MIS_Occ_Census_New
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_OnCall')
BEGIN
Delete from Mast_OnCall
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Resp')
BEGIN
Delete from EMR_ROS_Resp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='DashBoard_Details')
BEGIN
Delete from DashBoard_Details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Doctor_Notes')
BEGIN
Delete from Pat_Doctor_Notes
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_Vital')
BEGIN
Delete from EMR_ROS_Vital
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_Patient_Update')
BEGIN
Delete from Log_Patient_Update
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Pay')
BEGIN
Delete from Mast_Doc_Pay
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Ref_Details')
BEGIN
Delete from Mast_Pat_Ref_Details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Doc_PE_Template')
BEGIN
Delete from EMR_Doc_PE_Template
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_FO')
BEGIN
Delete from MIS_Occ_Census_FO
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Soc_Hist')
BEGIN
Delete from EMR_Soc_Hist
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_HealthCard')
BEGIN
Delete from Mast_HealthCard
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_PatInfo')
BEGIN
Delete from Mast_PatInfo
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Feedback_Dtl')
BEGIN
Delete from Feedback_Dtl
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='all_india_PO_list')
BEGIN
Delete from all_india_PO_list
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_infection_dtl')
BEGIN
Delete from Pat_infection_dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_ROS_head')
BEGIN
Delete from EMR_ROS_head
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doctor_Opinion_OPIP')
BEGIN
Delete from Doctor_Opinion_OPIP
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_UserTrack')
BEGIN
Delete from Mast_UserTrack
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doctor_Opinion_Daignosis')
BEGIN
Delete from Doctor_Opinion_Daignosis
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Accident_Register')
BEGIN
Delete from Accident_Register
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_TS')
BEGIN
Delete from Mast_Patient_TS
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Record_Param')
BEGIN
Delete from Pat_Record_Param
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='HR_Hols')
BEGIN
Delete from HR_Hols
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Log_Diet_Grp')
BEGIN
Delete from Mast_Pat_Log_Diet_Grp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='order_Grp_dtl')
BEGIN
Delete from order_Grp_dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Fam_Hist')
BEGIN
Delete from EMR_Fam_Hist
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Donate')
BEGIN
Delete from Blood_Donate
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_Transfer')
BEGIN
Delete from Mast_Pat_Transfer
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='History_Mast_Patient')
BEGIN
Delete from History_Mast_Patient
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doctor_Recommended_BedType')
BEGIN
Delete from Doctor_Recommended_BedType
End
Go

IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Rad_Orders')
BEGIN
Delete from EMR_Rad_Orders
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Allergy_Reaction')
BEGIN
Delete from EMR_Allergy_Reaction
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Appt')
BEGIN
Delete from Mast_Appt
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00071_Ward_DisCons')
BEGIN
Delete from A00071_Ward_DisCons
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='ChartTypes')
BEGIN
Delete from ChartTypes
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBPat_Req')
BEGIN
Delete from BBPat_Req
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Equip_Bill')
BEGIN
Delete from Pat_Equip_Bill
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mast_moduleFunctionality')
BEGIN
Delete from mast_moduleFunctionality
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Header')
BEGIN
Delete from Mast_Header
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Display_DrugList')
BEGIN
Delete from Mast_Display_DrugList
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_Dashboard_UserActivity')
BEGIN
Delete from Log_Dashboard_UserActivity
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Print_Count')
BEGIN
Delete from A00061_Print_Count
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_Target')
BEGIN
Delete from Mast_Patient_Target
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Phone_Server')
BEGIN
Delete from Mast_Phone_Server
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_AutoPost')
BEGIN
Delete from Bed_AutoPost
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='ward_DisflagTemp')
BEGIN
Delete from ward_DisflagTemp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Ctrl_Drugtype')
BEGIN
Delete from Ward_Ctrl_Drugtype
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_UserPhone')
BEGIN
Delete from Mast_UserPhone
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_UHID')
BEGIN
Delete from Mast_Pat_UHID
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Phone_BillType')
BEGIN
Delete from Mast_Phone_BillType
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_BloodReqType')
BEGIN
Delete from Mast_BloodReqType
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BedCtrl_Panel')
BEGIN
Delete from BedCtrl_Panel
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Return')
BEGIN
Delete from Blood_Return
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Pending_Req')
BEGIN
Delete from Pat_Pending_Req
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Transfusion')
BEGIN
Delete from Blood_Transfusion
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_PhoneLocation')
BEGIN
Delete from Mast_PhoneLocation
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Preliminary_ICD_Code')
BEGIN
Delete from Preliminary_ICD_Code
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='tmp1')
BEGIN
Delete from tmp1
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Meds_OrderList')
BEGIN
Delete from IP_Meds_OrderList
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_UserMenuDef')
BEGIN
Delete from Mast_UserMenuDef
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Cube_Report_PivotGrid')
BEGIN
Delete from Cube_Report_PivotGrid
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Hist_Log_Delete')
BEGIN
Delete from Hist_Log_Delete
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MO_EMR_Service_Order_Dtl')
BEGIN
Delete from Mast_Doc_Appointment_Schedule_Reserve
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Pat_UHID_Dtl')
BEGIN
Delete from Mast_Pat_UHID_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBPat_Req_Dtl')
BEGIN
Delete from BBPat_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='PatCumulativeReport')
BEGIN
Delete from PatCumulativeReport
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Transfusion_Dtl')
BEGIN
Delete from Blood_Transfusion_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Allergy')
BEGIN
Delete from EMR_Allergy
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Mast_Doctor_Rate')
BEGIN
Delete from A00061_Mast_Doctor_Rate
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dis_summary_log')
BEGIN
Delete from Mast_Dis_summary_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Doc_Visit')
BEGIN
Delete from IP_Doc_Visit
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dept_Appt')
BEGIN
Delete from Mast_Dept_Appt
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MHCRegNo')
BEGIN
Delete from MHCRegNo
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_Temp')
BEGIN
Delete from Mast_Patient_Temp
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Running_Nos_Log')
BEGIN
Delete from Ward_Running_Nos_Log
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Lab_DeNormalize_Info')
BEGIN
Delete from Lab_DeNormalize_Info
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mast_appointment')
BEGIN
Delete from mast_appointment
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_Appointment')
BEGIN
Delete from Doc_Appointment
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Def_Sch_Display')
BEGIN
Delete from Mast_Def_Sch_Display
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Equipment_Result')
BEGIN
Delete from Blood_Equipment_Result
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_Enquries')
BEGIN
Delete from Mast_Patient_Enquries
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MyPatientList_Type')
BEGIN
Delete from MyPatientList_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_report_BoldHdr')
BEGIN
Delete from disch_summary_report_BoldHdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_docleave_Details')
BEGIN
Delete from Mast_docleave_Details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_docleave_Details')
BEGIN
Delete from Mast_docleave_Details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Dept_Sch')
BEGIN
Delete from Mast_Dept_Sch
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_RefLetter_Dtl')
BEGIN
Delete from Pat_RefLetter_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Transfusion_App')
BEGIN
Delete from Blood_Transfusion_App
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Notification_Group')
BEGIN
Delete from BB_Notification_Group
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_Doctor_Visit')
BEGIN
Delete from IP_Doctor_Visit
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Blood_Return_Req')
BEGIN
Delete from Blood_Return_Req
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_Xray_Scan_Film_New_Receive')
BEGIN
Delete from MRD_Xray_Scan_Film_New_Receive
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='disch_summary_report')
BEGIN
Delete from disch_summary_report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Death_Register')
BEGIN
Delete from Mast_Death_Register
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Referal_Incentives_Hdr')
BEGIN
Delete from Referal_Incentives_Hdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Company_Holiday_List')
BEGIN
Delete from Mast_Company_Holiday_List
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Blood_Type')
BEGIN
Delete from BB_Blood_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_Film_Request')
BEGIN
Delete from MRD_Film_Request
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Notification_Group_Dtl')
BEGIN
Delete from BB_Notification_Group_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_DoctorNurse_Notes_log')
BEGIN
Delete from Pat_DoctorNurse_Notes_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Referal_Incentives_Post')
BEGIN
Delete from Referal_Incentives_Post
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MannualReg_Log_Details')
BEGIN
Delete from MannualReg_Log_Details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Patient_Count')
BEGIN
Delete from A00061_Patient_Count
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Hospital')
BEGIN
Delete from Mast_Hospital
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Notification')
BEGIN
Delete from BB_Notification
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Referal_Utilization_Log')
BEGIN
Delete from Referal_Utilization_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_Film_Receive')
BEGIN
Delete from MRD_Film_Receive
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='A00061_Slot_Count')
BEGIN
Delete from A00061_Slot_Count
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_Allergy_Type')
BEGIN
Delete from Pat_Allergy_Type
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_IP_Admission')
BEGIN
Delete from Mast_IP_Admission
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Pat_DoctorNurse_Comments')
BEGIN
Delete from Pat_DoctorNurse_Comments
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_User_CompAccess')
BEGIN
Delete from Mast_User_CompAccess
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_Update_Log')
BEGIN
Delete from Mast_Patient_Update_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_BudgetDashboard')
BEGIN
Delete from Log_BudgetDashboard
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Patient_IDProof')
BEGIN
Delete from Mast_Patient_IDProof
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='PATIENT_MLC_REGISTER')
BEGIN
Delete from PATIENT_MLC_REGISTER
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='FeedBack_Tmpl_Dtl')
BEGIN
Delete from FeedBack_Tmpl_Dtl 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='FeedBack_Tmpl_Hdr')
BEGIN
Delete from FeedBack_Tmpl_Hdr
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Ward_CDept')
BEGIN
Delete from Mast_Ward_CDept
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Pharmaprint_Log')
BEGIN
Delete from Ward_Pharmaprint_Log 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='CKC_IDCard_PrintPath')
BEGIN
Delete from Kmch_FrontOffice..CKC_IDCard_PrintPath
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Token_report')
BEGIN
Delete from Kmch_FrontOffice..Token_report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='ER_Token_Pat_details')
BEGIN
Delete from Kmch_FrontOffice..ER_Token_Pat_details
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BBPat_Req_Issue_Dtl_Cancel_Log')
BEGIN
Delete from BBPat_Req_Issue_Dtl_Cancel_Log  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_Appointment_Cancel')
BEGIN
Delete from Doc_Appointment_Cancel  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Appointment_Schedule_Log')
BEGIN
Delete from Mast_Doc_Appointment_Schedule_Log  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Pres_Appr_Log')
BEGIN
Delete from EMR_Pres_Appr_Log  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Birthreg_Attach')
BEGIN
Delete from Mast_Birthreg_Attach  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Loyalty_Card_Duplicate_Issue')
BEGIN
Delete from Loyalty_Card_Duplicate_Issue  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Loyalty_Card_Registration')
BEGIN
Delete from Loyalty_Card_Registration  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IPREGCHECK')
BEGIN
Delete from IPREGCHECK 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='EMR_Tmp_Presidlog')
BEGIN 
Delete from EMR_Tmp_Presidlog  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_utilization_log')
BEGIN 
Delete from Bed_utilization_log  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_utilization_log_Vaccant')
BEGIN 
Delete from Bed_utilization_log_Vaccant  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_utilization_log_All_Vaccant')
BEGIN 
Delete from Bed_utilization_log_All_Vaccant  
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_FO')
BEGIN 
Delete from MIS_Occ_Census_FO  
End

Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census')
BEGIN 
Delete from MIS_Occ_Census  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Eligibility_Coverage')
BEGIN 
Delete from Insurance_Eligibility_Coverage  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Eligibility_PatientShare')
BEGIN 
Delete from Insurance_Eligibility_PatientShare  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Create_Patient_RCM')
BEGIN 
Delete from Insurance_Create_Patient_RCM  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Eligibility_Request_Attachment')
BEGIN 
Delete from Insurance_Eligibility_Request_Attachment  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Approval_Response')
BEGIN 
Delete from Insurance_Approval_Response  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='HM_Patient_Registration')
BEGIN 
Delete from HM_Patient_Registration  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Card_Read_Patient_RCM')
BEGIN 
Delete from Insurance_Card_Read_Patient_RCM  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Eligibility_Request')
BEGIN 
Delete from Insurance_Eligibility_Request  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Insurance_Eligibility_Response')
BEGIN 
Delete from Insurance_Eligibility_Response  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='HM_Patient_Session')
BEGIN 
Delete from HM_Patient_Session  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='HM_Patient_Vascular_Access')
BEGIN 
Delete from HM_Patient_Vascular_Access  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='HM_Patient_Visit_Schedule')
BEGIN 
Delete from HM_Patient_Visit_Schedule  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_FO_Old')
BEGIN 
Delete from MIS_Occ_Census_FO_Old  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MIS_Occ_Census_Old')
BEGIN 
Delete from MIS_Occ_Census_Old  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_Details')
BEGIN 
Delete from Log_Details  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doctor_OPCount')
BEGIN 
Delete from Doctor_OPCount  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_utilization_log_All')
BEGIN 
Delete from Bed_utilization_log_All  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Donor_Registration')
BEGIN 
Delete from BB_Donor_Registration  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Donor_Registration')
BEGIN 
Delete from Blood_Donate
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='BB_Donor_Registration')
BEGIN 
Delete from BB_Questionnaire_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Log_User')
BEGIN 
Delete from Mast_Log_User 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Modified_Files')
BEGIN 
Delete from Modified_Files  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_DailyDashboard_20141224')
BEGIN 
Delete from Log_DailyDashboard_20141224  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_DailyDashboard')
BEGIN 
Delete from Log_DailyDashboard  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nurse_Handover')
BEGIN 
Delete from Nurse_Handover  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='nurse_handover_Dtl')
BEGIN 
Delete from nurse_handover_Dtl  
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Log_Dashboard_UserActivity')
BEGIN 
Delete from Log_Dashboard_UserActivity  
End
 Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='RCM_Token')
BEGIN 
Delete from RCM_Token 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_IP_CaseSheet_Track')
BEGIN 
Delete from MRD_IP_CaseSheet_Track 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Fumg_Schd')
BEGIN 
Delete from Bed_Fumg_Schd 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Fumg_Req')
BEGIN 
Delete from Bed_Fumg_Req 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Bed_Fumg_Proc')
BEGIN 
Delete from Bed_Fumg_Proc 
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_IP_Admission_Billable_BedType_Log')
BEGIN 
Delete from Mast_IP_Admission_Billable_BedType_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Fumg_Attach')
BEGIN 
Delete from Mast_Fumg_Attach
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_Incident')
BEGIN 
Delete from Nrsg_Incident
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_Diabetic_Error')
BEGIN 
Delete from Nrsg_Diabetic_Error
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_Drug_Error')
BEGIN 
Delete from Nrsg_Drug_Error
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_IP_FeedBack')
BEGIN 
Delete from Nrsg_IP_FeedBack
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_Postdiscall_Report')
BEGIN 
Delete from Nrsg_Postdiscall_Report
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Nrsg_Pressure_Sore')
BEGIN 
Delete from Nrsg_Pressure_Sore
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Users_PassLog')
BEGIN 
Delete from Mast_Users_PassLog
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_IP_Admission_Billable_BedType_Log')
BEGIN 
Delete from Mast_IP_Admission_Billable_BedType_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='t')
BEGIN 
Delete from t
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='t')
BEGIN 
Delete from t
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Birth_Nurse_Dtl')
BEGIN 
Delete from Birth_Nurse_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='IP_ER_Triage_Dtl')
BEGIN 
Delete from IP_ER_Triage_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Dis_Handover_Dtl')
BEGIN 
Delete from Dis_Handover_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_Dis_Handover')
BEGIN 
Delete from Ward_Dis_Handover
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='FO_Online_Bill_Data')
BEGIN 
Delete from FO_Online_Bill_Data
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Online_Transaction')
BEGIN 
Delete from Online_Transaction
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Mast_Doc_Appointment_Schedule_Week_Day_Log')
BEGIN 
Delete from Mast_Doc_Appointment_Schedule_Week_Day_Log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_DI_Req')
BEGIN 
Delete from kmch_Frontoffice..Doc_DI_Req
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='ward_discharge_chkoutslip_log')
BEGIN 
Delete from kmch_Frontoffice..ward_discharge_chkoutslip_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='MRD_File_Reserve')
BEGIN 
Delete from kmch_Frontoffice..MRD_File_Reserve
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mrdtrack_log')
BEGIN 
Delete from kmch_Frontoffice..mrdtrack_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='tempRecvmrd')
BEGIN 
Delete from kmch_Frontoffice..tempRecvmrd
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Doc_Appointment_BlockUnBlock')
BEGIN 
Delete from kmch_Frontoffice..Doc_Appointment_BlockUnBlock
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='PATIENT_ER_REGISTER')
BEGIN 
Delete from kmch_Frontoffice..PATIENT_ER_REGISTER
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='mstJobDescriptionLevelMatch')
BEGIN 
Delete from kmch_Frontoffice..mstJobDescriptionLevelMatch
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Tmp_OPStatisticsView')
BEGIN 
Delete from kmch_Frontoffice..Tmp_OPStatisticsView
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_API_Token')
BEGIN 
Delete from kmch_Frontoffice..Ward_API_Token
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='Ward_API_Status_log')
BEGIN 
Delete from kmch_Frontoffice..Ward_API_Status_log
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='FO_SRM_APIResult')
BEGIN 
Delete from kmch_Frontoffice..FO_SRM_APIResult
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='SRM_Fo_API')
BEGIN 
Delete from kmch_Frontoffice..SRM_Fo_API
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='JD_Hod_Interview_Dtl')
BEGIN 
Delete from kmch_Frontoffice..JD_Hod_Interview_Dtl
End
Go
IF EXISTS(select * from Kmch_Frontoffice.sys.objects where type='U' and name='JD_Hod_Interview_Hdr')
BEGIN 
Delete from kmch_Frontoffice..JD_Hod_Interview_Hdr
End
Go

USe Kmch_hr
Go
-- Tables Of Predefined Values , Masters and Settings
/*
CP_DeductionType
CP_AllowanceType
Mast_Static_Deduction_Name
Mast_Static_Allowance_Name
Mast_Month
Mast_Employee_Log
Mast_InstutionESINo
Mast_Resignation_Type
Mast_Vaccine_Category
Mast_Department
Emp_CumLeave
Mast_Vaccine_Category_Mapping
Mast_BloodGroup
Mast_Emp_Type
Mast_Emp_Addr
Mast_Hostel
Mast_Degree
Mast_Language
Mast_Relation
Mast_Training_Category
Mast_Client_Name
Mast_Allowance
Mast_Training_Sub_Category
Mast_Leave
CP_VehicleType
Mast_NoDue_Certificate_Header
Mast_NoDue_Certificate_Header_Dept_Mapping
Mast_Vaccine
Mast_Certificate
Mast_Floor_Mast_Store_Mapping
Mast_Budget_Header
Mast_Resign_Notice_Period
Mast_Salary_Class
Mast_Salary_Bank
Mast_Floor_HR_Dept_Mapping
Mast_Salary_Class_Percentage
Mast_Floor
Mast_Vehicle
Mast_Wage_Category
Mast_Parking_Area
Mast_Employee
Mast_Emp_Certificate
Mast_NoDue_Certificate_Header_HOD_Mapping
Mast_Salary_Digital_Sign_Hierarchy
Mast_HOD_Dept_Mapping
Mast_Emp_Addr_Emergency
Mast_Dept_Hierarchy
Mast_Emp_Vehicle
Mast_Professional_Tax
Mast_Emp_Category
Mast_Caste
Mast_Emp_Dependance
CP_Salary_Date
Mast_University
Emp_LeaveApprove_DeptHead
Mast_Employee_ReportTo_HOD
Mast_Emp_Exp
Mast_Salary_Category
Mast_Resign_Exit_Interview
Mast_Emp_Degree
Mast_Community
Mast_Designation
Mast_Budget_Header_ReportsTo
Mast_HOD_Branch_Group_Mapping
Mast_Vaccine_Dose
Mast_Branch_Group
Mast_EB_Water_Dept_Percentage
Mast_Branch_Addr
Mast_Shift
Mast_Deduction
Mast_Emp_Lang
Mast_Religion
CP_Cal
Mast_EmpImage
Mast_Dept_Group
Mast_Branch
NumberWords
 KPO_Project_Requirement  
FROM KPO_Service_Type  
FROM KPO_Mast_Project  
FROM KPO_Mast_Client 
Mast_Certificate_Designation_Applicable
Mast_Document_Type
Recruit_Job_Post_Control_Panel
*/
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Earning_Salary_Log')
BEGIN
Delete from A00061_Emp_Earning_Salary_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Monthly_Attendance_Entry')
BEGIN
Delete from Monthly_Attendance_Entry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Mast_Conference_Allowance')
BEGIN
Delete from A00061_Mast_Conference_Allowance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_sundays')
BEGIN
Delete from Mast_sundays
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_AutoAllowance_PreApprove')
BEGIN
Delete from Emp_AutoAllowance_PreApprove
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Conference_Allowance_Post')
BEGIN
Delete from A00061_Conference_Allowance_Post
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Temp_Trigger')
BEGIN
Delete from Temp_Trigger
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Earning_Salary')
BEGIN
Delete from A00061_Emp_Earning_Salary
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Temp_TriggerCnt')
BEGIN
Delete from Temp_TriggerCnt
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Salary_Attendance_Period')
BEGIN
Delete from Mast_Salary_Attendance_Period
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Budget_Dept_Month')
BEGIN
Delete from Budget_Dept_Month
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Salary_Increment_Arrear_Log')
BEGIN
Delete from Salary_Increment_Arrear_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Budget_Inven_Month')
BEGIN
Delete from Budget_Inven_Month
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_NoDue_Certificate')
BEGIN
Delete from Mast_NoDue_Certificate
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Salary_Log')
BEGIN
Delete from A00061_Emp_Salary_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Annual_Health_Checkup_Log')
BEGIN
Delete from Emp_Annual_Health_Checkup_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_CarryOver_Salary_Post_Remove')
BEGIN
Delete from A00061_CarryOver_Salary_Post_Remove
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='CP_HHMMSS')
BEGIN
Delete from CP_HHMMSS
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_CarryOver_Salary_Post')
BEGIN
Delete from A00061_CarryOver_Salary_Post
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_WeekOff')
BEGIN
Delete from Emp_WeekOff
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_AutoAllowance_LOG')
BEGIN
Delete from Emp_AutoAllowance_LOG
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Resign')
BEGIN
Delete from Emp_Resign
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Emp_Holiday')
BEGIN
Delete from Mast_Emp_Holiday
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_NoDue_Certificate')
BEGIN
Delete from Emp_NoDue_Certificate
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_ResignNotice')
BEGIN
Delete from Emp_ResignNotice
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Monthly_Leave_Post_Log')
BEGIN
Delete from Monthly_Leave_Post_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Emp_Signature')
BEGIN
Delete from Mast_Emp_Signature
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Punch_Import_Log')
BEGIN
Delete from Punch_Import_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='duty13')
BEGIN
Delete from duty13
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Attendance')
BEGIN
Delete from Emp_Attendance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_DutyRoster_Day')
BEGIN
Delete from Emp_DutyRoster_Day
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Holiday')
BEGIN
Delete from Mast_Holiday
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Salary_Digital_Sign_Approve')
BEGIN
Delete from Salary_Digital_Sign_Approve
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Earning_Salary_Dtl')
BEGIN
Delete from A00061_Emp_Earning_Salary_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Punch_Import')
BEGIN
Delete from Punch_Import
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Training_Schedule')
BEGIN
Delete from Mast_Training_Schedule
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Allowance')
BEGIN
Delete from Emp_Allowance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='EMP_Deduction')
BEGIN
Delete from EMP_Deduction
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Payslip_Email_Send')
BEGIN
Delete from Payslip_Email_Send
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Compensation')
BEGIN
Delete from Emp_Compensation
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_AttendanceImport')
BEGIN
Delete from Emp_AttendanceImport
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Leave_Alternate')
BEGIN
Delete from Emp_Leave_Alternate
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Training_Schedule_Log')
BEGIN
Delete from Mast_Training_Schedule_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Training_Attendees')
BEGIN
Delete from Mast_Training_Attendees
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='TimeSheet_Entry_Log')
BEGIN
Delete from TimeSheet_Entry_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='TimeSheet_Entry')
BEGIN
Delete from TimeSheet_Entry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_OverTime_Calculation_Formula')
BEGIN
Delete from Mast_OverTime_Calculation_Formula
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_CumLeave_Log')
BEGIN
Delete from Emp_CumLeave_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Designation_Hierarchy')
BEGIN
Delete from Mast_Designation_Hierarchy
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Emp_Addr_Log')
BEGIN
Delete from Mast_Emp_Addr_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Salary')
BEGIN
Delete from A00061_Emp_Salary
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='MOSC_LICDetail')
BEGIN
Delete from MOSC_LICDetail
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Yearly_Leave_Post_Log')
BEGIN
Delete from Yearly_Leave_Post_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Lic_Deduction')
BEGIN
Delete from A00061_Emp_Lic_Deduction
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Leave')
BEGIN
Delete from Emp_Leave
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Forms_Header')
BEGIN
Delete from Forms_Header
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_FO_Dept_Deduction_Match')
BEGIN
Delete from Mast_FO_Dept_Deduction_Match
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Emp_NoImage')
BEGIN
Delete from Mast_Emp_NoImage
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='CP_SalaryHold')
BEGIN
Delete from CP_SalaryHold
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='CP_Budget_Header')
BEGIN
Delete from CP_Budget_Header
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_PF_Voluntary')
BEGIN
Delete from Mast_PF_Voluntary
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_BudgetHeader_Dept_Mapping')
BEGIN
Delete from Mast_BudgetHeader_Dept_Mapping
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Salary_NegativeSalary_Check')
BEGIN
Delete from A00061_Emp_Salary_NegativeSalary_Check
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_OverTime')
BEGIN
Delete from Emp_OverTime
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_OnDuty')
BEGIN
Delete from Emp_OnDuty
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_AutoAllowance')
BEGIN
Delete from Emp_AutoAllowance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Vaccination_Entry_Log')
BEGIN
Delete from Emp_Vaccination_Entry_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Salary_Increment_Arrear')
BEGIN
Delete from Salary_Increment_Arrear
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Session')
BEGIN
Delete from Session
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Salary_Leave_Carry')
BEGIN
Delete from A00061_Salary_Leave_Carry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Permission')
BEGIN
Delete from Emp_Permission
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='duty26')
BEGIN
Delete from duty26
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Vaccination_Entry')
BEGIN
Delete from Emp_Vaccination_Entry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Earning_Salary_NegativeSalary_Check_Dtl')
BEGIN
Delete from A00061_Emp_Earning_Salary_NegativeSalary_Check_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Salary_Leave_Balance')
BEGIN
Delete from A00061_Salary_Leave_Balance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Gratuity_LOP')
BEGIN
Delete from Gratuity_LOP
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Annual_Health_Checkup')
BEGIN
Delete from Emp_Annual_Health_Checkup
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='sysdiagrams')
BEGIN
Delete from sysdiagrams
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Mast_Training_Attendees_Log')
BEGIN
Delete from Mast_Training_Attendees_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_AutoDeduction')
BEGIN
Delete from Emp_AutoDeduction
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Emp_Leave_Log')
BEGIN
Delete from Emp_Leave_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='A00061_Emp_Earning_Salary_NegativeSalary_Check')
BEGIN
Delete from A00061_Emp_Earning_Salary_NegativeSalary_Check
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Salary_Narration_Entry')
BEGIN
Delete from Salary_Narration_Entry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='KPO_Project_Allocation_QC')
BEGIN
Delete from KPO_Project_Allocation_QC
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='KPO_Project_Allocation_Prod')
BEGIN
Delete from KPO_Project_Allocation_Prod
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Recruit_Job_Offer')
BEGIN
Delete from kmch_hr..Recruit_Job_Offer
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Recruit_Job_OnBoard_Certificate')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Certificate
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Recruit_Job_OnBoard_Dependent')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Dependent
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Recruit_Job_OnBoard_Education')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Education
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Recruit_Job_OnBoard_Experience')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Experience
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Recruit_Job_OnBoard_Language')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Language
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='Recruit_Job_OnBoard_OTP')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_OTP
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Recruit_Job_OnBoard_Personal_Details')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Personal_Details
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Recruit_Job_OnBoard_Document_Upload')
BEGIN
Delete from kmch_hr..Recruit_Job_OnBoard_Document_Upload
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_PolicyAccept')
BEGIN
Delete from kmch_hr..Emp_PolicyAccept
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_CTCAllowance')
BEGIN
Delete from kmch_hr..Emp_CTCAllowance
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_Circular_Read')
BEGIN
Delete from kmch_hr..Emp_Circular_Read
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_RolesAndResponsibilities')
BEGIN
Delete from kmch_hr..Emp_RolesAndResponsibilities
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_Project')
BEGIN
Delete from kmch_hr..Emp_Project
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_MISPunch_Eliminate')
BEGIN
Delete from kmch_hr..Mast_MISPunch_Eliminate
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_DepartmentShiftMapping')
BEGIN
Delete from kmch_hr..Mast_DepartmentShiftMapping
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_Probation')
BEGIN
Delete from kmch_hr..Emp_Probation
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_GraceTime')
BEGIN
Delete from kmch_hr..Emp_GraceTime
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..EmployeeNoDue_Dtl')
BEGIN
Delete from kmch_hr..EmployeeNoDue_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..EmployeeNoDue_Hdr')
BEGIN
Delete from kmch_hr..EmployeeNoDue_Hdr
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_Resignation')
BEGIN
Delete from kmch_hr..Emp_Resignation
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..mstJobDescription_Log')
BEGIN
Delete from kmch_hr..mstJobDescription_Log
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Tmp_PunchpostMonitor')
BEGIN
Delete from kmch_hr..Tmp_PunchpostMonitor
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_PunchPostManualMonitor')
BEGIN
Delete from kmch_hr..Emp_PunchPostManualMonitor
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..mstJobDescriptionLevelMatch')
BEGIN
Delete from kmch_hr..mstJobDescriptionLevelMatch
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Job_Referral')
BEGIN
Delete from kmch_hr..Job_Referral
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_JDAttachments')
BEGIN
Delete from kmch_hr..Mast_JDAttachments
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..JD_Hod_Interview_Dtl')
BEGIN
Delete from kmch_hr..JD_Hod_Interview_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..JD_Hod_Interview_Hdr')
BEGIN
Delete from kmch_hr..JD_Hod_Interview_Hdr
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Job_Schedule')
BEGIN
Delete from kmch_hr..Job_Schedule
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..mstJobDescription')
BEGIN
Delete from kmch_hr..mstJobDescription
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_Emp_Addr_Emergency_Temp')
BEGIN
Delete from kmch_hr..Mast_Emp_Addr_Emergency_Temp
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_Address_Entry')
BEGIN
Delete from kmch_hr..Emp_Address_Entry
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_IDCard_Request')
BEGIN
Delete from kmch_hr..Emp_IDCard_Request
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_PunchDevice_Dtl')
BEGIN
Delete from kmch_hr..Mast_PunchDevice_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Mast_KMCH_MedicalCollege_VL_Branch')
BEGIN
Delete from kmch_hr..Mast_KMCH_MedicalCollege_VL_Branch
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_AssetAllocation_Dtl')
BEGIN
Delete from kmch_hr..Emp_AssetAllocation_Dtl
End
Go
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..Emp_AssetAllocation_Hdr')
BEGIN
Delete from kmch_hr..Emp_AssetAllocation_Hdr
End
IF EXISTS(select * from KMCH_HR.sys.objects where type='U' and name='kmch_hr..WorkingHrs')
BEGIN
Delete from kmch_hr..WorkingHrs
End
Go

Go

Use KMCH_MHC

Go
-- Tables Of Predefined Values , Masters and Settings
/*
EMR_MHC_Pat_Dtl
MHC_Reports
EMR_MHC_TempFld_Hdr
Ctrl_Panel_MHC
EMR_Note_Template
Master_Reports
Emr_Vitals
Prn_Settings_MHC
EMR_MHC_Template
MHC_Template_Hdr
EMR_MHC_Pat_Dtl
*/
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Diag_Template')
BEGIN
Delete from EMR_OCR_Diag_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='MHC_Template_Hdr_Dtl')
BEGIN
Delete from MHC_Template_Hdr_Dtl
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Doc_Hist_Template')
BEGIN
Delete from EMR_Doc_Hist_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_BMI_Elements')
BEGIN
Delete from Emr_BMI_Elements
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Mast_MHC_Template')
BEGIN
Delete from Mast_MHC_Template
End
Go

IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Joints')
BEGIN
Delete from EMR_PE_Joints
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Doc_Ocr_Template')
BEGIN
Delete from EMR_Doc_Ocr_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Joints_Template')
BEGIN
Delete from EMR_PE_Joints_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Resp')
BEGIN
Delete from EMR_PE_Resp
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Fund_Template')
BEGIN
Delete from EMR_OCR_Fund_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='MHC_Template_Notes_Summary')
BEGIN
Delete from MHC_Template_Notes_Summary
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_General')
BEGIN
Delete from EMR_PE_General
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='MHC_Patient_Notes_Summary')
BEGIN
Delete from MHC_Patient_Notes_Summary
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Pat_Note_Template')
BEGIN
Delete from EMR_Pat_Note_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Diag')
BEGIN
Delete from EMR_OCR_Diag
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_BMI_Class')
BEGIN
Delete from Emr_BMI_Class
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Doc_Ros_Template')
BEGIN
Delete from EMR_Doc_Ros_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='MHC_Doctor_List')
BEGIN
Delete from MHC_Doctor_List
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='emr_pe_vision')
BEGIN
Delete from emr_pe_vision
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_Resp_Template')
BEGIN
Delete from EMR_ROS_Resp_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_ENT_Note')
BEGIN
Delete from Emr_ENT_Note
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_vision_Template')
BEGIN
Delete from EMR_PE_vision_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Gen_Notes')
BEGIN
Delete from Emr_Gen_Notes
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Vitals_Value')
BEGIN
Delete from Emr_Vitals_Value
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_Vital')
BEGIN
Delete from EMR_ROS_Vital
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_cardio')
BEGIN
Delete from EMR_ROS_cardio
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_Vital_Template')
BEGIN
Delete from EMR_ROS_Vital_Template
End
Go

IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_cardio_Template')
BEGIN
Delete from EMR_ROS_cardio_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR')
BEGIN
Delete from EMR
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Template')
BEGIN
Delete from EMR_OCR_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_CNS_Template')
BEGIN
Delete from EMR_PE_CNS_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Fam_Hist_Template')
BEGIN
Delete from EMR_Fam_Hist_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Anterior')
BEGIN
Delete from EMR_OCR_Anterior
End
Go

IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='MHC_Note_Gen_Template')
BEGIN
Delete from MHC_Note_Gen_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_CNS')
BEGIN
Delete from EMR_PE_CNS
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Anterior_Template')
BEGIN
Delete from EMR_OCR_Anterior_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_WWC_Notes')
BEGIN
Delete from Emr_WWC_Notes
End
Go

IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_OCR_Fund')
BEGIN
Delete from EMR_OCR_Fund
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Soc_Hist_Template')
BEGIN
Delete from EMR_Soc_Hist_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Mast_Pat_Hist')
BEGIN
Delete from Mast_Pat_Hist
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_General_Template')
BEGIN
Delete from EMR_PE_General_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Resp_Template')
BEGIN
Delete from EMR_PE_Resp_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Doc_Note_Template')
BEGIN
Delete from Doc_Note_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Doc_Eye_Note_Template')
BEGIN
Delete from Doc_Eye_Note_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Mast_Patient_History')
BEGIN
Delete from Mast_Patient_History
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Abdomen')
BEGIN
Delete from EMR_PE_Abdomen
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Gen_EMR')
BEGIN
Delete from Gen_EMR
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Abdomen_Template')
BEGIN
Delete from EMR_PE_Abdomen_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='A00061_MHCSchedule')
BEGIN
Delete from A00061_MHCSchedule
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Gen_Emr_Note_Elements')
BEGIN
Delete from Gen_Emr_Note_Elements
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Dental_Exams')
BEGIN
Delete from Emr_Dental_Exams
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_CVS')
BEGIN
Delete from EMR_PE_CVS
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='emr_Personal')
BEGIN
Delete from emr_Personal
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_CVS_Template')
BEGIN
Delete from EMR_PE_CVS_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Note_Elements')
BEGIN
Delete from Emr_Note_Elements
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='emr_Personal_Template')
BEGIN
Delete from emr_Personal_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Gen_Emr_Vitals_Value')
BEGIN
Delete from Gen_Emr_Vitals_Value
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='emr_stress_hist_template')
BEGIN
Delete from emr_stress_hist_template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Eye_Acuity')
BEGIN
Delete from Emr_Eye_Acuity
End
Go

IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Doc_ENT_Note_Template')
BEGIN
Delete from Doc_ENT_Note_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_Hist_Template')
BEGIN
Delete from EMR_Hist_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Bowel_Template')
BEGIN
Delete from EMR_PE_Bowel_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Pat_Notes')
BEGIN
Delete from Pat_Notes
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='Emr_Gynaec_Template')
BEGIN
Delete from Emr_Gynaec_Template
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_BBH')
BEGIN
Delete from EMR_PE_BBH
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_ROS_Resp')
BEGIN
Delete from EMR_ROS_Resp
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_PE_Skin')
BEGIN
Delete from EMR_PE_Skin
End
Go
IF EXISTS(select * from KMCH_MHC.sys.objects where type='U' and name='EMR_MHC_Pat_Dtl')
BEGIN
Delete from EMR_MHC_Pat_Dtl
END
Go
Use KMCH_OT
GO
-- Tables Of Predefined Values , Masters and Settings
/*
Pat_OT_Assessment
Mast_Theater
Mast_Surgery
Mast_AsessmentTemplate_dtl
Mast_Pat_SurgeryType
Mast_CancelReason
Mast_AsessmentTemplate
OT_Template_Hdr
Mast_Position
Mast_Group
Mast_Group_Service
Mast_Anaes_Grp
Mast_Anaes
Mast_Surgery_Type
Mast_OTComplex
OT_Template_Dtl
OT_Surgery_Template
Control_Panel
Mast_AsessmentTemplateGroup
CathLab_Book_Cancel_Reason
Mast_Proc_Method
Mast_Doctor_Day_Schedule
HM_WeekDay
Mast_ClinicalActivity_Dtl
Mast_ClinicalActivity_Category
*/
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Genral_Anaesthesia')
BEGIN
Delete from Pat_OT_Genral_Anaesthesia
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_REPORT_CONTROL_PANEL')
BEGIN
Delete from OT_REPORT_CONTROL_PANEL
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Quality_Complications')
BEGIN
Delete from Pat_OT_Quality_Complications
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Book_Cancel')
BEGIN
Delete from Pat_OT_Book_Cancel
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Doctor_Fee')
BEGIN
Delete from OT_Doctor_Fee
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Tempcheck')
BEGIN
Delete from Tempcheck
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Special_Equip')
BEGIN
Delete from OT_Special_Equip
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Job_AutoPost_Log')
BEGIN
Delete from Job_AutoPost_Log
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Diagnosis')
BEGIN
Delete from OT_Booking_Diagnosis
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Theater_Table')
BEGIN
Delete from Mast_Theater_Table
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Aneas_Technician')
BEGIN
Delete from Pat_OT_Aneas_Technician
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Monitoring')
BEGIN
Delete from Mast_Monitoring
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Unit')
BEGIN
Delete from Mast_Unit
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_BloodGroup')
BEGIN
Delete from Mast_BloodGroup
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Billing_Surgery')
BEGIN
Delete from Pat_OT_Job_Billing_Surgery
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Assessment_Doc')
BEGIN
Delete from OT_Booking_Assessment_Doc
End
Go

IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Complication')
BEGIN
Delete from Mast_Complication
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_RS')
BEGIN
Delete from Mast_RS
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_PAC_Surgeon')
BEGIN
Delete from OT_PAC_Surgeon
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_CVS')
BEGIN
Delete from Mast_CVS
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_PAC_Proc')
BEGIN
Delete from OT_PAC_Proc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_AneasDoc')
BEGIN
Delete from OT_Booking_AneasDoc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Posting')
BEGIN
Delete from Pat_OT_Job_Posting
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_PAC')
BEGIN
Delete from OT_PAC
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_CheckList_Surgery_Mapping')
BEGIN
Delete from Mast_CheckList_Surgery_Mapping
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_CheckList_Dtl')
BEGIN
Delete from Pat_CheckList_Dtl
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Doc')
BEGIN
Delete from Pat_OT_Job_Doc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Circulate_Nurse')
BEGIN
Delete from Pat_OT_Circulate_Nurse
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='PAT_OT_PAC')
BEGIN
Delete from PAT_OT_PAC
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_WHO_CheckList_Dtl')
BEGIN
Delete from Pat_WHO_CheckList_Dtl
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Surgery_Price_Matrix')
BEGIN
Delete from Surgery_Price_Matrix
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Billing_Surgery')
BEGIN
Delete from Mast_Billing_Surgery
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_WHO_CheckList')
BEGIN
Delete from Pat_WHO_CheckList
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Proc')
BEGIN
Delete from OT_Booking_Proc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Surgeon')
BEGIN
Delete from OT_Booking_Surgeon
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Scrub_Nurse')
BEGIN
Delete from Pat_OT_Scrub_Nurse
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Proc')
BEGIN
Delete from Pat_OT_Job_Proc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Primary_Surgeon')
BEGIN
Delete from Pat_OT_Job_Primary_Surgeon
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_WHO_CheckList')
BEGIN
Delete from Mast_WHO_CheckList
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Perfusionist')
BEGIN
Delete from Pat_OT_Perfusionist
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Booking')
BEGIN
Delete from Pat_OT_Booking
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_CheckList')
BEGIN
Delete from Pat_CheckList
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_CheckList_Items')
BEGIN
Delete from Mast_CheckList_Items
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_CheckList')
BEGIN
Delete from Mast_CheckList
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Corp_Surgery_Dtl')
BEGIN
Delete from Mast_Corp_Surgery_Dtl
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Book_Log')
BEGIN
Delete from Pat_OT_Book_Log
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Aneasthesia_Doc')
BEGIN
Delete from OT_Booking_Aneasthesia_Doc
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Complication')
BEGIN
Delete from OT_Complication
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Aneas_Technician')
BEGIN
Delete from OT_Booking_Aneas_Technician
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Basic_Assessment')
BEGIN
Delete from Pat_OT_Basic_Assessment
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='OT_Booking_Scrub_Nurse')
BEGIN
Delete from OT_Booking_Scrub_Nurse
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job')
BEGIN
Delete from Pat_OT_Job
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_CNS')
BEGIN
Delete from Mast_CNS
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Surgery_CheckList')
BEGIN
Delete from Mast_Surgery_CheckList
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Book_Cancel_Reason')
BEGIN
Delete from Pat_OT_Book_Cancel_Reason
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_History_DrugDtl')
BEGIN
Delete from Pat_OT_History_DrugDtl
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_NotesEntryImg')
BEGIN
Delete from Pat_NotesEntryImg
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_Corp_Surgery')
BEGIN
Delete from Mast_Corp_Surgery
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Job_Emp')
BEGIN
Delete from Pat_OT_Job_Emp
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Job_Equipment')
BEGIN
Delete from kmch_ot..CathLab_Job_Equipment  
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Job_Proc')
BEGIN
Delete from kmch_ot..CathLab_Job_Proc 
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Job_Doc')
BEGIN 
Delete from kmch_ot..CathLab_Job_Doc 
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Job')
BEGIN
Delete from kmch_ot..CathLab_Job  
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Booking_Cancel')
BEGIN
Delete from kmch_ot..CathLab_Booking_Cancel  
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Booking_Equipment')
BEGIN
Delete from kmch_ot..CathLab_Booking_Equipment
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Booking_Proc')
BEGIN
Delete from kmch_ot..CathLab_Booking_Proc  
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Booking_Doc')
BEGIN
Delete from kmch_ot..CathLab_Booking_Doc  
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='CathLab_Booking')
BEGIN
Delete from kmch_ot..CathLab_Booking 
End
GO
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Clinical_Remainders')
BEGIN
Delete from kmch_ot..Pat_OT_Clinical_Remainders 
End
GO
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Mast_PatVitals_Rights')
BEGIN
Delete from kmch_ot..Mast_PatVitals_Rights
End
GO
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_CR_Followup')
BEGIN
Delete from Pat_OT_CR_Followup
End
Go
IF EXISTS(select * from KMCH_OT.sys.objects where type='U' and name='Pat_OT_Clinical_Activity')
BEGIN
Delete from Pat_OT_Clinical_Activity
End
Go
Use KMCH_Pharmacy

Go
-- Tables Of Predefined Values , Masters and Settings
/*
Ctrl_Rpt_Options
Drug_Freq
Drug_Brand_Discount
Issue_Type
Mast_Dispatch_Counter
Drug_Package
Drug_Package_Dtl
Drug_Release
Drug_Pack
User_PhStore_Rights
Drug_Index
Drug_Class
UOM
Drug_Generic
Drug_Grp
Bin_Location
Drug_Tax
Payment_Terms
Ctrl_ListItems
Mast_MfrSupp_Link
ControlPanel
Mast_SalRtn_Counts
Drug_Brand_Location
Drug_Type
Drug_Brand
Ctrl_AcHeader_Dtl
Supplier
Pharma_Store
Mast_SalRtnRemarks
Drug_Brand_Generic
Supplier_Item
Drug_Brand_Doc
Manf
Item_Stk_Detail
Mast_Marketer
Running_Numbers
Ctrl_PriceRoundOff
PriceList_Hdr
GRN_Hdr
Item_Batchwise_Stk
PriceList_Dtl
PO_Dtl
GRN_Dtl
PO_Hdr
Mast_Drug_Brand -> Not Necessary master. But Referreed with Drug_Brand
PO_Dtl_Temp
PO_Hdr_Temp
Item_Grp
Ctrl_User_PayModeSetting
Log_File_Download
Package_Issue_Dtl
SalesPrice_Def_Logs
Mast_SalesPrice_Def
PurcIndent_Appr_Log
Pur_NewItem_Indent
PatMeds_Issue_Recall_Dtl
GRN_Template_Hdr
GRN_Template_Dtl
Drug_Brand_Generic_Recall
Ctrl_User_SourceSetting
Item_Prepartaion_Dtl
Drug_Brand_SalesMan
Pharm_Print_Formats

*/
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Adj')
BEGIN
Delete From Stk_Adj
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='StkDept_Usage')
BEGIN
Delete From StkDept_Usage
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_SentTo_AC')
BEGIN
Delete From GRN_SentTo_AC
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Cheque')
BEGIN
Delete From GRN_Cheque
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Other_SourceName')
BEGIN
Delete From Mast_Other_SourceName
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Pur_StrAppr_ItemDtl')
BEGIN
Delete From Pur_StrAppr_ItemDtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Upd_Log')
BEGIN
Delete From GRN_Upd_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Vaccine_Dtl')
BEGIN
Delete From Mast_Vaccine_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Transfer_Note_Dtl')
BEGIN
Delete From Stk_Transfer_Note_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Temp_Manu_Dtl')
BEGIN
Delete From GRN_Temp_Manu_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request_App')
BEGIN
Delete From Stk_Request_App
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Dispatch_Queue')
BEGIN
Delete From Bill_Dispatch_Queue
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Card_Holder')
BEGIN
Delete From Bill_Card_Holder
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Adj_Req_Dtl')
BEGIN
Delete From Stk_Adj_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Pharmacology')
BEGIN
Delete From Drug_Pharmacology
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Return_Req_Dtl')
BEGIN
Delete From Sales_Return_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Vaccine')
BEGIN
Delete From Mast_Vaccine
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_OutStanding_Dtl')
BEGIN
Delete From Bill_OutStanding_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Temp_Manu_Hdr')
BEGIN
Delete From GRN_Temp_Manu_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_DemandDraft')
BEGIN
Delete From GRN_DemandDraft
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Drug_Brand_Dtl')
BEGIN
Delete From Mast_Drug_Brand_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rtn_Cash')
BEGIN
Delete From Bill_Rtn_Cash
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Meds_Reserve')
BEGIN
Delete From Meds_Reserve
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Log_Dtl')
BEGIN
Delete From Purchase_Log_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_DemandDraft')
BEGIN
Delete From Bill_DemandDraft
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Indent')
BEGIN
Delete From Purchase_Indent
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Enq_Dtl')
BEGIN
Delete From Drug_Brand_Enq_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue_BounceDtl')
BEGIN
Delete From PatMeds_Issue_BounceDtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Concession')
BEGIN
Delete From GRN_Concession
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Blocked')
BEGIN
Delete From Drug_Brand_Blocked
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Return_App')
BEGIN
Delete From Purchase_Return_App
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Drug_Brand_ADR')
BEGIN
Delete From Mast_Drug_Brand_ADR
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Dtl_ONSCR')
BEGIN
Delete From Item_Stk_Dtl_ONSCR
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='pharmBillTotalLog')
BEGIN
Delete From pharmBillTotalLog
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='SCM_PO_Hdr')
BEGIN
Delete From SCM_PO_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Outstanding')
BEGIN
Delete From GRN_Outstanding
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Stk_Dt')
BEGIN
Delete From Item_Batchwise_Stk_Dt
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='TblDN_POLists_Gen')
BEGIN
Delete From TblDN_POLists_Gen
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Enq')
BEGIN
Delete From Drug_Brand_Enq
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Transfered_Dtl')
BEGIN
Delete From Bill_Transfered_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Cancelled')
BEGIN
Delete From Bill_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Doctor_Return_Dtl')
BEGIN
Delete From Doctor_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Stk_DtStk')
BEGIN
Delete From Item_Batchwise_Stk_DtStk
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='TblLog_Consolidated_Lists')
BEGIN
Delete From TblLog_Consolidated_Lists
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Return_Dtl')
BEGIN
Delete From Stk_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Quotation_Hdr')
BEGIN
Delete From Quotation_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PurchDC_Hdr')
BEGIN
Delete From PurchDC_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='RtnBill_Cancelled')
BEGIN
Delete From RtnBill_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='SCM_GRN_Hdr')
BEGIN
Delete From SCM_GRN_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Outstanding')
BEGIN
Delete From Bill_Outstanding
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Generic_ADR')
BEGIN
Delete From Drug_Generic_ADR
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='purchasertn1007')
BEGIN
Delete From purchasertn1007
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Cancelled')
BEGIN
Delete From PO_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Concession')
BEGIN
Delete From Bill_Concession
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Transfer_Note')
BEGIN
Delete From Stk_Transfer_Note
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Doctor_Return')
BEGIN
Delete From Doctor_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Return')
BEGIN
Delete From Stk_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Return_Dtl')
BEGIN
Delete From Purchase_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue_App')
BEGIN
Delete From PatMeds_Issue_App
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Req_Addr')
BEGIN
Delete From PatMeds_Req_Addr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request_Dtl')
BEGIN
Delete From Stk_Request_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Doctor_Issues_Dtl')
BEGIN
Delete From Doctor_Issues_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Return_Req')
BEGIN
Delete From Sales_Return_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Return')
BEGIN
Delete From Sales_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Drug_Formulation')
BEGIN
Delete From Mast_Drug_Formulation
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Adj_Req_App')
BEGIN
Delete From Stk_Adj_Req_App
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='vacc_mast_DoseNo')
BEGIN
Delete From vacc_mast_DoseNo
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request_App_Dtl')
BEGIN
Delete From Stk_Request_App_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Req')
BEGIN
Delete From PatMeds_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Indent_dtl')
BEGIN
Delete From Purchase_Indent_dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Doctor_Issues')
BEGIN
Delete From Doctor_Issues
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Vaccine')
BEGIN
Delete From Drug_Vaccine
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='sysdiagrams')
BEGIN
Delete From sysdiagrams
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='vacc_mast_Site')
BEGIN
Delete From vacc_mast_Site
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_SoundLike')
BEGIN
Delete From Drug_Brand_SoundLike
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rtn_OutStanding')
BEGIN
Delete From Bill_Rtn_OutStanding
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Wanted_Items')
BEGIN
Delete From Wanted_Items
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Return_Addr')
BEGIN
Delete From Sales_Return_Addr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='ArtMaster')
BEGIN
Delete From ArtMaster
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Manu_Dtl')
BEGIN
Delete From GRN_Manu_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Temp_Hdr')
BEGIN
Delete From GRN_Temp_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request')
BEGIN
Delete From Stk_Request
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Stk_Blocked')
BEGIN
Delete From Item_Batchwise_Stk_Blocked
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Formulation')
BEGIN
Delete From Drug_Formulation
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='InvoiceDtls')
BEGIN
Delete From InvoiceDtls
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Stk_UnBlocked')
BEGIN
Delete From Item_Batchwise_Stk_UnBlocked
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_VIP_SourceName')
BEGIN
Delete From Mast_VIP_SourceName
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Sqtk_1')
BEGIN
Delete From Item_Batchwise_Sqtk_1
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Quotation_Dtl')
BEGIN
Delete From Quotation_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_SuppPrn_Path')
BEGIN
Delete From Ctrl_SuppPrn_Path
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete From dtproperties
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Detail_Log')
BEGIN
Delete From Item_Stk_Detail_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_LookLike')
BEGIN
Delete From Drug_Brand_LookLike
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Temp_CrDr_Note')
BEGIN
Delete From GRN_Temp_CrDr_Note
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue_Addr')
BEGIN
Delete From PatMeds_Issue_Addr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Outstanding_Tot')
BEGIN
Delete From Bill_Outstanding_Tot
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_CrDr_Note')
BEGIN
Delete From GRN_CrDr_Note
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Vacc_AEFI_details')
BEGIN
Delete From Vacc_AEFI_details
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRM_Manu_Hdr')
BEGIN
Delete From GRM_Manu_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='vacc_mast_brand')
BEGIN
Delete From vacc_mast_brand
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Salesman')
BEGIN
Delete From Mast_Salesman
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Adj_Req')
BEGIN
Delete From Stk_Adj_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Payment_CN')
BEGIN
Delete From GRN_Payment_CN
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='vacc_mast_Dose')
BEGIN
Delete From vacc_mast_Dose
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='vacc_mast_route')
BEGIN
Delete From vacc_mast_route
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Batchwise_Stk_Log')
BEGIN
Delete From Item_Batchwise_Stk_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Adj_Req_Can')
BEGIN
Delete From Stk_Adj_Req_Can
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rtn_Concession')
BEGIN
Delete From Bill_Rtn_Concession
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Drug_Brand_Generic')
BEGIN
Delete From Mast_Drug_Brand_Generic
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Payment_Dtl')
BEGIN
Delete From GRN_Payment_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_AddrBook')
BEGIN
Delete From Mast_AddrBook
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Alternate_Drug')
BEGIN
Delete From Alternate_Drug
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Return')
BEGIN
Delete From Purchase_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='SCM_GRN_Dtl')
BEGIN
Delete From SCM_GRN_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_SalesMargin')
BEGIN
Delete From Ctrl_SalesMargin
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Cash')
BEGIN
Delete From Bill_Cash
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Denomination')
BEGIN
Delete From Denomination
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rept')
BEGIN
Delete From Bill_Rept
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Deno_Rec_Dtl')
BEGIN
Delete From Deno_Rec_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PurchDC_Dtl')
BEGIN
Delete From PurchDC_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_EFT')
BEGIN
Delete From Bill_EFT
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='User_PhStore_HomePage')
BEGIN
Delete From User_PhStore_HomePage
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='SCM_PO_Dtl')
BEGIN
Delete From SCM_PO_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Cancelled')
BEGIN
Delete From GRN_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Running_Numbers_Log')
BEGIN
Delete From Running_Numbers_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_BlockTrans')
BEGIN
Delete From Drug_Brand_BlockTrans
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Generic_Dtl')
BEGIN
Delete From Drug_Generic_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='IPReq_Cancelled')
BEGIN
Delete From IPReq_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue_Dtl')
BEGIN
Delete From PatMeds_Issue_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='TblDN_Consolidated_Lists')
BEGIN
Delete From TblDN_Consolidated_Lists
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Temp_Dtl')
BEGIN
Delete From GRN_Temp_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Transfered')
BEGIN
Delete From Bill_Transfered
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue')
BEGIN
Delete From PatMeds_Issue
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Payment')
BEGIN
Delete From GRN_Payment
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stock_Ctrl_Register')
BEGIN
Delete From Stock_Ctrl_Register
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='drug_brand_old')
BEGIN
Delete From drug_brand_old
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_Rpt_Options_310102014')
BEGIN
Delete From Ctrl_Rpt_Options_310102014
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PurchDC_Manu_Hdr')
BEGIN
Delete From PurchDC_Manu_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Req_Dtl')
BEGIN
Delete From Purchase_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Return_Dtl')
BEGIN
Delete From Sales_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_Rpt_Options_New')
BEGIN
Delete From Ctrl_Rpt_Options_New
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Req')
BEGIN
Delete From Purchase_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_SuppUser')
BEGIN
Delete From Mast_SuppUser
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Card_Holder')
BEGIN
Delete From GRN_Card_Holder
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Approval')
BEGIN
Delete From Purchase_Approval
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Drug_VED')
BEGIN
Delete From Mast_Drug_VED
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Req_Dtl')
BEGIN
Delete From PatMeds_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Approval_Dtl')
BEGIN
Delete From Purchase_Approval_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Detail_StkDt')
BEGIN
Delete From Item_Stk_Detail_StkDt
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Transfered')
BEGIN
Delete From GRN_Transfered
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Detail_Stock')
BEGIN
Delete From Item_Stk_Detail_Stock
End
Go
 
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PurchDC_Manu_Dtl')
BEGIN
Delete From PurchDC_Manu_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_BlockStkTrans')
BEGIN
Delete From Drug_Brand_BlockStkTrans
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Issue_OverrideDtl')
BEGIN
Delete From PatMeds_Issue_OverrideDtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Cheque')
BEGIN
Delete From Bill_Cheque
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_IPAddress')
BEGIN
Delete From Ctrl_IPAddress
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Detail_UpdLog')
BEGIN
Delete From Item_Stk_Detail_UpdLog
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Cash')
BEGIN
Delete From GRN_Cash
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drugindex')
BEGIN
Delete From Drugindex
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Rept')
BEGIN
Delete From GRN_Rept
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rtn_Rept')
BEGIN
Delete From Bill_Rtn_Rept
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Dispatched')
BEGIN
Delete From Bill_Dispatched
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Amount')
BEGIN
Delete From Mast_Amount
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PR_Cancelled')
BEGIN
Delete From PR_Cancelled
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Deno_Pay_Dtl')
BEGIN
Delete From Deno_Pay_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Hdr_Amendment')
BEGIN
Delete From PO_Hdr_Amendment
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Dtl_Amendment')
BEGIN
Delete From PO_Dtl_Amendment
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Hdr_Temp')
BEGIN
Delete From PO_Dtl_Temp
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Hdr_Temp')
BEGIN
Delete From PO_Hdr_Temp
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Request')
BEGIN
Delete From Drug_Brand_Request
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_ItemPackage_Log')
BEGIN
Delete From Mast_ItemPackage_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Prepartaion_Dtl')
BEGIN
Delete From Item_Prepartaion_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Dtl')
BEGIN
Delete From GIR_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Grn_Log')
BEGIN
Delete From GIR_Grn_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Hdr')
BEGIN
Delete From GIR_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Issue')
BEGIN
Delete From GIR_Issue
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Issue_Dtl')
BEGIN
Delete From GIR_Issue_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Return')
BEGIN
Delete From GIR_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Return_Dtl')
BEGIN
Delete From GIR_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GIR_Return_Log_Dtl')
BEGIN
Delete From GIR_Return_Log_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GP_Cls_Log')
BEGIN
Delete From GP_Cls_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GP_Dtl')
BEGIN
Delete From GP_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GP_Hdr')
BEGIN
Delete From GP_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GP_Log_Dtl')
BEGIN
Delete From GP_Log_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Files_Attach')
BEGIN
Delete From Mast_Files_Attach
End
Go

IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Request_Approval')
BEGIN
Delete From Purchase_Request_Approval
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Dtl_Reserve')
BEGIN
Delete From PO_Dtl_Reserve
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Dtl_Reserve')
BEGIN
Delete From GRN_Dtl_Reserve
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_ItemPackage_Log')
BEGIN
Delete From Mast_ItemPackage_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Inven_GRN_MRP_Items')
BEGIN
Delete From Inven_GRN_MRP_Items
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Image')
BEGIN
Delete From Drug_Brand_Image
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Ctrl_BackUp_Settings')
BEGIN
Delete From Ctrl_BackUp_Settings
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Rejection')
BEGIN
Delete From Item_Sterilize_Rejection
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Req_Dtl')
BEGIN
Delete From Item_Sterilize_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Dtl')
BEGIN
Delete From Item_Sterilize_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize')
BEGIN
Delete From Item_Sterilize
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Prepare_Dtl')
BEGIN
Delete From Item_Prepare_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Prepare')
BEGIN
Delete From Item_Prepare
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Request_App_Log')
BEGIN
Delete From Sales_Request_App_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Employee_Profile')
BEGIN
Delete From Employee_Profile
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sale_Request_Addr')
BEGIN
Delete From Sale_Request_Addr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Request_Dtl')
BEGIN
Delete From Sales_Request_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Request')
BEGIN
Delete From Sales_Request
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Retn_Dtl')
BEGIN
Delete From Item_Recall_Retn_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Retn')
BEGIN
Delete From Item_Recall_Retn
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Rec_Dtl')
BEGIN
Delete From Item_Recall_Rec_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Rec')
BEGIN
Delete From Item_Recall_Rec
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Req_Dtl')
BEGIN
Delete From Item_Recall_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Recall_Req')
BEGIN
Delete From Item_Recall_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Prepare_Batch_Dtl')
BEGIN
Delete From Item_Prepare_Batch_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Return_Req_Dtl')
BEGIN
Delete From Item_Reuse_Return_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Return_Req')
BEGIN
Delete From Item_Reuse_Return_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Return_Dtl')
BEGIN
Delete From Item_Reuse_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Return')
BEGIN
Delete From Item_Reuse_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Process_Dtl')
BEGIN
Delete From Item_Reuse_Process_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_Process')
BEGIN
Delete From Item_Reuse_Process
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_PackItem_Rtn_Dtl')
BEGIN
Delete From Item_Reuse_PackItem_Rtn_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_PackItem_Rtn')
BEGIN
Delete From Item_Reuse_PackItem_Rtn
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_PackItem_Req_Dtl')
BEGIN
Delete From Item_Reuse_PackItem_Req_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Reuse_PackItem_Req')
BEGIN
Delete From Item_Reuse_PackItem_Req
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Prepare_Sterilize_Log')
BEGIN
Delete From Prepare_Sterilize_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Upd_Log')
BEGIN
Delete From Drug_Brand_Upd_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Supplier_API_Authentication')
BEGIN
Delete From Kmch_pharmacy..Supplier_API_Authentication
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='drug_tax2021_19_10bact')
BEGIN
Delete From Kmch_pharmacy..drug_tax2021_19_10bact
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='drug_tax2021_19_10')
BEGIN
Delete From Kmch_pharmacy..drug_tax2021_19_10
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Return_Dtl')
BEGIN
Delete From Kmch_pharmacy..Item_Sterilize_Return_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Return')
BEGIN
Delete From Kmch_pharmacy..Item_Sterilize_Return
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Sterilize_Log_Dtl')
BEGIN
Delete From Kmch_pharmacy..Item_Sterilize_Log_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Recpt_PayMode_Update')
BEGIN
Delete From Kmch_pharmacy..Bill_Recpt_PayMode_Update
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Template_Hdr')
BEGIN
Delete From Kmch_pharmacy..GRN_Template_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Template_Dtl')
BEGIN
Delete From Kmch_pharmacy..GRN_Template_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Brand_Dept')
BEGIN
Delete From Kmch_pharmacy..Item_Brand_Dept
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='TEMPGSTR3B')
BEGIN
Delete From Kmch_pharmacy..TEMPGSTR3B
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Supplier_Rating')
BEGIN
Delete From Kmch_pharmacy..Supplier_Rating
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_BatchWise_Trans_Log')
BEGIN
Delete From Kmch_pharmacy..Item_BatchWise_Trans_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Post_Log')
BEGIN
Delete From Kmch_pharmacy..PatMeds_Post_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stk_Trans_Log')
BEGIN
Delete From Kmch_pharmacy..Item_Stk_Trans_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_TDS_Rpt')
BEGIN
Delete From Kmch_pharmacy..GRN_TDS_Rpt
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Batch_Stk_Entry')
BEGIN
Delete From Kmch_pharmacy..Batch_Stk_Entry
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Indent_PO_Dtl')
BEGIN
Delete From Kmch_pharmacy..Purchase_Indent_PO_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request_Pres_Dtl_Log')
BEGIN
Delete From Kmch_pharmacy..Stk_Request_Pres_Dtl_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Bill_Rtn_Advance')
BEGIN
Delete From Kmch_pharmacy..Bill_Rtn_Advance
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Pharmacy_Bill_Dep_Usage_Log')
BEGIN
Delete From Kmch_pharmacy..Pharmacy_Bill_Dep_Usage_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Purchase_Indent_Proposal')
BEGIN
Delete From Kmch_pharmacy..Purchase_Indent_Proposal
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Request_Short_URL')
BEGIN
Delete From Kmch_pharmacy..Sales_Request_Short_URL
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Sales_Request_AuthDtl')
BEGIN
Delete From Kmch_pharmacy..Sales_Request_AuthDtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mail_Error_Log')
BEGIN
Delete From Kmch_pharmacy..Mail_Error_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Stock_API_Status')
BEGIN
Delete From Kmch_pharmacy..Item_Stock_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_Data_API')
BEGIN
Delete From Kmch_pharmacy..Drug_Brand_Data_API
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Drug_Brand_API_Status')
BEGIN
Delete From Kmch_pharmacy..Drug_Brand_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Issue_Data_API')
BEGIN
Delete From Kmch_pharmacy..Stk_Issue_Data_API
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Pharma_Bill_OutStanding_Adjust')
BEGIN
Delete From Kmch_pharmacy..Pharma_Bill_OutStanding_Adjust
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Return_API_Status')
BEGIN
Delete From Kmch_pharmacy..Stk_Return_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Req_Cancel_API_Status')
BEGIN
Delete From Kmch_pharmacy..Stk_Req_Cancel_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='WhatsApp_SMS_Post_Log')
BEGIN
Delete From Kmch_pharmacy..WhatsApp_SMS_Post_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Request_API_Status')
BEGIN
Delete From Kmch_pharmacy..Stk_Request_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Receive_Data_File')
BEGIN
Delete From Kmch_pharmacy..Stk_Receive_Data_File
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Receive_Data_API')
BEGIN
Delete From Kmch_pharmacy..Stk_Receive_Data_API
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Receive_API_Status')
BEGIN
Delete From Kmch_pharmacy..Stk_Receive_API_Status
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Advance')
BEGIN
Delete From Kmch_pharmacy..PO_Advance
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Mast_Files_Attach_DelChk')
BEGIN
Delete From Kmch_pharmacy..Mast_Files_Attach_DelChk
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Post_Log')
BEGIN
Delete From Kmch_pharmacy..PatMeds_Post_Log
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PatMeds_Post_Log_2022')
BEGIN
Delete From Kmch_pharmacy..PatMeds_Post_Log_2022
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='TEMPGSTR3B')
BEGIN
Delete From Kmch_pharmacy..TEMPGSTR3B
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Item_Prepartaion_Discard_Dtl')
BEGIN
Delete From Kmch_pharmacy..Item_Prepartaion_Discard_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Stk_Return_Reject')
BEGIN
Delete From Kmch_pharmacy..Stk_Return_Reject
End
Go

Use KMCH_Radiology

go
-- Tables Of Predefined Values , Masters and Settings
/*
RAD_REPORT_CONTROL_PANEL
Mast_Proc_Bio_Template
Proc_Template_Name
Mast_Observation
Mast_Proc_Observation
Mast_AsessmentTemplate_dtl
Mast_AsessmentTemplate
Mast_AsessmentTemplateGroup
Mast_Radiologist
Mast_Contrast
Mast_Xray_Film
Control_Panel_Printing
Mast_Proc
PMast_DigitalSign_Defn
Proc_Group
Mast_AsessmentTemplate_Val
Mast_Proc_Group_Template
Dept_Prefix_Number 
Mast_Proc_Impression
*/
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Task_List_Dtl')
BEGIN
Delete from Task_List_Dtl
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Result')
BEGIN
Delete from Proc_Result
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='IARadTemp')
BEGIN
Delete from IARadTemp
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Result_Log')
BEGIN
Delete from Proc_Result_Log
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Mast_SubProc')
BEGIN
Delete from Mast_SubProc
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Mast_Proc_Alias')
BEGIN
Delete from Mast_Proc_Alias
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='DigitalSign_Dtl')
BEGIN
Delete from DigitalSign_Dtl
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Months')
BEGIN
Delete from Months
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='PACS_Result_info')
BEGIN
Delete from PACS_Result_info
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Template_Result')
BEGIN
Delete from Proc_Template_Result
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Radiology_Schedule')
BEGIN
Delete from Radiology_Schedule
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Rad_Template')
BEGIN
Delete from Rad_Template
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Film_Used_Entry')
BEGIN
Delete from Film_Used_Entry
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Mast_Equipment_Grp')
BEGIN
Delete from Mast_Equipment_Grp
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Rad_Report_Doctor')
BEGIN
Delete from Rad_Report_Doctor
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Pat_ResultEntryImg')
BEGIN
Delete from Pat_ResultEntryImg
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Task_List_Dtl')
BEGIN
Delete from Task_List_Dtl
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Result_Img')
BEGIN
Delete from Proc_Result_Img
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Result_Impression_Log')
BEGIN
Delete from Proc_Result_Impression_Log
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Result_Impression')
BEGIN
Delete from Proc_Result_Impression
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Critical_Result_SMS')
BEGIN
Delete from Critical_Result_SMS
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Rad_FrontOffice_Revert')
BEGIN
Delete from Rad_FrontOffice_Revert
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Proc_Send_Response')
BEGIN
Delete from Proc_Send_Response
End
Go
IF EXISTS(select * from KMCH_Radiology.sys.objects where type='U' and name='Rad_SMS_Log')
BEGIN
Delete from Rad_SMS_Log
End
Go
USe KMCH_Lab
Go
-- Tables Of Predefined Values , Masters and Settings
/*
LAB_REPORT_CONTROL_PANEL
Mast_Proc
Mast_Proc_Bio_Template
Mast_Antibiotic_Isolate
Mast_Proc_Specimen
Mast_SubProc
Proc_Group
UOM
Lab_Equipment_Name
Control_Panel_Printing
A00061_Colony_Count
Mast_Lab_Counter
Mast_Barcode_Count
Mast_Specimen
Mast_Organism_Panel_Dtl
Mast_Organism_Panel
Mast_Isolate
Mast_SpecimenContainer
Mast_RptStatus
Mast_TestMethod
Mast_Barcode_Type
Mast_Interim_Proc_Match
Mast_Sticker_Loc
Cul_Master
Request_Print_User
Proc_Template_Name
Mast_Organisms
Mast_Lab
Mast_Request_Loc
Mast_Culture_Remarks
Mast_SpecimenGroup
Mast_AutoRelease_DS
Mast_WeekDay
Digital_Sign_User
Pathology_Template
Mast_Proc_Impression
Dept_User_Rights
Lab_Equipment_Specimen_Type - COntrol
Mast_Proc_Bio_Template_Calc
Mast_SystemicPathology
Mast_PathCategory
*/
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Remarks')
BEGIN
Delete from Proc_Remarks
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Result')
BEGIN
Delete from Culture_Result
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Result_Group_Sub')
BEGIN
Delete from Mast_Result_Group_Sub
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Path_Task_Process')
BEGIN
Delete from Path_Task_Process
End
Go

IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result')
BEGIN
Delete from Proc_Result
End

Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Clinical_Result_Corelation')
BEGIN
Delete from Clinical_Result_Corelation
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Result_Group')
BEGIN
Delete from Mast_Result_Group
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Task_List_Specimen')
BEGIN
Delete from Task_List_Specimen
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Runing_Numbers')
BEGIN
Delete from Runing_Numbers
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Outside_Lab_sent')
BEGIN
Delete from Outside_Lab_sent
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='A00061_Culture_Isolate')
BEGIN
Delete from A00061_Culture_Isolate
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Pathology_Image_Capture')
BEGIN
Delete from Pathology_Image_Capture
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Task_List_Dtl')
BEGIN
Delete from Task_List_Dtl
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Result_Complete_SMS')
BEGIN
Delete from Result_Complete_SMS
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Clinical_Result_Corelation_dtl')
BEGIN
Delete from Clinical_Result_Corelation_dtl
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Task_Order_Specimen')
BEGIN
Delete from Task_Order_Specimen
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='FinalDiagnosisCorrelation')
BEGIN
Delete from FinalDiagnosisCorrelation
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Isolate_Remarks')
BEGIN
Delete from Culture_Isolate_Remarks
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='labtempdata')
BEGIN
Delete from labtempdata
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Antibiogram_Val')
BEGIN
Delete from Antibiogram_Val
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='PathologyCorrelation')
BEGIN
Delete from PathologyCorrelation
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='RadiologyCorrelation')
BEGIN
Delete from RadiologyCorrelation
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='TempProcResult')
BEGIN
Delete from TempProcResult
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='A00063_Vitros_Analyte_Code')
BEGIN
Delete from A00063_Vitros_Analyte_Code
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='File_Attach_Name')
BEGIN
Delete from File_Attach_Name
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='EMR_Pat_Dtls')
BEGIN
Delete from EMR_Pat_Dtls
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Chemwell_Procs')
BEGIN
Delete from Chemwell_Procs
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Equipment_Grp')
BEGIN
Delete from Mast_Equipment_Grp
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Celldyn_Result')
BEGIN
Delete from Celldyn_Result
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Control_Panel_Company_Header')
BEGIN
Delete from Control_Panel_Company_Header
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_CultureBloodSet')
BEGIN
Delete from Mast_CultureBloodSet
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_Temp')
BEGIN
Delete from Proc_Result_Temp
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Proc_Bio_Template_1204')
BEGIN
Delete from Mast_Proc_Bio_Template_1204
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Task_List')
BEGIN
Delete from Task_List
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Item')
BEGIN
Delete from Proc_Item
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_Log')
BEGIN
Delete from Proc_Result_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Hitachi_Result')
BEGIN
Delete from Hitachi_Result
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Celldyn_Proc')
BEGIN
Delete from Celldyn_Proc
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='QC_EQUIPMENT_RESULT')
BEGIN
Delete from QC_EQUIPMENT_RESULT
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='mast_connectionString')
BEGIN
Delete from mast_connectionString
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Isolate')
BEGIN
Delete from Culture_Isolate
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='EMR_Order_Alert')
BEGIN
Delete from EMR_Order_Alert
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Result_Antibiotic')
BEGIN
Delete from Culture_Result_Antibiotic
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_PathProcess')
BEGIN
Delete from Mast_PathProcess
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Equipment')
BEGIN
Delete from Mast_Equipment
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='A00063_Vitrus_Raw_Data')
BEGIN
Delete from A00063_Vitrus_Raw_Data
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Hitachi_Proc')
BEGIN
Delete from Hitachi_Proc
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='QBSP_Culture_Infection')
BEGIN
Delete from QBSP_Culture_Infection
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_AutoSave')
BEGIN
Delete from Proc_Result_AutoSave
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_Img')
BEGIN
Delete from Proc_Result_Img
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='A00061_Culture_Result_Antibiotic')
BEGIN
Delete from A00061_Culture_Result_Antibiotic
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='User_Permission')
BEGIN
Delete from User_Permission
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='dtproperties')
BEGIN
Delete from dtproperties
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Equipment_Result')
BEGIN
Delete from Culture_Equipment_Result
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Alias_Celldyn')
BEGIN
Delete from Alias_Celldyn
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Temp_TokenOrder')
BEGIN
Delete from Temp_TokenOrder
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Data_Celldyn')
BEGIN
Delete from Data_Celldyn
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Critical_Result_SMS')
BEGIN
Delete from Critical_Result_SMS
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_CultureType')
BEGIN
Delete from Mast_CultureType
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Kit')
BEGIN
Delete from Mast_Kit
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Dept_Remarks')
BEGIN
Delete from Proc_Dept_Remarks
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Proc_Alias')
BEGIN
Delete from Mast_Proc_Alias
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Dept_Prefix_Number')
BEGIN
Delete from Dept_Prefix_Number
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Digital_Sign_dtl')
BEGIN
Delete from Digital_Sign_dtl
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Antibiogram_Val')
BEGIN
Delete from Proc_Antibiogram_Val
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Specimen_Revert')
BEGIN
Delete from Specimen_Revert
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Cul_Template')
BEGIN
Delete from Proc_Cul_Template
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Specimen_ReceiveTJ')
BEGIN
Delete from Specimen_ReceiveTJ
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='CelldynTemp')
BEGIN
Delete from CelldynTemp
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_CultureSiteSpec')
BEGIN
Delete from Mast_CultureSiteSpec
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Mast_Finding')
BEGIN
Delete from Mast_Finding
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Emr_DirectCancel_Log')
BEGIN
Delete from Emr_DirectCancel_Log 
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Control_Panel_Log')
BEGIN
Delete from Kmch_lab..Control_Panel_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_Impression_Log')
BEGIN
Delete from Kmch_lab..Proc_Result_Impression_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Proc_Result_Impression')
BEGIN
Delete from Kmch_lab..Proc_Result_Impression
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Result_Antibiotic_Log')
BEGIN
Delete from Kmch_lab..Culture_Result_Antibiotic_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Culture_Isolate_Log')
BEGIN
Delete from Kmch_lab..Culture_Isolate_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='kmch_lab..Lab_Email_Log')
BEGIN
Delete from Kmch_lab..Lab_Email_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Digital_Sign_Dtl_Log')
BEGIN
Delete from Kmch_lab..Digital_Sign_Dtl_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Lab_Email_Log')
BEGIN
Delete from Kmch_lab..Lab_Email_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Pat_Specimen_Archive')
BEGIN
Delete from Kmch_lab..Pat_Specimen_Archive
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Pat_Specimen_Issue')
BEGIN
Delete from Kmch_lab..Pat_Specimen_Issue
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Pat_Specimen_Issue_Dtl')
BEGIN
Delete from Kmch_lab..Pat_Specimen_Issue_Dtl
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='EMR_BloodCulture_Specimen_Dtl')
BEGIN
Delete from Kmch_lab..EMR_BloodCulture_Specimen_Dtl
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Lab_Report_Export_Log')
BEGIN
Delete from Kmch_lab..Lab_Report_Export_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Lab_BillRefund_Log')
BEGIN
Delete from Kmch_lab..Lab_BillRefund_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Lab_SMS_Log')
BEGIN
Delete from Kmch_lab..Lab_SMS_Log
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Pat_PathOrder_Link')
BEGIN
Delete from Kmch_lab..Pat_PathOrder_Link
End
Go
IF EXISTS(select * from KMCH_Lab.sys.objects where type='U' and name='Lab_File_Attachment')
BEGIN
Delete from Kmch_lab..Lab_File_Attachment
End
Go
Use Kmch_Inventory
/*
Controls & masters
Bin_Location
ControlPanel
Ctrl_AcHeader_Dtl
Ctrl_Appr_UserLvl
Ctrl_RunningNos
GRN_MRP_Items
Issue_Type
Item_Brand
Item_Brand_Dept
Item_Grp
Item_Pack
Item_Service_Dtl
Item_Tax
Item_Type
ItemOrderList
Manf
Mast_Contract_Dtl
Mast_Contract_Hdr
Mast_Currency
Mast_Delivery_Terms
Mast_Equip_Dtl
Mast_Equipment
Mast_Files_Attach
Mast_Item_Concession
Mast_PO_Comments
Mast_SalesPrice_Def
Mast_Stk_ItemBrand
Mast_Store
Mast_Terms
OT_Package
OT_Package_Dtl
Payment_Terms
PO_Ins
PO_Prn_Content
Running_Numbers
Running_Numbers_Log
Str_Item_Type
Str_ItemRights
Supplier
Supplier_Item
Supplier_Type
Temp_TriggerCnt
UOM
User_Dept_Rights
User_Str_Rights
GRN_Dtl
GRN_Hdr
Item_Batchwise_Stk
Item_Stk_Detail
PO_Dtl
PO_Hdr
Purchase_Dtl
Purchase_Hdr
Mast_EmptyBin_Type

*/
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Asset_Condm_Req')
BEGIN
Delete From Asset_Condm_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Condm_App')
BEGIN
Delete From Condm_App
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Condm_App_Dtl')
BEGIN
Delete From Condm_App_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Condm_Req')
BEGIN
Delete From Condm_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Condm_Req_Dtl')
BEGIN
Delete From Condm_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Ctrl_ListItems')
BEGIN
Delete From Ctrl_ListItems
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Dept_Stk_Value')
BEGIN
Delete From Dept_Stk_Value
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Dtl')
BEGIN
Delete From GIR_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Grn_Log')
BEGIN
Delete From GIR_Grn_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Hdr')
BEGIN
Delete From GIR_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Issue')
BEGIN
Delete From GIR_Issue
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Issue_Dtl')
BEGIN
Delete From GIR_Issue_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Return')
BEGIN
Delete From GIR_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Return_Dtl')
BEGIN
Delete From GIR_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GIR_Return_Log_Dtl')
BEGIN
Delete From GIR_Return_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GP_Cls_Log')
BEGIN
Delete From GP_Cls_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GP_Dtl')
BEGIN
Delete From GP_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GP_Hdr')
BEGIN
Delete From GP_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GP_Log_Dtl')
BEGIN
Delete From GP_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Card_Holder')
BEGIN
Delete From GRN_Card_Holder
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Cash')
BEGIN
Delete From GRN_Cash
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Cheque')
BEGIN
Delete From GRN_Cheque
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_DemandDraft')
BEGIN
Delete From GRN_DemandDraft
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Note_CrDr')
BEGIN
Delete From GRN_Note_CrDr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Outstanding')
BEGIN
Delete From GRN_Outstanding
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Payment')
BEGIN
Delete From GRN_Payment
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Payment_Dtl')
BEGIN
Delete From GRN_Payment_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_PO_Dtl')
BEGIN
Delete From GRN_PO_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Rept')
BEGIN
Delete From GRN_Rept
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Return')
BEGIN
Delete From GRN_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Return_App')
BEGIN
Delete From GRN_Return_App
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Return_Dtl')
BEGIN
Delete From GRN_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_SentTo_AC')
BEGIN
Delete From GRN_SentTo_AC
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Tmp')
BEGIN
Delete From GRN_Tmp
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Tmp_Dtl')
BEGIN
Delete From GRN_Tmp_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Tmp_ItemList')
BEGIN
Delete From GRN_Tmp_ItemList
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_TmpStock_ItemList')
BEGIN
Delete From GRN_TmpStock_ItemList
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_TmpStock_Raise')
BEGIN
Delete From GRN_TmpStock_Raise
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_TmpStock_Raise_Dtl')
BEGIN
Delete From GRN_TmpStock_Raise_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Upd_Log')
BEGIN
Delete From GRN_Upd_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Update_Log')
BEGIN
Delete From GRN_Update_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_VIEW')
BEGIN
Delete From GRN_VIEW
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Bill_Rtn_Dtl')
BEGIN
Delete From Item_Bill_Rtn_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Brand_Upd_log')
BEGIN
Delete From Item_Brand_Upd_log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Enq')
BEGIN
Delete From Item_Enq
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Enq_Dtl')
BEGIN
Delete From Item_Enq_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Enq_Log_Dtl')
BEGIN
Delete From Item_Enq_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Issue_ReUse_Log')
BEGIN
Delete From Item_Issue_ReUse_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Pend_Req_Dtl')
BEGIN
Delete From Item_Pend_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Pharmacology')
BEGIN
Delete From Item_Pharmacology
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Prepare')
BEGIN
Delete From Item_Prepare
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Prepare_Batch_Dtl')
BEGIN
Delete From Item_Prepare_Batch_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Prepare_Dtl')
BEGIN
Delete From Item_Prepare_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Quote')
BEGIN
Delete From Item_Quote
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Quote_Cost_Dtl')
BEGIN
Delete From Item_Quote_Cost_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Quote_Dtl')
BEGIN
Delete From Item_Quote_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Quote_Log_Dtl')
BEGIN
Delete From Item_Quote_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Req')
BEGIN
Delete From Item_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Req_Dtl')
BEGIN
Delete From Item_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reserve')
BEGIN
Delete From Item_Reserve
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Return')
BEGIN
Delete From Item_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Return_Dtl')
BEGIN
Delete From Item_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Return_Req')
BEGIN
Delete From Item_Return_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Return_Req_Dtl')
BEGIN
Delete From Item_Return_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_ReUsable_Dtl')
BEGIN
Delete From Item_ReUsable_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_ReUsable_Log_Dtl')
BEGIN
Delete From Item_ReUsable_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_ReUsable_Order')
BEGIN
Delete From Item_ReUsable_Order
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_PackItem_Req')
BEGIN
Delete From Item_Reuse_PackItem_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_PackItem_Req_Dtl')
BEGIN
Delete From Item_Reuse_PackItem_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_PackItem_Rtn')
BEGIN
Delete From Item_Reuse_PackItem_Rtn
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_PackItem_Rtn_Dtl')
BEGIN
Delete From Item_Reuse_PackItem_Rtn_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Process')
BEGIN
Delete From Item_Reuse_Process
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Process_Dtl')
BEGIN
Delete From Item_Reuse_Process_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Return')
BEGIN
Delete From Item_Reuse_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Return_Dtl')
BEGIN
Delete From Item_Reuse_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Return_Req')
BEGIN
Delete From Item_Reuse_Return_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Reuse_Return_Req_Dtl')
BEGIN
Delete From Item_Reuse_Return_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Service_Hdr')
BEGIN
Delete From Item_Service_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Service_Spare_Dtl')
BEGIN
Delete From Item_Service_Spare_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize')
BEGIN
Delete From Item_Sterilize
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Dtl')
BEGIN
Delete From Item_Sterilize_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Log_Dtl')
BEGIN
Delete From Item_Sterilize_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Rejection')
BEGIN
Delete From Item_Sterilize_Rejection
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Req_Dtl')
BEGIN
Delete From Item_Sterilize_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Return')
BEGIN
Delete From Item_Sterilize_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Item_Sterilize_Return_Dtl')
BEGIN
Delete From Item_Sterilize_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Rec')
BEGIN
Delete From Lenin_Rec
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Rec_Dtl')
BEGIN
Delete From Lenin_Rec_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Req')
BEGIN
Delete From Lenin_Req
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Req_Dtl')
BEGIN
Delete From Lenin_Req_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Trans')
BEGIN
Delete From Lenin_Trans
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Lenin_Trans_Dtl')
BEGIN
Delete From Lenin_Trans_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OPReqItem')
BEGIN
Delete From OPReqItem
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OT_ItemReq')
BEGIN
Delete From OT_ItemReq
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OT_ItemReq_Dtl')
BEGIN
Delete From OT_ItemReq_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OT_Package_Dtl_Old')
BEGIN
Delete From OT_Package_Dtl_Old
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OTItem_Issue')
BEGIN
Delete From OTItem_Issue
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='OTItem_Issue_Dtl')
BEGIN
Delete From OTItem_Issue_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PatItem_Issue')
BEGIN
Delete From PatItem_Issue
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PatItem_Issue_Addr')
BEGIN
Delete From PatItem_Issue_Addr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PatItem_Issue_Dtl')
BEGIN
Delete From PatItem_Issue_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PO_Amd_Dtl')
BEGIN
Delete From PO_Amd_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PO_Amd_Hdr')
BEGIN
Delete From PO_Amd_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PO_Indent_Link')
BEGIN
Delete From PO_Indent_Link
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Prepare_Sterilize_Log')
BEGIN
Delete From Prepare_Sterilize_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Pur_Indent_Flow')
BEGIN
Delete From Pur_Indent_Flow
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Pur_NewItem_Indent')
BEGIN
Delete From Pur_NewItem_Indent
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Pur_StrAppr_ItemDtl')
BEGIN
Delete From Pur_StrAppr_ItemDtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Amd')
BEGIN
Delete From Purchase_Amd
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Amd_Dtl')
BEGIN
Delete From Purchase_Amd_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Control_Panel_Log')
BEGIN
Delete From Purchase_Dept_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Indent')
BEGIN
Delete From Purchase_Indent
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Indent_dtl')
BEGIN
Delete From Purchase_Indent_dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Log_Dtl')
BEGIN
Delete From Purchase_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Log_Email')
BEGIN
Delete From Purchase_Log_Email
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Return')
BEGIN
Delete From Purchase_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Return_Dtl')
BEGIN
Delete From Purchase_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Terms_Dtl')
BEGIN
Delete From Purchase_Terms_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PurcIndent_Appr_Log')
BEGIN
Delete From PurcIndent_Appr_Log
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Quotation_Dtl')
BEGIN
Delete From Quotation_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Quotation_Hdr')
BEGIN
Delete From Quotation_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Quotation_Supp_Dtl')
BEGIN
Delete From Quotation_Supp_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='SalesPrice_Def_Logs')
BEGIN
Delete From SalesPrice_Def_Logs
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='SMS_Received_Detail')
BEGIN
Delete From SMS_Received_Detail
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Adj')
BEGIN
Delete From Stk_Adj
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Adjust')
BEGIN
Delete From Stk_Adjust
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Adjust_Dtl')
BEGIN
Delete From Stk_Adjust_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Diff_Batch')
BEGIN
Delete From Stk_Diff_Batch
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Item_Close')
BEGIN
Delete From Stk_Item_Close
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_MRN')
BEGIN
Delete From Stk_MRN
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_MRN_Dtl')
BEGIN
Delete From Stk_MRN_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_MTN_Dtl')
BEGIN
Delete From Stk_MTN_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Return')
BEGIN
Delete From Stk_Return
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Control_Panel_Log')
BEGIN
Delete From Stk_Return_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_TallyPost_Dtl')
BEGIN
Delete From Stk_TallyPost_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Transfer_Note')
BEGIN
Delete From Stk_Transfer_Note
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Transfer_Note_Dtl')
BEGIN
Delete From Stk_Transfer_Note_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stk_Upd_ItemDetails')
BEGIN
Delete From Stk_Upd_ItemDetails
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Approve')
BEGIN
Delete From Stock_Approve
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Approve_Dtl')
BEGIN
Delete From Stock_Approve_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Ctrl_Register')
BEGIN
Delete From Stock_Ctrl_Register
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Ledger')
BEGIN
Delete From Stock_Ledger
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_ReqApp_Log_Dtl')
BEGIN
Delete From Stock_ReqApp_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Request')
BEGIN
Delete From Stock_Request
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Stock_Request_Dtl')
BEGIN
Delete From Stock_Request_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Str_AMR_Dtl')
BEGIN
Delete From Str_AMR_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Str_Link_Page')
BEGIN
Delete From Str_Link_Page
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Supplier_Log_Dtl')
BEGIN
Delete From Supplier_Log_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Tmptrig')
BEGIN
Delete From Tmptrig
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Trans_Approve')
BEGIN
Delete From Trans_Approve
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Trans_Approve_Dtl')
BEGIN
Delete From Trans_Approve_Dtl
End 
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Tally_Purchase_ledger')
BEGIN
Delete From Tally_Purchase_ledger
End 
Go
USe ASTIL_Tally
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Doctor_Fee_Payment')
BEGIN
Delete from Doctor_Fee_Payment
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Doctor_Fee_payment_Dtl')
BEGIN
Delete from Doctor_Fee_payment_Dtl
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Tally_Sales')
BEGIN
Delete from Tally_Sales
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Tally_Purchase')
BEGIN
Delete from Tally_Purchase
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Rec')
BEGIN
Delete from Item_Recall_Rec
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Rec_Dtl')
BEGIN
Delete from Item_Recall_Rec_Dtl
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Req')
BEGIN
Delete from Item_Recall_Req
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Req_Dtl')
BEGIN
Delete from Item_Recall_Req_Dtl
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Retn')
BEGIN
Delete from Item_Recall_Retn
End
Go
IF EXISTS(select * from ASTIL_Tally.sys.objects where type='U' and name='Item_Recall_Retn_Dtl')
BEGIN
Delete from Item_Recall_Retn_Dtl
End

Go
Use ASTIL_Stock
Go
IF EXISTS(select * from ASTIL_Stock.sys.objects where type='U' and name='POSTerminal_Transaction')
BEGIN
Delete from ASTIL_Stock..POSTerminal_Transaction
End

 