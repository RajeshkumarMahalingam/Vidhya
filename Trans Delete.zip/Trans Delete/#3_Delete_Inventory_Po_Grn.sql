 

Use Kmch_Inventory
/*
Controls & masters
Bin_Location
ControlPanel
Ctrl_AcHeader_Dtl
Ctrl_Appr_UserLvl
Ctrl_RunningNos
GRN_MRP_Items
Issue_Type
Item_Brand
Item_Brand_Dept
Item_Grp
Item_Pack
Item_Service_Dtl
Item_Tax
Item_Type
ItemOrderList
Manf
Mast_Contract_Dtl
Mast_Contract_Hdr
Mast_Currency
Mast_Delivery_Terms
Mast_Equip_Dtl
Mast_Equipment
Mast_Files_Attach
Mast_Item_Concession
Mast_PO_Comments
Mast_SalesPrice_Def
Mast_Stk_ItemBrand
Mast_Store
Mast_Terms
OT_Package
OT_Package_Dtl
Payment_Terms
PO_Ins
PO_Prn_Content
Running_Numbers
Running_Numbers_Log
Str_Item_Type
Str_ItemRights
Supplier
Supplier_Item
Supplier_Type
Temp_TriggerCnt
UOM
User_Dept_Rights
User_Str_Rights
GRN_Dtl --
GRN_Hdr --
Item_Batchwise_Stk --
Item_Stk_Detail --
PO_Dtl --
PO_Hdr --
Purchase_Dtl --
Purchase_Hdr --

*/
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Dtl')
BEGIN
Delete From GRN_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='GRN_Hdr')
BEGIN
Delete From GRN_Hdr
End
Go


IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PO_Dtl')
BEGIN
Delete From PO_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='PO_Hdr')
BEGIN
Delete From PO_Hdr
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Dtl')
BEGIN
Delete From Purchase_Dtl
End
Go
IF EXISTS(select * from Kmch_Inventory.sys.objects where type='U' and name='Purchase_Hdr')
BEGIN
Delete From Purchase_Hdr
End
Go

 
