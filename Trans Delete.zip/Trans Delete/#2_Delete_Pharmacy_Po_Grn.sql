 

Use KMCH_Pharmacy

Go
-- Tables Of Predefined Values , Masters and Settings
/*
Ctrl_Rpt_Options
Drug_Freq
Drug_Brand_Discount
Issue_Type
Mast_Dispatch_Counter
Drug_Package
Drug_Package_Dtl
Drug_Release
Drug_Pack
User_PhStore_Rights
Drug_Index
Drug_Class
UOM
Drug_Generic
Drug_Grp
Bin_Location
Drug_Tax
Payment_Terms
Ctrl_ListItems
Mast_MfrSupp_Link
ControlPanel
Mast_SalRtn_Counts
Drug_Brand_Location
Drug_Type
Drug_Brand
Ctrl_AcHeader_Dtl
Supplier
Pharma_Store
Mast_SalRtnRemarks
Drug_Brand_Generic
Supplier_Item
Drug_Brand_Doc
Manf
Item_Stk_Detail --
Mast_Marketer
Running_Numbers
Ctrl_PriceRoundOff
PriceList_Hdr
GRN_Hdr --
Item_Batchwise_Stk --
PriceList_Dtl
PO_Dtl --
GRN_Dtl --
PO_Hdr --
Mast_Drug_Brand -> Not Necessary master. But Referreed with Drug_Brand

*/

Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Hdr')
BEGIN
Delete From GRN_Hdr
End

Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='GRN_Cheque')
BEGIN
Delete From GRN_Cheque
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Dtl')
BEGIN
Delete From PO_Dtl
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='PO_Hdr')
BEGIN
Delete From PO_Hdr
End
Go
IF EXISTS(select * from KMCH_Pharmacy.sys.objects where type='U' and name='Grn_Dtl')
BEGIN
Delete From Grn_Dtl
End

 