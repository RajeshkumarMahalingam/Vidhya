from  importstatements import *
class ReadExcell(Selenium2Library) :
 r = 0
 d = {}
 d[r] = {}
 objects = {}
 def data_off(self,sheet):    
    c = 1
    wrkbk = load_workbook('../../datas/bb_datas.xlsx')
    sheet = wrkbk[sheet]
    number_of_rows = sheet.max_row
    number_of_columns = sheet.max_column
    while self.r <= number_of_rows - 2 :
      self.r= self.r + 1 
      self.d[self.r]= {}
      c = 1
      while c <= number_of_columns - 1:
       c = c + 1
       self.d[self.r][sheet.cell(row=(1),column=c).value] = sheet.cell(row=(self.r+1),column=c).value         
    return self.d
 def bb_objects(self):      
        wb = openpyxl.load_workbook('../../object_repository/objects.xlsx')        
        ws = wb["obj"]           
        for row in ws.rows:            
            self.objects[row[0].value] = row[1].value
        return self.objects
   

#ReadExcell().data_off("op_new_reg") 
#ReadExcell().bb_objects()
#d = ReadExcell().data_off("op_new_reg")
#print d[1]
#print ReadExcell().objects