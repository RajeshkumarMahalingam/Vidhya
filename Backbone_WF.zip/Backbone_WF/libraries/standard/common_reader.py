from  common_importstatements import *
class Capturing(Selenium2Library) :
 #r = 0
 d = {}
 #d[r] = {}
 objects = {}
 
 def data_off(self,sheet):
    self.d={}
    r = 0
    c = 1
    try :
         wrkbk = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
    except NameError:
         wrkbk = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
    except :
         wrkbk = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
    sheet = wrkbk[sheet]
    number_of_rows = sheet.max_row
    number_of_columns = sheet.max_column
    while r <= number_of_rows - 2 :
      r= r + 1 
      self.d[r]= {}
      c = 1
      while c <= number_of_columns - 1:
       c = c + 1
       self.d[r][sheet.cell(row=(1),column=c).value] = sheet.cell(row=(r+1),column=c).value
    #print sheet
    #print self.d
    return self.d
 
 def capture_screenshot(self,filename):
        getscreenshot = pyautogui.screenshot()
        try :
         getscreenshot.save((r'D:\workspace\Backbone_WF\screenshots')+"\\"+str(filename)+'.png')
        except NameError:
         getscreenshot.save((r'D:\workspace\Backbone_WF\screenshots')+"\\"+str(filename)+'.png')
        except :
         getscreenshot.save((r'D:\workspace\Backbone_WF\screenshots')+"\\"+str(filename)+'.png')

 def backbone_objects(self):
        try :  
          wb = openpyxl.load_workbook('D:\workspace\Backbone_WF\object_repository\objects.xlsx')  
        except NameError :
          wb = openpyxl.load_workbook('D:\workspace\Backbone_WF\object_repository\objects.xlsx')  
        except :
          wb = openpyxl.load_workbook('D:\workspace\Backbone_WF\object_repository\objects.xlsx')         
        ws = wb["obj"]           
        for row in ws.rows:            
            self.objects[row[0].value] = row[1].value
        return self.objects

Capturing().backbone_objects()
#Capturing().data_off(sheet)
#print d[1]
#print d[2]
#print d[3]
#print d[4]
#print Capture().objects