"""
Class Name           : (1)lanuching browser to menu load
Contains 3 functions : (2)drive_browser_and_url 
                           Step 1 : Get browser which is marked as "1" from excell SHEET
                           step 2 : Get Url which is marked as "1" from excell SHEET
                           step 3 : Launch browser and url
                     : (3)login_module(Module to be be logged in)
                           Step 1 : Get user name and password from excell for which module to login
                           Step 2 : Login module with user name and password
                     : (4)load_menu
                           Step 1 : Get Sub menu name and menu name from excel for the specified link
                           Srep 2 : Load menu
"""
#from  .standard import importstatements 
import sys
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
#from pyautogui import moveRel
#from selenium.webdriver.common.keys import Keys
sys.path.append('../standard')
sys.path.append('../../libraries/standard')
#newly added
from Selenium2Library import Selenium2Library
import common_importstatements
from common_importstatements import *
class FromConfigFile(Selenium2Library):
 i = 1
 j = 1
 k = 1
 l = 1
 temp = 0
 dict = {}  
 telement = ""
  
 '''def admin_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()'''
        
 def checking_menu_test(self, link):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.link = link
        y = len(self.link)
        for z in range(y):
            t = (self.link[z:z+1])
            if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
                flink = (self.link[z:])
                z = 0
                break
        z = z + 1
        try : 
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')   
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2).value
          sm =  sheet.cell(row=(self.i),column=3).value
          mm = sheet.cell(row=(self.i),column=4).value
          wrkbk.close()
          i = 0
          break
        else:
         print "Link does not exists in excel sheet"
        if tm is not None:
            print "top menu is", tm
            self.wait_until_element_is_visible('xpath=//*[@id="menulist"]', 30, 'Menu list is not loaded')
            self.mouse_over('xpath=//*[text()="'+tm+'"]/..')
            time.sleep(1)
            self.dict['BROWSER'] = self._current_browser()
            if sm is not None:
                print "sub menu is", sm
                self.click_element('xpath=//*[text()="'+sm+'"]')
                time.sleep(1)
                self.dict['BROWSER'] = self._current_browser()
                if mm is not None:
                    print "main menu is",  mm
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    time.sleep(1)
                    self.dict['BROWSER'] = self._current_browser()
            else:
                if mm is not None:
                    print "else part main menu is", mm
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    time.sleep(1)
                    self.dict['BROWSER'] = self._current_browser()
        else:
            print "top menu not found"
        self.dict['BROWSER'] = self._current_browser()
 def loading_menu_of_link(self,link):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.i = 1
        self.temp = 0
        self.telement = ""
        self.link = link
        y = len(self.link)
        for z in range(y):
         t = (self.link[z:z+1])
         if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
          flink = (self.link[z:])
          print "flink value"
          print flink
          z = 0
          break
         z = z + 1
        #Step 1 : Get Sub menu name and menu name from excel for the specified link
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        try : 
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')   
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2)
          sm =  sheet.cell(row=(self.i),column=3)
          mm = sheet.cell(row=(self.i),column=4)
          print tm
          print sm
          print mm
          
          wrkbk.close()
          i = 0
          break
        else:
         print "Link does not exists in excel sheet" 
         i = 0 
        
        #Step 2 : Load Menu
        while i <= 5 and flink == xllink:
         #i = i + 1
         self.temp = self.temp + 1
         x = str(self.temp)
         t1 = '"menulist"]/li['
         t2 = ']'
         x = t1 + x + t2 
         #time.sleep(1)
         telement = self._element_find('xpath=//*[@id='+x+'', True, False)
         time.sleep(1)
         #element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "myDynamicElement")) 
         if telement  is not None:
            time.sleep(1)
            if (telement.is_displayed()) == True:
             #time.sleep(2)
             self.mouse_over('xpath=//*[@id='+x+'')
             #time.sleep(1)
             if sm.value is not None:
              #time.sleep(2)
              selement = self._element_find('xpath=//*[(text()="'+sm.value+'")]', True, False)
              #print selement
              time.sleep(1)
              melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
              #print melement
              time.sleep(2)
              if selement is not None:
               #time.sleep(2)
               if (selement.is_displayed()) == True:
                #print "hello"
                self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                if melement is not None :
                  time.sleep(2)
                  if (melement.is_displayed()) == True:
                   self.click_element('xpath=//*[(text()="'+mm.value+'")]') 
                   #time.sleep(5)
                   self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                   #time.sleep(3)
                   self.mouse_over('xpath=//*[@id="chkNewwindow"]') 
                   #pyautogui.moveRel(100, 100)
                   self.dict['BROWSER'] = self._current_browser()
                   return self.dict
                   break         
             elif sm.value is None:
                melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
                if melement is not None:
                     if (melement.is_displayed()) == True:
                      time.sleep(2)
                      self.click_element('xpath=//*[(text()="'+mm.value+'")]')
                      time.sleep(3)
                      self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                      #pyautogui.moveRel(0, 20)
                      #time.sleep(2) 
                      #pyautogui.moveRel(100, 100)
                      self.dict['BROWSER'] = self._current_browser()
                      return self.dict
                      break
         else: 
              print "top menu not found"
         i = i + 1  
        
 def driving_browser_and_url(self):
        self.set_selenium_implicit_wait(30)
        self.j = 1
        self.k = 1
        #Step 1 : Get browser which is marked as "1" from excell SHEET
        try :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')  
        except NameError :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')        
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        sheet = wrkbk["browser_sheet"] 
        number_rows = sheet.max_row
               
        while self.j <= number_rows:
         self.j = self.j + 1
         if sheet.cell(row=(self.j),column=2).value == 1:
          bwr = sheet.cell(row=(self.j),column=1)
        #step 2 : Get Url which is marked as "1" from excell SHEET
        sheet = wrkbk["url_sheet"]
        number_rows = sheet.max_row
        while self.k <= number_rows:
         self.k = self.k + 1
         if sheet.cell(row=(self.k),column=2).value == 1:
          url = sheet.cell(row=(self.k),column=1)
          wrkbk.close()
        #step 3 : Launch browser and url
        self.open_browser(''+url.value+'',''+bwr.value+'', None, False, None, None)
        #newly added
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 50, 'relogin  button not visible')
        #newly commented
        #time.sleep(5)
        self.maximize_browser_window()
        self.browser = self._current_browser()
        self.dict['BROWSER'] = self._current_browser()
      
 def logging(self,loginmod):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.l = 1
        #Step 1 : Get user name and password from excell for which module to login
        try : 
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        except :  
          wrkbk = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')  
        sheet = wrkbk["login_sheet"] 
        number_rows = sheet.max_row
        while self.l <= number_rows:
         self.l = self.l + 1
         if sheet.cell(row=(self.l),column=1).value == loginmod:
             user = sheet.cell(row=(self.l),column=2)
             pw =   sheet.cell(row=(self.l),column=3)
        #Step 2 : Login module with user name and password
        self.click_element('xpath=//a[@href="#divNewSession"]')
        #newly added
        self.wait_until_element_is_visible('xpath=//*[@id="newuname"]', 50, 'login button not visible')
        # newly commented
        #time.sleep(5)
        self.input_text('xpath=//*[@id="newuname"]',''+user.value+'')
        self.input_text('xpath=//*[@id="txtrepassword"]',''+pw.value+'')
        self.click_button('xpath=//*[@id="btnrelogin"]')
        #Newly commented
        #time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
 
 def Logoff(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(30)
        self.unselect_frame()
        self.wait_until_element_is_visible('xpath=//*[@class="fa fa-power-off"]', 30, 'Log out was not visible')
        self.click_element('xpath=//*[@class="fa fa-power-off"]')
        self.wait_until_element_is_visible('id=uname', 30, 'Log out is not successful')
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 100, 'login button not visible')
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
  
 def zoom_out_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.browser.execute_script("document.body.style.zoom='65%'")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()  
 def zoom_in_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.browser.execute_script("document.body.style.zoom='100%'")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()  
        
 def Test_Teardown(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.close_browser()
        