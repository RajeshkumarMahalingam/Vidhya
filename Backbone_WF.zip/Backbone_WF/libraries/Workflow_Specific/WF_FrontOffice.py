import sys
from Selenium2Library import Selenium2Library
from random import randint
#from genericpath import exists
#from selenium.webdriver.remote.webelement import isDisplayed_js
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
from openpyxl import load_workbook
#from selenium import webdriver
#from selenium.webdriver.common.keys import Keys
from datetime import datetime, timedelta
import datetime
import time



class InNewOpRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    reg = ""
    d = Capturing().data_off("QA_Multiple_OPREG")
    regtobedone = 0
    j = 0
    def InNewOp_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def select_the_frame(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_MainFrame'], 20, 'Frame was not visible')
        self.select_frame(self.objects["FO_MainFrame"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Dept'], 20, 'Dept was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["opnewreg_department"])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctorUnit"]', 50, 'Unit was not visible')
        self.select_from_list_by_label('xpath=//*[@id="cboDoctorUnit"]',self.d[r]["opnewreg_unit"])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Doc'], 20, 'doctor was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["opnewreg_doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Sal'], 20, 'sal was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"],self.d[r]["opnewreg_sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        #time.sleep(50)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Name'], 20, 'name was not visible')
        self.input_text(self.objects["FO_NewRegistration_Name"],self.d[r]["opnewreg_name"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Gender'], 20, 'gender was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"],self.d[r]["opnewreg_gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Age'], 20, 'age was not visible')
        self.input_text(self.objects["FO_NewRegistration_Age"],self.d[r]["opnewreg_age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_MaritalStatus'], 20, 'status was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],self.d[r]["opnewreg_marital_status"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Address'], 20, 'address was not visible')
        self.input_text(self.objects["FO_NewRegistration_Address"],self.d[r]["opnewreg_present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_City'], 50, 'City was not visible')
        self.click_element(self.objects['FO_NewRegistration_City'])
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_City_Entry'], 50, 'City entry was not visible')
        self.input_text(self.objects["FO_NewRegistration_City_Entry"],self.d[r]["opnewreg_city"])
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_City_Entry'], 50, 'City entry was not visible')
        self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile_with_data(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Mobile'], 50, 'City entry was not visible')
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Mobile'], 50, 'save was not enabled')
        self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()
    def entering_email_with_data(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtEmail"]', 50, 'email entry was not visible')
        self.wait_until_element_is_enabled('xpath=//*[@id="txtEmail"]', 50, 'email was not enabled')
        self.click_element('xpath=//*[@id="txtEmail"]')
        self.dict['BROWSER'] = self._current_browser()         
    def clicking_save(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled(self.objects["FO_NewRegistration_Save"], 50, 'save btn was not enabled')
        self.click_button(self.objects["FO_NewRegistration_Save"])
        self.dict['BROWSER'] = self._current_browser()

    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

        
    def regmatchcount(self,required_op_new_count):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="PtCount"]', 20, 'patient count was not visible')
        #patientcount =  self.get_text('xpath=//*[@id="PtCount"]')
        #print patientcount
        #newcount = ((patientcount).split('New : '))[1].split(' / Review :')[0]
        #reviewcount = (patientcount).split('Review : ')[1]
        #print int(newcount)
        #print int(reviewcount)
        #patientregisteredcount =  int(newcount) + int(reviewcount)
        #print "patient registered count", patientregisteredcount
        patientregisteredcount = 1
        regtobedone = required_op_new_count - patientregisteredcount
        print "registration checking starts"
        return regtobedone
        self.dict['BROWSER'] = self._current_browser()
        
    def testexcep(self,r,wb,j):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 10, 'save was not visible before try block')
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Save'], 10, 'save was not enabled')
        try :
         self.click_button(self.objects["FO_NewRegistration_Save"]) 
         #time.sleep(1)
         self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 10, 'save was not visible before try block-1') 
         self.click_element(self.objects["FO_NewRegistration_Mobile"])
         #self.input_text(self.objects["FO_NewRegistration_Mobile"], "1")
         #self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["opnewreg_department"])
        except ElementNotInteractableException:
              try:
                if self._is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]'):
                 self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]', 50, 'no button was not visible')
                 self.click_element('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]')
                 self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
                 self.click_button('xpath=//*[@id="btnClr"]')
                 print "Invalid Data, already registered pop up msg"
                 ws = wb["QA_Multiple_OPREG"]
                 ws.cell(row=(r),column=3).value = "Invalid Data"
                 j = j + 1
              except:
                    self.unselect_frame()
                    self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                    self.click_element('xpath=//*[@class="fa fa-home"]')
                    ws = wb["QA_Multiple_OPREG"]
                    ws.cell(row=(self.r),column=3).value = "Invalid Data"
                    j = j + 1
                    self.select_frame(self.objects["FO_MainFrame"])
        except ElementClickInterceptedException:
            try:
                if self._is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]'):
                 self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]', 50, 'no button was not visible')
                 self.click_element('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]')
                 self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
                 self.click_button('xpath=//*[@id="btnClr"]')
                 print "Invalid data"
                 ws = wb["QA_Multiple_OPREG"]
                 ws.cell(row=(r),column=3).value = "Invalid Data"
                 j = j + 1
            except:
                    self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                    self.click_element('xpath=//*[@class="fa fa-home"]')
                    ws = wb["QA_Multiple_OPREG"]
                    ws.cell(row=(self.r),column=3).value = "Invalid Data"
                    j = j + 1
                    self.select_frame(self.objects["FO_MainFrame"])
        except StaleElementReferenceException:
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=3).value = "Data Posted"
            print "Data posted - except part"
            j = j + 1
            self.unselect_frame()
            self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
            self.click_element('xpath=//*[@class="fa fa-home"]')
            self.select_frame(self.objects["FO_MainFrame"])
            #time.sleep(randint(5,20))
        else:
         try:
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'message was not visible in else')
            self.click_button('xpath=//button[@class="toast-close-button"]')
         except:
            print "Data posted - else part message was not displayed"
            self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
            self.click_button('xpath=//*[@id="btnClr"]')
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=3).value = "Data Posted"
            j = j + 1
         else:           
            print "Data posted - else part"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=3).value = "Data Posted"
            j = j + 1
            #time.sleep(randint(5,20))
        return j
        self.dict['BROWSER'] = self._current_browser()

