import sys
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import admin
from admin import FromConfigFile
import WF_FrontOffice
from WF_FrontOffice import InNewOpRegistration
from datetime import datetime, timedelta, date
import datetime
import time
import pyautogui
import openpyxl
from openpyxl import load_workbook
import common_reader
from common_reader import Capturing
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
import common_importstatements
from common_importstatements import *
import psutil
from selenium.common.exceptions import StaleElementReferenceException  
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotInteractableException


class Opnewregistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    #regtobedone = WF_FrontOffice.InNewOpRegistration.regtobedone
    #rw = 0
    def multiple_opnew_registration(self):
        self.set_selenium_implicit_wait(30)
        print datetime.datetime.now()
        wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
        ws = wb["QA_Multiple_OPREG"]
        num_rows = ws.max_row
        self.r = 1
        wb.close()
        admin.FromConfigFile().driving_browser_and_url()
        admin.FromConfigFile().logging("frontofficeQAnew")
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        WF_FrontOffice.InNewOpRegistration().select_the_frame()
        wb = load_workbook('D:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        ws = wb["Reg_WF_Settings"]
        setregcount = ws.cell(row=2,column=3).value
        wb.close()
        required_op_new_count = 0 
        if setregcount == 1:
            required_op_new_count = ws.cell(row=2,column=1).value
            regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
            print "regtobedone before save", regtobedone
        else:
            regtobedone = 1000000
        print regtobedone
        print required_op_new_count
        i = 1
        j = 0
        wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
        ws = wb["QA_Multiple_OPREG"]
        while self.r < num_rows and j < regtobedone:
         self.r = self.r + 1
         statusvalue = ws.cell(row=(self.r),column=2).value
         print statusvalue
         if statusvalue == "yes":
          rwno = self.r - 1
          start_time = datetime.datetime.now()
          try :
           time.sleep(3)
           WF_FrontOffice.InNewOpRegistration().selecting_department_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().selecting_doctor_with_data(rwno)
           #WF_FrontOffice.InNewOpRegistration().selecting_unit_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().selecting_sal_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().entering_name_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().selecting_gender_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().entering_age_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().selecting_maritalstatus_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().entering_address_with_data(rwno)
           #time.sleep(1)
           WF_FrontOffice.InNewOpRegistration().entering_mobile_with_data(rwno)
           #time.sleep(1)
           #WF_FrontOffice.InNewOpRegistration().selecting_city_with_data(rwno)
           try:
            WF_FrontOffice.InNewOpRegistration().entering_email_with_data()
           except ElementClickInterceptedException:
                 self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
                 self.click_button('xpath=//*[@id="btnClr"]')
                 print "Invalid"
                 ws = wb["QA_Multiple_OPREG"]
                 ws.cell(row=(r),column=3).value = "Invalid Data"
                 j = j
                 return j
           else: 
          #WF_FrontOffice.InNewOpRegistration().clicking_save()
          #WF_FrontOffice.InNewOpRegistration().test_Fetching_regno()
          #WF_FrontOffice.InNewOpRegistration().testing_Fetching_regno()
          #WF_FrontOffice.InNewOpRegistration().testinggg_Fetching_regno()
            j = WF_FrontOffice.InNewOpRegistration().testexcep(self.r,wb,j)
            print j
           #regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
           #finally:
            print "regtobedone after save", regtobedone
            print "self.r", self.r
            print "numberofnows",num_rows
            print "j", j
            end_time = datetime.datetime.now()
            diff_time = end_time-start_time
            diff_seconds =  diff_time.total_seconds()
            ws = wb["QA_Multiple_OPREG"]
            ws = wb.active
            ws.cell(row=(self.r),column=4).value = diff_seconds
            print(diff_seconds)
            ws = wb["QA_Multiple_OPREG"]
            rampercentage =  psutil.virtual_memory()[2]
            ws.cell(row=(self.r),column=6).value = rampercentage
            print rampercentage
            if diff_seconds > 50 or rampercentage > 80:
              print "Crossed 50 second"
              ws = wb["QA_Multiple_OPREG"]
              ws = wb.active
              ws.cell(row=(self.r),column=5).value = "Crossed 50 secs or ram percent crossed 80, so re-login browser"
              admin.FromConfigFile().Logoff()
              admin.FromConfigFile().Test_Teardown()
              admin.FromConfigFile().driving_browser_and_url()
              admin.FromConfigFile().logging("frontofficeQAnew")
              WF_FrontOffice.InNewOpRegistration().select_the_frame()
          except :
              print "overall except"
              ws = wb["QA_Multiple_OPREG"]
              ws = wb.active
              ws.cell(row=(self.r),column=3).value = "Data not Posted - overall Exception"
              wb.save('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
              wb.close()
              try:
                  end_time = datetime.datetime.now()
                  diff_time = end_time-start_time
                  diff_seconds =  diff_time.total_seconds()
                  wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
                  ws = wb["QA_Multiple_OPREG"]
                  ws = wb.active
                  ws.cell(row=(self.r),column=4).value = diff_seconds
                  print(diff_seconds)
                  ws = wb["QA_Multiple_OPREG"]
                  rampercentage =  psutil.virtual_memory()[2]
                  ws.cell(row=(self.r),column=6).value = rampercentage
                  print rampercentage
                  wb.close()
                  WF_FrontOffice.InNewOpRegistration().unselecting_the_frame
                  admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontofficeQAnew")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
              except:
                  print "inside except except"
                  WF_FrontOffice.InNewOpRegistration().unselecting_the_frame
                  admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontofficeQAnew")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
        wb.save('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
        wb.close()
        WF_FrontOffice.InNewOpRegistration().unselecting_the_frame
        admin.FromConfigFile().Logoff()
        admin.FromConfigFile().Test_Teardown()

