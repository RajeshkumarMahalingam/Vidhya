SELECT * 
from (
select  'cs1' id,'FO' as Module,'Consultation Based on (New/Review)' as control, iConSett_Based as value from KMCH_fRONTOFFICE..Control_Panel_Frontoffice where ipat_type = 1 and icomp_id =1 
union
select  'cs2' id,'FO' as Module,'Nationality Mandatory' as control, bNationality_Mandatory as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch 
union
select  'cs3' id,'FO' as Module,'Nationality ID Mandatory' as control, bNationality_ID_Mandatory as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs4' id,'FO' as Module,'Occupation required' as control, iOccupationRequired as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs5' id,'FO' as Module,'referral doctor mandatory' as control, bReferralDoctorMandatory as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs6' id,'FO' as Module,'IP Admit Diagnosis Mandatory(icd code)' as control, bIP_Admit_Diagnosis_Mandatory as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs7' id,'FO' as Module,'Casecoordinator & casemanager' as control, iCaseCoordinatorAndCaseManagerCaptureInIP as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs8' id,'FO' as Module,'Same day review registration alert' as control, bSameDay_Review_Alert_Required as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs9' id,'FO' as Module,'Billing Datas Required' as control, ibill_Data as value from KMCH_fRONTOFFICE..Control_Panel_Frontoffice WHERE  ipat_type = 1 AND icomp_id = 1	
union
select  'cs10' id,'FO' as Module,'Redirect to Billing' as control, bRedirect_To_Billing as value from KMCH_fRONTOFFICE..FO_Reg_Consultant_Fee_Fetch	
union
select  'cs11' id,'FO' as Module,'Reg Bill Approval' as control, iColumn as value from KMCH_billing..billing_ascertain where cDescription = 'Reg Bill Approval' and iCompany_id =1	
union
select  'cs12' id,'FO' as Module,'OP Bill Direct Refund Limit' as control, iColumn as value from KMCH_billing..billing_ascertain where cDescription = 'OP Bill Direct Refund Limit' and iCompany_id =1	
union
select  'cs13' id,'FO' as Module,'IP Concession Request and Approval Flow' as control, iColumn as value from KMCH_billing..billing_ascertain where cDescription = 'IP Concession Request and Approval Flow' and iCompany_id =1	
union
select  'cs14' id,'FO' as Module,'Need Admission Bed Acknowledgement (Assign to Bed)' as control, bRecpAck as value from KMCH_Frontoffice..Ward_Ctrl_Panel WHERE iCompany_Id=1	
union
select  'cs15' id,'FO' as Module,'Need Fumigation process' as control, iFumigation as value from KMCH_Frontoffice..Ward_Ctrl_Panel WHERE iCompany_Id=1	
union
select  'cs16' id,'FO' as Module,'Allow Bed Transfer in Ward Home' as control, iBedtrans_Home as value from KMCH_Frontoffice..Ward_Ctrl_Panel WHERE iCompany_Id=1	
union
select  'cs17' id,'FO' as Module,'Need Acknowledgement for Bed Transfer' as control, bBedAck as value from KMCH_Frontoffice..Ward_Ctrl_Panel WHERE iCompany_Id=1	
union
select  'cs18' id,'FO' as Module,'After Discharge Bed Status changed as' as control, iAftbedDis as value from KMCH_Frontoffice..Ward_Ctrl_Panel WHERE iCompany_Id=1	
union
select  'cs19' id,'FO' as Module,'Specimen Send To Department' as control, bSpecimenSendtoDept as value from KMCH_Lab..Control_Panel_Printing	
union
select  'cs20' id,'FO' as Module,'Depart Wise Specimen Collection' as control, bDeptWise_SNo as value from KMCH_Lab..Control_Panel_Printing	
union
select  'cs21' id,'FO' as Module,'InSpecimenCollectionLab' as control, bRequest_Approve_Reception as value from KMCH_Lab..Control_Panel_Printing	
union
select  'cs22' id,'FO' as Module,'InSpecimenCollectionWard' as control, bNurseStationPrn as value from KMCH_Lab..Control_Panel_Printing	
union
select  'cs23' id,'FO' as Module,'InCultureTechnicianApprove' as control, bCultureTechApprove as value from KMCH_Lab..Control_Panel_Printing	
union
select  'cs24' id,'FO' as Module,'OT Booking Approval' as control, bOTBookingApproval as value from KMCH_OT..Control_Panel
union
select  'cs25' id,'FO' as Module,'PAC Required' as control, bPACRequired as value from KMCH_OT..Control_Panel
union
select  'cs26' id,'FO' as Module,'CARD-FrontOffice Approval Require ' as control, bFrontOffice_Approval_Require as value from KMCH_Cardiology..Control_Panel
union
select  'cs27' id,'FO' as Module,'RAD-FrontOffice Approval Require ' as control, bFrontOffice_Approval_Require as value from KMCH_Radiology..Control_Panel_Printing
union
select  'cs500' id,'OPBILLING' as Module,'RefundPaymode allowed only by Cash in OPBillRefund ' as control, iColumn as value from KMCH_Billing..Billing_Ascertain WHERE iRow_id=3587
union
select  'cs501' id,'WARD' as Module,'Accident Register Need Manual Running No ' as control, iAcc_Manualrun_no as value from KMCH_Frontoffice..Ward_Ctrl_Panel
union
select  'cs502' id,'RAD' as Module,'Result Approve ' as control, bProc_Approval as value from KMCH_Radiology..Control_Panel_Printing
union
select  'cs503' id,'CARD' as Module,'Request Print ' as control, bRequest_Print as value from KMCH_Cardiology..Control_Panel
union
select  'cs504' id,'BloodBank' as Module,'Reg Date & Unit No Edit ' as control, bUser_Pref as value from kmch_frontoffice..Control_Panel
union
select  'cs505' id,'OPBILLING' as Module,'Advance Direct Refund ' as control, iColumn as value from KMCH_Billing..Billing_Ascertain WHERE iRow_id=3510
union
select  'cs506' id,'IPBILLING' as Module,'Auto Deposit Transfer to IP ' as control, iColumn as value from KMCH_Billing..Billing_Ascertain WHERE iRow_id=233
union
select  'cs507' id,'OT' as Module,'Anesthetist Name Required  ' as control, bAneasthetistRequired as value from KMCH_OT..Control_Panel



) AS subquery
ORDER BY CAST(SUBSTRING(id, 3, LEN(id)) AS INT) ASC;
