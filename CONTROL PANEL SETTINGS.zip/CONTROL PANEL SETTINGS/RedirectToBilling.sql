Select * from FO_Reg_Consultant_Fee_Fetch
Select bRedirect_To_Billing from FO_Reg_Consultant_Fee_Fetch

Update FO_Reg_Consultant_Fee_Fetch set bRedirect_To_Billing = 1

select * from FO_Reg_Consultant_Fee_Fetch
update FO_Reg_Consultant_Fee_Fetch set iCurrentDtValidationforIpReg=1