ALTER procedure Sp_ExecStatUpdate 
as 
begin         
	-- exec Sp_ExecStatUpdate         
	/*Query to run stat update for the mentioned database automatically*/     
	/*Region : start*/     
	exec kmch_frontoffice..sp_updatestats      
	exec KMCH_Billing..sp_updatestats  
	exec KMCH_Cardiology..sp_updatestats  
	exec KMCH_Radiology..sp_updatestats  
	exec KMCH_Pharmacy..sp_updatestats  
	exec KMCH_OT..sp_updatestats  
	exec KMCH_MHC..sp_updatestats  
	exec KMCH_Lab..sp_updatestats  
	exec Kmch_Inventory..sp_updatestats  
	exec KMCH_HR..sp_updatestats  
	exec KMCH_EMR..sp_updatestats  
	exec KMCH_Dietary..sp_updatestats  
	exec KMCH_CSSD..sp_updatestats  
	exec ASTIL_Physiotherapy..sp_updatestats  
	exec ASTIL_Canteen..sp_updatestats     
	exec ASTIL_Asset..sp_updatestats   
	/*Region : end*/     
end