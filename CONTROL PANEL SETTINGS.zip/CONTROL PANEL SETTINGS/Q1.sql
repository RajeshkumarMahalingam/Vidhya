Select iReg_Consultant_Fee_Fetch_Type from FO_Reg_Consultant_Fee_Fetch

select  '1' id,'FO' as Module,'asdasd' as control, iReg_Consultant_Fee_Fetch_Type as value from FO_Reg_Consultant_Fee_Fetch 
union
select  '2' id,'FO' as Module,'asdasd' as control, iReg_Consultant_Fee_Fetch_Type as value from FO_Reg_Consultant_Fee_Fetch 
