import sys
from selenium.webdriver.support.select import Select
from selenium.webdriver.edge.webdriver import WebDriver
from selenium.webdriver.edge import webdriver
from pygetwindow._pygetwindow_win import NULL
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import admin
from admin import FromConfigFile
import WF_FrontOffice
#from WF_FrontOffice import InNewOpRegistration
#from WF_FrontOffice import InIPRegistration
from datetime import datetime, timedelta, date
import datetime
import time
import pyautogui
import openpyxl
from openpyxl import load_workbook
import common_reader
from common_reader import Capturing
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
import common_importstatements
from common_importstatements import *
import psutil
from selenium.common.exceptions import StaleElementReferenceException  
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotInteractableException
from selenium.common.exceptions import UnexpectedAlertPresentException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.keys import Keys


class Opnewregistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_new")
    def multiple_opnew_registration(self):
        self.set_selenium_implicit_wait(30)
        print datetime.datetime.now()
        admin.FromConfigFile().driving_browser_and_url()
        admin.FromConfigFile().logging("frontoffice12semgm")
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        WF_FrontOffice.InNewOpRegistration().select_the_frame()
        wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
        ws = wb["test_new"]
        num_rows = ws.max_row
        wb.close()
        self.r = 1
        wb = load_workbook('E:\workspace\Backbone_WF_12\Config\Prerequsiteconfig.xlsx')
        ws = wb["Reg_WF_Settings"]
        setregcount = ws.cell(row=2,column=3).value
        wb.close()
        required_op_new_count = 0 
        if setregcount == 1:
            required_op_new_count = ws.cell(row=2,column=1).value
            regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
            print "regtobedone before save", regtobedone
        else:
            regtobedone = 1000000
        i = 1
        j = 0
        wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
        ws = wb["test_new"]
        time.sleep(5)
        while self.r < num_rows and j < regtobedone:
         self.r = self.r + 1
         statusvalue = ws.cell(row=(self.r),column=2).value
         print statusvalue
         if statusvalue == "yes":
           rwno = self.r - 1
           start_time = datetime.datetime.now()
           try:
            #time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="txtDept"]', 30, 'Dept txt 12se was not visible')
            self.click_element('xpath=//*[@id="txtDept"]')
            self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, 'Dept 12se was not visible')
            deptlistvalue = self.get_list_items(self.objects["FO_NewRegistration_Dept_12se"])
            sallistvalue = self.get_list_items(self.objects['FO_NewRegistration_Sal_12se'])
            pattypelistvalue = self.get_list_items(self.objects['FO_NewRegistration_PatType_12se'])
            deptstatus = self.d[rwno]["opnewreg_department"] in deptlistvalue
            salstatus = self.d[rwno]["opnewreg_sal"] in sallistvalue
            pattypestatus = self.d[rwno]["opnewreg_pattype"] in pattypelistvalue
            namelenvalue = len(self.d[rwno]["opnewreg_name"])
            namevalue = str(self.d[rwno]["opnewreg_name"])
            regularExp = re.compile('[~!@#$%^&*()_+-={}[]|\:;<>,?/*"')
            genlistvalue = self.get_list_items(self.objects["FO_NewRegistration_Gender_12se"])
            maritalstatuslistvalue = self.get_list_items(self.objects["FO_NewRegistration_MaritalStatus_12se"])
            genstatus = self.d[rwno]["opnewreg_gender"] in genlistvalue
            maritalstatus = self.d[rwno]["opnewreg_marital_status"] in maritalstatuslistvalue
            mobilelenvalue = len(str(self.d[rwno]["opnewreg_mobile"]))
            #print "deptlistvalue", deptlistvalue
            if deptstatus == True:
             WF_FrontOffice.InNewOpRegistration().selecting_department_with_data(rwno)
             #time.sleep(2)
             self.wait_until_element_is_visible('xpath=//*[@id="txtDoctor"]', 20, "unit txt element was not visible")
             self.click_element('xpath=//*[@id="txtDoctor"]')
             self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 20, 'unit 12se cbo was not visible')
             doclistvalue = self.get_list_items('xpath=//*[@id="cboDoctor"]')
             Reqdoc = self.d[rwno]["opnewreg_unit"]
             docstatus = Reqdoc in doclistvalue
             self.clear_element_text('xpath=//*[@id="txtDoctor"]')
             self.click_element('xpath=//*[@id="txtDoctor"]')
             #print ("doclistvalue"), doclistvalue
             if docstatus == True:
                WF_FrontOffice.InNewOpRegistration().selecting_unit_with_data(rwno)
                if salstatus == True:
                   WF_FrontOffice.InNewOpRegistration().selecting_sal_with_data(rwno)
                   if (namelenvalue <= 100) and (regularExp.search(namevalue) == None) and not(namevalue.__contains__('"')) and not (namevalue.__contains__("'")) or (namevalue.__contains__(".")):
                      WF_FrontOffice.InNewOpRegistration().entering_name_with_data(rwno)
                      if pattypestatus == True:
                         WF_FrontOffice.InNewOpRegistration().selecting_pattype_with_data(rwno)
                         if genstatus == True:
                            WF_FrontOffice.InNewOpRegistration().selecting_gender_with_data(rwno)
                            if int(self.d[rwno]["opnewreg_age"]) <= 150:
                               WF_FrontOffice.InNewOpRegistration().entering_age_with_data(rwno)
                               if maritalstatus == True:
                                  WF_FrontOffice.InNewOpRegistration().selecting_maritalstatus_with_data(rwno)
                                  if str(self.d[rwno]["opnewreg_present_address"]) and (str(self.d[rwno]["opnewreg_present_address"]).strip()):
                                     WF_FrontOffice.InNewOpRegistration().entering_address_with_data(rwno)
                                     if self.d[rwno]["opnewreg_city"] is not None:
                                        WF_FrontOffice.InNewOpRegistration().selecting_city_with_data(rwno)
                                        rellistvalue = self.get_list_items('xpath=//*[@id="cboRelation"]')
                                        relstatus = self.d[rwno]["opnewreg_relation"] in rellistvalue
                                        if self.d[rwno]["opnewreg_relationname"] is not None and relstatus == True:
                                           WF_FrontOffice.InNewOpRegistration().entering_relationname_with_data(rwno) 
                                           WF_FrontOffice.InNewOpRegistration().selecting_relation_with_data(rwno)
                                           #if (int(self.d[rwno]["opnewreg_mobile"])) is not None and (mobilelenvalue == 10) and (str(self.d[rwno]["opnewreg_mobile"])[0]!='0') and (str(self.d[rwno]["opnewreg_mobile"])[0]!='2'):
                                           print "mobile number:", str(self.d[rwno]["opnewreg_mobile"])
                                           mobilenumber = self.d[rwno]["opnewreg_mobile"]
                                           print type(mobilenumber)
                                           print mobilenumber
                                           if self.d[rwno]["opnewreg_mobile"] is not None:
                                              if (int(self.d[rwno]["opnewreg_mobile"]) > 0) and (str(self.d[rwno]["opnewreg_mobile"])[0]!='0') :
                                                 print "insid if mobile"
                                                 WF_FrontOffice.InNewOpRegistration().entering_mobile_with_data(rwno)
                                              WF_FrontOffice.InNewOpRegistration().entering_email_with_data()
                                              j = WF_FrontOffice.InNewOpRegistration().testexcep(self.r,wb,j)
                                              print "required_op_new_count", required_op_new_count
                                              if required_op_new_count !=0:
                                                     regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
                                                     print "regtobedone after", regtobedone
                                           else:
                                            ws.cell(row=(self.r),column=3).value = "Improper Mobile number"
                                            j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)
                                        else:
                                         ws.cell(row=(self.r),column=3).value = "Improper relation"
                                         j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)
                                     else:
                                      ws.cell(row=(self.r),column=3).value = "Improper City"
                                      j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j) 
                                  else:
                                    ws.cell(row=(self.r),column=3).value = "Improper address"
                                    j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j) 
                               else:
                                 ws.cell(row=(self.r),column=3).value = "Improper Marital status"
                                 j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j) 
                            else:
                              ws.cell(row=(self.r),column=3).value = "Improper age"
                              j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j) 
                         else:
                          ws.cell(row=(self.r),column=3).value = "Improper gender" 
                          j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)
                      else:
                          ws.cell(row=(self.r),column=3).value = "Improper patient type" 
                          j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)      
                   else:
                       ws.cell(row=(self.r),column=3).value = "Improper name"
                       j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)           
                else:
                    ws.cell(row=(self.r),column=3).value = "Improper Salutation"
                    j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)
             else:
                 ws.cell(row=(self.r),column=3).value = "Improper Unit"
                 j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)       
            else:
                ws.cell(row=(self.r),column=3).value = "Improper Department"
                j =  WF_FrontOffice.InNewOpRegistration().selecting_next_record(j)                             
            end_time = datetime.datetime.now()
            diff_time = end_time-start_time
            diff_seconds =  diff_time.total_seconds()
            #print "diff_seconds", diff_seconds
            ws = wb["test_new"]
            ws = wb.active
            ws.cell(row=(self.r),column=4).value = diff_seconds
            ws = wb["test_new"]
            rampercentage =  psutil.virtual_memory()[2]
            ws.cell(row=(self.r),column=6).value = rampercentage
            #print "ramperce", rampercentage
            if diff_seconds > 50 or rampercentage > 80:
               print "inside crossed secs loop"
               self.unselect_frame()
               admin.FromConfigFile().Logoff()
               ws = wb["test_new"]
               ws.cell(row=(self.r),column=5).value = "Crossed 50 secs or ram percent crossed 80, so re-login browser"
               admin.FromConfigFile().Test_Teardown()
               admin.FromConfigFile().driving_browser_and_url()
               admin.FromConfigFile().logging("frontoffice12semgm")
               WF_FrontOffice.InNewOpRegistration().select_the_frame()
               print "after cross end"
           except :
             ws.cell(row=(self.r),column=3).value = "Data not Posted - overall Exception"
             j = j + 1
             wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
             wb.close()
             try:
                  print "inside overall exception try"
                  end_time = datetime.datetime.now()
                  diff_time = end_time-start_time
                  diff_seconds =  diff_time.total_seconds()
                  ws = wb["test_new"]
                  ws = wb.active
                  ws.cell(row=(self.r),column=7).value = diff_seconds
                  print(diff_seconds)
                  ws = wb["test_new"]
                  rampercentage =  psutil.virtual_memory()[2]
                  ws.cell(row=(self.r),column=8).value = rampercentage
                  print rampercentage
                  wb.close()
                  #admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgm")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
             except:
                  print "inside overall except except"
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgm")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
        wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
        wb.close()
        WF_FrontOffice.InNewOpRegistration().unselecting_the_frame()
        admin.FromConfigFile().Logoff()
        admin.FromConfigFile().Test_Teardown()


class Opreviewregistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_review")
    def multiple_review_registration(self):
     self.set_selenium_implicit_wait(10)
     wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     ws = wb["test_review"]
     num_rows = ws.max_row
     self.r = 1
     wb.close()
        #self.x = 0
     print "start time of script"
     print datetime.datetime.now()
     admin.FromConfigFile().driving_browser_and_url()
     admin.FromConfigFile().logging("frontoffice12semgmreview")
     WF_FrontOffice.InReviewRegistration().select_the_frame()
     wb = load_workbook('E:\workspace\Backbone_WF_12\Config\Prerequsiteconfig.xlsx')
     ws = wb["Reg_WF_Settings"]
     setregcount = ws.cell(row=2,column=3).value
     required_op_review_count = 0
     if setregcount == 1:
         required_op_review_count = ws.cell(row=2,column=2).value
         regtobedone = WF_FrontOffice.InReviewRegistration().regmatchcount(required_op_review_count)
         print "regtobedone before save", regtobedone
     else:
          regtobedone = 1000000
     wb.close()
     j = 0
     wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     ws = wb["test_review"]
     while self.r < num_rows and j < regtobedone:
      try:
        self.msg = ""
        self.r = self.r + 1
        statusvalue = ws.cell(row=(self.r),column=5).value
        print statusvalue
        if ws.cell(row=(self.r),column=5).value == "yes":
         rwno = self.r - 1
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         start_time = datetime.datetime.now()
         reglenvalue = len(str(self.d[rwno]["opreviewreg_regno"]))
         if (int(self.d[rwno]["opreviewreg_regno"])) is not None and (reglenvalue == 8):
          try :
               WF_FrontOffice.InReviewRegistration().entering_regno_with_data(rwno)
          except StaleElementReferenceException:
               ws = wb["test_review"]
               ws.cell(row=(self.r),column=6).value = "On Save Error"
               self.unselect_frame()
               admin.FromConfigFile().HomeBtn()
               self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
               self.select_frame(self.objects['FO_MainFrame1_12se'])                       
               WF_FrontOffice.InReviewRegistration().select_the_frame()
               WF_FrontOffice.InReviewRegistration().entering_regno_with_data(rwno)
          #self.press_key(self.objects['FO_ReviewRegistration_Regno_12se'], '\\10')
          try:
              self.click_element(self.objects['FO_ReviewRegistration_Regno_12se'])
          except UnexpectedAlertPresentException:
              print "pop up message displayed"
              self.msg = self._get_text('xpath=//*[@id="lblAlert"]')
              print self.msg
              if self.msg == "Patient Dead":
                  #print "status - Patient died"
                  ws = wb["test_review"]
                  ws.cell(row=(self.r),column=6).value = "Patient Dead" 
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn()
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
          except ValueError:
                  print "not able to click regno immediately"  
                  ws = wb["test_review"]
                  ws.cell(row=(self.r),column=6).value = "Unhandled Exception"
                  # Value error during regno click element statement after entering reg no.
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn()
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
          else:
              self.msg = self._get_text('xpath=//*[@id="lblAlert"]')
              print self.msg
              if self.msg[0:16] == "Patient Admitted":
                  print "status - Patient Admitted"
                  ws = wb["test_review"]
                  ws.cell(row=(self.r),column=6).value = "Patient Admitted"                    
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn() 
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
              elif self.msg == "Same Day Same Department / Doctor not allowed":
                  print "Same Day Same Department / Doctor not allowed"
                  ws = wb["test_review"]
                  ws.cell(row=(self.r),column=6).value = "Same Day Same Department / Doctor not allowed"                    
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn() 
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
              elif self.msg == "No Patient Data Found":
                  print "no patient data"
                  ws = wb["test_review"]
                  ws.cell(row=(self.r),column=6).value = "No Patient Data Found"                    
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn() 
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InReviewRegistration().select_the_frame() 
              else:
                self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Dept_Entry_12se'], 20, 'Dept txt 12se was not visible')
                self.click_element(self.objects['FO_ReviewRegistration_Dept_Entry_12se'])
                self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Dept_12se'], 20, 'Dept list 12se was not visible')
                deptlistvalue = self.get_list_items(self.objects["FO_ReviewRegistration_Dept_12se"])
                #print deptlistvalue
                deptstatus = self.d[rwno]["opreviewreg_department"] in deptlistvalue
                #print "deptstatus", deptstatus
                if deptstatus == True:
                  WF_FrontOffice.InReviewRegistration().selecting_department_with_data(rwno)
                  try:
                    self._handle_alert(True)
                    self._handle_alert(True)
                    self._handle_alert(True)
                    #time.sleep(5)
                  except:
                      self.pattype = self._get_text('xpath=//*[@id="lblPatType"]')
                      if self.pattype != "Z4":
                        print "patient type is not z4"
                        ws = wb["test_review"]
                        ws.cell(row=(self.r),column=6).value = 'Not scenario patient. Patient type is "'+self.pattype +'"'
                        j = j + 1
                        #break
                  else:
                   self.wait_until_element_is_visible('xpath=//*[@id="txtDoctor"]', 20, "unit txt element was not visible")
                   self.click_element('xpath=//*[@id="txtDoctor"]')
                  
                   #self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 20, 'unit 12se cbo was not visible')
                   unitlistvalue = self.get_list_items('xpath=//*[@id="cboDoctor"]')
                   Requnit = self.d[rwno]["opreviewreg_unit"]
                   unitstatus = Requnit in unitlistvalue
                   #self.clear_element_text('xpath=//*[@id="txtDoctor"]')
                   #self.click_element('xpath=//*[@id="txtDoctor"]')
                   print ("unitlistvalue"), unitlistvalue
                   if unitstatus == True:
                     WF_FrontOffice.InReviewRegistration().selecting_unit_with_data(rwno)
                     try:
                      self._handle_alert(True)
                      print "inside try: after alert"
                     except:
                      self.msg = self._get_text('xpath=//*[@id="lblAlert"]')
                      if self.msg == "Same Day Same Department / Doctor not allowed":
                          print "Same Day Same Department / Doctor not allowed"
                          ws = wb["test_review"]
                          ws.cell(row=(self.r),column=6).value = "Same Day Same Department / Doctor not allowed"                    
                          j = j + 1
                          #break
                          #self.unselect_frame()
                          #admin.FromConfigFile().HomeBtn() 
                          #self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                          #self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                          #WF_FrontOffice.InReviewRegistration().select_the_frame()
                     else:
                          try:
                              #time.sleep(10)
                              WF_FrontOffice.InReviewRegistration().clicking_save()
                          except StaleElementReferenceException:
                              ws = wb["test_review"]
                              ws.cell(row=(self.r),column=6).value = "On Save Error"
                              j = j + 1
                              self.unselect_frame()
                              admin.FromConfigFile().HomeBtn() 
                              self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 50, 'Main was not visible')
                              self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                              WF_FrontOffice.InReviewRegistration().select_the_frame()
                          else:
                             try:
                               self.wait_until_page_contains_element('xpath=//*[@id="lblAlert"]', 20, 'No data available')
                               self.msg = self._get_text('xpath=//*[@id="lblAlert"]')
                               print self.msg
                               self.wait_until_page_contains("Patient Registerted Successfully.Slot No:", 10, "registration success msg was not visible")
                               print "reg done"
                             except StaleElementReferenceException:
                                  print "Not able to get msg- StaleElementReferenceException"
                                  self.msg = self.get_text('xpath=//*[@id="lblAlert"]')
                                  print "message: ", self.msg
                                  ws.cell(row=(self.r),column=6).value = "Patient saved without capturing message - stale"
                                  j = j + 1
                             except:
                                if self.msg == "Enter the Mobile Number, Minimum 10 Numbers":
                                    ws = wb["test_review"]
                                    ws.cell(row=(self.r),column=6).value = "Mobile number missing"
                                    j = j + 1
                                    self.unselect_frame()
                                    admin.FromConfigFile().HomeBtn() 
                                    self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                                    self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                                    WF_FrontOffice.InReviewRegistration().select_the_frame()
                                else:
                                     j = j + 1
                                     ws = wb["test_review"]
                                     ws.cell(row=(self.r),column=6).value = "Patient not Registered Successfully"
                             else:
                                 if self.msg == "Enter the Mobile Number, Minimum 10 Numbers":
                                    ws = wb["test_review"]
                                    ws.cell(row=(self.r),column=6).value = "Mobile number missing"
                                    j = j + 1
                                    self.unselect_frame()
                                    admin.FromConfigFile().HomeBtn() 
                                    self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                                    self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                                    WF_FrontOffice.InReviewRegistration().select_the_frame()
                                 else:
                                     print "review registration done"
                                     j = j + 1
                                     ws = wb["test_review"]
                                     ws.cell(row=(self.r),column=6).value = "Patient Registered Successfully"
                   else:
                     ws.cell(row=(self.r),column=6).value = "Improper Unit"
                     j =  WF_FrontOffice.InReviewRegistration().selecting_next_record(j)             
                else:
                  ws.cell(row=(self.r),column=6).value = "Improper Department Name"
                  j =  WF_FrontOffice.InReviewRegistration().selecting_next_record(j)                  
         else:
             ws.cell(row=(self.r),column=6).value = "Improper registration number"
             j =  WF_FrontOffice.InReviewRegistration().selecting_next_record(j)
         end_time = datetime.datetime.now()
         diff_time = end_time-start_time
         diff_seconds =  diff_time.total_seconds()
         ws = wb["test_review"]
         ws = wb.active
         ws.cell(row=(self.r),column=7).value = diff_seconds
         #print(diff_seconds)
         ws = wb["test_review"]
         rampercentage =  psutil.virtual_memory()[2]
         ws.cell(row=(self.r),column=8).value = rampercentage
         #print rampercentage
         if diff_seconds > 50 or rampercentage > 80:
              print "Crossed 10 seconds"
              WF_FrontOffice.InReviewRegistration().unselecting_the_frame()
              ws = wb["test_review"]
              ws.cell(row=(self.r),column=9).value = "Crossed 50 secs or ram percent crossed 80, so re-login browser"
              admin.FromConfigFile().Test_Teardown()
              admin.FromConfigFile().driving_browser_and_url()
              admin.FromConfigFile().logging("frontoffice12semgmreview")
              WF_FrontOffice.InReviewRegistration().select_the_frame()   
      except:
        if self.msg == "Same Day Same Department / Doctor not allowed":
           ws.cell(row=(self.r),column=6).value = "Same Day Same Department / Doctor not allowed"
        else:
           ws.cell(row=(self.r),column=6).value = "Data not Posted - overall Exception"
        j = j + 1
        wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
        try:
                  end_time = datetime.datetime.now()
                  diff_time = end_time-start_time
                  diff_seconds =  diff_time.total_seconds()
                  ws = wb["test_review"]
                  ws = wb.active
                  ws.cell(row=(self.r),column=7).value = diff_seconds
                  print(diff_seconds)
                  ws = wb["test_review"]
                  rampercentage =  psutil.virtual_memory()[2]
                  ws.cell(row=(self.r),column=8).value = rampercentage
                  print rampercentage
                  #admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgmreview")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
        except:
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgmreview")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
     wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     wb.close()
     WF_FrontOffice.InReviewRegistration().unselecting_the_frame()
     admin.FromConfigFile().Logoff()
     admin.FromConfigFile().Test_Teardown()
     print "End time of script"
     print datetime.datetime.now()
     
     
     
'''class IPRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_ipreg")
    def multiple_ip_registration(self):
     self.set_selenium_implicit_wait(10)
     wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     ws = wb["test_ipreg"]
     num_rows = ws.max_row
     self.r = 1
     wb.close()
     print "start time of script"
     print datetime.datetime.now()
     admin.FromConfigFile().driving_browser_and_url()
     admin.FromConfigFile().logging("frontoffice12semgmipreg")
     WF_FrontOffice.InIPRegistration().select_the_frame()
     wb = load_workbook('E:\workspace\Backbone_WF_12\Config\Prerequsiteconfig.xlsx')
     ws = wb["Reg_WF_Settings"]
     setregcount = ws.cell(row=2,column=3).value
     required_op_review_count = 0
     if setregcount == 1:
         required_op_review_count = ws.cell(row=2,column=2).value
         regtobedone = WF_FrontOffice.InIPRegistration().regmatchcount(required_op_review_count)
         print "regtobedone before save", regtobedone
     else:
          regtobedone = 1000000
     wb.close()
     j = 0
     wb = load_workbook('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     ws = wb["test_ipreg"]
     while self.r < num_rows and j < regtobedone:
      #try:
        self.r = self.r + 1
        statusvalue = ws.cell(row=(self.r),column=2).value
        print statusvalue
        if statusvalue == "yes":
         rwno = self.r - 1
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         start_time = datetime.datetime.now()
         reglenvalue = len(str(self.d[rwno]["ipreg_regno"]))
         print reglenvalue
         if (int(self.d[rwno]["ipreg_regno"])) is not None and (reglenvalue == 8):
          try :
               WF_FrontOffice.InIPRegistration().entering_regno_with_data(rwno)
          except StaleElementReferenceException:
               ws = wb["test_ipreg"]
               ws.cell(row=(self.r),column=6).value = "On Save Error"
               self.unselect_frame()
               admin.FromConfigFile().HomeBtn()
               self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
               self.select_frame(self.objects['FO_MainFrame1_12se'])                       
               WF_FrontOffice.InIPRegistration().select_the_frame()
               WF_FrontOffice.InIPRegistration().entering_regno_with_data(rwno)
          #self.press_key(self.objects['FO_ReviewRegistration_Regno_12se'], '\\10')
          try:
              self.click_element(self.objects['FO_IPRegistration_regno_12se'])
          except UnexpectedAlertPresentException:
              print "pop up message displayed"
              self.msg = self._get_text(self.objects['FO_IPRegistration_Message_12se'])
              print self.msg
              if self.msg == "Patient Dead":
                  print "status - Patient dead"
                  ws = wb["test_ipreg"]
                  ws.cell(row=(self.r),column=3).value = "Patient Dead" 
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn()
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InIPRegistration().select_the_frame()
          except ValueError:
                  print "not able to click regno immediately"  
                  ws = wb["test_ipreg"]
                  ws.cell(row=(self.r),column=3).value = "Un-handled Exception"
                  # Value error during regno click element statement after entering reg no.
                  j = j + 1
                  self.unselect_frame()
                  admin.FromConfigFile().HomeBtn()
                  self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                  self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                  WF_FrontOffice.InIPRegistration().select_the_frame()
          else:
            print "inside no pop up loop"
            try:
              #self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Inpatstatus_12se'], 10, "In patient status was not visible")
              self.wait_until_page_contains_element(self.objects['FO_IPRegistration_Inpatstatus_12se'], 20, 'patient status field was not available')
              self.Inpatmsg = self.get_text(self.objects['FO_IPRegistration_Inpatstatus_12se'])
              print "inpatmsg", self.Inpatmsg
            except:
                print "In-patient element not found"
                self.Inpatmsg = "No In-patient element available"
                print self.Inpatmsg
            finally:
              if self.Inpatmsg == "In Patient":
                   ws.cell(row=(self.r),column=3).value = "In patient"
                   j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)
              else:
                self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Dept_Entry_12se'], 20, 'Dept txt 12se was not visible')
                self.click_element(self.objects['FO_IPRegistration_Dept_Entry_12se'])
                self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Dept_12se'], 20, 'Dept list 12se was not visible')
                deptlistvalue = self.get_list_items(self.objects["FO_IPRegistration_Dept_12se"])
                self.clear_element_text(self.objects["FO_IPRegistration_Dept_Entry_12se"])
                self.click_element(self.objects["FO_IPRegistration_Dept_Entry_12se"])
                #print deptlistvalue
                deptstatus = self.d[rwno]["ipreg_department"] in deptlistvalue
                #print "deptstatus", deptstatus
                if deptstatus == True:
                   WF_FrontOffice.InIPRegistration().selecting_department_with_data(rwno)
                   self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Doc_Entry_12se'], 20, "unit txt was not visible")
                   self.click_element(self.objects['FO_IPRegistration_Doc_Entry_12se'])
                   #self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 20, 'unit 12se cbo was not visible')
                   unitlistvalue = self.get_list_items(self.objects['FO_IPRegistration_Doc_12se'])
                   Requnit = self.d[rwno]["ipreg_unit"]
                   unitstatus = Requnit in unitlistvalue
                   self.clear_element_text(self.objects['FO_IPRegistration_Doc_Entry_12se'])
                   self.click_element(self.objects['FO_IPRegistration_Doc_Entry_12se'])
                   #time.sleep(7)
                   #print ("unitlistvalue"), unitlistvalue
                   if unitstatus == True:
                      WF_FrontOffice.InIPRegistration().selecting_unit_with_data(rwno)
                      self.msg = self._get_text(self.objects['FO_IPRegistration_Message_12se'])
                      if self.msg == "Same Day Same Department / Doctor not allowed":
                          print "Same Day Same Department / Doctor not allowed"
                          ws = wb["test_ipreg"]
                          ws.cell(row=(self.r),column=3).value = "Same Day Same Department / Doctor not allowed"                    
                          j = j + 1
                          self.unselect_frame()
                          admin.FromConfigFile().HomeBtn() 
                          self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
                          self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                          WF_FrontOffice.InIPRegistration().select_the_frame()
                      else:
                         self.wait_until_element_is_visible(self.objects['FO_IPRegistration_BedType_Entry_12se'], 20, "bed type was not visible")
                         self.click_element(self.objects['FO_IPRegistration_BedType_Entry_12se'])
                         bedtypevalue = self.get_list_items(self.objects['FO_IPRegistration_BedType_12se'])
                         Reqbedtype = self.d[rwno]["ipreg_bedtype"]
                         bedtypestatus = Reqbedtype in bedtypevalue
                         self.clear_element_text(self.objects['FO_IPRegistration_BedType_Entry_12se'])
                         self.click_element(self.objects['FO_IPRegistration_BedType_Entry_12se'])
                         #print ("bedtypevalue"), bedtypevalue
                         if bedtypestatus == True:  
                            WF_FrontOffice.InIPRegistration().selecting_bedtype_with_data(rwno) 
                            self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Ward_Entry_12se'], 20, "ward was not visible")
                            self.click_element(self.objects['FO_IPRegistration_Ward_Entry_12se'])
                            wardlistvalue = self.get_list_items(self.objects['FO_IPRegistration_Ward_12se'])
                            Reqward = self.d[rwno]["ipreg_ward"]
                            wardstatus = Reqward in wardlistvalue
                            self.clear_element_text(self.objects['FO_IPRegistration_Ward_Entry_12se'])
                            self.click_element(self.objects['FO_IPRegistration_Ward_Entry_12se'])
                            #print ("wardlistvalue"), wardlistvalue
                            if wardstatus == True:
                               WF_FrontOffice.InIPRegistration().selecting_ward_with_data(rwno)  
                               #time.sleep(7)
                               self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Bedno_Entry_12se'], 20, "bed no was not visible")
                               self.click_element(self.objects['FO_IPRegistration_Bedno_Entry_12se'])
                               #time.sleep(1)
                               self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Bedno_12se'], 20, "bed no was not visible")
                               bednolistvalue = self.get_list_items(self.objects['FO_IPRegistration_Bedno_12se'])
                               Reqbedno = self.d[rwno]["ipreg_bedno"]
                               bednostatus = Reqbedno in bednolistvalue
                               self.clear_element_text(self.objects['FO_IPRegistration_Bedno_Entry_12se'])
                               self.click_element(self.objects['FO_IPRegistration_Bedno_Entry_12se'])
                               #time.sleep(5)
                               #print ("bednolistvalue"), bednolistvalue
                               if bednostatus == True:
                                 WF_FrontOffice.InIPRegistration().selecting_bedno_with_data(rwno)  
                                 try:
                                   #time.sleep(5)
                                   self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Pricelist_Entry_12se'], 20, "price list was not visible")
                                   self.click_element(self.objects['FO_IPRegistration_Pricelist_Entry_12se'])
                                   #time.sleep(1)
                                   self.press_key(self.objects['FO_IPRegistration_Pricelist_Entry_12se'], '\\09')
                                  
                                   #time.sleep(1)
                                   #self.wait_until_element_is_visible('xpath=//*[@id="txtnewcase"]', 20, "new case was not visible")
                                   #self.click_element('xpath=//*[@id="txtnewcase"]')
                                   
                                   #self.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 20, "new remarks was not visible")
                                   #self.click_element('xpath=//*[@id="txtRemarks"]')
                                   WF_FrontOffice.InIPRegistration().clicking_save()
                                   self.wait_until_page_contains_element(self.objects['FO_IPRegistration_Message_12se'], 20, 'message field was not available')
                                   self.msg = self.get_text(self.objects['FO_IPRegistration_Message_12se'])
                                   print "self.msg", self.msg
                                   
                                   #self.selbednovalue = self.get_selected_list_value('xpath=//*[@id="cboBedNo"]')
                                   #print "after txt box selected bed no value", self.selbednovalue
                                   #pyautogui.hotkey('alt', 's')
                                   
                                   #self.press_key('xpath=//*[@id="txtRemarks"]', '\\09')
                                   #time.sleep(2)
                                   #pyautogui.hotkey('enter')
                                   
                                   #pyautogui.hotkey('alt', 's')
                                   
                                   
                                   #self.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 20, "remarks  was not visible")
                                   #self.click_element('xpath=//*[@id="txtRemarks"]')
                                   #time.sleep(2)
                                   #self.press_key('xpath=//*[@id="txtRemarks"]', '\\09')
                                   #time.sleep(7)
                                   #pyautogui.hotkey('enter')
                                   
                                   #WF_FrontOffice.InIPRegistration().clicking_save()
                                   #WF_FrontOffice.InIPRegistration().clicking_cancel()
                                   #time.sleep(5)
                                 except StaleElementReferenceException:
                                   ws = wb["test_ipreg"]
                                   ws.cell(row=(self.r),column=3).value = "On Save Error"
                                   j = j + 1
                                   self.unselect_frame()
                                   admin.FromConfigFile().HomeBtn() 
                                   self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 50, 'Main was not visible')
                                   self.select_frame(self.objects['FO_MainFrame1_12se'])                       
                                   WF_FrontOffice.InIPRegistration().select_the_frame()
                                 except UnexpectedAlertPresentException:
                                    print "inside alert loop"
                                    #self.wait_until_page_contains_element(self.objects['FO_IPRegistration_Message_12se'], 20, 'message field was not available')
                                    #self.msg = self.get_text(self.objects['FO_IPRegistration_Message_12se'])
                                    #print "self.msg", self.msg
                                    if self.msg == "No Record(s) Found":
                                       j = j + 1
                                       ws = wb["test_ipreg"]
                                       ws.cell(row=(self.r),column=3).value = "No Record(s) Found"
                                    elif self.msg[0:32] == "Patient Registered Successfully.":
                                        print "inside 1"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient Registered Successfully"
                                        pyautogui.hotkey('enter')
                                        self.unselect_frame()
                                        self.select_frame('xpath=//*[@id="FrBottom"]')
                                        self.wait_until_element_is_visible('xpath=//*[@class="homebtnbg"]', 20, 'Home btn was not visible')
                                        self.click_element('xpath=//*[@class="homebtnbg"]')
                                        WF_FrontOffice.InIPRegistration().select_the_frame()
                                    else:
                                        print "no error during save btn click 1"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient not registered Successfully-alert loop"
                                 else:
                                  print "inside else loop"
                                  try:
                                    if self.msg == "No Record(s) Found":
                                       j = j + 1
                                       ws = wb["test_ipreg"]
                                       ws.cell(row=(self.r),column=3).value = "No Record(s) Found"
                                    elif self.msg[0:32] == "Patient Registered Successfully.":
                                        print "inside loop"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient Registered Successfully"
                                        self._close_alert(True)
                                        print "after alert closed"
                                        #self._handle_alert(True)
                                    
                                        #pyautogui.hotkey('enter')
                                        #self.unselect_frame()
                                        #self.select_frame('xpath=//*[@id="FrBottom"]')
                                        #self.wait_until_element_is_visible('xpath=//*[@class="homebtnbg"]', 20, 'Home btn was not visible')
                                        #self.click_element('xpath=//*[@class="homebtnbg"]')
                                        #WF_FrontOffice.InIPRegistration().select_the_frame()
                                    elif self.msg == "Price List not Assigned":
                                        print "inside price loop"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient Registered Successfully"
                                        self._close_alert(True)
                                        print "after alert closed"
                                    else:
                                        print "no error during save btn click 2"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient not registered Successfully"
                                        self._close_alert(True)
                                        print "after close alert 2"
                                  except:
                                        print "no alert came"
                                        j = j + 1
                                        ws = wb["test_ipreg"]
                                        ws.cell(row=(self.r),column=3).value = "Patient not registered Successfully"       
                               else:
                                  ws.cell(row=(self.r),column=3).value = "Improper bedno"
                                  j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j) 
                            else:
                               ws.cell(row=(self.r),column=3).value = "Improper ward"
                               j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)
                         else:
                            ws.cell(row=(self.r),column=3).value = "Improper bed type"
                            j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)
                   else:
                     ws.cell(row=(self.r),column=3).value = "Improper Unit"
                     j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)             
                else:
                  ws.cell(row=(self.r),column=3).value = "Improper Department Name"
                  j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)
         else:
             ws.cell(row=(self.r),column=3).value = "Improper registration number"
             j =  WF_FrontOffice.InIPRegistration().selecting_next_record(j)
         end_time = datetime.datetime.now()
         diff_time = end_time-start_time
         diff_seconds =  diff_time.total_seconds()
         ws = wb["test_ipreg"]
         ws = wb.active
         ws.cell(row=(self.r),column=4).value = diff_seconds
         print"diff_seconds:  ", diff_seconds
         ws = wb["test_ipreg"]
         rampercentage =  psutil.virtual_memory()[2]
         ws.cell(row=(self.r),column=5).value = rampercentage
         print "rampercentage:  ", rampercentage
         if diff_seconds > 50 or rampercentage > 80:
              print "Crossed 50 seconds"
              WF_FrontOffice.InIPRegistration().unselecting_the_frame()
              ws = wb["test_ipreg"]
              ws.cell(row=(self.r),column=6).value = "Crossed 50 secs or ram percent crossed 80, so re-login browser"
              admin.FromConfigFile().Test_Teardown()
              admin.FromConfigFile().driving_browser_and_url()
              admin.FromConfigFile().logging("frontoffice12semgmipreg")
              WF_FrontOffice.InIPRegistration().select_the_frame()   
        except:
        ws.cell(row=(self.r),column=3).value = "Data not Posted - overall Exception"
        j = j + 1
        wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
        try:
                  end_time = datetime.datetime.now()
                  diff_time = end_time-start_time
                  diff_seconds =  diff_time.total_seconds()
                  ws = wb["test_ipreg"]
                  ws = wb.active
                  ws.cell(row=(self.r),column=4).value = diff_seconds
                  print "diff_seconds: ", diff_seconds
                  ws = wb["test_ipreg"]
                  rampercentage =  psutil.virtual_memory()[2]
                  ws.cell(row=(self.r),column=5).value = rampercentage
                  print "rampercentage: ",  rampercentage
                  if diff_seconds > 50 or rampercentage > 80:
                      print "Crossed 50 seconds"
                      WF_FrontOffice.InIPRegistration().unselecting_the_frame()
                      ws = wb["test_ipreg"]
                      ws.cell(row=(self.r),column=6).value = "Crossed 50 secs or ram percent crossed 80, so re-login browser"
                      admin.FromConfigFile().Test_Teardown()
                      admin.FromConfigFile().driving_browser_and_url()
                      admin.FromConfigFile().logging("frontoffice12semgmipreg")
                      WF_FrontOffice.InIPRegistration().select_the_frame()  
                  #admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgmipreg")
                  WF_FrontOffice.InIPRegistration().select_the_frame()
        except:
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontoffice12semgmipreg")
                  WF_FrontOffice.InIPRegistration().select_the_frame()
     wb.save('E:\workspace\Backbone_WF_12\datas\Bb_datas.xlsx')
     wb.close()
     WF_FrontOffice.InIPRegistration().unselecting_the_frame()
     admin.FromConfigFile().Logoff()
     admin.FromConfigFile().Test_Teardown()
     print "End time of script"
     print datetime.datetime.now()'''
     
