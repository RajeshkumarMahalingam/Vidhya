import sys
from Selenium2Library import Selenium2Library
from random import randint
from selenium.webdriver.support.select import Select
from lib2to3.tests.support import driver
from lib2to3.pgen2.driver import Driver
from selenium.webdriver.edge.webdriver import WebDriver
from selenium.webdriver.edge import webdriver
from selenium.webdriver.common.keys import Keys
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
from openpyxl import load_workbook
from datetime import datetime, timedelta
import datetime
import time
from selenium.common.exceptions import StaleElementReferenceException  
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotInteractableException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select


class InNewOpRegistration(Selenium2Library, WebDriver):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_new")
    regtobedone = 0
    j = 0
    
    def select_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_MainFrame2_12se'], 20, 'Main Frame2 was not visible')
        self.select_frame(self.objects['FO_MainFrame2_12se'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        deptele = self.get_webelement('xpath=//tr[@id="trdoc"]/td[2]/div[2]/select')
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, deptele, str(self.d[r]["opnewreg_department"]))
        self.press_key('xpath=//*[@id="txtDept"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//tr[@id="trdoc"]/td[4]/div[2]/select', 15, "select element was not visible")
        print self.d[r]["opnewreg_unit"]
        docele = self.get_webelement('xpath=//tr[@id="trdoc"]/td[4]/div[2]/select')
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["opnewreg_unit"]))
        self.press_key('xpath=//*[@id="txtDoctor"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_doctor_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc_12se"],self.d[r]["opnewreg_doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Sal_12se"], 20, 'Sal was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal_12se"],self.d[r]["opnewreg_sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name_12se"], 20, 'Name was not visible')
        self.input_text(self.objects["FO_NewRegistration_Name_12se"],self.d[r]["opnewreg_name"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Gender_12se"], 20, 'Gender was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender_12se"],self.d[r]["opnewreg_gender"])
        self.dict['BROWSER'] = self._current_browser()
        
        
    def selecting_pattype_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType_12se"], 20, 'patient type was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_PatType_12se"],self.d[r]["opnewreg_pattype"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Age_12se"], 20, 'Age was not visible')
        self.input_text(self.objects["FO_NewRegistration_Age_12se"],self.d[r]["opnewreg_age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_MaritalStatus_12se"], 20, 'Age was not visible')
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus_12se"],self.d[r]["opnewreg_marital_status"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Address_12se"], 20, 'address was not visible')
        self.input_text(self.objects["FO_NewRegistration_Address_12se"],self.d[r]["opnewreg_present_address"])
        self.dict['BROWSER'] = self._current_browser()
        
    
    def selecting_city_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtCity"]', 20, "city txt was not visible")
        self.click_element('xpath=//*[@id="txtCity"]')
        self.wait_until_element_is_visible('xpath=//*[@id="cboCity"]', 20, "city cbo was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboCity"]', str(self.d[r]["opnewreg_city"]))
        self.dict['BROWSER'] = self._current_browser()

    def entering_relationname_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtRelName"]', 20, 'relation name was not visible')
        self.input_text('xpath=//*[@id="txtRelName"]',self.d[r]["opnewreg_relationname"])
        self.dict['BROWSER'] = self._current_browser()

        
    def selecting_relation_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboRelation"]', 20, 'relation was not visible')
        self.select_from_list_by_label('xpath=//*[@id="cboRelation"]',self.d[r]["opnewreg_relation"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile_with_data(self,r):
        #self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Mobile_12se'], 50, 'Mobile no. was not visible')
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Mobile_12se'], 50, 'Mobile no. was not enabled')
        self.input_text(self.objects["FO_NewRegistration_Mobile_12se"],str(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()
    def entering_email_with_data(self):
        #self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtEmail"]', 50, 'email entry was not visible')
        self.wait_until_element_is_enabled('xpath=//*[@id="txtEmail"]', 50, 'email was not enabled')
        self.click_element('xpath=//*[@id="txtEmail"]')
        self.dict['BROWSER'] = self._current_browser()         
    def clicking_save(self):
        #self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Save_12se"], 10, "save btn was not visible")
        self.click_button(self.objects["FO_NewRegistration_Save_12se"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    def Cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        pyautogui.FAILSAFE = False
        time.sleep(15)
        pyautogui.click(1129, 671)
        pyautogui.FAILSAFE = True
        self.dict['BROWSER'] = self._current_browser()
    def regmatchcount(self,required_op_new_count):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        print "inside regmatch",required_op_new_count
        #self.wait_until_element_is_visible('xpath=//*[@id="PtCount"]', 20, 'patient count was not visible')
        #patientcount =  self.get_text('xpath=//*[@id="PtCount"]')
        #print patientcount
        #newcount = ((patientcount).split('New : '))[1].split(' / Review :')[0]
        #reviewcount = (patientcount).split('Review : ')[1]
        #print int(newcount)
        #print int(reviewcount)
        #patientregisteredcount =  int(newcount) + int(reviewcount)
        #print "patient registered count", patientregisteredcount
        patientregisteredcount = 1
        regtobedone = required_op_new_count - patientregisteredcount
        return regtobedone
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_next_record(self,j):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()      
        j = j + 1
        self.unselect_frame()
        admin.FromConfigFile().HomeBtn() 
        self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
        self.select_frame(self.objects['FO_MainFrame1_12se'])                       
        self.select_the_frame()      
        return j
        self.dict['BROWSER'] = self._current_browser()
        
    def testexcep(self,r,wb,j):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        try:
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save_12se'], 30, 'save was not visible before try block')
            self.click_button(self.objects["FO_NewRegistration_Save_12se"])
            #time.sleep(500)
            #self.wait_until_element_is_visible('xpath=//*[@id="txtDept"]', 30, 'department was not visible inside try block')
            #self.press_key('xpath=//*[@id="txtDept"]', '\\09')
            #time.sleep(2)
            #self.wait_until_element_is_visible('xpath=//*[@id="txtEmail"]', 50, 'email entry was not visible')
            #self.wait_until_element_is_enabled('xpath=//*[@id="txtEmail"]', 50, 'email was not enabled')
            #self.click_element('xpath=//*[@id="txtEmail"]')            
            #self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save_12se'], 15, 'save was not visible before try block')
            #self.click_button(self.objects["FO_NewRegistration_Save_12se"])
            #time.sleep(1)
            self._handle_alert(True)
        except:
            MessageDisplayed =  self.get_text('xpath=//*[@id="lblAlert"]')
            print "MessageDisplayed", MessageDisplayed
            ws = wb["test_new"]
            ws.cell(row=(r),column=3).value = "Patient not registered"
            j = j + 1
        else:
            print "Data posted - else part"
            ws = wb["test_new"]
            ws.cell(row=(r),column=3).value = "Data Posted"
            j = j + 1
            #time.sleep(randint(5,20))
            #time.sleep(50)
        return j
        self.dict['BROWSER'] = self._current_browser()
    
    
class InReviewRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_review")
    def InReviewReg_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def select_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_MainFrame2_12se'], 50, 'Main Frame2 was not visible')
        self.select_frame(self.objects['FO_MainFrame2_12se'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self,r):
        r = int(r)
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_contains(self.objects['FO_ReviewRegistration_Regno_12se'], '', 20, "regno was not visible new")
        #self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Regno_12se'], 50, 'Regno was not visible')
        self.input_text(self.objects['FO_ReviewRegistration_Regno_12se'], str(self.d[r]["opreviewreg_regno"]))
        self.press_key(self.objects['FO_ReviewRegistration_Regno_12se'], '\\10')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(5)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        deptele = self.get_webelement('xpath=//*[@id="cboDept"]')
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, deptele, str(self.d[r]["opreviewreg_department"]))
        self.press_key('xpath=//*[@id="txtDept"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(5)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Doc_Entry_12se'], 50, 'Doct 12se was not visible')
        self.click_element(self.objects['FO_ReviewRegistration_Doc_Entry_12se'])
        self.input_text(self.objects['FO_ReviewRegistration_Doc_Entry_12se'],self.d[r]["opreviewreg_doctor"])
        self.press_key(self.objects['FO_ReviewRegistration_Doc_Entry_12se'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Save_12se"], 50, 'Save was not visible')
        #self.wait_until_element_is_enabled(self.objects["FO_ReviewRegistration_Save_12se"], 50, 'save was not enabled')
        self.click_button(self.objects["FO_ReviewRegistration_Save_12se"])
        #print "after click"
        #time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()
    def regmatchcount(self,required_op_review_count):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="PtCount"]', 20, 'patient count was not visible')
        #patientcount =  self.get_text('xpath=//*[@id="PtCount"]')
        #print patientcount
        #newcount = ((patientcount).split('New : '))[1].split(' / Review :')[0]
        #reviewcount = (patientcount).split('Review : ')[1]
        #print int(newcount)
        #print int(reviewcount)
        #patientregisteredcount =  int(newcount) + int(reviewcount)
        #print "patient registered count", patientregisteredcount
        patientregisteredcount = 1
        regtobedone = required_op_review_count - patientregisteredcount
        return regtobedone
        print regtobedone
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 15, "select element was not visible")
        print self.d[r]["opreviewreg_unit"]
        docele = self.get_webelement('xpath=//*[@id="cboDoctor"]')
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["opreviewreg_unit"]))
        self.press_key('xpath=//*[@id="txtDoctor"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
       
    def selecting_next_record(self,j):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()      
        j = j + 1
        self.unselect_frame()
        admin.FromConfigFile().HomeBtn() 
        self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
        self.select_frame(self.objects['FO_MainFrame1_12se'])                       
        self.select_the_frame()      
        return j
        self.dict['BROWSER'] = self._current_browser()


'''class InIPRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("test_ipreg")
    def InIPReg_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def select_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_MainFrame2_12se'], 50, 'Main Frame2 was not visible')
        self.select_frame(self.objects['FO_MainFrame2_12se'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self,r):
        r = int(r)
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_contains(self.objects['FO_IPRegistration_regno_12se'], '', 20, "ip regno was not visible")
        #self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Regno_12se'], 50, 'Regno was not visible')
        self.input_text(self.objects['FO_IPRegistration_regno_12se'], str(self.d[r]["ipreg_regno"]))
        self.press_key(self.objects['FO_IPRegistration_regno_12se'], '\\10')
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(5)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        deptele = self.get_webelement(self.objects['FO_IPRegistration_Dept_12se'])
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, deptele, self.d[r]["ipreg_department"])
        self.press_key(self.objects['FO_IPRegistration_Dept_Entry_12se'], '\\09')
        self.seldeptvalue = self.get_selected_list_value(self.objects['FO_IPRegistration_Dept_12se'])
        print "selected dept value", self.seldeptvalue
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Doc_12se'], 15, "select element was not visible")
        print self.d[r]["ipreg_unit"]
        docele = self.get_webelement(self.objects['FO_IPRegistration_Doc_12se'])
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["ipreg_unit"]))
        self.press_key(self.objects['FO_IPRegistration_Doc_Entry_12se'], '\\09')
        self.selunitvalue = self.get_selected_list_value(self.objects['FO_IPRegistration_Doc_12se'])
        print "selected unit value", self.selunitvalue
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_bedtype_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_BedType_12se'], 15, "select element was not visible")
        print self.d[r]["ipreg_bedtype"]
        docele = self.get_webelement(self.objects['FO_IPRegistration_BedType_12se'])
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["ipreg_bedtype"]))
        self.press_key(self.objects['FO_IPRegistration_BedType_Entry_12se'], '\\09')
        self.selbedtypevalue = self.get_selected_list_value(self.objects['FO_IPRegistration_BedType_12se'])
        print "selected bed type value", self.selbedtypevalue
        self.dict['BROWSER'] = self._current_browser()
    
    
    def selecting_ward_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Ward_12se'], 15, "select element was not visible")
        print self.d[r]["ipreg_ward"]
        docele = self.get_webelement(self.objects['FO_IPRegistration_Ward_12se'])
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["ipreg_ward"]))
        self.press_key(self.objects['FO_IPRegistration_Ward_Entry_12se'], '\\09')
        self.selwardvalue = self.get_selected_list_value(self.objects['FO_IPRegistration_Ward_12se'])
        print "selected ward value", self.selwardvalue
        self.dict['BROWSER'] = self._current_browser()
    
    
    def selecting_bedno_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="txtBedNo"]', 15, "select element was not visible")
        #self.input_text('xpath=//*[@id="txtBedNo"]', "GNS7")
        
        #self.wait_until_element_is_visible('xpath=//*[@id="cboBedNo"]', 15, "select element was not visible")
        print self.d[r]["ipreg_bedno"]
        
        docele = self.get_webelement(self.objects['FO_IPRegistration_Bedno_12se'])
        jsFunction = "var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }"
        self.browser.execute_script(jsFunction, docele, str(self.d[r]["ipreg_bedno"]))
        self.press_key(self.objects['FO_IPRegistration_Bedno_Entry_12se'], '\\09')
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Bedno_Entry_12se'], 15, "select element was not visible")
        self.input_text(self.objects['FO_IPRegistration_Bedno_Entry_12se'], str(self.d[r]["ipreg_bedno"]))
        
        
        #pyautogui.hotkey()
        #pyautogui.hotkey('enter')
        self.selbednovalue = self.get_selected_list_value(self.objects['FO_IPRegistration_Bedno_12se'])
        print "selected bed no value", self.selbednovalue
        self.dict['BROWSER'] = self._current_browser()    
    

    def clicking_save(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Save_12se"], 50, 'Save was not visible')
        #self.wait_until_element_is_enabled(self.objects["FO_IPRegistration_Save_12se"], 50, 'save was not enabled')
        self.click_button(self.objects["FO_IPRegistration_Save_12se"])
        #time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
        
    def clicking_cancel(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Cancel_12se"], 50, 'cancel was not visible')
        self.click_button(self.objects["FO_IPRegistration_Cancel_12se"])
        print "cancel btn clicked"
        self.dict['BROWSER'] = self._current_browser()
    
    def regmatchcount(self,required_op_review_count):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="PtCount"]', 20, 'patient count was not visible')
        #patientcount =  self.get_text('xpath=//*[@id="PtCount"]')
        #print patientcount
        #newcount = ((patientcount).split('New : '))[1].split(' / Review :')[0]
        #reviewcount = (patientcount).split('Review : ')[1]
        #print int(newcount)
        #print int(reviewcount)
        #patientregisteredcount =  int(newcount) + int(reviewcount)
        #print "patient registered count", patientregisteredcount
        patientregisteredcount = 1
        regtobedone = required_op_review_count - patientregisteredcount
        return regtobedone
        print regtobedone
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
       
    def selecting_next_record(self,j):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()      
        j = j + 1
        self.unselect_frame()
        admin.FromConfigFile().HomeBtn() 
        self.wait_until_element_is_visible(self.objects['FO_MainFrame1_12se'], 20, 'Main was not visible')
        self.select_frame(self.objects['FO_MainFrame1_12se'])                       
        self.select_the_frame()      
        return j
        self.dict['BROWSER'] = self._current_browser()'''
        
        
   