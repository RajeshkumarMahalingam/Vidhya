from Selenium2Library import Selenium2Library
import sys
import openpyxl
from openpyxl import load_workbook
import time
import pyautogui
import logging
from random import randint
logging.getLogger("RobotFramework").addHandler(logging.StreamHandler())
from webbrowser import Chrome 
import os
import os.path
sys.path.append('..\..\libraries\standard') 
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
from robot.libraries.BuiltIn import BuiltIn
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime, timedelta, date
import datetime
import time
import re

'''from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC'''
