import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InNewOpRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    reg = ""
    d = Capturing().data_off("op_new_registration")
    
    def InNewOp_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["opnewreg_department"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["opnewreg_doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"],self.d[r]["opnewreg_sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        #Tempname = randint(100,999)
        #self.input_text(self.objects["FO_NewRegistration_Name"],"TANISH "+str(Tempname))
        self.input_text(self.objects["FO_NewRegistration_Name"],self.d[r]["opnewreg_name"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"],self.d[r]["opnewreg_gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects["FO_NewRegistration_Age"],self.d[r]["opnewreg_age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],self.d[r]["opnewreg_marital_status"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects["FO_NewRegistration_Address"],self.d[r]["opnewreg_present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_NewRegistration_City'])
        time.sleep(2)
        self.input_text(self.objects["FO_NewRegistration_City_Entry"],self.d[r]["opnewreg_city"])
        time.sleep(3)
        self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile_with_data(self,r):
        #r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #Tempmobile = randint(100,999)
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],"9785621"+str(Tempmobile))
        self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["opnewreg_mobile"]))
        #print self.d[r]["opnewreg_mobile"]
        #print(len(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()    
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects["FO_NewRegistration_Save"])
        self.dict['BROWSER'] = self._current_browser()
    def Fetching_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
        self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0] 
        self.dict['REGNO'] = self.reg
        print self.dict['REGNO']
        print("Registered Reg number is",self.dict['REGNO'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    def Cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        pyautogui.FAILSAFE = False
        time.sleep(20)
        pyautogui.click(1129, 671)
        pyautogui.FAILSAFE = True
        self.dict['BROWSER'] = self._current_browser()
    
class InDoctorOpinion_Entry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Doctor_Opinion_Entry")
    def InDocOpnEntry_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self, r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        print self.dict['REGNO']
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(2)
        self.click_element(self.objects['FO_DoctorOpinionEntry_RegNo'])
        time.sleep(2)
        self.input_text(self.objects["FO_DoctorOpinionEntry_RegNo"],str(self.dict['REGNO']))
        time.sleep(1)
        self.press_key(self.objects['FO_DoctorOpinionEntry_RegNo'], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ICDCode_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element(self.objects['FO_DoctorOpinionEntry_ICDCode'])
        time.sleep(2)
        self.input_text(self.objects["FO_DoctorOpinionEntry_ICDCode_Entry"],self.d[r]['DoctorOpinionEntry_ICD Code'])
        time.sleep(2)
        self.press_key(self.objects['FO_DoctorOpinionEntry_ICDCode_Entry'], '\\09')
        self.click_button(self.objects['FO_DoctorOpinionEntry_ICDCode_Add'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_duration_of_admission_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_DoctorOpinionEntry_duration'])
        self.input_text(self.objects['FO_DoctorOpinionEntry_duration'],self.d[r]['DoctorOpinionEntry_duration'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_tentative_days(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_DoctorOpinionEntry_tentative_admission'],self.d[r]['DoctorOpinionEntry_tentative_admission'])
        time.sleep(1)
        self.press_key(self.objects['FO_DoctorOpinionEntry_tentative_admission'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_estimation_value(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_DoctorOpinionEntry_estimation'],self.d[r]['DoctorOpinionEntry_estimation'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_adviced_doctor_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_DoctorOpinionEntry_adviceddoctor'],self.d[r]['DoctorOpinionEntry_advised_by_doctor'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bed_type_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_DoctorOpinionEntry_bedtype'],self.d[r]['DoctorOpinionEntry_bed_type'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ward_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_DoctorOpinionEntry_ward'],self.d[r]['DoctorOpinionEntry_ward'])
        time.sleep(2)
        self.click_button(self.objects['FO_DoctorOpinionEntry_addadmission'])
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_DoctorOpinionEntry_save"])
        self.dict['BROWSER'] = self._current_browser()
        time.sleep(15)
    def clicking_ok(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_DoctorOpinionEntry_Message_OK"])
        self.dict['BROWSER'] = self._current_browser()
        
class InOpinion_Convert_to_IP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Opinion_convert_to_IP")
    reg = ""
    def InOpnToIP_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(2)
        self.click_element(self.objects['FO_Opinion_convert_to_IP_Regno'])
        time.sleep(2)
        self.input_text(self.objects["FO_Opinion_convert_to_IP_Regno"],str(self.dict['REGNO']))
        time.sleep(1)
        self.press_key(self.objects['FO_Opinion_convert_to_IP_Regno'], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Dept"],self.d[r]["OpinionToIP_department"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Doc"],self.d[r]["OpinionToIP_doctor"])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedtype_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_BedType"],self.d[r]["OpinionToIP_bedtype"])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ward_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Ward"],self.d[r]["OpinionToIP_ward"])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Bedno"],self.d[r]["OpinionToIP_bed_no"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_Opinion_convert_to_IP_Save"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def Fetching_IPno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_Opinion_convert_to_IP_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_Opinion_convert_to_IP_Message'])
        self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
        self.dict['IPNO'] = self.IPno
        print self.IPno
        print("Registered IPNO is",self.dict['IPNO'])
    def clicking_ok(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_Opinion_convert_to_IP_Message_OK"])
        self.dict['BROWSER'] = self._current_browser()

class InIPDirectAdmission(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IP_registration")
    
    def InIPDirAdm_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_department_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(3)
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["IPreg_department"])
        #self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],'test')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["IPreg_doctor"])
        #self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],'test')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"],self.d[r]["IPreg_sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        Tempname = randint(100,999)
        self.input_text(self.objects["FO_NewRegistration_Name"],"Senthil "+str(Tempname))
        #self.input_text(self.objects["FO_NewRegistration_Name"],self.d[r]["IPreg_name"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"],self.d[r]["IPreg_gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects["FO_NewRegistration_Age"],self.d[r]["IPreg_age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],self.d[r]["IPreg_marital_status"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects["FO_NewRegistration_Address"],self.d[r]["IPreg_present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_NewRegistration_City'])
        time.sleep(2)
        self.input_text(self.objects["FO_NewRegistration_City_Entry"],self.d[r]["IPreg_city"])
        time.sleep(5)
        self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        Tempmobile = randint(100,999)
        self.input_text(self.objects["FO_NewRegistration_Mobile"],"9985621 "+str(Tempmobile))
        
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],self.d[r]["IPreg_mobile"])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_bedtype_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_NewRegistration_BedType'], '3')
        #self.select_from_list_by_label(self.objects["FO_NewRegistration_BedType"],self.d[r]["IPreg_bedtype"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_wardname_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_NewRegistration_Ward'], "MALE GENERAL WARD ONE asd asd asd as END")
        #self.select_from_list_by_index(self.objects['FO_NewRegistration_Ward'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_NewRegistration_BedNo'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_NewRegistration_Save"])
        self.dict['BROWSER'] = self._current_browser() 
    def Fetching_IPno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPNewRegistration_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_IPNewRegistration_Message'])
        self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
        self.dict['IPNO'] = self.IPno
        print self.IPno
        print("Registered IPNO is",self.dict['IPNO'])
    def clicking_ok(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_IPNewRegistration_Message_Ok"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InIPRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IP_registration")
    def InIPReg_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_registered_op_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()  
        self.click_element(self.objects['FO_NewRegistration_Advance_Search'])
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Advance_Search_Page'], 30, 'Advance search page is not open')
        self.input_text(self.objects['FO_NewRegistration_Patient_RegNo'], str(self.dict['REGNO']))
        self.click_element(self.objects['FO_NewRegistration_Patient_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+self.dict['REGNO']+'")]', 20, 'No data available')
        self.click_element('xpath=//*[(text()="'+self.dict['REGNO']+'")]')
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_department_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["IPreg_department"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["IPreg_doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedtype_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_from_list_by_label(self.objects['FO_NewRegistration_BedType'], "GENERAL BED")
        #self.select_from_list_by_index(self.objects['FO_NewRegistration_BedType'], '1')
        time.sleep(1)
        self.dict['WARD-BEDTYPE'] = self.get_selected_list_label(self.objects["FO_NewRegistration_BedType"])
        print self.dict['WARD-BEDTYPE']
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_wardname_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_from_list_by_label(self.objects['FO_NewRegistration_Ward'], "MALE GENERAL WARD ONE asd asd asd as END")
        #self.select_from_list_by_index(self.objects['FO_NewRegistration_Ward'], '1')
        time.sleep(2)
        self.dict['WARD-NAME'] = self.get_selected_list_label(self.objects["FO_NewRegistration_Ward"])
        print self.dict['WARD-NAME']
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_from_list_by_index(self.objects['FO_NewRegistration_BedNo'], '1')
        time.sleep(1)
        self.dict['WARD-BEDNO'] = self.get_selected_list_label(self.objects["FO_NewRegistration_BedNo"])
        print self.dict['WARD-BEDNO']
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['FO_NewRegistration_Save'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def Fetching_IPno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPNewRegistration_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_IPNewRegistration_Message'])
        self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
        self.dict['IPNO'] = self.IPno
        print("Registered IPNO is",self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()
    def clicking_ok(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects["FO_IPNewRegistration_Message_Ok"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()