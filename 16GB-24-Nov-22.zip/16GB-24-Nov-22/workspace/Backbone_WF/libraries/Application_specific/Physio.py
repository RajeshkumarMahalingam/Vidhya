import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InphysiocompletionEntry_OP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def Inphysio_OP_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "608467"
        time.sleep(3)
        self.click_element('xpath=//*[@id="txtregno"]')
        time.sleep(1)
        self.input_text('xpath=//*[@id="txtregno"]',str(self.dict['REGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button('xpath=//*[@class="pull-right"]//button[1]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'register number not available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_therapist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_OP_Therapist'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.input_text(self.objects['PHYSIO_Completion_Entry_OP_Remarks'],"Test normal")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['PHYSIO_Completion_Entry_OP_Save'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_OK_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['PHYSIO_Completion_Entry_OP_Msg_OK'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InphysiocompletionEntry_IP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def Inphysio_IP_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "611409"
        #self.dict['IPNO'] = "0000011437"
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        time.sleep(3)
        self.click_element(self.objects['PHYSIO_Completion_Entry_IP_RegNo'])
        time.sleep(1)
        self.input_text(self.objects['PHYSIO_Completion_Entry_IP_RegNo'],str(self.dict['REGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Search'])
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'register number not available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_therapist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_OP_Therapist'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physio_type(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_IP_Type'], '2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_service_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_IP_ServiceName'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.input_text(self.objects['PHYSIO_Completion_Entry_IP_Remarks'],"Test normal")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Save'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_OK_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Msg_OK'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()