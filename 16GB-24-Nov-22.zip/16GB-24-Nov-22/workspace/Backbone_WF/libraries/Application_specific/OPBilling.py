import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InOPBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def InOPBilling_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['OPB_MainFrame'])
        self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "610196"
        time.sleep(2)
        self.click_element(self.objects['OPB_OpBilling_RegNo'])
        time.sleep(2)
        self.input_text(self.objects["OPB_OpBilling_RegNo"],str(self.dict['REGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['OPB_OpBilling_Search'])
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceName'], 30, 'OP billing page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_standard_service'])
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_standard_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_culture_service'])
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_culture_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_pathology_service'])
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_pathology_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['rad_service'])
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['rad_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        if self._is_visible('xpath=//*[@id="s2id_autogen16_search"]'):
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['card_service'])
        else:
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
            time.sleep(1)
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['card_service'])
        
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['card_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_physio_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        if self._is_visible('xpath=//*[@id="s2id_autogen16_search"]'):
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['physio_service'])
        else:
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
            time.sleep(1)
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['physio_service'])
        
        time.sleep(1) 
        self.click_element('xpath=//*[text()="'+str(self.d[r]['physio_service'])+'"]')
        time.sleep(1)
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def pressing_tabkey(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.press_key('xpath=//*[@id="s2id_autogen16_search"]', '\\09')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.input_text('xpath=//*[@id="txtRemarks"]', 'test')
        time.sleep(1) 
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.click_link(self.objects['OPB_Paymode'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.click_button(self.objects['OPB_CashDetails_Save'])
        time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['OPB_OPBilling_Services_Save'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()