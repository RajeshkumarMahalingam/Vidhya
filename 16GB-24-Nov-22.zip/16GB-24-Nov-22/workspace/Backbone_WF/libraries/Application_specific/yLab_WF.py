import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import Lab



class Lab_WF(Selenium2Library):
    def specimencollectionlab(self):
        print "test"
        Lab.InSpecimenCollectionLab().printingtest()
        
        #Lab.InSpecimenCollectionLab.selecting_the_frame
        #Lab.InSpecimenCollectionLab.entering_into_speccolleclab_approvescreen
        #Lab.InSpecimenCollectionLab.Validate_Patient_OP
        #Lab.InSpecimenCollectionLab.selecting_allcheckboxes
        #Lab.InSpecimenCollectionLab.clicking_approve_button
        #Lab.InSpecimenCollectionLab.getmessage_after_specimencollected