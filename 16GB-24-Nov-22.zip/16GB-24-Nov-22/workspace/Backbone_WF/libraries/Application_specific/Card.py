import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InReqApproval_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible(self.objects['CARD_Request_Approve_RegNo']):
                time.sleep(1)
                self.input_text(self.objects['CARD_Request_Approve_RegNo'], str(self.dict['REGNO']))
                self.click_button(self.objects['CARD_Request_Approve_Search'])
                time.sleep(2)
                self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['CARD_Request_Approve_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestreceive_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element(self.objects['CARD_Request_Approve_Request_Receive'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message_afterrequestreceive(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['CARD_Request_Approve_Message'], 30, 'Record was not saved')
        CardReqReceiveMsg = self._get_text(self.objects['CARD_Request_Approve_Message'])
        print CardReqReceiveMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InResEntry_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible(self.objects['CARD_Result_Entry_RegNo']):
                time.sleep(2)
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Entry_RegNo'], str(self.dict['REGNO']))
                time.sleep(1)
                self.click_button(self.objects['CARD_Result_Entry_Search'])
                time.sleep(2)
                self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['card_service']+'")]', 20, 'No Tests available')
        time.sleep(2)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_entry_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        r = int(r)
        time.sleep(3)
        self.click_element('xpath=//*[(text()="'+self.d[r]['card_service']+'")]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Cardiologist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['CARD_Result_Entry_Cardiologist'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Template_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['CARD_Result_Entry_Template'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['CARD_Result_Entry_Save'])        
        self.dict['BROWSER'] = self._current_browser()
    def getting_message_once_CardResultEntered(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Message'], 30, 'Record was not saved')    
        CardResMsg = self._get_text(self.objects['CARD_Result_Entry_Message'])
        print CardResMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultDispatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InResDispatch_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_dispatch_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.input_text(self.objects['CARD_Result_Dispatch_RegNo'], str(self.dict['REGNO']))
        time.sleep(1)
        self.click_button(self.objects['CARD_Result_Dispatch_Search'])
        time.sleep(2)
        self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['CARD_Result_Dispatch_checkbox'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ResultDispatch_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_button(self.objects['CARD_Result_Dispatch_ResultDispatchBtn'])
        time.sleep(2)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message_once_Resultdispatched(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_Message'], 30, 'Record was not saved')    
        CardDispatchMsg = self._get_text(self.objects['CARD_Result_Dispatch_Message'])
        print CardDispatchMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()