from Selenium2Library import Selenium2Library
import time
from openpyxl import load_workbook
from webbrowser import Chrome

class BB_FrontOffice(Selenium2Library):
    dict = {}
    Objects = {}
  
    def Login(self):#FrontOfice login
        print "test login"
        self.open_browser(self.dict["URL"], self.dict["ENGINE"], None, False, None, None)
        time.sleep(1)
        self.maximize_browser_window()
        time.sleep(2)
        print "after maximize"
        self.input_text(self.Objects["Login_UserName"], self.dict["USERNAME"])
        time.sleep(1)
        self.input_password(self.Objects["Login_Password"], self.dict["PASSWORD"])
        time.sleep(1)
        self.click_button(self.Objects["Login_LoginButton"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
             
    def printtest(self):
        print "test"

    def Get_Login_Data(self):#get login page data
        wb = load_workbook("D:\BackBone\Automation\Automation_Demo\Data\LoginDetail_Data.xlsx")
        print "test login data"
        ws = wb['FrontOffice']
        for row in ws.rows:
            self.dict[row[0].value] = row[1].value

    def Get_Login_Objects(self):#get login page objects
        wb = load_workbook("D:\BackBone\Automation\Automation_Demo\Object_Rep\Objects_LoginScreen.xlsx")
        print "login objects"
        ws = wb['LoginScreen']
        for row in ws.rows:
            self.Objects[row[0].value] = row[1].value
        
    def Get_BackBone_Objects_From_Excel(self):#get ip cancel workflow objects
        wb = load_workbook("D:\BackBone\Automation\Automation_Demo\Object_Rep\Objects_BackBone.xlsx")
        print "test bb from excel"
        ws = wb['BackBone']
        for row in ws.rows:
            self.Objects[row[0].value] = row[1].value

    def IP_Reg_Cancel(self):  #This function helps to cancel the IP Registration
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.set_selenium_implicit_wait(3)
        self.mouse_over(self.Objects['FO_REGISTRATION_MENU'])
        time.sleep(1)
        self.click_element(self.Objects['FO_IP_REGISTRATION'])
        time.sleep(1)
        self.click_element(self.Objects['FO_IP_REGISTRATION_CANCEL'])
        time.sleep(5)
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(1)
        self.input_text(self.Objects['FO_IP_CancelReg_IPNo'], '0000010672')
        time.sleep(2)
        self.click_button(self.Objects['FO_IP_CancelReg_GoButton'])
        time.sleep(1)
        self.click_element(self.Objects['FO_IP_CancelReg_Cancel'])
        time.sleep(5)
        self.input_text_into_prompt("duplicate")
        time.sleep(3)
        self.dismiss_alert(accept=True)
    
      
BB_FrontOffice().Get_Login_Data()
BB_FrontOffice().Get_Login_Objects()
BB_FrontOffice().Get_BackBone_Objects_From_Excel()
BB_FrontOffice().Login()
#BB_FrontOffice().IP_Reg_Cancel()

    
        
