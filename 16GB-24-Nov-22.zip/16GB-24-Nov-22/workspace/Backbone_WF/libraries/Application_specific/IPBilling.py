#import sys
#from Selenium2Library import Selenium2Library
#sys.path.append('..\..\libraries\standard')
#sys.path.append('../../libraries/standard')
#sys.path.append('..\..\libraries\Application_specific')
#from common_importstatements import *
#from admin import FromConfigFile
#from common_reader import Capturing

import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
class InIPBillGeneration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InIPBillGen_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000010748"
        self.click_element(self.objects['IPB_IP_Bill_Generation_Page'])
        self.input_text(self.objects['IPB_IP_Bill_Generation_IPNo'], str(self.dict['IPNO']))    
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_IPPatient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['IPB_IP_Bill_Generation_Search'])
        #self.dict['IPNO'] = "0000010748"
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['IPNO'])+'")]', 20, 'No data available')
        self.click_element('xpath=//*[(text()="'+str(self.dict['IPNO'])+'")]')
        self.wait_until_element_is_visible(self.objects['IPB_IP_Bill_Generation_Page'], 30, 'IP Bill Generation page is not loaded')
        self.wait_until_element_is_enabled(self.objects['IPB_IP_Bill_Generation_Save'], 5, 'Save button is not enabled')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['IPB_IP_Bill_Generation_Save'])
        self._close_alert()
        self.dict['BROWSER'] =  self._current_browser() 
class InReceiptGeneration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InReceiptGen_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000011072"
        self.click_element(self.objects['IPB_IP_Receipt_Generation_Page'])
        self.input_text(self.objects['IPB_IP_Receipt_Generation_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element(self.objects['IPB_IP_Receipt_Generation_Search'])
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_IP_Patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000011072"
        time.sleep(1)
        self.click_element('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element('xpath=//*[@id="paymentDetailLink"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame('xpath=//*[@id="iframe1"]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[text()="PAYMENT TYPE "]', 30, 'Payment type page is not loaded')        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button('xpath=//*[@id="savecashdetails"]')
        time.sleep(1)
        PaymodeSaveMsg = self.get_alert_message()
        print PaymodeSaveMsg
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@id="btnSaveText"]')
        time.sleep(2)
        ReceiptGenMsg = self.get_alert_message()
        print ReceiptGenMsg
        self.dict['BROWSER'] = self._current_browser()
class InServiceBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InServiceBilling_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['REGNO'] = "612217"
        self.input_text(self.objects['IPB_ServiceBilling_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] =  self._current_browser()
    def entering_into_servicebillingpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@id="tbodyPatList"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@id="btnSave"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_servicename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.input_text('xpath=//*[@id="s2id_autogen3_search"]', "%%%")
        time.sleep(2)
        self.press_key('xpath=//*[@id="s2id_autogen3_search"]', '\\13')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element('xpath=//*[@id="btnSaveText"]')
        time.sleep(2)
        self._handle_alert(True)
        time.sleep(1)
        self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    
        
    
    