import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
from pynput.keyboard import Key, Controller 

class InWardHome_AssignToBed(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InAssgToBed_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        #self.dict['IPNO'] = "0000011437"
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 20, 'No data present')
        #self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_AssignToBed(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(9)
        if self._is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]'):
           self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]')
           self.dict['AssgnToBed_Msg'] = self.get_alert_message()
           print self.dict['AssgnToBed_Msg']
           self.dict['BROWSER'] = self._current_browser()
        else:
           pass 
        self.dict['BROWSER'] = self._current_browser()
        
class InWardHome_WardOrders(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    
    def InWardOrders_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        #print self.dict['WARD-NAME']
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "0000011154"
        time.sleep(7)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 25, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardorders_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_OrdersTab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        if self._is_visible('xpath=//*[@id="select2-drop"]//./input'):
           self.click_element('xpath=//*[@id="select2-drop"]//./input')
           #self.input_text('xpath=//*[@id="select2-drop"]//./input', "test")
           self.press_key('xpath=//*[@id="select2-drop"]//./input', '\\09')
        else:
           pass
        #if self._is_visible('xpath=//*[@id="select2-results-1"]//li'):
        #   self.press_key('xpath=//*[@id="select2-results-1"]//li', '\\09')
        #else:
        #   pass
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_Orders'], 30, 'Order Page is not loaded')
        time.sleep(3)
        self.click_element(self.objects['WARD_Orders'])
        self.dict['BROWSER'] = self._current_browser()
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['card_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['rad_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['rad_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_standard_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_culture_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_culture_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_pathology_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_pathology_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 10, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
        
class InWardHome_DischargeIntimation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OPBilling")
    def InDischargeIntim_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        #print self.dict['WARD-NAME']
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "0000011151"
        time.sleep(7)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 25, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimation_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//div[3]//div[2]//button[4]//span')
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_DischargeIntim_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_Discharge_Intimation_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimType(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.select_from_list_by_index(self.objects['WARD_Discharge_Intimation_Type'], '1')  
        self.select_from_list_by_index('xpath=//*[@id="cboDischargeType"]', '3')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['WARD_Discharge_Intimation_Save'])
        self._handle_alert(True)
        self.wait_until_element_is_visible(self.objects['WARD_Discharge_Intimation_Message'], 10, 'Record was not saved')
        self.dict['DischgIntimMsg'] = self._get_text(self.objects['WARD_Discharge_Intimation_Message'])
        print self.dict['DischgIntimMsg']
        self.dict['BROWSER'] = self._current_browser()
class InWardDischarge(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def zoom_out_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        keyboard = Controller()
        keyboard.press(Key.ctrl)
        keyboard.tap('-')
        keyboard.tap('-')
        keyboard.tap('-')
        keyboard.tap('-')
        keyboard.release(Key.ctrl)
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def InWardDisch_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.wait_until_element_is_visible('xpath=//*[text()=" WARD DISCHARGE"]', 10, 'page is not loaded')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_view_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button('xpath=//*[@id="form_control_1"]/div[1]/div[2]/div[3]/div/button[1]')
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_discharge_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.click_element('xpath=//*[@id="trdiscbo"]/td[text()="'+str(self.dict['IPNO'])+'"]//..//span[3]')
        time.sleep(2)
        if self._is_visible('xpath=//*[@id="txtDelayRmks"]'):
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "due to billing")
            time.sleep(1)
            self.click_button('xpath=//*[@id="txtDelayRmks"]/../..//div[2]/button[1]')
            time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()     
    def selecting_discharge_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button('xpath=//*[@id="btnDischarge"]')
        time.sleep(1)
        self._handle_alert(True)
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]/div/div', 10, 'Message not received')
        self.dict['WardDischMsg'] = self._get_text('xpath=//*[@id="toast-container"]/div/div')
        print self.dict['WardDischMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InWardquicklinks(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InWardquicklinks_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 25, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_toviewpatientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        time.sleep(2)
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_quicklink(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.mouse_over(self.objects['WARD_QuickLinks'])
        time.sleep(2)
        self.click_element(self.objects['WARD_QuickLinks_Link'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physiorequest(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physioframe(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(15)
        self.select_frame(self.objects['WARD_QuickLinks_Physiotherapy_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_physio_diagnosis(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.input_text(self.objects['WARD_QuickLinks_Physiotherapy_Physio'], "uft testing")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element('xpath=//*[@id="s2id_cboDoctor"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_doctor_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]')
        time.sleep(1)
        self.input_text('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', "ELANGO")
        time.sleep(1)
        self.press_key('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy_Save'])
        time.sleep(1)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()