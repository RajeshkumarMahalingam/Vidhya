import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InSpecimenCollectionLab(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InSpecCollLab_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_speccolleclab_approvescreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        #self.click_element('xpath=//*[@class="actions"]//button[1]')
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['LAB_Specimen_Collection_Lab_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Specimen_Collection_Lab_Page'])
        if self._is_visible(self.objects['LAB_SCL_RegNo']):
            time.sleep(1)
            self.input_text(self.objects['LAB_SCL_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SCL_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 5, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SCL_Approve'], 10, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_SCL_Selectall_CheckBox'])        
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SCL_Approve'])
        time.sleep(3)
        self._close_alert()
        time.sleep(1)
        self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_specimencollected(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SCL_Message'], 30, 'Approval not successful')
        LabSpecCollecMsg = self._get_text(self.objects['LAB_SCL_Message'])
        print LabSpecCollecMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
    
class InSendSpecimenToDepartment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InSendSpecToDept_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def entering_into_sendspectodept_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible(self.objects['LAB_SSTD_RegNo']):
            self.input_text(self.objects['LAB_SSTD_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SSTD_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['LAB_SSTD_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_senttodepartment_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SSTD_Send_To_Dept'])
        time.sleep(3)
        self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_specimensent(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTD_Message'], 30, 'Approval not successful')
        LabSendSpecToDeptMsg = self._get_text(self.objects['LAB_SSTD_Message'])
        print LabSendSpecToDeptMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InSpecimenReceiveDepartmentWise(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InSpecRecDeptWise_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_deptwisereceive_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        if self._is_visible(self.objects['LAB_SRDW_RegNo']):
            self.input_text(self.objects['LAB_SRDW_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SRDW_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['LAB_SRDW_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_departmentreceive_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SRDW_Dept_Receive'])
        time.sleep(3)
        self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_deptreceive(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_SRDW_Message'], 30, 'Approval not successful')
        LabDeptRecvMsg = self._get_text(self.objects['LAB_SRDW_Message'])
        print LabDeptRecvMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
      
class InStandardResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def InStdResEntry_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_resultentry_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible(self.objects['LAB_SSTRE_RegNo']):
            self.input_text(self.objects['LAB_SSTRE_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SSTRE_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_SSTRE_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultentry_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SSTRE_Result_Entry'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_result(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 20, 'No Tests available')
        self.input_text(self.objects['LAB_SSTRE_RE_Result'], str(self.d[r]['standard_result']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_comments(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 20, 'No Tests available')
        r = int(r)
        self.input_text(self.objects['LAB_SSTRE_RE_Comments'], str(self.d[r]['standard_comments']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_internalremarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 20, 'No Tests available')
        r = int(r)
        self.input_text(self.objects['LAB_SSTRE_RE_Internal_Remarks'], str(self.d[r]['standard_internalremarks']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 20, 'No Tests available')
        r = int(r)
        self.input_text(self.objects['LAB_SSTRE_RE_Remarks'], str(self.d[r]['standard_remarks']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_SSTRE_RE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_resultsentered(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRE_Message'], 30, 'Approval not successful')
        LabSSTREMsg = self._get_text(self.objects['LAB_SSTRE_Message'])
        print LabSSTREMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
     
class InStandardResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InStdResApprove_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_resultapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        if self._is_visible(self.objects['LAB_SSTRA_RegNo']):
            self.input_text(self.objects['LAB_SSTRA_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SSTRA_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_SSTRA_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultapprove_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SSTRA_Result_Approve'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRA_Approve'], 20, 'No Tests available')
        self.click_button(self.objects['LAB_SSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()         
    def getmessage_after_resultapprove(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRA_Message'], 30, 'Approval not successful')
        LabSSTRAMsg = self._get_text(self.objects['LAB_SSTRA_Message'])
        print LabSSTRAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InDigitalSignApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InDigSignApprov_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_digitalsignapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible(self.objects['LAB_SSTDA_RegNo']):
            self.input_text(self.objects['LAB_SSTDA_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_SSTDA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Result_Approve'], 10, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_SSTDA_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultapprove_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['LAB_SSTDA_Result_Approve'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Approve'], 20, 'No Tests available')
        self.click_button(self.objects['LAB_SSTDA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_digitalsignapprove(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTDA_Message'], 30, 'Approval not successful')
        LabSSTDAMsg = self._get_text(self.objects['LAB_SSTDA_Message'])
        print LabSSTDAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InCultureResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def InCulResEntry_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_cultureresultentry_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_Culture_Service_Result_Entry_Update_Page'], 10, 'Page not loaded')
        self.click_element(self.objects['LAB_Culture_Service_Result_Entry_Update_Page'])
        time.sleep(1)
        r = int(r)
        time.sleep(1)
        if self._is_visible(self.objects['LAB_CSTRE_RegNo']):
            self.input_text(self.objects['LAB_CSTRE_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_CSTRE_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['Lab_culture_service']+'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.click_element('xpath=//*[(text()="'+str(self.d[r]['Lab_culture_service'])+'")]')
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['LAB_CSTRE_Report_Status'], 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reportstatus(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['LAB_CSTRE_Report_Status'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cultureresult(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_from_list_by_index(self.objects['LAB_CSTRE_Culture_Result'], '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['LAB_CSTRE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_cultureresultentered(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CSTRE_Message'], 30, 'Approval not successful')
        LabCSTREMsg = self._get_text(self.objects['LAB_CSTRE_Message'])
        print LabCSTREMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InCultureResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def InCulResApprove_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_cultureresultapprove_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_Culture_Service_Result_Approve_Page'], 10, 'Page not loaded')
        self.click_element(self.objects['LAB_Culture_Service_Result_Approve_Page'])
        time.sleep(1)
        r = int(r)
        time.sleep(1)
        if self._is_visible(self.objects['LAB_CSTRA_RegNo']):
            self.input_text(self.objects['LAB_CSTRA_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_CSTRA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['Lab_culture_service']+'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.click_element('xpath=//*[(text()="'+str(self.d[r]['Lab_culture_service'])+'")]')
        time.sleep(5)
        self.wait_until_element_is_visible(self.objects['LAB_CSTRA_Approve'], 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.click_element(self.objects['LAB_CSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_cultureresultapproved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CSTRA_Message'], 30, 'Approval not successful')
        LabCSTRAMsg = self._get_text(self.objects['LAB_CSTRA_Message'])
        print LabCSTRAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InPathologyResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def InPathResEntry_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.select_frame(self.objects['LAB_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologyresultentry_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_Pathology_Service_Result_Entry_Page'], 10, 'Page not loaded')
        self.click_element(self.objects['LAB_Pathology_Service_Result_Entry_Page'])
        time.sleep(1)
        r = int(r)
        time.sleep(1)
        if self._is_visible(self.objects['LAB_PSTRE_RegNo']):
            self.input_text(self.objects['LAB_PSTRE_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_PSTRE_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['Lab_pathology_service']+" - [ Report : 1]"'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologytestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.click_element('xpath=//*[(text()="'+self.d[r]['Lab_pathology_service']+" - [ Report : 1]"'")]')
        time.sleep(5)
        #self._close_alert()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRE_Report_Type'], 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reporttype(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("Lab")
        r = int(r)
        time.sleep(1)
        self.select_from_list_by_label(self.objects['LAB_PSTRE_Report_Type'], self.d[r]['pathology_report_type'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element(self.objects['LAB_PSTRE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InPathologyResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def InPathResApprove_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologyresultapprove_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_Pathology_Service_Result_Approve_Page'], 10, 'Page not loaded')
        self.click_element(self.objects['LAB_Pathology_Service_Result_Approve_Page'])
        time.sleep(1)
        r = int(r)
        time.sleep(1)
        if self._is_visible(self.objects['LAB_PSTRA_RegNo']):
            self.input_text(self.objects['LAB_PSTRA_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_PSTRA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['Lab_pathology_service']+" - [ Report : 1]"'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologytestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.click_element('xpath=//*[(text()="'+self.d[r]['Lab_pathology_service']+" - [ Report : 1]"'")]')
        time.sleep(5)
        #self._close_alert()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRA_Approve'], 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_report_status(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("Lab")
        r = int(r)
        time.sleep(1)
        self.select_from_list_by_label(self.objects['LAB_PSTRA_Report_Status'], self.d[r]['pathology_select_report_status'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element(self.objects['LAB_PSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_pathologyapproved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRA_Message'], 30, 'Approval not successful')
        LabPSTRAMsg = self._get_text(self.objects['LAB_PSTRA_Message'])
        print LabPSTRAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InLabDispatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InLabDispatch_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_labdispatch_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_Dispatch_Page'], 10, 'Page not loaded')
        self.click_element(self.objects['LAB_Dispatch_Page'])
        time.sleep(1)
        if self._is_visible(self.objects['LAB_Dispatch_RegNo']):
            self.input_text(self.objects['LAB_Dispatch_RegNo'], str(self.dict['REGNO']))
            self.click_button(self.objects['LAB_Dispatch_Search'])
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def Validate_Patient_OP(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Selectall_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_element(self.objects['LAB_Dispatch_Selectall'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultdispatch_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.click_button(self.objects['LAB_Dispatch_ResultDispatch'])
        time.sleep(2)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_resultdispatch(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_Dispatch_Message'], 40, 'Approval not successful')
        LabresdispatchMsg = self._get_text(self.objects['LAB_Dispatch_Message'])
        print LabresdispatchMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
        