import sys
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import admin
from admin import FromConfigFile
import WF_FrontOffice
from WF_FrontOffice import InNewOpRegistration
from datetime import datetime, timedelta, date
import datetime
import time
import pyautogui
import openpyxl
from openpyxl import load_workbook
import common_reader
from common_reader import Capturing
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
import common_importstatements
from common_importstatements import *
import psutil
from selenium.common.exceptions import StaleElementReferenceException  
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotInteractableException


class Opnewregistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    #regtobedone = WF_FrontOffice.InNewOpRegistration.regtobedone
    #rw = 0
    def multiple_opnew_registration(self):
        self.set_selenium_implicit_wait(30)
        print datetime.datetime.now()
        wb = load_workbook('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
        ws = wb["QA_Multiple_OPREG"]
        num_rows = ws.max_row
        self.r = 1
        wb.close()
        #self.x = 0
        admin.FromConfigFile().driving_browser_and_url()
        admin.FromConfigFile().logging("frontofficeQAnew")
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        WF_FrontOffice.InNewOpRegistration().select_the_frame()
        time.sleep(2)
        wb = load_workbook('E:\workspace\Backbone_WF\Config\Prerequsiteconfig.xlsx')
        ws = wb["Reg_WF_Settings"]
        statusregcount = ws.cell(row=2,column=3).value
        print "statusregcount", statusregcount
        wb.close()
        if statusregcount == 1:
            time.sleep(2)
            required_op_new_count = ws.cell(row=2,column=1).value
            print "required_op_new_count", required_op_new_count
            regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
            print "regtobedone before save", regtobedone
        else:
            regtobedone = 1000000
        i = 1
        j = 0
        while self.r < num_rows and j < regtobedone:
         #print "regtobedone inside while", regtobedone
         self.r = self.r + 1
         wb = load_workbook('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
         ws = wb["QA_Multiple_OPREG"]
         statusvalue = ws.cell(row=(self.r),column=2).value
         if ws.cell(row=(self.r),column=2).value == "yes":
          rwno = self.r - 1
          #self.x = self.x + 1
          #WF_FrontOffice.InNewOpRegistration().InNewOp_ScreenshotOnFailure()
          #WF_FrontOffice.InNewOpRegistration().select_the_frame()
          start_time = datetime.datetime.now()
          time.sleep(2)
          try :
           WF_FrontOffice.InNewOpRegistration().selecting_department_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().selecting_doctor_with_data(rwno)
           #WF_FrontOffice.InNewOpRegistration().selecting_unit_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().selecting_sal_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().entering_name_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().selecting_gender_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().entering_age_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().selecting_maritalstatus_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().entering_address_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().selecting_city_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().entering_mobile_with_data(rwno)
           WF_FrontOffice.InNewOpRegistration().entering_email_with_data()
          #WF_FrontOffice.InNewOpRegistration().clicking_save()
          #WF_FrontOffice.InNewOpRegistration().test_Fetching_regno()
          #WF_FrontOffice.InNewOpRegistration().testing_Fetching_regno()
          #WF_FrontOffice.InNewOpRegistration().testinggg_Fetching_regno()
           j = WF_FrontOffice.InNewOpRegistration().testexcep(self.r,wb,j)
           regtobedone = WF_FrontOffice.InNewOpRegistration().regmatchcount(required_op_new_count)
           print "regtobedone after save", regtobedone
           end_time = datetime.datetime.now()
           diff_time = end_time-start_time
           diff_seconds =  diff_time.total_seconds()
          
          #wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
          
           ws = wb["QA_Multiple_OPREG"]
           ws = wb.active
           ws.cell(row=(self.r),column=4).value = diff_seconds
          #print datetime.datetime.now()
          #wb.save('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
          #print datetime.datetime.now()
          #wb.close()
           print(diff_seconds)
           ws = wb["QA_Multiple_OPREG"]
           rampercentage =  psutil.virtual_memory()[2]
           ws.cell(row=(self.r),column=6).value = rampercentage
           print rampercentage
           if diff_seconds > 50 or rampercentage > 80:
              print "Crossed 11 second"
              admin.FromConfigFile().Logoff()
              #wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx') 
              ws = wb["QA_Multiple_OPREG"]
              ws.cell(row=(self.r),column=5).value = "Crossed 11 secs or ram percent crossed 80, so re-login browser"
              #wb.save('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
              #wb.close()
              admin.FromConfigFile().Test_Teardown()
              admin.FromConfigFile().driving_browser_and_url()
              admin.FromConfigFile().logging("frontofficeQAnew")
              WF_FrontOffice.InNewOpRegistration().select_the_frame()
            #if self.x!=0 and self.x%20 == 0:
            #time.sleep(30)
           # admin.FromConfigFile().Logoff()
            #admin.FromConfigFile().logging("frontoffice")
         #admin.FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tOPNewRegistration.aspx")
          except :
             wb.save('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
             ws.cell(row=(self.r),column=3).value = "Data not Posted - Exception"
        wb.save('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
        wb.close()
        admin.FromConfigFile().Logoff()
        admin.FromConfigFile().Test_Teardown()


class Opreviewregistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Multiple_ReviewReg")
    def Opreviewregistration_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('Registration.Opreviewregistration.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def multiple_review_registration(self):
     self.set_selenium_implicit_wait(10)
     wb = load_workbook('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx') 
     ws = wb["Multiple_ReviewReg"]
     num_rows = ws.max_row
     self.r = 1
        #self.x = 0
     print "start time of script"
     print datetime.datetime.now()
     admin.FromConfigFile().driving_browser_and_url()
     #admin.FromConfigFile().admin_ScreenshotOnFailure()
     Opreviewregistration().Opreviewregistration_ScreenshotOnFailure()
     admin.FromConfigFile().logging("frontofficeQAreview")
        #admin.FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tOPReviewRegistration.aspx")
     WF_FrontOffice.InReviewRegistration().select_the_frame()
     #Total count value in app
     # Match count - Total op count from app
     while self.r < num_rows:
      try:
         self.r = self.r + 1
         statusvalue = ws.cell(row=(self.r),column=5).value
         if ws.cell(row=(self.r),column=5).value == "yes":
          rwno = self.r - 1
          #self.x = self.x + 1
          self._cache.current = self.dict['BROWSER']
          self.browser = self._current_browser()
          start_time = datetime.datetime.now()
          #WF_FrontOffice.InReviewRegistration().InReviewReg_ScreenshotOnFailure()
          WF_FrontOffice.InReviewRegistration().entering_regno_with_data(rwno)
          #self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
          #self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
          #self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
          #time.sleep(2)
          try:
              self.click_element(self.objects['FO_ReviewRegistration_Regno'])                             
          except ElementClickInterceptedException:
                  print "pop up message displayed"
                  self.popmsg = self.get_text(self.objects['FO_ReviewRegistration_Popup_Msg'])
                  print self.popmsg
                  self.unselect_frame()
                  self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                  self.click_element('xpath=//*[@class="fa fa-home"]')
                  ws = wb["Multiple_ReviewReg"]
                  self.excelmsg = "Registration not done", str(self.popmsg)
                  print self.excelmsg
                  ws.cell(row=(self.r),column=6).value = str(self.excelmsg)
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
          else:
             print "can perform new registration"
             try :
                  self.click_element(self.objects['FO_ReviewRegistration_Regno'])
                  WF_FrontOffice.InReviewRegistration().selecting_department_with_data(rwno)
                  self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
                  self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
                  self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
                  #self.click_element(self.objects["FO_ReviewRegistration_Doc"])
                  #self.click_element(self.objects['FO_ReviewRegistration_Regno']) 
                  #self.click_element(self.objects["FO_ReviewRegistration_Doc"])
                  WF_FrontOffice.InReviewRegistration().selecting_doctor_with_data(rwno)
                  self.click_element(self.objects['FO_ReviewRegistration_Regno'])
             except :
                  print "pop up message displayed"
                  self.popmsg = self.get_text(self.objects['FO_ReviewRegistration_Popup_Msg'])
                  print self.popmsg
                  self.unselect_frame()
                  self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                  self.click_element('xpath=//*[@class="fa fa-home"]')
                  #time
                  ws = wb["Multiple_ReviewReg"]
                  self.excelmsg = "Registration not done", str(self.popmsg)
                  print self.excelmsg
                  ws.cell(row=(self.r),column=6).value = str(self.excelmsg)
                  WF_FrontOffice.InReviewRegistration().select_the_frame()
             else :
                 try:
                   WF_FrontOffice.InReviewRegistration().clicking_save()
                   try :
                       self.click_button(self.objects["FO_ReviewRegistration_Save"])
                       ws = wb["Multiple_ReviewReg"]
                       ws.cell(row=(self.r),column=6).value = "On Save data error"
                   except :
                       self.popmsg = self.get_text(self.objects['FO_ReviewRegistration_Popup_Msg'])
                       if self.popmsg == "Please Enter valid Mobile Number":
                           self.unselect_frame()
                           self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                           self.click_element('xpath=//*[@class="fa fa-home"]')
                           ws = wb["Multiple_ReviewReg"]
                           ws.cell(row=(self.r),column=6).value = "Registration is not done, mobile number is missing"
                           WF_FrontOffice.InReviewRegistration().select_the_frame()
                           
                       elif self.popmsg == "OP Review patient registered successfully":
                           self.wait_until_element_is_visible(self.objects['FO_IPNewRegistration_Message_Ok'], 50, 'record saved msg was not visible')
                           self.click_button(self.objects['FO_IPNewRegistration_Message_Ok'])
                           ws = wb["Multiple_ReviewReg"]
                           ws.cell(row=(self.r),column=6).value = "OP Review patient registered successfully"
                       else:
                           self.unselect_frame()
                           self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                           self.click_element('xpath=//*[@class="fa fa-home"]')
                           ws = wb["Multiple_ReviewReg"]
                           ws.cell(row=(self.r),column=6).value = "Data Error"
                           WF_FrontOffice.InReviewRegistration().select_the_frame()
                 except:
                   self.unselect_frame()
                   self.wait_until_element_is_visible('xpath=//*[@class="fa fa-home"]', 30, 'Home btn was not visible')
                   self.click_element('xpath=//*[@class="fa fa-home"]')
                   #time
                   ws = wb["Multiple_ReviewReg"]
                   ws.cell(row=(self.r),column=6).value = "On Save data error"
                   WF_FrontOffice.InReviewRegistration().select_the_frame()
          end_time = datetime.datetime.now()
          diff_time = end_time-start_time
          diff_seconds =  diff_time.total_seconds()
          ws = wb["Multiple_ReviewReg"]
          ws = wb.active
          ws.cell(row=(self.r),column=7).value = diff_seconds
          print(diff_seconds)
          ws = wb["Multiple_ReviewReg"]
          rampercentage =  psutil.virtual_memory()[2]
          ws.cell(row=(self.r),column=8).value = rampercentage
          print rampercentage
          if diff_seconds > 10 or rampercentage > 47:
              print "Crossed 10 seconds"
              admin.FromConfigFile().Logoff()
              ws = wb["Multiple_ReviewReg"]
              ws.cell(row=(self.r),column=9).value = "Crossed 10 secs or ram percent crossed 47, so re-login browser"
              admin.FromConfigFile().Test_Teardown()
              admin.FromConfigFile().driving_browser_and_url()
              admin.FromConfigFile().logging("frontofficeQAreview")
              #admin.FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tOPReviewRegistration.aspx")              
              WF_FrontOffice.InNewOpRegistration().select_the_frame()    
      except :
              print "overall except"
              ws = wb["Multiple_ReviewReg"]
              ws.cell(row=(self.r),column=6).value = "Unhandled exception"
              try:
                  #time
                  end_time = datetime.datetime.now()
                  diff_time = end_time-start_time
                  diff_seconds =  diff_time.total_seconds()
                  ws = wb["Multiple_ReviewReg"]
                  ws = wb.active
                  ws.cell(row=(self.r),column=7).value = diff_seconds
                  print(diff_seconds)
                  ws = wb["Multiple_ReviewReg"]
                  rampercentage =  psutil.virtual_memory()[2]
                  ws.cell(row=(self.r),column=8).value = rampercentage
                  print rampercentage
                  admin.FromConfigFile().Logoff()
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontofficeQAreview")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
              except:
                  #time
                  admin.FromConfigFile().Test_Teardown()
                  admin.FromConfigFile().driving_browser_and_url()
                  admin.FromConfigFile().logging("frontofficeQAreview")
                  WF_FrontOffice.InNewOpRegistration().select_the_frame()
     wb.save('E:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
     wb.close()
     admin.FromConfigFile().Logoff()
     admin.FromConfigFile().Test_Teardown()
     print "End time of script"
     print datetime.datetime.now()