import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
from openpyxl import load_workbook
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from Selenium2Library import Selenium2Library

'''class testings(Selenium2Library):
    def browseropening(self):

        driver = webdriver.Chrome()
        print "hi"
        driver.get("http://192.168.0.232/bb15se/Backbone/admin/login.aspx")


testings().browseropening()'''

'''try:
    element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "myDynamicElement"))
    )
finally:
    driver.quit()'''

j = 0
regtobedone = 2

while j<regtobedone:
    print "test"
    j = j+1
print "end while loop"




'''class InNewOpRegistration(Selenium2Library):
    x = 0
    r = 0
    def selecting_department_with_data(self,r):
      while self.x <= 20:
        print self.x
        self.x = self.x + 1
        print self.x
        #time.sleep(7)
        if self.x == 2:
           time.sleep(1)
           self.x = 0
           print self.x
    
    def selecting_doctor_with_data(self,r):
      while self.x <= 20:
        print self.x
        self.x = self.x + 1
        print self.x
        #time.sleep(7)
        if divmod(self.r, y) == 2:
           time.sleep(1)
           self.x = 0
           print self.x
           
InNewOpRegistration().selecting_department_with_data(1)'''