import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
from Selenium2Library import Selenium2Library
import admin
from admin import FromConfigFile
from datetime import datetime, timedelta, date
import datetime
import time
import openpyxl
from openpyxl import load_workbook
import common_importstatements
from common_importstatements import *
import psutil
from datetime import datetime, timedelta, date
import datetime
import time
#import os


#print psutil.virtual.memory()[2]
print datetime.datetime.now()
print psutil.virtual_memory()[2]
print datetime.datetime.now()


'''total_memory, used_memory, free_memmory = map(int ,os.popen('free -t -m').readlines()[-1].split()[1:])
print ('RAM IN %',round((used_memory/total_memory) * 100 , 2) )
'''


'''class trial(Selenium2Library):
    def test(self):
        self.open_browser('http://192.168.0.232/BB15se/Backbone/admin/login.aspx', 'Opera', None, False, None, None)
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 50, 'relogin  button not visible')
        self.maximize_browser_window()
        self.click_element('xpath=//a[@href="#divNewSession"]')
        time.sleep(2)
        self.input_text('xpath=//*[@id="newuname"]',"recpv15")
        self.input_text('xpath=//*[@id="txtrepassword"]',"aosta")
        self.click_button('xpath=//*[@id="btnrelogin"]')
        #self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        self.set_selenium_implicit_wait(10)
        #seshour = self.get_value('xpath = //*[@id="txtTimerHrs"]')
        seshour = self.get_text('xpath = //*[@id="txtTimerHrs"]')
        print "session hour", seshour
        #sesmin = self.get_value('xpath=//*[@id="txtTimermin"]')
        sesmin = self.get_text('xpath=//*[@id="txtTimermin"]')
        print "session minutes", sesmin
        sessec = self.get_text('xpath=//*[@id="txtTimersec"]')
        print "session seconds", sessec
        #time.sleep(65)
        sesmin = int (sesmin)
        if sesmin <= 18:
            print "goes less than 19"
            
        else:
            print "no"

trial().test()
'''

        
        
        
        
        
'''print "test" 
wb = load_workbook('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
print "wb loaded"
ws = wb["test"]
ws = wb.active
print datetime.datetime.now() 
ws.cell(row=2,column=15).value = "2500"
print datetime.datetime.now()
#wb.save('D:\workspace\Backbone_WF\datas\Bb_datas.xlsx')
#print datetime.datetime.now()
'''


