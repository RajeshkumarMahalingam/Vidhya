   def testexcep(self,r,wb):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 50, 'save was not visible before try block')
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Save'], 50, 'save was not enabled')
        try :
         self.click_button(self.objects["FO_NewRegistration_Save"])
         ws = wb["QA_Multiple_OPREG"]
         ws.cell(row=(r),column=14).value = "Data Posted"
        except ElementClickInterceptedException:
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'message was not visible')
            self.click_button('xpath=//button[@class="toast-close-button"]')
            print "Data posted"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
            #self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
            #self.wait_until_element_is_enabled('xpath=//*[@id="btnClr"]', 50, 'clr was not enabled')
            #self.click_button('xpath=//*[@id="btnClr"]')
        except ElementNotInteractableException:
                print "hi testing"
        else :
         try :
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 50, 'save was not visible inside try block')
            self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Save'], 50, 'save was not enabled')
            self.input_text(self.objects["FO_NewRegistration_Mobile"], "1")
            #new code
         except ElementNotInteractableException:
            if self._is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]'):
                 self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]', 50, 'no button was not visible')
                 self.click_element('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]')
                 self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
                 self.click_button('xpath=//*[@id="btnClr"]')
                 print "no worries"
                 ws = wb["QA_Multiple_OPREG"]
                 ws.cell(row=(r),column=14).value = "Invalid Data"
         except StaleElementReferenceException:
            print "no worries"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
         except ElementClickInterceptedException:
             # new code
            print "access error"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "access error"
            self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
            self.click_button('xpath=//*[@id="btnClr"]')
            
         else :
            print "hi"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
        self.dict['BROWSER'] = self._current_browser()
        
        
        '''
        def testexcep(self,r,wb):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 50, 'save was not visible before try block')
        self.wait_until_element_is_enabled(self.objects['FO_NewRegistration_Save'], 50, 'save was not enabled')
        #self.click_button(self.objects["FO_NewRegistration_Save"])
        try :
         self.click_button(self.objects["FO_NewRegistration_Save"]) 
         self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Save'], 50, 'save was not visible before try block')
         #self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]', 50, 'no button was not visible')  
         self.input_text(self.objects["FO_NewRegistration_Mobile"], "1")
        except ElementNotInteractableException:
                if self._is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]'):
                 self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]', 50, 'no button was not visible')
                 self.click_element('xpath=//*[@class="bootstrap-dialog-footer-buttons"]//button[@id="btn-No"]')
                 self.wait_until_element_is_visible('xpath=//*[@id="btnClr"]', 50, 'clr button was not visible')
                 self.click_button('xpath=//*[@id="btnClr"]')
                 print "no worries"
                 ws = wb["QA_Multiple_OPREG"]
                 ws.cell(row=(r),column=14).value = "Invalid Data"
        except ElementClickInterceptedException:
            print "element click intercepted exception"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'message was not visible in ElementClickInterceptedException')
            self.click_button('xpath=//button[@class="toast-close-button"]')
            print "Data posted"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
        except StaleElementReferenceException:
            print "no worries"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
        else:
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'message was not visible in else')
            self.click_button('xpath=//button[@class="toast-close-button"]')
            print "Data posted"
            ws = wb["QA_Multiple_OPREG"]
            ws.cell(row=(r),column=14).value = "Data Posted"
        self.dict['BROWSER'] = self._current_browser() 
        '''
