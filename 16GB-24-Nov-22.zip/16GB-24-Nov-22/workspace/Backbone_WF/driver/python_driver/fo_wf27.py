# Configutation
import sys
sys.path.append('..\..\libraries\standard') 
sys.path.append('..\..\libraries\Application_specific')
import  common_importstatements
from admin import FromConfigFile
from FrontOffice import InNewOpRegistration
from FrontOffice import InDoctorOpinion_Entry
from FrontOffice import InOpinion_Convert_to_IP
import time
import pyautogui
import common_reader
from common_reader import Capturing
# Drive browser and url - Logging module - Loading menu
FromConfigFile().driving_browser_and_url()
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tOPNewRegistration.aspx")
# Capture Objects and Reading data
Capturing().backbone_objects()
Capturing().data_off("op_new_registration")
# Frontoffice Registration
#reg = ""

testdata = 1
InNewOpRegistration().selecting_department_with_data(testdata)
InNewOpRegistration().selecting_doctor_with_data(testdata)
InNewOpRegistration().selecting_sal_with_data(testdata)
InNewOpRegistration().entering_name_with_data(testdata)
InNewOpRegistration().selecting_gender_with_data(testdata)
InNewOpRegistration().entering_age_with_data(testdata)
InNewOpRegistration().selecting_maritalstatus_with_data(testdata)
InNewOpRegistration().entering_address_with_data(testdata)
InNewOpRegistration().selecting_city_with_data(testdata)
InNewOpRegistration().entering_mobile_with_data(testdata)
InNewOpRegistration().clicking_save()
InNewOpRegistration().Fetching_regno()
InNewOpRegistration().unselecting_the_frame()
InNewOpRegistration().Cancelling_print_preview()
print "ENDING FLOW - OP NEW REGISTRATION"
print "Starting FLOW - Doctor Opinion Entry page"
FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tDoctorOpinionEntry.aspx") 
Capturing().data_off("Doctor_Opinion_Entry")
InDoctorOpinion_Entry().entering_regno_with_data(testdata)
InDoctorOpinion_Entry().entering_ICDCode_with_data(testdata)
InDoctorOpinion_Entry().entering_during_of_admission_with_data(testdata)
InDoctorOpinion_Entry().entering_tentative_days(testdata)
InDoctorOpinion_Entry().entering_estimation_value(testdata)
InDoctorOpinion_Entry().selecting_adviced_doctor_with_data(testdata)
InDoctorOpinion_Entry().selecting_bed_type_with_data(testdata)
InDoctorOpinion_Entry().selecting_ward_with_data(testdata)
InDoctorOpinion_Entry().clicking_save()
InDoctorOpinion_Entry().clicking_ok()
InNewOpRegistration().unselecting_the_frame()
print "Ending FLOW - Doctor Opinion Entry page"
print "Starting FLOW - Opinion convert to IP page"
FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tIPRegistration.aspx?OPT=ctip")
Capturing().data_off("Opinion_convert_to_IP")
InOpinion_Convert_to_IP().entering_regno_with_data(testdata)
InOpinion_Convert_to_IP().selecting_department_with_data(testdata)
InOpinion_Convert_to_IP().selecting_doctor_with_data(testdata)
InOpinion_Convert_to_IP().selecting_bedtype_with_data(testdata)
InOpinion_Convert_to_IP().selecting_ward_with_data(testdata)
InOpinion_Convert_to_IP().selecting_bedno_with_data(testdata) 
InOpinion_Convert_to_IP().clicking_save()
InOpinion_Convert_to_IP().Fetching_IPno()
InOpinion_Convert_to_IP().clicking_ok()
print "Ending FLOW - Opinion convert to IP page"