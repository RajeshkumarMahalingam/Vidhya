import sys
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
import admin
from admin import FromConfigFile
import FrontOffice
from FrontOffice import InNewOpRegistration
import time
import pyautogui
import common_reader
from common_reader import Capturing
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
import common_importstatements
from common_importstatements import *

class opnewregistration(Selenium2Library):
    def multiple_opnew_registration(self):
        self.set_selenium_implicit_wait(10)
        wrkbk = load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx') 
        sheet = wrkbk["Medical"]
        number_rows = sheet.max_row
        print number_rows
        self.r = 1
        admin.FromConfigFile().driving_browser_and_url()
        admin.FromConfigFile().admin_ScreenshotOnFailure()
        admin.FromConfigFile().logging("frontoffice")
        admin.FromConfigFile().loading_menu_of_link("//FrontOfficeCS/tOPNewRegistration.aspx")
        while self.r < number_rows:
         self.r = self.r + 1
         print "row value is", self.r
         statusvalue = sheet.cell(row=(self.r),column=13).value
         print "status value is", statusvalue
         if sheet.cell(row=(self.r),column=13).value == "yes":
          ptest = "test"
          print ptest
          rwno = self.r - 1
          FrontOffice.InNewOpRegistration().InNewOp_ScreenshotOnFailure
          FrontOffice.InNewOpRegistration().selecting_department_with_data(rwno)    
          FrontOffice.InNewOpRegistration().selecting_doctor_with_data(rwno)
          FrontOffice.InNewOpRegistration().selecting_sal_with_data(rwno)
          FrontOffice.InNewOpRegistration().entering_name_with_data(rwno)
          FrontOffice.InNewOpRegistration().selecting_gender_with_data(rwno)
          FrontOffice.InNewOpRegistration().entering_age_with_data(rwno)
          FrontOffice.InNewOpRegistration().selecting_maritalstatus_with_data(rwno)
          FrontOffice.InNewOpRegistration().entering_address_with_data(rwno)
          FrontOffice.InNewOpRegistration().selecting_city_with_data(rwno)
          FrontOffice.InNewOpRegistration().entering_mobile_with_data(rwno)
          FrontOffice.InNewOpRegistration().clicking_save()
          FrontOffice.InNewOpRegistration().Fetching_regno()                                    
          FrontOffice.InNewOpRegistration().unselecting_the_frame()                    
          FrontOffice.InNewOpRegistration().Cancelling_print_preview()
          #admin.FromConfigFile().Logoff()


opnewregistration().multiple_opnew_registration()