import sys
from Selenium2Library import Selenium2Library
from _ast import If
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class Validation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("field_data")
   
    def in_fo_select_dep(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(2)
        
             
                
        self.select_from_list_by_label(self.objects['FO_NewRegistration_Dept'], self.d[1]['department'])
        
        self.input_text(self.objects['FO_NewRegistration_Name'], self.d[1][1])
        a=self.d[1]['name']
        a=a.lower()
        b=self.get_value(self.objects['FO_NewRegistration_Name'])
        b=b.lower()
        print (self.get_value(self.objects['FO_NewRegistration_Name']))
        self.clear_element_text(self.objects['FO_NewRegistration_Name'])
        b=b.lower()
        print (self.get_value(self.objects['FO_NewRegistration_Name']) )
        self.dict['BROWSER'] = self._current_browser() 
        print (a+"=="+b)
        if a==b:
            print "PASS"
        else:
            print "FAIL"
                
        
FromConfigFile().driving_browser_and_url()
Capturing().data_off("field_data")
r = 1
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('/FrontOfficeCS/tOPNewRegistration.aspx')
Validation().in_fo_select_dep(r)

