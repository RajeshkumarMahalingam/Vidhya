import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import pypyodbc
import pandas as pd


class DBUpdate(Selenium2Library):

 def establishconnection(self):
    
    wrkbk = load_workbook('D:\workspace\Automate_BB15_local\Config\Prerequsiteconfig.xlsx')
    sheet = wrkbk["ServerDetails"]
    number_rows = sheet.max_row
    self.i = 1
    while self.i < number_rows:
         self.i = self.i + 1
         servername = sheet.cell(row=(self.i),column=1).value
         dbname = sheet.cell(row=(self.i),column=2).value
         userid = sheet.cell(row=(self.i),column=3).value
         pwd = sheet.cell(row=(self.i),column=4).value
         #print "servername", servername
         #print "dbname", dbname
         #print "userid", userid
         #print "pwd", pwd
         cnxn = pypyodbc.connect("Driver={SQL Server};" "Server="+servername+";" "Database="+dbname+";" "uid="+userid+"; pwd="+pwd+"")
         #print "connected    ", dbname
         print "connected    ", dbname
    print "all db update done"
DBUpdate().establishconnection()
