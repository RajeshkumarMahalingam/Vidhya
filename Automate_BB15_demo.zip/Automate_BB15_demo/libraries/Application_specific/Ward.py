import sys
from Selenium2Library import Selenium2Library
import pyautogui
#import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
#from pynput.keyboard import Key, Controller 


class InWard_Common(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser() 

class InWardHome_AssignToBed(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="DONTUSEAUTOMATIONWARD"
        self.wait_until_page_contains_element(self.objects['WARD_Select_Ward'], 30, 'Ward name was not visible')
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        #self.dict['IPNO'] = "Ip13047"
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 30, 'No ward search box present')
        self.click_element(self.objects['WARD_Search_Box'])
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 30, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_AssignToBed(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(9)
        if self._is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]'):
           self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]')
           try:
               self._handle_alert(True)
           except:
               pass
           #self.dict['AssgnToBed_Msg'] = self.get_alert_message()
           #print self.dict['AssgnToBed_Msg']
           self.dict['BROWSER'] = self._current_browser()
        else:
           pass 
        self.dict['BROWSER'] = self._current_browser()
        
    def clearing_ipnoinsearchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 30, 'Search box was not visible')
        self.wait_until_page_contains_element(self.objects['WARD_Search_Box'], 30, 'Search box was not visible in page')
        #self.click_element(self.objects['WARD_Search_Box'])
        self.clear_element_text(self.objects['WARD_Search_Box'])
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()    
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        
class InWardHome_WardOrders(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    
    def InWardOrders_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(7)
        time.sleep(10) #Release server
        #self.dict['WARD-NAME']="DONTUSEAUTOMATIONWARD"
        #print self.dict['WARD-NAME']
        self.wait_until_element_is_visible(self.objects['WARD_Select_Ward'], 30, 'ward drop down list was not present') #release server
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "Ip14185"
        #self.dict['IPNO']= "IP13371"
        time.sleep(7)
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 30, 'No ward search box present')
        self.click_element(self.objects['WARD_Search_Box'])
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 30, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardorders_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]', 30, "order icon was not visible")
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_OrdersTab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(15)
        self.select_frame(self.objects['WARD_MainFrame'])
        
        if self._is_visible('xpath=//*[@id="select2-drop"]//./input'):
           self.click_element('xpath=//*[@id="select2-drop"]//./input')
           #self.input_text('xpath=//*[@id="select2-drop"]//./input', "test")
           self.press_key('xpath=//*[@id="select2-drop"]//./input', '\\09')
        else:
           pass
        
        #if self._is_visible('xpath=//*[@id="select2-results-1"]//li'):
        #   self.press_key('xpath=//*[@id="select2-results-1"]//li', '\\09')
        #else:
        #   pass
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select2_Lab"]/a', 30, 'Order Page is not loaded')        
        self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['BROWSER'] = self._current_browser()
    def adding_diet_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(2)
        #self.d[r]['card_service'] = "ECG - ECG"
        #self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        #self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.d[r]['card_service']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        #time.sleep(1) 
        #self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['card_service'])+'")]')
        #time.sleep(3)
        #self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        #self.dict['BROWSER'] = self._current_browser()
        time.sleep(2)
        #self.d[r]['card_service'] = "Brain ECG updated"
        #self.wait_until_page_contains_element('xpath=//*[@id="s2id_select2_Lab"]/a', 10, "order service tab was not visible")
        #self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['CARDIOLOGY_SERVICE']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]', 30, "searched card service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['RADIOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]', 30, "searched rad service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_lab_glucometer_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_GLUCOMETER_SERVICE'] = self.d[r]['Lab_glucometer_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_GLUCOMETER_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_GLUCOMETER_SERVICE'])+'")]', 30, "searched service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_GLUCOMETER_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_STANDARD_SERVICE'] = self.d[r]['Lab_standard_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_STANDARD_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_STANDARD_SERVICE'])+'")]', 30, "searched lab std service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_STANDARD_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_CULTURE_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 30, "culture service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_PATHOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]', 30, "pathology service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['BLOODBANKSERVICE'] = self.d[r]['bloodbank_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODBANKSERVICE']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]', 30, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_componentservice(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODCOMPONENTNAME'])) #This dict value is assigned from the function (getting_conversioncomponentname) in bloodbank module 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODCOMPONENTNAME'])+'")]', 30, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODCOMPONENTNAME'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['WARD_Orders_Save'], 60, "save btn was not enabled")
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 60, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()         
        
class InWardHome_DischargeIntimation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("WardHome_DischargeIntim")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="DONTUSEAUTOMATIONWARD"
        #print self.dict['WARD-NAME']
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13047"
        time.sleep(3)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 30, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimation_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_enabled('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//div[3]//div[2]//button[4]//span', 30, 'No data present')
        #self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//div[3]//div[2]//button[4]//span')
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintim_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_Discharge_Intimation_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimType(self,dischargetype):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.select_from_list_by_index(self.objects['WARD_Discharge_Intimation_Type'], '1')
        #self.click_element('xpath=//*[@id="cboDischargeType"]')
        self.wait_until_page_contains_element('xpath=//*[@id="cboDischargeType"]', 30, "discharge type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDischargeType"]', dischargetype)
        #seldischargetype = self.get_selected_list_label('xpath=//*[@id="cboDischargeType"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        try:
            self.wait_until_element_is_enabled(self.objects['WARD_Discharge_Intimation_Save'], 30, "save btn was not enabled")
            self.click_element(self.objects['WARD_Discharge_Intimation_Save'])
        except:
            self.wait_until_element_is_visible('xpath=//a[@data-action="incrementHour"]', 30, "increment hour was not visible")
            self.click_element('xpath=//a[@data-action="incrementHour"]')
            self.wait_until_element_is_visible('xpath=//*[@id="spnBedtype"]', 30, "bedtype in label section was not visible")
            self.click_element('xpath=//*[@id="spnBedtype"]')
            self.wait_until_element_is_enabled(self.objects['WARD_Discharge_Intimation_Save'], 30, "save btn was not enabled")
            self.click_element(self.objects['WARD_Discharge_Intimation_Save'])
        finally:
            self._handle_alert(True)
            self.wait_until_page_contains_element(self.objects['WARD_Discharge_Intimation_Message'], 30, 'Record was not saved')
            self.wait_until_element_is_visible(self.objects['WARD_Discharge_Intimation_Message'], 30, 'Record was not saved')
            self.dict['DischgIntimMsg'] = self._get_text(self.objects['WARD_Discharge_Intimation_Message'])
            print self.dict['DischgIntimMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser() 
class InDirectOrder(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = '406'
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, 'ipno was not visible')
        self.wait_until_page_contains_element('xpath=//*[@id="txtIPno"]', 30, 'ipno was not visible')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnGo"]', 30, 'Go btn was not enabled')
        self.click_button('xpath=//*[@id="btnGo"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_directorderspage(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]', 30, "patient details not in grid")
        self.wait_until_page_contains_element('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]', 30, "patient details not in grid")
        self.click_element('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_orderservices(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        print "1"
        self.wait_until_page_contains_element('xpath=//*[@id="s2id_select2_Lab"]/a', 50, "service name was not visible in page")
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select2_Lab"]/a', 30, "service name was not visible")
        self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['BROWSER'] = self._current_browser()
    def adding_diet_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['CARDIOLOGY_SERVICE']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]', 30, "searched card service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['RADIOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]', 30, "searched rad service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_standard_service']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]', 30, "searched lab std service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_CULTURE_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 30, "culture service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_PATHOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]', 30, "pathology service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['BLOODBANKSERVICE'] = self.d[r]['bloodbank_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODBANKSERVICE']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]', 30, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 30, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()       
        
                     
class InWardDischarge(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InWardDisch_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_IPNO(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.wait_until_page_contains_element('xpath=//*[@id="txtIPno"]', 30, 'ipno was not visible')
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, 'ipno was not visible')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_view_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="trdiscbo"][1]', 30, "patient details was not visible in page")
        self.wait_until_element_is_visible('xpath=//*[@id="trdiscbo"][1]', 30, "patient details was not visible")
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[text()="View "]', 30, "view button was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[text()="View "]')
        time.sleep(2)
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_discharge_checkbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.wait_until_element_is_visible('xpath=//*[@id="trdiscbo"]/td[text()="'+str(self.dict['IPNO'])+'"]//..//span[3]', 30, 'patient was not visible in grid')
        self.click_element('xpath=//*[@id="trdiscbo"]/td[text()="'+str(self.dict['IPNO'])+'"]//..//span[3]')
        time.sleep(2)
        if self._is_visible('xpath=//*[@id="txtDelayRmks"]'):
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "due to billing")
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]/../..//div[2]/button[1]', 30, "delay remarks btn was not visible")
            self.click_button('xpath=//*[@id="txtDelayRmks"]/../..//div[2]/button[1]')
            time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()     
    def selecting_discharge_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnDischarge"]', 30, 'discharge btn was not enabled')
        self.click_button('xpath=//*[@id="btnDischarge"]')
        #time.sleep(1)
        self._handle_alert(True)
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]/div/div', 30, 'Message not received')
        self.dict['WardDischMsg'] = self._get_text('xpath=//*[@id="toast-container"]/div/div')
        print self.dict['WardDischMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InWardquicklinks(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_page_contains_element('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        #self.wait_until_element_is_visible('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        #self.wait_until_page_contains_element('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        self.wait_until_page_contains_element(self.objects['WARD_Search_Box'], 30, "search box was not visible")
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        time.sleep(3)
        self.wait_until_page_contains_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 30, 'No patient gets viewed in home page')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_toviewpatientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i', 30, "ip patient was not visible")
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i', 30, "ip patient was not visible")
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        time.sleep(2)
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_quicklink(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_QuickLinks'], 30, 'Quick links was not visible')
        self.mouse_over(self.objects['WARD_QuickLinks'])
        time.sleep(2)
        self.click_element(self.objects['WARD_QuickLinks_Link'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physiorequest(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy'], 30, 'WARD_QuickLinks_Physiotherapy was not visible')
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physioframe(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(7)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy_Frame'], 30, 'Physio frame was not visible')
        self.select_frame(self.objects['WARD_QuickLinks_Physiotherapy_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_physio_diagnosis(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy_Physio'], 30, 'WARD_QuickLinks_Physiotherapy_Physio  was not visible')
        self.input_text(self.objects['WARD_QuickLinks_Physiotherapy_Physio'], "uft testing")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctor"]', 30, 'doctor name was not visible')
        self.click_element('xpath=//*[@id="s2id_cboDoctor"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', 30, 'doctor name was not visible')
        self.click_element('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]')
        time.sleep(1)
        self.input_text('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', "%%%")
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]/../..//li[2]//span', 30, "doctors name list was not visible")
        self.click_element('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]/../..//li[2]//span')
        #self.press_key('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_QuickLinks_Physiotherapy_Save'], 30, 'physio save btn was not visible')
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy_Save'])
        try:
         self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InBirthRegister(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_BirthReg')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def dob_datepicker(self,loc, date):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        today = date.today()
        print today.strftime('%d/%B/%Y')
        #print date
        print "today", today
        print type(today)
        
        picdate = date
        print picdate.strftime('%d/%B/%Y')
        
        print "picdate", picdate
        print type(picdate)
        
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        #loc = 'xpath=//*[@id="txtRDt"]'
        self.click_element(loc)
        
        if picdate > today:        
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                self.wait_until_element_is_visible('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]', 10, "calender was not visible")
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')              
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="next"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="next"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
        else:
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="prev"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="prev"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_babydob(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtRDt"]', 30, "baby dob date was not visible")
        self.click_element('xpath=//*[@id="txtRDt"]')
        self.click_element('xpath=(//*[@class="day"])[6]')
        #date = self.d[r]['birthregdate']
        #self.dob_datepicker('xpath=//*[@id="txtRDt"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 30, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        #self.dict['IPNO'] = 'IP15751'
        self.wait_until_element_is_visible('xpath=//*[@id="txtipregno"]', 30, 'ipno was not visible')
        self.click_element('xpath=//*[@id="txtipregno"]')
        self.input_text('xpath=//*[@id="txtipregno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtipregno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_babygeneraldocinfotab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@href="#portlet_tab3"]', 30, 'baby gen&doc info tab was not enabled')
        self.click_element('xpath=//*[@href="#portlet_tab3"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_birthtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboBirthType"]', 30, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboBirthType"]', '1')
        self.dict['BROWSER'] = self._current_browser()
    def entering_nationality(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtNationality"]', 30, 'nationality was not visible')
        self.click_element('xpath=//*[@id="txtNationality"]')
        self.input_text('xpath=//*[@id="txtNationality"]', "Indian")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_religion(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboReligion"]', 30, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_weeksofpregnancy(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboWks"]', 30, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboWks"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_consultunder(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctorattended"]', 30, 'consult under was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboDoctorattended"]', '2')
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_deliveredby(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDeldoc"]', 30, 'delivered by was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboDeldoc"]', '2')
        self.dict['BROWSER'] = self._current_browser()          
    def selecting_babyandparentdetailtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@href="#portlet_tab5"]', 30, 'baby & parent detail info tab was not enabled')
        self.click_element('xpath=//*[@href="#portlet_tab5"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtWht"]', 30, 'weight was not visible')
        self.input_text('xpath=//*[@id="txtWht"]', "3")
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_maturity(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboMat"]', 30, 'Maturity was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMat"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_babygender(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboBabysex"]', 30, 'baby gender was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboBabysex"]', '2')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_calender(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRDt"]', 30, 'calender was not enabled')
        self.click_element('xpath=//*[@id="txtRDt"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_fathername(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.press_key('xpath=//*[@id="txtRDt"]', '\\09')
        self.press_key('xpath=//*[@id="txtRDt"]', '\\09')
        self.wait_until_element_is_visible('xpath=//*[@id="txtFatherName"]', 30, 'father name was not visible')
        self.click_element('xpath=//*[@id="txtFatherName"]')
        self.input_text('xpath=//*[@id="txtFatherName"]', self.d[r]['fathername'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_ageatmarriage(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtmAge"]', 30, 'ageatmarriage was not visible')
        self.input_text('xpath=//*[@id="txtmAge"]', str(self.d[r]['ageatmarriage']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_motherqualification(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboMQual"]', 30, 'Mother qualification was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMQual"]', '2')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_motheroccupation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboMotherOccupation"]', 30, 'Mother occupation was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMotherOccupation"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_motherreligion(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboMReligion"]', 30, 'Mother religion was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_mothernationality(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtMNationality"]', 30, 'Mother nationality was not visible')
        self.input_text('xpath=//*[@id="txtMNationality"]', self.d[r]['mothernationality'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fatherqualification(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboFQual"]', 30, 'father qualification was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFQual"]', '2')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_fatheroccupation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboFatherOccupation"]', 30, 'Father occupation was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFatherOccupation"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fatherreligion(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboFReligion"]', 30, 'Father religion was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_fathernationality(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtFNationality"]', 30, 'Father nationality was not visible')
        self.input_text('xpath=//*[@id="txtFNationality"]', self.d[r]['fathernationality'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//*[@id="btnSave"]', 30, 'save btn was not enabled')
        self.click_button('xpath=//*[@class="actions"]//*[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()   
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_page_contains_element('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InBirthRegisterSentToCorporation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off('Ward_BirthReg')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipnoradiobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="rdoIPno"]/..//span[3]', 30, 'ipno btn was not visible')
        self.click_element('xpath=//*[@id="rdoIPno"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        #self.dict['IPNO'] = '406'
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPRegNO"]', 30, 'ipno was not visible')
        self.click_element('xpath=//*[@id="txtIPRegNO"]')
        self.input_text('xpath=//*[@id="txtIPRegNO"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPRegNO"]', '\\13')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatdata"]//label[@for="checkAll"]/span[3]', 30, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tblPatdata"]//label[@for="checkAll"]/span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_internalrefno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtMRDno"]', 30, 'internal ref no was not visible')
        self.click_element('xpath=//*[@id="txtMRDno"]')
        self.input_text('xpath=//*[@id="txtMRDno"]', str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()
    def entering_corporationackno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtCorpAckno"]', 30, 'ack no was not visible')
        self.click_element('xpath=//*[@id="txtCorpAckno"]')
        self.input_text('xpath=//*[@id="txtCorpAckno"]', "ACK"+str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 30, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InDeathRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_DeathReg')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 30, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ipnoradiobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000712"
        try:
          msg = self.get_text('xpath=//*[@class="toast-message"]')
          if msg == "Select IPNO OR OPNO Option":
             self.click_element('xpath=//button[@class="toast-close-button"]') 
        except:
            time.sleep(2)
        else:
            pass
        self.wait_until_element_is_visible('xpath=//*[@id="rdoip"]/..//span[3]', 30, "ipno radio btn was not visible")
        self.click_element('xpath=//*[@id="rdoip"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboipno"]', 30, "ipno dropdown was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboipno"]', self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_deathinfotab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.wait_until_element_is_visible('xpath=//*[@href="#portlet_tab2"]', 60, "death info tab was not visible")
        self.click_element('xpath=//*[@href="#portlet_tab2"]')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_religion(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboReligion"]', 30, "religion was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_diagnosis(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtDiagnosis"]', 30, "diagnosis was not visible")
        self.input_text('xpath=//*[@id="txtDiagnosis"]', self.d[r]['diagnosis'])
        self.dict['BROWSER'] = self._current_browser()   
    def entering_causeofdeath(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtCauseofDeath"]', 30, "cause of death was not visible")
        self.input_text('xpath=//*[@id="txtCauseofDeath"]', self.d[r]['cause'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_declaredby(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDeclaredBy"]', 30, "declared by was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDeclaredBy"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 30, "savebtn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.wait_until_page_contains_element('xpath=//*[@id="toast-container"]', 10, 'save message was not visible')
        #self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        #print self.msg
        self._handle_alert(True)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InDeathRegistrationSentToCorp(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def searching_patientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13047"
        self.wait_until_element_is_enabled('xpath=//*[@id="tblPatdata_filter"]//input', 30, 'search box was not enabled')
        self.input_text('xpath=//*[@id="tblPatdata_filter"]//input', "IP "+str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="checkAll"]/..//span[3]', 30, 'checkbox all was not visible')
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()    
    def entering_corporationackno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtCorpAckno"]', 30, 'ack no was not visible')
        self.click_element('xpath=//*[@id="txtCorpAckno"]')
        self.input_text('xpath=//*[@id="txtCorpAckno"]', str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()         
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 30, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(2)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tDeathCorpEntry.aspx")
InWardHome_AssignToBed().InAssgToBed_ScreenshotOnFailure()               
InWardHome_AssignToBed().selecting_the_frame()
InWardHome_AssignToBed().selecting_skip()
InWardHome_AssignToBed().selecting_wardname()
InWardHome_AssignToBed().entering_and_searching_registered_ipno()
InWardHome_AssignToBed().selecting_AssignToBed()
InWardHome_DischargeIntimation().screenshotonfailure()
InWardHome_DischargeIntimation().selecting_the_frame()
InWardHome_DischargeIntimation().selecting_skip()
InWardHome_DischargeIntimation().selecting_wardname()
InWardHome_DischargeIntimation().entering_and_searching_registered_ipno()
InWardHome_DischargeIntimation().selecting_dischargeintimation_button()
InWardHome_DischargeIntimation().selecting_dischargeintim_frame()
InWardHome_DischargeIntimation().selecting_dischargeintimType('1')
InWardHome_DischargeIntimation().selecting_save_button()
InDeathRegistration().screenshotonfailure()
InDeathRegistration().selecting_the_frame()
InDeathRegistration().selecting_newbtn()
InDeathRegistration().selecting_ipnoradiobtn()
InDeathRegistration().selecting_ipno()
InDeathRegistration().selecting_deathinfotab()
InDeathRegistration().selecting_religion()
InDeathRegistration().entering_diagnosis('1')
InDeathRegistration().entering_causeofdeath('1')
InDeathRegistration().selecting_declaredby()
InDeathRegistration().selecting_savebtn()
InDeathRegistration().getmessage_after_save()
InDeathRegistration().unselecting_the_frame()
InDeathRegistrationSentToCorp().screenshotonfailure()
InDeathRegistrationSentToCorp().selecting_the_frame()
InDeathRegistrationSentToCorp().searching_patientdetails()
InDeathRegistrationSentToCorp().selecting_allcheckbox()
InDeathRegistrationSentToCorp().entering_corporationackno()
InDeathRegistrationSentToCorp().selecting_savebtn()
InDeathRegistrationSentToCorp().getmessage_after_save()
InDeathRegistrationSentToCorp().unselecting_the_frame()'''
class InAccidentRegister(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off('Ward_AccidentReg')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 30, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000712"
        time.sleep(15)
        self.wait_until_element_is_visible('xpath=//*[@id="txtSrch"]', 30, 'text search box was not enabled')
        self.wait_until_page_contains_element('xpath=//*[@id="txtSrch"]', 30, 'text search box was not enabled in page')
        self.input_text('xpath=//*[@id="txtSrch"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtSrch"]', '\\13')
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def entering_accidentplace(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="txtAccplace"]', 30, 'accident place was not visible')
        self.input_text('xpath=//*[@id="txtAccplace"]',self.d[r]['place'])
        self.dict['BROWSER'] = self._current_browser()
    #### Release server included below function###############################
    def entering_accidentnumber(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        ctrlvalue = self.cs['cs501']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible('xpath=//*[@id="txtAcdno"]', 30, 'brought by was not visible')
            self.input_text('xpath=//*[@id="txtAcdno"]',"A2B000"+str(randint(100,999)))
        else:
            print "Accident number was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def entering_broughtby(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtBrghtname"]', 30, 'brought by was not visible')
        self.input_text('xpath=//*[@id="txtBrghtname"]',self.d[r]['broughtby'])
        self.dict['BROWSER'] = self._current_browser()   
        
    def selecting_relation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboRel"]', 30, 'relation was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboRel"]', '3')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_policeinfo(self,status):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        
        self.wait_until_element_is_visible('xpath=//*[@id="cboPcInf"]', 30, 'police info was not visible')
        self.select_from_list_by_label('xpath=//*[@id="cboPcInf"]', status)
        '''try:
            r = int(r)
          #self.select_from_list_by_label('xpath=//*[@id="cboPcInf"]', self.d[r]['policeinfo'])          
          msg = self.get_text('xpath=//*[@class="toast-message"]')
          if msg == "Select Police Station Name":
             self.click_element('xpath=//button[@class="toast-close-button"]')
        except:
          time.sleep(5)
        else:
            pass'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_policestationname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboPCname"]', 30, 'police station name was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboPCname"]', '3')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_attendingdoctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctorattend"]', 30, 'attending doctor was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboDoctorattend"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opinionreserved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="chkResv"]/..//span[3]', 30, 'opinion reserved was not visible')
        self.click_element('xpath=//*[@id="chkResv"]/..//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 30, 'save btn was not visible')
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@class="toast-message"]')
        print self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InDischargeIntimationDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_DischargeDirect")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13062"
        self.wait_until_element_is_enabled('xpath=//*[@id="txtIPno"]', 30, 'text search box was not enabled')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 30, 'Patient was not enabled')
        try:
          self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        except:
         try:
           self._handle_alert(True)
         except:
             time.sleep(2)
             self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        else:
          pass    
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeType(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_page_contains_element('xpath=//*[@id="cboDischargeType"]', 30, "discharge type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDischargeType"]', self.d[r]['dischargetype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 30, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_un8til_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
#Discharge Intimation direct
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?Opt=6")
InDischargeIntimationDirect().screenshotonfailure()
InDischargeIntimationDirect().selecting_the_frame()
InDischargeIntimationDirect().entering_ipno()
InDischargeIntimationDirect().selecting_patientdetails()
InDischargeIntimationDirect().selecting_dischargeType('1')
InDischargeIntimationDirect().selecting_savebtn()
InDischargeIntimationDirect().unselecting_the_frame()
admin.FromConfigFile().Logoff()'''



class InCancelIntimation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipnoinsearchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000733"
        try:
           if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
              self.click_element('xpath=//*[@id="select2-drop"]//input')
              self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
           else:
               pass
        except:
           pass
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge_filter"]//input', 30, 'text search box was not enabled')
        self.input_text('xpath=//*[@id="tblDischarge_filter"]//input', str(self.dict['IPNO']))
        #self.press_key('xpath=//*[@id="tblDischarge_filter"]//input', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge"]//td[text()="'+str(self.dict['IPNO'])+'"]', 10, 'Patient was not enabled')
        #self.wait_until_element_is_visible('xpath=//*[@id="chkdis0"]/..//span[3]', 10, 'checkbox was not visible')
        self.wait_until_element_is_visible('xpath=//*[@name="chkdis"]', 30, 'checkbox was not visible')
        #self.click_element('xpath=//*[@id="chkdis0"]/..//span[3]')
        self.click_element('xpath=//*[@name="chkdis"]')
        time.sleep(1)
        ###################    Added below lines for release server   ###################################
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]', 30, "delay remarks was not displayed")
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "Not applicable")
            self.click_button('xpath=//button[@name="btnVOk"]')
        except:
            pass
        ################################################################################################      
        self.dict['BROWSER'] = self._current_browser()

    def selecting_cancelintimationbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        #self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge"]//td[text()="'+str(self.dict['IPNO'])+'"]', 10, 'Patient was not enabled')
        self.wait_until_element_is_enabled('xpath=//*[@id="btnDischarge"]', 30, 'cancel intimation btn was not enabled')
        self.click_element('xpath=//*[@id="btnDischarge"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser        


#Cancel Discharge Intimation
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//ward/tDisCancel.aspx")
print "menu loaded"
InCancelIntimation().screenshotonfailure()
InCancelIntimation().selecting_the_frame()
InCancelIntimation().entering_ipnoinsearchbox()
InCancelIntimation().selecting_checkbox()
InCancelIntimation().selecting_cancelintimationbtn()
InCancelIntimation().unselecting_the_frame()'''


class InDirectBedTransfer(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13205"
        time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, "ipno was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 30, 'Patient was not present')
        self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ward(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'ward input text box was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cbowardlist"]',"1")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allocatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="rdoAlloc0"]/..//span[3]', 30, 'allocate btn was not visible')
        try:
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        except ElementClickInterceptedException:
          time.sleep(3)
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]', 30, 'transfer btn was not visible')
        self.click_button('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser      

#Direct Bed Transfer
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?Opt=10&Bedtrans=0")
print "menu loaded"
InDirectBedTransfer().screenshotonfailure()
InDirectBedTransfer().selecting_the_frame()
InDirectBedTransfer().entering_ipno()
InDirectBedTransfer().selecting_patientdetails()
InDirectBedTransfer().selecting_ward()
InDirectBedTransfer().selecting_allocatebtn()
InDirectBedTransfer().selecting_transferbtn()
InDirectBedTransfer().unselecting_the_frame()'''

class InWardHomeBedTransfer(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="MM2 WARD"
        #print self.dict['WARD-NAME']
        self.wait_until_element_is_visible(self.objects['WARD_Select_Ward'], 25, 'Ward name was not visible')
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "OP00010852"
        time.sleep(7)
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 25, 'No data present')
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 25, 'Patient not present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedtransferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button[@title="BED TRANSFER"]', 25, 'bedtransfer btn was not present')
        try:
          self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button[@title="BED TRANSFER"]')
        except:
          self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardnewwindow_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_NewWindowFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardforbedtransfer(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'ward input text box was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cbowardlist"]',"1")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allocatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="rdoAlloc0"]/..//span[3]', 30, 'allocate btn was not visible')
        try:
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        except ElementClickInterceptedException:
          time.sleep(3)
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]', 30, 'transfer btn was not visible')
        self.click_button('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
#admin.FromConfigFile().loading_menu_of_link("//WARD/tBedAcknowledge.aspx")
#print "menu loaded"
InWardHomeBedTransfer().screenshotonfailure()
InWardHomeBedTransfer().selecting_the_frame()
InWardHomeBedTransfer().selecting_skip()
InWardHomeBedTransfer().selecting_wardname()
InWardHomeBedTransfer().entering_and_searching_registered_ipno()
InWardHomeBedTransfer().selecting_bedtransferbtn()
InWardHomeBedTransfer().selecting_wardnewwindow_frame()
InWardHomeBedTransfer().selecting_wardforbedtransfer()
InWardHomeBedTransfer().selecting_allocatebtn()
InWardHomeBedTransfer().selecting_transferbtn()
InWardHomeBedTransfer().unselecting_the_frame()'''

class InBedTransferAcknowledge(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="OP00010852"
        self.wait_until_element_is_visible('xpath=//*[@id="txtipno"]', 30, "ipno search was not visible")
        self.input_text('xpath=//*[@id="txtipno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtipno"]', '\\13')
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@title="Approve"]', 30, "approve btn was not visible")
        self.click_element('xpath=//*[@title="Approve"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()     
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser  
         
#BED ACKNOWLDEGE
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tBedAcknowledge.aspx")
print "menu loaded"
InBedTransferAcknowledge().screenshotonfailure()
InBedTransferAcknowledge().selecting_the_frame()
InBedTransferAcknowledge().entering_ipno()
InBedTransferAcknowledge().selecting_approvebtn()
InBedTransferAcknowledge().unselecting_the_frame()'''

#ward:
#//*[@id="selWard"]

#checkbox
#//*[@id="tblBedclean"]//td[2][contains(text(),"Ip13033")]/preceding-sibling::td//span[3]

#employee
#//*[@id="tblBedclean"]//td[2][contains(text(),"Ip13033")]/following-sibling::td//select[@id="cboEmp"]

class InBedClean(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000009924"
        #self.dict['WARD-NAME']= "DONTUSEAUTOMATIONWARD"
        #self.dict['WARD-BEDNO'] = "AUTOBED62"
        self.wait_until_element_is_visible('xpath=//*[@id="selWard"]', 30, "ward name was not visible")
        self.select_from_list_by_label('xpath=//*[@id="selWard"]', self.dict['WARD-NAME'])
        time.sleep(2)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_bednointosearchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean_filter"]//input[@type="search"]', 30, "search box was not visible")
        self.input_text('xpath=//*[@id="tblBedclean_filter"]//input[@type="search"]', str(self.dict['WARD-BEDNO']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/preceding-sibling::td//span[3]', 10, "checkbox was not visible")
        #self.click_element('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/preceding-sibling::td//span[3]')
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/preceding-sibling::td//span[3]', 30, "checkbox was not visible")
        self.click_element('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/preceding-sibling::td//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_employee(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/following-sibling::td//select[@id="cboEmp"]', 10, "employee was not visible")
        #self.select_from_list_by_index('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/following-sibling::td//select[@id="cboEmp"]', '2')
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/following-sibling::td//select[@id="cboEmp"]', 30, "employee was not visible")
        self.select_from_list_by_index('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/following-sibling::td//select[@id="cboEmp"]', '2')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_timedelayremarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]', 5, "delay remarks was not visible")
            self.click_element('xpath=//*[@id="txtDelayRmks"]')
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "Not Applicable")
            self.wait_until_element_is_enabled('xpath=//*[@name="btnVOk"]', 30, "okbtn in timedelay remarks was not visible")
            self.click_button('xpath=//*[@name="btnVOk"]')
            time.sleep(1)
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_cleanbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 30, "clean btn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 15, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()     
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

class InFumigationRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])        
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDept"]','5' )
        self.dict['FumigationDeptName'] = self.get_selected_list_label('xpath=//*[@id="cboDept"]')
        print self.dict['FumigationDeptName']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigationreqbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnFumigation"]', 30, "fumigation btn was not enabled")
        self.click_button('xpath=//*[@id="btnFumigation"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigationreason(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]', 10, error)
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_page_contains_element('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', 30, "Fumigation reason was not visible")
        self.select_from_list_by_index('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', '1')
        #time.sleep(1)
        #self.press_key('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', '\\09')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_preinfectiondetails(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]', 30, "pre-infection details was not visible")
        self.click_element('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]')
        self.input_text('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]', "None")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//button[@id="btnfumSave"]', 30, "Save btn was not visible")
        self.click_button('xpath=//*[@style="display: block;"]//button[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
#Fumigation Request        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tFumigationDeptEntry.html")
print "menu loaded"
InFumigationRequest().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationRequest().selecting_the_frame()
InFumigationRequest().selecting_department()
InFumigationRequest().selecting_fumigationreqbtn()
InFumigationRequest().selecting_fumigationreason()
InFumigationRequest().entering_preinfectiondetails()
InFumigationRequest().selecting_savebtn()
InFumigationRequest().getmessage_after_save()
InFumigationRequest().unselecting_the_frame()'''

class InFumigationScheduleSearch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_FumigSchedSearch")
    def reopendatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(15)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        picdate = picdate.date()
        today = today.date()
        print "picdate", picdate
        print "today", today
        if (picdate > today) or (picdate == today):
            print "picdate>=today"       
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                print "pdate", pdate
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[@class="next"]')
            #self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day" or @class = "day active"][text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                print "picdate! >=today"  
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                print "exception occurs"
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_fumigationschedulescreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]')
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_typeoffumigation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]', 10, error)
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_page_contains_element('xpath=//*[@id="cboFumtype"]', 30, "fumigation type was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboFumtype"]', '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reopendate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtReopenDt"]', 30, "fumigation reopen date was not visible")
        date = self.d[r]['reopendate']
        self.reopendatepicker('xpath=//*[@id="txtReopenDt"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def entering_approvedby(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtApprvby"]', 30, "approved by was not visible")
        self.input_text('xpath=//*[@id="txtApprvby"]', self.d[r]['approvedby'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="btnfumSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
#fumigation Schedule Search
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/Ward/tFumigationsearch.html")
print "menu loaded"
InFumigationScheduleSearch().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationScheduleSearch().screenshotonfailure()
InFumigationScheduleSearch().selecting_the_frame()
InFumigationScheduleSearch().selecting_department()
InFumigationScheduleSearch().entering_into_fumigationschedulescreen()
InFumigationScheduleSearch().selecting_typeoffumigation()
InFumigationScheduleSearch().selecting_reopendate('1')
InFumigationScheduleSearch().entering_approvedby('1')
InFumigationScheduleSearch().selecting_savebtn()
InFumigationScheduleSearch().getmessage_after_save()
InFumigationScheduleSearch().unselecting_the_frame()'''

class InFumigationEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_FumigEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_fumigationentryscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(6)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]', 60, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_precleaning(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboPreclean"]', 30, "pre-clean was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboPreclean"]','1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigant(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboFumigant"]', 30, "fumigant was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboFumigant"]','1')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_fumigatedby(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtFumigantby"]', 30, "fumigatedBy was not visible")
        self.input_text('xpath=//*[@id="txtFumigantby"]',self.d[r]['fumigatedby'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRmks"]', 30, "remarks was not visible")
        self.input_text('xpath=//*[@id="txtRmks"]',self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="btnfumSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def entering_into_fumigationpostinfecscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(10)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_postinfection(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtPostinfection"]', 30, "postinfection was not visible")
        self.input_text('xpath=//*[@id="txtPostinfection"]',self.d[r]['postinfection'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_postinfecsavebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group p-t-15 pull-right"]//button[@id="btnSave"]', 30, "post infec save btn was not visible")
        self.click_button('xpath=//*[@class="form-group p-t-15 pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
        
#Fumigation Entry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/WARD/tFumigationentry.html")
print "menu loaded"
InFumigationScheduleSearch().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationEntry().screenshotonfailure()
InFumigationEntry().selecting_the_frame()
InFumigationEntry().selecting_department()
InFumigationEntry().entering_into_fumigationentryscreen()
InFumigationEntry().selecting_precleaning()
InFumigationEntry().selecting_fumigant()
InFumigationEntry().entering_fumigatedby('1')
InFumigationEntry().entering_remarks('1')
InFumigationEntry().selecting_savebtn()
InFumigationEntry().getmessage_after_save()
InFumigationEntry().selecting_department()
InFumigationEntry().entering_into_fumigationpostinfecscreen()
InFumigationEntry().entering_postinfection('1')
InFumigationEntry().selecting_postinfecsavebtn()
InFumigationEntry().getmessage_after_save()
InFumigationEntry().unselecting_the_frame()'''

class InFumigationApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("Ward_FumigEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkboxall(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="checkAll"]/..//span[3]', 30, "checkbox all was not visible")
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnApprove"]', 30, "approve btn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnApprove"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#Fumigation Approval
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("Ward/tFumigationApprv.html")
print "menu loaded"
InFumigationApproval().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationApproval().screenshotonfailure()
InFumigationApproval().selecting_the_frame()
InFumigationApproval().selecting_department()
InFumigationApproval().selecting_checkboxall()
InFumigationApproval().selecting_approvebtn()
InFumigationApproval().getmessage_after_save()
InFumigationApproval().unselecting_the_frame()'''

class InIncidentEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_IncidentEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def incidentdatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="next"]')
            #self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active" or @class="day" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active" or @class="day" and text()="'+day+'"]')            
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def notifieddatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            #self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="prev"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def reportingdatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
        
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000740"
        self.wait_until_element_is_visible('xpath=//*[@id="txtEMPIP"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtEMPIP"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtEMPIP"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_incidenttype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="cboInctype"]', 30, "incident type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboInctype"]', self.d[r]['incidenttype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_incidentdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        date = self.d[r]['incidentdate']
        self.incidentdatepicker('xpath=//*[@id="txtIncdate"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_location(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboLocation"]', 30, "Location was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboLocation"]','2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nature(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboNature"]', 30, "Nature was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboNature"]','2')
        self.dict['BROWSER'] = self._current_browser()  
    def entering_descripofincident(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncdesc"]', 30, "incident description was not visible")
        self.input_text('xpath=//*[@id="txtIncdesc"]',self.d[r]['incidentdescription'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_harmresulted(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncresult"]', 30, "harm was not visible")
        self.input_text('xpath=//*[@id="txtIncresult"]',self.d[r]['harm'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_witness(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncwitness"]', 30, "witness was not visible")
        self.input_text('xpath=//*[@id="txtIncwitness"]',self.d[r]['witness'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_otherstext(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtNTOthers"]', 30, "witness was not visible")
        self.input_text('xpath=//*[@id="txtNTOthers"]',self.d[r]['otherstext'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_employee(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboEmployee"]', 30, "employee was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboEmployee"]','2')
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_notifieddate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        date = self.d[r]['notifieddate']
        self.notifieddatepicker('xpath=//*[@id="txtIncNotifydt"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reportingdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        date = self.d[r]['reportingdate']
        self.reportingdatepicker('xpath=//*[@id="txtEmprptdt"]', date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
        
        
#Incident Entry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Nursing/tIncidentrpt.aspx")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InIncidentEntry().screenshotonfailure()
InIncidentEntry().selecting_the_frame()
InIncidentEntry().entering_ipno()
InIncidentEntry().selecting_incidentdate('1')
InIncidentEntry().selecting_location()
InIncidentEntry().selecting_nature()
InIncidentEntry().entering_descripofincident('1')
InIncidentEntry().entering_harmresulted('1')
InIncidentEntry().entering_witness('1')
InIncidentEntry().entering_otherstext('1')
InIncidentEntry().selecting_employee()
InIncidentEntry().selecting_notifieddate('1')
InIncidentEntry().selecting_reportingdate('1')
InIncidentEntry().selecting_savebtn()
InIncidentEntry().getmessage_after_save()
InIncidentEntry().unselecting_the_frame()'''

class InHandOverEntryNursing(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("Ward_IncidentEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
            
        
        
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "503"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(1)
        try:
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "Approval Pending":
               time.sleep(2)
            else:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingshift(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboShift"]', 30, "Nursing shift was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboShift"]','2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_handoverto(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select_handoverTo"]/a', 30, "handover to was not visible")
        self.click_element('xpath=//*[@id="s2id_select_handoverTo"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "handoverto text was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//ul/li[2]', 30, "handoverto list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//ul/li[2]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="chkListID0"]/..//span[3]', 30, "checkbox was not visible")
        self.click_element('xpath=//*[@id="chkListID0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 10, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#HandOverEntry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/Ward/Patsearch.html?opt=9")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InHandOverEntryNursing().screenshotonfailure()
InHandOverEntryNursing().selecting_the_frame()
InHandOverEntryNursing().entering_ipno()
InHandOverEntryNursing().selecting_patientdetails()
InHandOverEntryNursing().selecting_nursingshift()
InHandOverEntryNursing().selecting_handoverto()
InHandOverEntryNursing().selecting_checkbox()
InHandOverEntryNursing().selecting_handoverto()
InHandOverEntryNursing().selecting_savebtn()
InHandOverEntryNursing().getmessage_after_save()
InHandOverEntryNursing().unselecting_the_frame()'''      

class InEquipmentBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_EquipBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def startdatepicker(self, loc):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(loc, 30, "start date field was not visible")
        self.click_element(loc)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[3]/table/tbody/tr/td[@class="day today active"]', 30, "current start date was not visible")
        self.click_element('xpath=/html/body/div[1]/div[3]/table/tbody/tr/td[@class="day today active"]')
        time.sleep(3)
        #self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]', 30, "hour 0:00 was not visible")
        #selectedhrs = self._get_text('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
        #self.click_element('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]', 30, "hour 0:00 was not visible")
        selectedhrs = self._get_text('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]')
        self.click_element('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]')
        print "selectedhrs", selectedhrs
        time.sleep(3)
        #self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]', 30, "mins 0:00 was not visible")
        #selectedmins = self.get_text('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
        #self.click_element('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]', 30, "mins 0:00 was not visible")
        selectedmins = self.get_text('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]')
        self.click_element('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]')
        print "selectedmins", selectedmins
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
    def enddatepicker(self, loc):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(loc, 30, "end date field was not visible")
        self.click_element(loc)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active"]', 30, "current end date was not visible")
        self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active"]')
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]', 30, "hour 1:00 was not visible")
        #selectedhrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]')
        #self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hour was not visible")
        selectedhrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print "selectedhrs", selectedhrs
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]', 30, "active mins was not visible")
        #selectedmins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]')
        #self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins was not visible")
        selectedmins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print "selectedmins", selectedmins
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
   
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['EQUIPMENTBILLINGIPNO'] = "IP00000739"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]',self.dict['EQUIPMENTBILLINGIPNO'])
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(7)
        self.wait_until_element_is_visible('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 10, "Patient details not in grid")
        self.click_element('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(1)
        '''try:
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "Approval Pending":
               time.sleep(2)
            else:
                pass
        except:
            pass'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_services(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboServices"]', 30, "services was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboServices"]','2')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_equipment(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboEquipment"]', 30, "equipment was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboEquipment"]','2')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_addbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@id="btnAdd"]', 30, "add btn was not visible")
        self.click_button('xpath=//*[@id="btnAdd"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_startdate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #r = int(r)
        time.sleep(1)
        #date = self.d[r]['startdate']
        print "date", date
        self.startdatepicker('xpath=//*[@id="txtSDt0"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_startdatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btnSdate"]', 30, "start date btn was not visible")
        self.click_button('xpath=//*[@id="btnSdate"]')
        time.sleep(2)
        self._handle_alert(True)
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_enddate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #r = int(r)
        time.sleep(1)
        #date = self.d[r]['enddate']
        self.enddatepicker('xpath=//*[@id="txtEDt0"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_enddatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btnEdate"]', 30, "enddate btn was not visible")
        self.click_button('xpath=//*[@id="btnEdate"]')
        time.sleep(2)
        self._handle_alert(True)
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def getting_totalhrs_after_save(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_page_contains_element('xpath=//*[@id="lblTohrs0"]', 30, 'total hrs was not visible in page')
         self.wait_until_element_is_visible('xpath=//*[@id="lblTohrs0"]', 30, 'total hrs was not visible')
         self.msg = self.get_text('xpath=//*[@id="lblTohrs0"]')
         print "Total hrs:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
            
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@class="toast-message"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#EquipmentBilling
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?opt=12")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InEquipmentBilling().screenshotonfailure()
InEquipmentBilling().selecting_the_frame()
InEquipmentBilling().entering_ipno()
InEquipmentBilling().selecting_patientdetails()
InEquipmentBilling().selecting_services()
InEquipmentBilling().selecting_equipment()
InEquipmentBilling().selecting_addbtn()
InEquipmentBilling().selecting_startdate('1')
InEquipmentBilling().selecting_startdatebtn()
InEquipmentBilling().selecting_enddate('1')
InEquipmentBilling().selecting_enddatebtn()
InEquipmentBilling().getmessage_after_save()
InEquipmentBilling().unselecting_the_frame()'''

        
class InTemplateEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_TemplateEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btnNew"]', 30, "new btn was not visible")
        self.click_button('xpath=//*[@id="btnNew"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000739"
        self.wait_until_element_is_visible('xpath=//*[@id="txtSrch"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtSrch"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtSrch"]', '\\13')
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="toast-message"]', 7, "message was not visible")
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "No Existing Template Found":
               time.sleep(2)
            else:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_template(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@class="trTemphdr"]/td[text()="'+self.d[r]['templatename']+'"]', 30, "template name was not visible")
        self.click_element('xpath=//*[@class="trTemphdr"]/td[text()="'+self.d[r]['templatename']+'"]')
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@class="actions disAction"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_element('xpath=//*[@class="actions disAction"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 

#Template Entry        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?opt=11")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(1)
InTemplateEntry().screenshotonfailure()
InTemplateEntry().selecting_the_frame()
InTemplateEntry().selecting_newbtn()
InTemplateEntry().entering_ipno()
InTemplateEntry().selecting_template('1')
InTemplateEntry().selecting_savebtn()
InTemplateEntry().getmessage_after_save()
InTemplateEntry().unselecting_the_frame()'''

class InDoctorVisitEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13243"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPNo"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPNo"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtIPNo"]', '\\13')
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="toast-message"]', 7, "message was not visible")
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "No Existing Record(s) Found":
               time.sleep(5)
            else:
                pass
        except:
            pass
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_visitingdoctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 30, "visiting doctor was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDoctor"]','2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_addbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btnAdd"]', 30, "add btn was not visible")
        self.click_button('xpath=//*[@id="btnAdd"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btnVSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnVSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 7, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
#Doctor Visit Entry      
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Nursing/tDocvisitentry.aspx")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(1)
InDoctorVisitEntry().screenshotonfailure()
InDoctorVisitEntry().selecting_the_frame()
InDoctorVisitEntry().entering_ipno()
InDoctorVisitEntry().selecting_visitingdoctor()
InDoctorVisitEntry().selecting_addbtn()
InDoctorVisitEntry().selecting_savebtn()
InDoctorVisitEntry().getmessage_after_save()
InDoctorVisitEntry().unselecting_the_frame()'''
        
class InDischargeSummaryEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000740"
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_DischargeSummaryEntry_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_DischargeSummaryEntry_IPNo'], '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_into_dischargesummscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td[1]', 30, "discharge summary screen was not visible")
        self.click_element('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(7)
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen12_search"]', 30, "template was not visible")
            self.click_element('xpath=//*[@id="s2id_autogen12_search"]')
            self.input_text('xpath=//*[@id="s2id_autogen12_search"]', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[1]//span', 30, "template list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[1]//span')
            time.sleep(1)
            self.wait_until_element_is_enabled(self.objects['WARD_DischargeSummaryEntry_TemplateApplybtn'], 30, "template list was not visible")
            self.click_element(self.objects['WARD_DischargeSummaryEntry_TemplateApplybtn'])
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled(self.objects['WARD_DischargeSummaryEntry_Savebtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_DischargeSummaryEntry_Savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_Message'], 15, 'save message was not visible')
         self.msg = self.get_text(self.objects['WARD_DischargeSummaryEntry_Message'])
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        pyautogui.click(585,155)
        time.sleep(1)
        pyautogui.click(585,155)
        time.sleep(1)
        pyautogui.click(585,155)  
    def selecting_signbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_Signbtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_DischargeSummaryEntry_Signbtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser     
    
class InDischargeSummaryView(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000742"
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryView_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_DischargeSummaryView_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_DischargeSummaryView_IPNo'], '\\13')
    def selecting_signbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(7)
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td//button[@title="Summary Signed. Click to View Summary Preview"]', 30, "Sign btn was not visible")
        self.click_button('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td//button[@title="Summary Signed. Click to View Summary Preview"]')
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        pyautogui.click(785,15)
        time.sleep(1)
        pyautogui.click(785,15)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
          
class InDeactivateDischargeSummary(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13281"
        self.wait_until_element_is_visible('xpath=//*[@id="hParamVal"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="hParamVal"]',self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible('xpath=//*[@id="btngo"]', 30, "go btn was not visible")
        self.click_button('xpath=//*[@id="btngo"]')
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser  

class InNursingAssessmentVitalsEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_NursingAssessment')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def scroll_web_element_into_view(self, locator):
        self.set_selenium_implicit_wait(15)
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "IP00000740"
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'],'\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_demographicbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_DemographicBtn'], 30, "Demograhic btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_DemographicBtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_demographic_closebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = "Ip13281"
        time.sleep(5)
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_Demographic_Closebtn'], 30, "Demograhic close btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_Demographic_Closebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_er_assessmentvitalbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVitalBtn'], 30, "ERAssessmentVital btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVitalBtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_assessmentframe(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentFrame'])
        time.sleep(1)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_triagecode(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_triagecode'], 30, "triage code was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_triagecode'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transportmode(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_transportmode'], 30, "transport mode was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_transportmode'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_idmarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_idmarks'], 30, "id marks was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_idmarks'], self.d[r]['idmarks'])
        self.dict['BROWSER'] = self._current_browser()   
    def entering_ervisit(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ERVisit'], 30, "id marks was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ERVisit'], self.d[r]['ervisit'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_complaints(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Complaints'], 30, "complaints was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Complaints'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_presentho(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Presentho'], 30, "presentho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Presentho'], '2')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_pastho(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Pastho'], 30, "pastho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Pastho'], '2')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_socialho(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Socialho'], 30, "social ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Socialho'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_familyho(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Familyho'], 30, "family ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Familyho'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allergies(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_allergies'], 30, "allergies ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_allergies'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_treatmenthistory(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'])      
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'], 30, "treatment history was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'], self.d[r]['treatmenthistory'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_traumadetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)     
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'])   
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'], 30, "TraumaDetails was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_general(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_General'], 30, "general was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_General'], self.d[r]['general'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_cardio(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)   
        r = int(r)     
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cardio'], 30, "cardio was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cardio'], self.d[r]['cardio'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_resp(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Resp'], 30, "resp was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Resp'], self.d[r]['resp'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_abdvalue(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Abdvalue'], 30, "abd value was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Abdvalue'], str(self.d[r]['abdvalue']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_cnsvalue(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5) 
        r = int(r)       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cnsvalue'], 30, "cns value was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cnsvalue'], str(self.d[r]['cnsvalue']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_painscore(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-painsore'+self.d[r]['painscore']+'"]', 30, "pain score was not visible")
        self.click_element('xpath=//*[@id="uniform-painsore'+self.d[r]['painscore']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_provisionaldiagnosis(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)  
        r = int(r)      
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ProvisionalDiagnosis'], 30, "provisional diagnosis was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ProvisionalDiagnosis'], self.d[r]['provisionaldiagnosis'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_treatmentplan(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'], 30, "treatment plan was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'], self.d[r]['treatmentplan'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_investigationplan(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'], 30, "investigation plan was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'], self.d[r]['investigationplan'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_assessingstaff(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'], 30, "assessment staff was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_referral(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'], 30, "referral was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_assessingdoctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'], 30, "referral was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_status(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'], 30, "status was not visible")
        self.select_from_list_by_label(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'], self.d[r]['status'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.scroll_web_element_into_view('xpath=//span[text()="ER Assessment "]')       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Savebtn'], 30, "save btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        pyautogui.click(1035,15)
        time.sleep(1)
        pyautogui.click(1035,15)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        #self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'], 30, "nursing tab was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingframe(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingFrame'])
        time.sleep(1)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()        
    def entering_medicationdrugs(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-medicdrug'+self.d[r]['medicationdrugs']+'"]', 30, "medication drugs was not visible")
        self.click_element('xpath=//*[@id="uniform-medicdrug'+self.d[r]['medicationdrugs']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodtransfusion(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-bloodtrans'+self.d[r]['bloodtransfusion']+'"]', 30, "bloodtransfusion was not visible")
        self.click_element('xpath=//*[@id=//*[@id="uniform-bloodtrans'+self.d[r]['bloodtransfusion']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_food(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-food'+self.d[r]['food']+'"]', 30, "food was not visible")
        self.click_element('xpath=//*[@id="uniform-food'+self.d[r]['food']+'"]')
        self.dict['BROWSER'] = self._current_browser()    
    def entering_bleeding(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-bleeding'+self.d[r]['bleeding']+'"]', 30, "bleeding was not visible")
        self.click_element('xpath=//*[@id="uniform-bleeding'+self.d[r]['bleeding']+'"]')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_openwound(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-openwound'+self.d[r]['openwound']+'"]', 30, "openwound was not visible")
        self.click_element('xpath=//*[@id="uniform-openwound'+self.d[r]['openwound']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_tobaco(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-tobaco'+self.d[r]['tobaco']+'"]', 30, "tobaco was not visible")
        self.click_element('xpath=//*[@id="uniform-tobaco'+self.d[r]['tobaco']+'"]')
        self.dict['BROWSER'] = self._current_browser() 
    def entering_smoking(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-smokinh'+self.d[r]['smoking']+'"]', 30, "smoking was not visible")
        self.click_element('xpath=//*[@id="uniform-smokinh'+self.d[r]['smoking']+'"]')
        self.dict['BROWSER'] = self._current_browser() 
    def entering_alhocoluse(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-alhocoluse'+self.d[r]['alhocoluse']+'"]', 30, "alhocoluse was not visible")
        self.click_element('xpath=//*[@id="uniform-alhocoluse'+self.d[r]['alhocoluse']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_otherdetails(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Otherdetails'], 30, "other details was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Otherdetails'],self.d[r]['otherdetails'])
        self.dict['BROWSER'] = self._current_browser()                                
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
class InExtraBedDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)        
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['REGNO'] = "2822"
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_RegNo'], 30, "REGNO was not visible")
        self.input_text(self.objects['WARD_ExtraBED_RegNo'],str(self.dict['REGNO']))
        self.press_key(self.objects['WARD_ExtraBED_RegNo'], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_extrabedallocationpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDTran"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient details not available in grid")
        self.click_element('xpath=//*[@id="patTableDTran"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()           
    def selecting_radiobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Radiobtn'], 30, "radio btn was not visible")
        self.click_element(self.objects['WARD_ExtraBED_Radiobtn'])
        time.sleep(0.5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Savebtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_ExtraBED_Savebtn'])
        self._handle_alert(True)        
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(15)
        self.wait_until_page_contains_element(self.objects['WARD_ExtraBED_Message'], 30, 'Record was not saved in page')
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Message'], 30, 'Record was not saved')
        Msg = self._get_text(self.objects['WARD_ExtraBED_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page('5')
admin.FromConfigFile().logging('ward')    
admin.FromConfigFile().loading_menu_of_link_test('//WARD/tFumigationDeptEntry.html','ward')
InFumigationRequest().screenshotonfailure()
InFumigationRequest().selecting_the_frame()
InFumigationRequest().unselecting_the_frame()
admin.FromConfigFile().loading_menu_of_link_test('/Ward/tFumigationsearch.html','ward')
InFumigationScheduleSearch().screenshotonfailure()
InFumigationScheduleSearch().selecting_the_frame() '''  