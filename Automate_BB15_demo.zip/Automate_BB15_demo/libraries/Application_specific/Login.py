from Selenium2Library import Selenium2Library
import time
from webbrowser import Chrome


class loginscreen(Selenium2Library):
    def login(self):
        self.open_browser('http://192.168.0.232/BB15se/Backbone/admin/login.aspx', 'chrome', None, False, None, None)
        time.sleep(2)
        self.maximize_browser_window()
        time.sleep(2)
        self.click_button('xpath=//a[@href="#divNewSession"]/button')
        time.sleep(2)
        self.input_text('xpath=//*[@id="newuname"]', "recpv15")
        time.sleep(2)
        self.input_password('xpath=//*[@id="txtrepassword"]', "aosta")
        time.sleep(2)
        self.click_button('xpath=//*[@id="btnrelogin"]')
        time.sleep(5)
        
loginscreen().login()