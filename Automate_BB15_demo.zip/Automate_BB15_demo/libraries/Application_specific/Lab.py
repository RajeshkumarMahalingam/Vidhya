import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InSpecimenCollectionLab(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SCL_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SCL_RegNo']):
             self.input_text(self.objects['LAB_SCL_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_SCL_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_SCL_Search'])     
             time.sleep(3)
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_speccolleclab_approvescreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        #self.click_element('xpath=//*[@class="actions"]//button[1]')
        #time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['LAB_Specimen_Collection_Lab_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Specimen_Collection_Lab_Page'])
        if self._is_visible(self.objects['LAB_SCL_RegNo']):
            self.input_text(self.objects['LAB_SCL_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SCL_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SCL_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 5, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="testdtl"]//tr[1]', 30, "procedure details was not visible")
        self.wait_until_page_contains_element(self.objects['LAB_SCL_Selectall_CheckBox'], 30, 'Checkbox was not visible in page')
        self.wait_until_element_is_visible(self.objects['LAB_SCL_Selectall_CheckBox'], 30, 'Checkbox was not visible')
        self.click_element(self.objects['LAB_SCL_Selectall_CheckBox'])
        
        '''self.wait_until_page_contains_element(self.objects['LAB_SCL_Selectall_CheckBox'], 10, 'Checkbox was not visible')
        self.click_element(self.objects['LAB_SCL_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SCL_Selectall_CheckBox'])'''
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SCL_Approve'], 30, 'Approval btn was not enabled')
        self.click_button(self.objects['LAB_SCL_Approve'])
        self._handle_alert(True)
        
        #time.sleep(3)
        #self._close_alert()
        #time.sleep(1)
        #self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_specimencollected(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SCL_Message'], 100, 'Approval not successful')
        LabSpecCollecMsg = self._get_text(self.objects['LAB_SCL_Message'])
        print LabSpecCollecMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
    
class InSpecimenCollectionWard(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SCW_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SCW_RegNo']):
             time.sleep(1)
             self.wait_until_element_is_visible('xpath=//*[@id="sample_1_filter"]//input', 30, 'search btn was not enabled')
             self.input_text('xpath=//*[@id="sample_1_filter"]//input', str(self.dict['REGNO']))
             time.sleep(3)
             self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'patient details was not visible')
             self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
             time.sleep(7)
             #self.input_text(self.objects['LAB_SCW_RegNo'], str(self.dict['REGNO']))
             #time.sleep(1)
             #self.wait_until_element_is_enabled(self.objects['LAB_SCW_Search'], 20, 'search btn was not enabled')
             #self.click_button(self.objects['LAB_SCW_Search'])
             #time.sleep(10)
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_speccolleclab_approvescreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        #self.click_element('xpath=//*[@class="actions"]//button[1]')
        #time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['LAB_Specimen_Collection_Lab_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Specimen_Collection_Lab_Page'])
        if self._is_visible(self.objects['LAB_SCW_RegNo']):
            self.input_text(self.objects['LAB_SCW_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SCW_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SCW_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 5, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element(self.objects['LAB_SCW_Selectall_CheckBox'], 30, 'Checkbox was not visible')
        self.click_element(self.objects['LAB_SCW_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SCW_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SCW_Approve'], 30, 'Approval btn was not enabled')
        self.click_button(self.objects['LAB_SCW_Approve'])
        self._handle_alert(True)
        
        #time.sleep(3)
        #self._close_alert()
        #time.sleep(1)
        #self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_specimencollected(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_SCW_Message'], 100, 'Approval not successful')
            LabSpecCollecMsg = self._get_text(self.objects['LAB_SCW_Message'])
            print LabSpecCollecMsg
            time.sleep(1)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()    
    
class InSendSpecimenToDepartment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SSTD_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SSTD_RegNo']):
             self.input_text(self.objects['LAB_SSTD_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_SSTD_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_SSTD_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
            
    def entering_into_sendspectodept_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible(self.objects['LAB_SSTD_RegNo']):
            self.input_text(self.objects['LAB_SSTD_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTD_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SSTD_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element(self.objects['LAB_SSTD_Selectall_CheckBox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSTD_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SSTD_Selectall_CheckBox'])
        time.sleep(30)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_senttodepartment_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTD_Send_To_Dept'], 30, 'SendToDept was not enabled')
        self.click_button(self.objects['LAB_SSTD_Send_To_Dept'])
        self._handle_alert(True)
        #time.sleep(3)
        #self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_specimensent(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSTD_Message'], 100, 'Approval not successful')
        self.wait_until_element_is_visible(self.objects['LAB_SSTD_Message'], 100, 'Approval not successful')
        LabSendSpecToDeptMsg = self._get_text(self.objects['LAB_SSTD_Message'])
        print LabSendSpecToDeptMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InSpecimenReceiveDepartmentWise(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SRDW_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SRDW_RegNo']):
             self.input_text(self.objects['LAB_SRDW_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_SRDW_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_SRDW_Search'])  
             time.sleep(5)   
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()

    def entering_into_deptwisereceive_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible(self.objects['LAB_SRDW_RegNo']):
            self.input_text(self.objects['LAB_SRDW_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SRDW_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SRDW_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_SRDW_Selectall_CheckBox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SRDW_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SRDW_Selectall_CheckBox'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_departmentreceive_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SRDW_Dept_Receive'], 30, 'DeptReceive btn was not enabled')
        self.click_button(self.objects['LAB_SRDW_Dept_Receive'])
        self._handle_alert(True)
        #time.sleep(3)
        #self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_deptreceive(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        try:
            self.wait_until_element_is_visible(self.objects['LAB_SRDW_Message'], 30, 'Approval not successful')
            #self.wait_until_page_contains_element(self.objects['LAB_SRDW_Message'], 30, 'Approval not successful')
            LabDeptRecvMsg = self._get_text(self.objects['LAB_SRDW_Message'])
            print LabDeptRecvMsg
            time.sleep(1)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
      
class InStandardResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SSTRE_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SSTRE_RegNo']):
             self.input_text(self.objects['LAB_SSTRE_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_SSTRE_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()

    def entering_into_resultentry_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_SSTRE_RegNo']):
            self.input_text(self.objects['LAB_SSTRE_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SSTRE_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSTRE_Selectall_CheckBox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSTRE_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="chkAllTest"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SSTRE_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultentry_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 30, 'resultentry btn was not enabled')
        self.click_button(self.objects['LAB_SSTRE_Result_Entry'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_result(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_Result_Entry'], 30, 'No Tests available')
        self.wait_until_element_is_visible(self.objects['LAB_SSTRE_RE_Result'], 30, 'result input was not enabled')
        self.input_text(self.objects['LAB_SSTRE_RE_Result'], str(self.d[r]['standard_result']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_comments(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_RE_Comments'], 30, 'comments was not visible')
        self.input_text(self.objects['LAB_SSTRE_RE_Comments'], str(self.d[r]['standard_comments']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_internalremarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_SSTRE_RE_Internal_Remarks'], 30, 'internal remarks was not visible')
        self.input_text(self.objects['LAB_SSTRE_RE_Internal_Remarks'], str(self.d[r]['standard_internalremarks']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_SSTRE_RE_Remarks'], 20, 'remarks was not visible')
        self.input_text(self.objects['LAB_SSTRE_RE_Remarks'], str(self.d[r]['standard_remarks']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRE_RE_Save'], 20, "save btn was not enabled")
        self.click_element(self.objects['LAB_SSTRE_RE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_resultsentered(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSTRE_Message'], 30, 'Approval not successful')
        LabSSTREMsg = self._get_text(self.objects['LAB_SSTRE_Message'])
        print LabSSTREMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
     
class InStandardResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_SSTRA_Selectall_CheckBox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_SSTRA_RegNo']):
             self.input_text(self.objects['LAB_SSTRA_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_SSTRA_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_SSTRA_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    
    
    def entering_into_resultapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(3)
        if self._is_visible(self.objects['LAB_SSTRA_RegNo']):
            self.input_text(self.objects['LAB_SSTRA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTRA_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SSTRA_Search'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno lbl was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRA_Selectall_CheckBox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSTRA_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="chkAllTest"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SSTRA_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultapprove_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRA_Result_Approve'], 30, 'result approve btn was not visible')
        self.click_button(self.objects['LAB_SSTRA_Result_Approve'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRA_Approve'], 30, 'approve btn was not enabled')
        self.click_button(self.objects['LAB_SSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()         
    def getmessage_after_resultapprove(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_SSTRA_Message'], 30, 'Approval not successful in page')
            self.wait_until_element_is_visible(self.objects['LAB_SSTRA_Message'], 30, 'Approval not successful')
            LabSSTRAMsg = self._get_text(self.objects['LAB_SSTRA_Message'])
            print LabSSTRAMsg
        except:
            pass
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InDigitalSignApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
             self._handle_alert(True)
        except:
             pass
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_digitalsignapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        try:
             self._handle_alert(True)
        except:
             pass
        if self._is_visible(self.objects['LAB_SSTDA_RegNo']):
            self.input_text(self.objects['LAB_SSTDA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Search'], 30, "search btn was not enabled")
            self.click_button(self.objects['LAB_SSTDA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Result_Approve'], 30, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno lbl was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTDA_Selectall_CheckBox'], 30, "checkbox was not visible")
        self.click_element(self.objects['LAB_SSTDA_Selectall_CheckBox'])
        element = self._get_checkbox('xpath=//*[@id="chkAllTest"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_SSTDA_Selectall_CheckBox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultapprove_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Result_Approve'], 30, "result approve btn was not enabled")
        self.click_button(self.objects['LAB_SSTDA_Result_Approve'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTDA_Approve'], 30, 'approve btn was not visible')
        self.click_button(self.objects['LAB_SSTDA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_digitalsignapprove(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSTDA_Message'], 30, 'Approval not successful')
        LabSSTDAMsg = self._get_text(self.objects['LAB_SSTDA_Message'])
        print LabSSTDAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InCultureResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_cultureresultentry_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Culture_Service_Result_Entry_Update_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Culture_Service_Result_Entry_Update_Page'])
        #time.sleep(1)
        #r = int(r)
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_CSTRE_RegNo']):
            self.input_text(self.objects['LAB_CSTRE_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_visible(self.objects['LAB_CSTRE_Search'], 30, "Search btn was not visible")
            self.click_button(self.objects['LAB_CSTRE_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['Lab_culture_service']+'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 30, "test name was not visible")
        self.click_element('xpath=//*[(text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reportstatus(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CSTRE_Report_Status'], 30, 'report status was not visible')
        self.select_from_list_by_index(self.objects['LAB_CSTRE_Report_Status'], '1')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cultureresult(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_CSTRE_Culture_Result'], 30, 'culture result was not visible')
        self.select_from_list_by_index(self.objects['LAB_CSTRE_Culture_Result'], '1')
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CSTRE_Save'], 30, "save btn was not enabled")
        self.click_element(self.objects['LAB_CSTRE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_cultureresultentered(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_CSTRE_Message'], 30, 'Approval not successful')
        LabCSTREMsg = self._get_text(self.objects['LAB_CSTRE_Message'])
        print LabCSTREMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InCultureResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_cultureresultapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Culture_Service_Result_Approve_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Culture_Service_Result_Approve_Page'])
        #time.sleep(1)
        #r = int(r)
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_CSTRA_RegNo']):
            self.input_text(self.objects['LAB_CSTRA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_CSTRA_Search'], 30, "search btn was not enabled")
            self.click_button(self.objects['LAB_CSTRA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_CULTURE_SERVICE']+'")]', 20, 'No Tests available')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_CULTURE_SERVICE']+'")]', 30, "lab culture service was not visible")
        self.click_element('xpath=//*[(text()="'+self.dict['LAB_CULTURE_SERVICE']+'")]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CSTRA_Approve'], 30, 'approve btn was not visible')
        self.click_button(self.objects['LAB_CSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_cultureresultapproved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_CSTRA_Message'], 30, 'Approval message was not captured')
        self.wait_until_element_is_visible(self.objects['LAB_CSTRA_Message'], 30, 'Approval message was not captured')
        LabCSTRAMsg = self._get_text(self.objects['LAB_CSTRA_Message'])
        print LabCSTRAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
        
class InCultureTechnicianApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetechnicianapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643553"
        #self.d = Capturing().data_off("OPBilling")
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Culture_Service_Result_Approve_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Culture_Service_Result_Approve_Page'])
        #time.sleep(1)
        #r = int(r)
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_CSTTA_RegNo']):
            self.input_text(self.objects['LAB_CSTTA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_CSTTA_Searchbtn'], 30, "search btn was not enabled")
            self.click_button(self.objects['LAB_CSTTA_Searchbtn'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_CULTURE_SERVICE']+'")]', 20, 'No Tests available')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r=int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="tbltestdtl"]//td[text()="'+self.dict['LAB_CULTURE_SERVICE']+'"]', 30, "lab culture service was not visible")
        self.click_element('xpath=//*[@id="tbltestdtl"]//td[text()="'+self.dict['LAB_CULTURE_SERVICE']+'"]')
        #time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_technicianapprove_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CSTTA_TechApprovebtn'], 30, 'technician approve btn was not visible')
        self.click_button(self.objects['LAB_CSTTA_TechApprovebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_culturetechnicianapproved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_CSTTA_Message'], 30, 'Approval not successful in page')
            self.wait_until_element_is_visible(self.objects['LAB_CSTTA_Message'], 30, 'Approval not successful')
            Msg = self._get_text(self.objects['LAB_CSTTA_Message'])
            print Msg
        except:
            pass
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InPathologyResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.select_frame(self.objects['LAB_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]'):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_PSTRE_RegNo']):
             self.input_text(self.objects['LAB_PSTRE_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_PSTRE_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_PSTRE_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_into_Pathologyresultentry_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Pathology_Service_Result_Entry_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Pathology_Service_Result_Entry_Page'])
        #time.sleep(1)
        #r = int(r)
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_PSTRE_RegNo']):
            self.input_text(self.objects['LAB_PSTRE_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_PSTRE_Search'], 30, "search btn was not enabled")
            self.click_button(self.objects['LAB_PSTRE_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologytestdetails_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]', 30, 'No Tests available')
        self.click_element('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]')
        #time.sleep(5)
        #self._close_alert()
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reporttype(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("Lab")
        r = int(r)
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_PSTRE_Report_Type'], 30, 'report type was not visible')
        self.select_from_list_by_label(self.objects['LAB_PSTRE_Report_Type'], self.d[r]['pathology_report_type'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_enabled(self.objects['LAB_PSTRE_Save'], 30, 'save btn was not enabled')
        self.click_element(self.objects['LAB_PSTRE_Save'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InPathologyResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologyresultapprove_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Pathology_Service_Result_Approve_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Pathology_Service_Result_Approve_Page'])
        #time.sleep(1)
        #r = int(r)
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_PSTRA_RegNo']):
            self.input_text(self.objects['LAB_PSTRA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_PSTRA_Search'], 30, "search btn was not enabled")
            self.click_button(self.objects['LAB_PSTRA_Search'])
            #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 20, 'No data available')
            #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        else:
            pass
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]', 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 30, "regno lbl was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        print "Patient", Patient
        print "Reg no.:", self.dict['REGNO']
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologytestdetails_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]', 30, "test name was not available")
        self.click_element('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]')
        time.sleep(10)
        #self._close_alert()
        #self.wait_until_element_is_visible(self.objects['LAB_PSTRA_Approve'], 20, 'No Tests available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_report_status(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("Lab")
        r = int(r)
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['LAB_PSTRA_Report_Status'], 30, 'report status was not visible')
        self.select_from_list_by_label(self.objects['LAB_PSTRA_Report_Status'], self.d[r]['pathology_select_report_status'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['LAB_PSTRA_Approve'], 30, 'approve btn was not enabled')
        self.click_element(self.objects['LAB_PSTRA_Approve'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_pathologyapproved(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRA_Message'], 30, 'Approval not successful')
        self.wait_until_page_contains_element(self.objects['LAB_PSTRA_Message'], 30, 'Approval not successful')
        LabPSTRAMsg = self._get_text(self.objects['LAB_PSTRA_Message'])
        print LabPSTRAMsg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InLabDispatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible(self.objects['LAB_Dispatch_Selectall']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_Dispatch_RegNo']):
             self.input_text(self.objects['LAB_Dispatch_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_Dispatch_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_Dispatch_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_labdispatch_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_Dispatch_Page'], 10, 'Page not loaded')
        #self.click_element(self.objects['LAB_Dispatch_Page'])
        #time.sleep(1)
        if self._is_visible(self.objects['LAB_Dispatch_RegNo']):
            self.input_text(self.objects['LAB_Dispatch_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_Dispatch_Search'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_Dispatch_Search'])
            time.sleep(1)
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno lbl was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_Selectall_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['LAB_Dispatch_Selectall'], 30, "checkbox was not visible")
        self.click_element(self.objects['LAB_Dispatch_Selectall'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultdispatch_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['LAB_Dispatch_ResultDispatch'], 30, "result dispatch was not enabled")
        self.click_button(self.objects['LAB_Dispatch_ResultDispatch'])
        #time.sleep(2)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_resultdispatch(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_Dispatch_Message'], 40, 'Approval not successful')
            LabresdispatchMsg = self._get_text(self.objects['LAB_Dispatch_Message'])
            print LabresdispatchMsg
        except:
            pass
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InPeripheralSendtoLab(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()            
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSEL_RegNo'], 30, 'regno was not visible')
        self.input_text(self.objects['LAB_SSEL_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSEL_Searchbtn'], 30, 'search btn was not visible')
        self.click_button(self.objects['LAB_SSEL_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSEL_Checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSEL_Checkbox'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_sendtestbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSEL_SendTest'], 30, 'send test btn was not visible')
        self.click_button(self.objects['LAB_SSEL_SendTest'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_labname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSEL_LabName'], 30, 'send test btn was not enabled')
        self.wait_until_element_is_visible(self.objects['LAB_SSEL_LabName'], 30, 'send test btn was not enabled')
        self.select_from_list_by_index(self.objects['LAB_SSEL_LabName'],'2')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSEL_Savebtn'], 30, 'save btn was not enabled')
        self.wait_until_element_is_enabled(self.objects['LAB_SSEL_Savebtn'], 30, 'save btn was not enabled')
        self.click_button(self.objects['LAB_SSEL_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()  
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSEL_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_SSEL_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InPeripheralReceivefromLab(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()            
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_RREL_RegNo'], 30, 'regno was not visible')
        self.input_text(self.objects['LAB_RREL_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_RREL_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['LAB_RREL_Searchbtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_RREL_Checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_RREL_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_receivetestbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_RREL_ReceiveTestbtn'], 30, 'receive test btn was not enabled')
        self.click_button(self.objects['LAB_RREL_ReceiveTestbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_RREL_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_RREL_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InSpecimenRevert(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Lab_specimenrevert')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()            
    def entering_into_specimenrevert_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626171"
        if self._is_visible(self.objects['LAB_SRVT_RegNo']):
            self.input_text(self.objects['LAB_SRVT_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SRVT_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SRVT_Searchbtn'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_revertreason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SRVT_Reason'], 30, 'reason was not visible')
        self.select_from_list_by_index(self.objects['LAB_SRVT_Reason'],'2')
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SRVT_SelectAll_Checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SRVT_SelectAll_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_SRVT_Remarks'], 30, 'remarks was not visible')
        self.input_text(self.objects['LAB_SRVT_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_specimenrevertbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SRVT_SpecimenRevertbtn'], 30, 'specimen revert btn was not enabled')
        self.click_element(self.objects['LAB_SRVT_SpecimenRevertbtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_SRVT_Message'], 40, 'message was not visible')
            Msg = self._get_text(self.objects['LAB_SRVT_Message'])
            print Msg
        except:
            pass        
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InStandardResultUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_into_resultupdate_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179"
        if self._is_visible(self.objects['LAB_SSTRU_RegNo']):
            self.input_text(self.objects['LAB_SSTRU_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTRU_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SSTRU_Searchbtn'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRU_Checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSTRU_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRU_Reason'], 30, 'reason was not visible')
        self.select_from_list_by_index(self.objects['LAB_SSTRU_Reason'],'2')
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_resultupdatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRU_ResultUpdatebtn'], 30, 'result update btn was not enabled')
        self.click_button(self.objects['LAB_SSTRU_ResultUpdatebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRU_Updatebtn'], 30, 'result update btn was not enabled')
        self.click_button(self.objects['LAB_SSTRU_Updatebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_SSTRU_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_SSTRU_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InCultureResultUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_into_resultupdate_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179"
        if self._is_visible(self.objects['LAB_CSTRU_RegNo']):
            self.input_text(self.objects['LAB_CSTRU_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_CSTRU_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_CSTRU_Searchbtn'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_culturetestdetails_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.dict['LAB_CULTURE_SERVICE'] = "Culture Serum"
        self.wait_until_element_is_visible('xpath=//*[(text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 30, "test name was not visible")
        self.click_element('xpath=//*[(text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CSTRU_Updatebtn'], 30, 'result update btn was not enabled')
        self.click_button(self.objects['LAB_CSTRU_Updatebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_CSTRU_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_CSTRU_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InPathologyResultUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_into_resultupdate_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179"
        if self._is_visible(self.objects['LAB_PSTRU_RegNo']):
            self.input_text(self.objects['LAB_PSTRU_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_PSTRU_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_PSTRU_Searchbtn'])            
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_Pathologytestdetails_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['LAB_PATHOLOGY_SERVICE'] = "paps nag"
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]', 30, 'No Tests available')
        self.click_element('xpath=//*[(text()="'+self.dict['LAB_PATHOLOGY_SERVICE']+" - [ Report : 1]"'")]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_PSTRU_Updatebtn'], 30, 'result update btn was not visible')
        self.wait_until_element_is_enabled(self.objects['LAB_PSTRU_Updatebtn'], 30, 'result update btn was not enabled')
        self.click_button(self.objects['LAB_PSTRU_Updatebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_PSTRU_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_PSTRU_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InStandardResPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_into_resultprint_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179"
        if self._is_visible(self.objects['LAB_SSTRP_RegNo']):
            self.input_text(self.objects['LAB_SSTRP_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_SSTRP_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_SSTRP_Searchbtn'])
        #self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 10, 'No data available')
        #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_SSTRP_Checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_SSTRP_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_printbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_SSTRP_Printbtn'], 30, 'print btn was not visible')
        self.click_button(self.objects['LAB_SSTRP_Printbtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
   
class InCultureResPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626195"
        self.wait_until_element_is_visible(self.objects['LAB_CSTRP_RegNo'], 30, 'regno was not visible')
        self.input_text(self.objects['LAB_CSTRP_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CSTRP_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['LAB_CSTRP_Searchbtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_printbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
           self.wait_until_element_is_visible(self.objects['LAB_CSTRP_Printbtn'], 30, 'print btn was not visible')
           self.click_element(self.objects['LAB_CSTRP_Printbtn'])
           time.sleep(3)
        except ElementClickInterceptedException:
            time.sleep(2)
            self.click_element(self.objects['LAB_CSTRP_Printbtn'])
        else:
            pass
            
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InPathologyResPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179" 
        self.wait_until_page_contains_element(self.objects['LAB_PSTRP_RegNo'], 30, 'regno was not visible')       
        self.wait_until_element_is_visible(self.objects['LAB_PSTRP_RegNo'], 30, 'regno was not visible')
        self.input_text(self.objects['LAB_PSTRP_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRP_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['LAB_PSTRP_Searchbtn'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regnoinsearchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626179" 
        self.wait_until_element_is_visible('xpath=//input[@type="search"]', 30, 'search btn was not visible')
        self.input_text('xpath=//input[@type="search"]', str(self.dict['REGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
        
    def selecting_printbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_PSTRP_Printbtn'], 30, 'print btn was not visible')
        self.click_element(self.objects['LAB_PSTRP_Printbtn'])
        time.sleep(3)                             
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InPeripheralExternalLabUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()            
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626210"
        self.wait_until_element_is_visible(self.objects['LAB_ELU_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['LAB_ELU_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tbDetails"]//td[text()="'+self.dict['REGNO']+'"]/..//td[1]//span[3]', 30, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tbDetails"]//td[text()="'+self.dict['REGNO']+'"]/..//td[1]//span[3]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_ELU_Updatebtn'], 30, 'update btn was not enabled')
        self.click_button(self.objects['LAB_ELU_Updatebtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_labname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_ELU_Labname'], 30, 'lab name was not visible')
        self.select_from_list_by_index(self.objects['LAB_ELU_Labname'],'3')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_labnameupdatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_ELU_UpdateLabnamebtn'], 30, 'lab name update btn was not enabled')
        self.click_button(self.objects['LAB_ELU_UpdateLabnamebtn'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def getting_labname_afterupdate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbDetails"]//td[text()="'+self.dict['REGNO']+'"]/..//td[8]', 30, 'updated lab name was not visible')
        Msg = self._get_text('xpath=//*[@id="tbDetails"]//td[text()="'+self.dict['REGNO']+'"]/..//td[8]')
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_ELU_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_ELU_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InCancelRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Lab')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_cancelrequestscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        if self._is_visible(self.objects['LAB_CR_RegNo']):
            self.input_text(self.objects['LAB_CR_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_CR_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_CR_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CR_checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['LAB_CR_checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CR_reason'], 30, 'Reason was not visible')
        self.select_from_list_by_index(self.objects['LAB_CR_reason'],'1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CR_Doctor'], 30, 'Doctor was not visible')
        self.select_from_list_by_index(self.objects['LAB_CR_Doctor'],'1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_CR_Remarks'], 30, 'Remarks was not visible')
        self.input_text(self.objects['LAB_CR_Remarks'],self.d[r]['cancelrequest_remarks'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_testrequestbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CR_TestCancelReqBtn'], 30, 'Test Request btn was not enabled')
        self.click_button(self.objects['LAB_CR_TestCancelReqBtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_page_contains_element(self.objects['LAB_CR_Message'], 40, 'message was not visible')
            self.wait_until_element_is_visible(self.objects['LAB_CR_Message'], 40, 'message was not visible')
            Msg = self._get_text(self.objects['LAB_CR_Message'])
            print Msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
    
class InCancelRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Lab')
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_cancelrequestscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625604"
        if self._is_visible(self.objects['LAB_CRA_RegNo']):
            self.input_text(self.objects['LAB_CRA_RegNo'], str(self.dict['REGNO']))
            self.wait_until_element_is_enabled(self.objects['LAB_CRA_Searchbtn'], 30, 'search btn was not enabled')
            self.click_button(self.objects['LAB_CRA_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element(self.objects['LAB_CRA_checkbox'], 30, 'Checkbox was not visible')
        self.click_element(self.objects['LAB_CRA_checkbox'])
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element(self.objects['LAB_CRA_checkbox'])
        time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_CRA_checkbox'], 10, 'checkbox was not visible')
        #self.click_element(self.objects['LAB_CRA_checkbox'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_CRA_remarks'], 30, 'Remarks was not visible')
        self.input_text(self.objects['LAB_CRA_remarks'],self.d[r]['cancelrequestapprove_remarks'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_testcancelapprovebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_CRA_testcancelapprovebtn'], 30, 'Test cancel approve btn was not enabled')
        self.click_button(self.objects['LAB_CRA_testcancelapprovebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_CRA_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_CRA_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InTestCancelDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_into_searchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbldtls_filter"]/label/input', 30, 'search btn was not visible')
        self.input_text('xpath=//*[@id="tbldtls_filter"]/label/input', str(self.dict['REGNO']))
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_testcanceldirectscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient details in grid was not visible")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="checkAll"]/..//span[3]', 30, 'Checkbox was not visible')
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_CRA_checkbox'], 10, 'checkbox was not visible')
        #self.click_element(self.objects['LAB_CRA_checkbox'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_reason'], 30, 'Reason was not visible')
        self.select_from_list_by_index(self.objects['LAB_TCD_reason'],'2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Doctor'], 30, 'Doctor was not visible')
        self.select_from_list_by_index(self.objects['LAB_TCD_Doctor'],'2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Remarks'], 30, 'Remarks was not visible')
        self.input_text(self.objects['LAB_TCD_Remarks'],"Not applicable")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()

    def selecting_directtestcancelbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_TCD_DirectTestCancelBtn'], 30, 'Direct Test cancel btn was not enabled')
        self.click_button(self.objects['LAB_TCD_DirectTestCancelBtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_TCD_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InTestCancelDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_into_searchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbldtls_filter"]/label/input', 30, 'search btn was not visible')
        self.input_text('xpath=//*[@id="tbldtls_filter"]/label/input', str(self.dict['REGNO']))
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_testcanceldirectscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient details in grid was not visible")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="checkAll"]/..//span[3]', 30, 'Checkbox was not visible')
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        element = self._get_checkbox('xpath=//*[@id="checkAll"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['LAB_CRA_checkbox'], 10, 'checkbox was not visible')
        #self.click_element(self.objects['LAB_CRA_checkbox'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_reason'], 30, 'Reason was not visible')
        self.select_from_list_by_index(self.objects['LAB_TCD_reason'],'2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Doctor'], 30, 'Doctor was not visible')
        self.select_from_list_by_index(self.objects['LAB_TCD_Doctor'],'2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Remarks'], 30, 'Remarks was not visible')
        self.input_text(self.objects['LAB_TCD_Remarks'],"Not applicable")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()

    def selecting_directtestcancelbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_TCD_DirectTestCancelBtn'], 30, 'Direct Test cancel btn was not enabled')
        self.click_button(self.objects['LAB_TCD_DirectTestCancelBtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_TCD_Message'], 40, 'message was not visible')
        Msg = self._get_text(self.objects['LAB_TCD_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        

class InGlucometerResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Lab")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643259"
        if self._is_visible(self.objects['LAB_GRE_checkbox']):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['LAB_GRE_RegNo']):
             self.input_text(self.objects['LAB_GRE_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['LAB_GRE_Searchbtn'], 30, 'search btn was not enabled')
             self.click_button(self.objects['LAB_GRE_Searchbtn'])
             time.sleep(2)    
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckboxes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="chkAllTest"]/..//span[3]', 30, 'Checkbox was not visible')
        self.click_element('xpath=//*[@id="chkAllTest"]/..//span[3]')
        element = self._get_checkbox('xpath=//*[@id="chkPrint0"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element('xpath=//*[@id="chkPrint0"]/..//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_resultentry_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_GRE_ResultEntrybtn'], 30, 'resultentry btn was not enabled')
        self.click_button(self.objects['LAB_GRE_ResultEntrybtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_result(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_GRE_Result'], 30, 'result was not enabled')
        self.input_text(self.objects['LAB_GRE_Result'], str(self.d[r]['glucometer_result']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_comments(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['LAB_GRE_Comments'], 30, 'comments was not visible')
        self.input_text(self.objects['LAB_GRE_Comments'], str(self.d[r]['glucometer_comments']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_internalremarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_GRE_Internal_Remarks'], 30, 'internal remarks was not visible')
        self.input_text(self.objects['LAB_GRE_Internal_Remarks'], str(self.d[r]['glucometer_internalremarks']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['LAB_GRE_Remarks'], 30, 'remarks was not visible')
        self.input_text(self.objects['LAB_GRE_Remarks'], str(self.d[r]['glucometer_remarks']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['LAB_GRE_Savebtn'], 30, "save btn was not enabled")
        self.click_element(self.objects['LAB_GRE_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_GRE_Message'], 30, 'result entry not successful')
        Msg = self._get_text(self.objects['LAB_GRE_Message'])
        print Msg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        time.sleep(1)   
        self.dict['BROWSER'] = self._current_browser()
        
class InRequestPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['LAB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643856" 
        self.wait_until_page_contains_element(self.objects['LAB_RequestPrint_Regno'], 30, 'regno was not visible')       
        self.wait_until_element_is_visible(self.objects['LAB_RequestPrint_Regno'], 30, 'regno was not visible')
        self.input_text(self.objects['LAB_RequestPrint_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_RequestPrint_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['LAB_RequestPrint_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
    def entering_into_requestprint_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'patient details was not visible')
        self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_printbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['LAB_RequestPrint_Printbtn'], 30, 'print btn was not visible')
        self.click_element(self.objects['LAB_RequestPrint_Printbtn'])
        time.sleep(3)                             
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['LAB_RequestPrint_Message'], 30, 'print was not successful in page')
        self.wait_until_element_is_visible(self.objects['LAB_RequestPrint_Message'], 30, 'print was not successful')
        Msg = self._get_text(self.objects['LAB_RequestPrint_Message'])
        print Msg
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        