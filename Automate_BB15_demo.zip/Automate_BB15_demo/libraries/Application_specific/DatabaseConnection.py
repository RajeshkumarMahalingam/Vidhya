import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import pypyodbc
import pandas as pd


class DatabaseConnection(Selenium2Library):

 def establishconnection(self):
    
    wrkbk = load_workbook('D:\workspace\Automate_BB15_local\Config\Prerequsiteconfig.xlsx')
    sheet = wrkbk["ServerDetails"]
    servername = sheet.cell(row=2,column=1).value
    userid = sheet.cell(row=2,column=2).value
    pwd = sheet.cell(row=2,column=3).value
    cnxn = pypyodbc.connect("Driver={SQL Server};" "Server="+servername+";" "uid="+userid+"; pwd="+pwd+"")
    print "db connected"
    cursor = cnxn.cursor()
    cursor.execute("Sp_ExecStatUpdate", None, False, False)
    cursor.close()
    time.sleep(30)
    cnxn.commit()
    cnxn.close()
    print "ended"

DatabaseConnection().establishconnection()
