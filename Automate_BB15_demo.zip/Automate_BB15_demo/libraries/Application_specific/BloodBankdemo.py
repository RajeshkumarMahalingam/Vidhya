import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class MainDonorRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BloodBank")
    def selecting_Sal_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.select_from_list_by_label(self.objects['BB_DonorReg_sal'], self.d[r]['bb_sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text(self.objects['BB_DonorReg_name'], self.d[r]['bb_name'])
        self.dict['BROWSER'] = self._current_browser()
        
#Bloon Donor registraion Process to Main Screeing        
FromConfigFile().driving_browser_and_url()
'''Capturing().backbone_objects()
Capturing().data_off("BloodBank")
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/DonorRegistration.aspx')
r = 1
MainDonorRegistration().selecting_Sal_with_data(r)
MainDonorRegistration().entering_name_with_data(r) '''       
        