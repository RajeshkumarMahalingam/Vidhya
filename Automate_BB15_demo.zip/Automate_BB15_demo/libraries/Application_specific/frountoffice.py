import sys
from Selenium2Library import Selenium2Library
import pyautogui
from numpy.random.mtrand import randint
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InPatientBlockAndUnblock(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("fo_block_unblock")
    
    def select_the_frame(self):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_frame(self.objects['FO_MainFrame'])
         self.dict['BROWSER'] = self._current_browser()
         
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['REGNO'] = "624412"
        self.input_password(self.objects['FO_patient_block_unblock_regno'], str(self.dict['REGNO']))
        pyautogui.hotkey('enter')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
        
    def block_reason(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_patient_block_unblock_patient_status'], self.d[r]['patient_status'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_patient_block_unblock_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
        
    def unlock(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects['FO_patient_block_unblock_patient_status'], 'UNLOCK')
        self.dict['BROWSER'] = self._current_browser()
        
    def save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['FO_patient_block_unblock_save'])
        text=self.get_text(self.objects['FO_patient_block_unblock_message'])
        self.click_button('xpath=//*[@id="btn-ok"]')
        print text
        self.dict['BROWSER'] = self._current_browser()
    
'''           
FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("fo_block_unblock")
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('//FrontOfficeCS/tPatientBlockUnBlock.aspx') 
r=1        
InPatientBlockAndUnblock().select_the_frame()
InPatientBlockAndUnblock().entering_regno()
InPatientBlockAndUnblock().block_reason(r)
InPatientBlockAndUnblock().entering_remarks(r)
InPatientBlockAndUnblock().unlock()
InPatientBlockAndUnblock().save()
'''
        
class CampRegestration(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("fo_camp_reg")
    
    def select_the_frame(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    
    def select_camp_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_campname'], "1")
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_camp_sal'], "1")
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_camp_name'], self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_gender(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_camp_gender'], "1")
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_camp_age'], str(self.d[1]['age']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_camp_address'], self.d[r]['add'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_city(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_camp_city'])
        self.input_text(self.objects['FO_camp_city_entry'], self.d[r]['city'])
        self.press_key(self.objects['FO_camp_city_entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_phno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        mobile = randint(9000000000,9999999999)
        self.wait_until_element_is_visible(self.objects["FO_camp_phno"], 10, "mobile was not visible")
        self.input_text(self.objects['FO_camp_phno'], str(mobile))
        self.dict['BROWSER'] = self._current_browser()
        
    def save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_camp_save'])
        message=self.get_text(self.objects['FO_camp_message'])
        print message
        self.dict['BROWSER'] = self._current_browser()
            
FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("fo_camp_reg")
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('//FrontOfficeCS/CampRegistration.aspx') 
r=1
CampRegestration().select_the_frame()
CampRegestration().select_camp_name()
CampRegestration().selecting_sal()
CampRegestration().entering_name(r)
CampRegestration().selecting_gender()
CampRegestration().entering_age(r)
CampRegestration().entering_address(r)
CampRegestration().selecting_city(r)
CampRegestration().entering_phno(r)
CampRegestration().save()

        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     