from Selenium2Library import Selenium2Library
import sys
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InDietItemRequest_Ward(Selenium2Library):    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietRequest_Ward")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
         
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.set_selenium_implicit_wait(13)
         #self.dict['IPNO'] = "Ip13314"
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_IPNo"], 10, "IP NO is not visible")
         self.input_text(self.objects['Diet_DietItemRequestWard_IPNo'], str(self.dict['IPNO']))
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestWard_Search"], 10, "search btn was not visible")
         self.click_button(self.objects["Diet_DietItemRequestWard_Search"])
         time.sleep(2)
         self.click_button(self.objects["Diet_DietItemRequestWard_Search"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()     
         
    def entering_into_dietitempage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['IPNO']+'"]', 10, "IP no in search grid is not visible")
         self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['IPNO']+'"]')
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_type(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_page_contains_element(self.objects["Diet_DietItemRequestWard_Type"], 15, "type is not visible")
         self.select_from_list(self.objects["Diet_DietItemRequestWard_Type"] ,self.d[r]['Type'])
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_diet_item(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Item"], 15, "diet item is not visible")
         self.click_element(self.objects['Diet_DietItemRequestWard_Item'])
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 15, "diet item is not visible")
         self.input_text('//*[@id="select2-drop"]//input',self.d[r]["Item"])
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span', 15, "diet item list was not visible")
         self.click_element('xpath=//*[@id="select2-drop"]//span')
         self.dict['BROWSER'] = self._current_browser()
        
    def entering_quantity(self,r):   
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestWard_Quantity'], 15, "diet qty was not visible")
         self.input_text(self.objects['Diet_DietItemRequestWard_Quantity'], str(self.d[r]["Quantity"]))
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_session(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestWard_Session'], 15, "diet session was not visible")
         self.select_from_list(self.objects["Diet_DietItemRequestWard_Session"],str(self.d[r]['Session']))
         self.dict['DIET_SESSION']=self.d[r]['Session']
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()     
     
    def selecting_session_again(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestWard_Session'], 15, "diet session again was not visible")
         self.select_from_list(self.objects["Diet_DietItemRequestWard_Session"],str(self.d[r]['Session']))
         self.dict['DIET_SESSION']=self.d[r]['Session']
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_reqday(self,r):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestWard_ReqDay'], 15, "diet req day was not visible")
         self.select_from_list(self.objects['Diet_DietItemRequestWard_ReqDay'],self.d[r]["ReqDay"])
         self.dict['BROWSER'] = self._current_browser()     
     
    def  selecting_urgency(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestWard_Urgency'], 15, "Urgency was not visible")
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestWard_Urgency"] ,self.d[r]['Urgency'])
         self.dict['BROWSER'] = self._current_browser()   
         
    def selecting_addbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.set_selenium_implicit_wait(10)
         self.wait_until_element_is_enabled(self.objects['Diet_DietItemRequestWard_Add'], 15, "add btn was not visible")
         self.click_button(self.objects['Diet_DietItemRequestWard_Add'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
         
    '''def clicking_delete(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietItemRequestWard_Delete'])
         self.dict['BROWSER'] = self._current_browser()'''
        
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.set_selenium_implicit_wait(2)
         self.wait_until_element_is_enabled(self.objects['Diet_DietItemRequestWard_Save'], 15, "save btn was not enabled")
         self.click_button(self.objects['Diet_DietItemRequestWard_Save'])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['Diet_DietItemRequestWard_Get_Message'], 10, "get message was not enabled")
         MSG1 = self._get_text(self.objects["Diet_DietItemRequestWard_Get_Message"])
         print MSG1
         self.dict['BROWSER'] = self._current_browser()
         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()      
                   
    
    '''def clicking_back(self):    
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietItemRequestWard_Back'], 10, 'back button is visible')
         self.click_button(self.objects['Diet_DietItemRequestWard_Back'])
         self.dict['BROWSER'] = self._current_browser() ''' 
                 
     
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietRequest_Ward")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('///Dietary/WardDietItemsPatsearch.aspx')
r = 1    
InDietItemRequest_Ward().entering_ipno()
InDietItemRequest_Ward().clicking_search()
InDietItemRequest_Ward().entering_into_dietitem()
InDietItemRequest_Ward().selecting_type(r)
InDietItemRequest_Ward().selecting_diet_item(r)
InDietItemRequest_Ward().entering_quantity(r)
InDietItemRequest_Ward().selecting_session(r)
r = 2
InDietItemRequest_Ward().selecting_session_again(r) #selecting session again to enable req. day field 
r = 1
InDietItemRequest_Ward().selecting_reqday(r)
InDietItemRequest_Ward().selecting_urgency(r)
InDietItemRequest_Ward().clicking_add()
InDietItemRequest_Ward().clicking_save()
#InDietItemRequest_Ward().unselecting_frame()
#InDietItemRequest_Ward().clicking_back()
#InDietItemRequest_Ward().clicking_delete()'''
        
        
class InPatientChange(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("PatientDietChange")   
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame was not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_PatientDietChange_IPNo"], 10, "ipno was not visible")
         self.input_text(self.objects['Diet_PatientDietChange_IPNo'], str(self.dict['IPNO']))
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_PatientDietChange_Search"], 10, "search is not visible")
         self.click_button(self.objects["Diet_PatientDietChange_Search"])
         self.dict['BROWSER'] = self._current_browser()           
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()     
         self.click_element(self.objects["Diet_PatientDietChange_Table"])
         self.dict['BROWSER'] = self._current_browser()  
    def selecting_dietary(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_PatientDietChange_Dietary"], 10, "dietary was not visible")
         self.click_element(self.objects["Diet_PatientDietChange_Dietary"])
         self.wait_until_element_is_visible(self.objects["Diet_PatientDietChange_Dietary_Textbox"], 10, "dietary was not visible")
         self.input_text(self.objects["Diet_PatientDietChange_Dietary_Textbox"], self.d[r]['Dietary'])
         time.sleep(2)
         self.press_key(self.objects['Diet_PatientDietChange_Dietary_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()   
    def entering_comments(self,r):    
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()   
         r = int (r)
         self.input_text(self.objects["Diet_PatientDietChange_Comments"], self.d[r]['Comments'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects["Diet_PatientDietChange_Save"])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         MSG2 = self.get_text(self.objects["Diet_PatientDietChange_Get_Message"])
         print MSG2
         self.dict['BROWSER'] = self._current_browser()
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()     
         
   
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("PatientDietChange")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//Dietary/PatientDietList.aspx')   
r = 1
InPatientChange().entering_ipno()
InPatientChange().clicking_search()
InPatientChange().entering_next_screen_by_clicking_gridvalue()
InPatientChange().selecting_dietary(r)
InPatientChange().entering_comments(r)
InPatientChange().clicking_save()'''
        
        
        
        
class InDietOrder(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietOrder") 
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_date(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         self.input_text(self.objects["Diet_DietOrders_RegDate"], str(self.d[r]['RegDate']))
         self.press_key(self.objects["Diet_DietOrders_RegDate"], '\\09')
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_ward(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.wait_until_element_is_visible(self.objects["Diet_DietOrders_Ward"], 10, 'ward is not visible')
         self.select_from_list(self.objects["Diet_DietOrders_Ward"],self.d[r]['Ward'])
         self.dict['BROWSER'] = self._current_browser()
         
    def clicking_search(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.click_button(self.objects["Diet_DietOrders_Search"])
         self.dict['BROWSER'] = self._current_browser()
         
    def searching_with_ipno(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['IPNO']="0000009060"
         self.click_element('xpath=//*[@id="tbldietlist"]//tbody//tr//td[text()='+str(self.dict["IPNO"])+']')
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_type(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietOrders_Type"], 10, 'type is not visible')
         self.select_from_list(self.objects["Diet_DietOrders_Type"],self.d[r]['Type'])
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_diet_item(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_element(self.objects['Diet_DietOrders_Item'])
         #self.wait_until_element_is_visible(self.objects["Diet_DietOrders_Item_Textbox"], 10, 'item is not visible')
         self.input_text(self.objects["Diet_DietOrders_Item_Textbox"],self.d[r]['Item'])
         time.sleep(3)
         self.press_key(self.objects['Diet_DietOrders_Item_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()     
        
    '''def selecting_supplementary(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_element(self.objects["Diet_DietOrders_Supplementary"])
         self.input_text(self.objects["Diet_DietOrders_Supplementary_Textbox"],str(self.d[r]['Supplementary']))
         time.sleep(2)
         self.press_key(self.objects["Diet_DietOrders_Supplementary_Textbox"], '\\09')
         self.dict['BROWSER'] = self._current_browser()'''
      
    def entering_quantity(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.input_text(self.objects["Diet_DietOrders_Quantity"], str(self.d[r]['Quantity']))
         self.dict['BROWSER'] = self._current_browser()
              
    def selecting_session(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_element(self.objects["Diet_DietOrders_Session"])
         self.input_text(self.objects["Diet_DietOrders_Session_Textbox"] ,str(self.d[r]['Session']))
         self.press_key(self.objects['Diet_DietOrders_Session_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()      
         
    def selecting_session(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.click_element(self.objects["Diet_DietOrders_Session"])
         self.select_from_list(self.objects["Diet_DietOrders_Session"] ,str(self.d[r]['Session']))
         #self.press_key(self.objects['Diet_DietOrders_Session_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_session_again(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_from_list(self.objects["Diet_DietOrders_Session"] ,str(self.d[r]['Session']))
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_reqday(self,r):  
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         self.select_from_list(self.objects['Diet_DietOrders_ReqDay'],self.d[r]["ReqDay"])
         self.dict['BROWSER'] = self._current_browser()          
         
    def  selecting_urgency(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_from_list_by_label(self.objects["Diet_DietOrders_Urgency"] ,self.d[r]['Urgency'])
         self.dict['BROWSER'] = self._current_browser()      
         
    def  selecting_charge(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_from_list_by_label(self.objects["Diet_DietOrders_Charge"] ,self.d[r]['Charge'])
         self.dict['BROWSER'] = self._current_browser()    
        
    def clicking_add(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietOrders_Add'])
         self.dict['BROWSER'] = self._current_browser()           
        
    def clicking_save(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietOrders_Save'])
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Get_Message"], 5 , 'Msg Not Displayed')
         time.sleep(1)
         MSG3 = self._get_text(self.objects["Diet_DietOrders_Message"])
         print MSG3
         self.dict['BROWSER'] = self._current_browser()      
         
    def entering_remarks(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.input_text(self.objects["Diet_DietOrders_Remarks"], str(self.d[r]['Remarks']))   
         self.dict['BROWSER'] = self._current_browser()     
   
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
    
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietOrder")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('///Dietary/dietOrders.aspx')   
r = 1        
InDietOrder().entering_date(r)  
InDietOrder().selecting_ward(r)   
InDietOrder().clicking_search()  
InDietOrder().searching_with_ipno()
InDietOrder().selecting_type(r)
InDietOrder().selecting_diet_item(r)
#InDietOrder().selecting_supplementary(r)
InDietOrder().entering_quantity(r)
InDietOrder().selecting_session(r) 
r = 2
InDietOrder().selecting_session_again(r)
r = 1
InDietOrder().selecting_reqday(r) 
InDietOrder().selecting_urgency(r)  
InDietOrder().selecting_charge(r)
InDietOrder().clicking_add()
InDietOrder().entering_remarks(r)
InDietOrder().clicking_save()'''
        
        
        
        
        
        
class InDietItemRequest_Dietary(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietRequest_Dietary")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()

    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame was not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)    
         self.dict['BROWSER'] = self._current_browser()
    
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_IPNo"], 10, "ipno was not visible")
         self.input_text(self.objects['Diet_DietItemRequestDietary_IPNo'], self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser()      
         
    def clicking_search(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestWard_Search"], 10, "search was not visible")
         self.click_button(self.objects["Diet_DietItemRequestWard_Search"])
         time.sleep(2)
         self.click_button(self.objects["Diet_DietItemRequestWard_Search"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()       
         
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
          #time.sleep(1)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Table"], 10, "IP no in search grid is not visible")
         self.click_element(self.objects["Diet_DietItemRequestDietary_Table"])
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_type(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Type"], 10, 'type was not visible')
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestDietary_Type"],self.d[r]['Type'])
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_diet_item(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Item"], 15, "diet item is not visible")
         self.click_element(self.objects['Diet_DietItemRequestDietary_Item'])
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 15, "diet item is not visible")
         self.input_text('//*[@id="select2-drop"]//input',self.d[r]["Item"])
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span', 15, "diet item list was not visible")
         self.click_element('xpath=//*[@id="select2-drop"]//span')
         self.dict['BROWSER'] = self._current_browser()

         
    def entering_quantity(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Quantity"], 10, "quantity was not visible")
         self.input_text(self.objects["Diet_DietItemRequestDietary_Quantity"], str(self.d[r]['Quantity']))
         self.dict['BROWSER'] = self._current_browser()
              
    def selecting_session(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Session"], 10, "session was not visible")
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestDietary_Session"] ,str(self.d[r]['Session']))
         self.dict['DIET_SESSION']=self.d[r]['Session']
         date=self.get_text('xpath=//*[@id="select2-chosen-3"]')
         self.dict['BROWSER'] = self._current_browser()    
         
    def selecting_session_again(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Session"], 10, "session was not visible")
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestDietary_Session"] ,str(self.d[r]['Session']))
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_reqday(self,r):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_ReqDay"], 10, "ReqDay was not visible")
         self.select_from_list_by_label(self.objects['Diet_DietItemRequestDietary_ReqDay'],self.d[r]["ReqDay"])
         self.dict['BROWSER'] = self._current_browser()           
         
    def  selecting_urgency(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Urgency"], 10, "urgency was not visible")
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestDietary_Urgency"] ,self.d[r]['Urgency'])
         self.dict['BROWSER'] = self._current_browser()      
         
    def  selecting_charge(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Charge"], 10, "charge was not visible")
         self.select_from_list_by_label(self.objects["Diet_DietItemRequestDietary_Charge"] ,self.d[r]['Charge'])
         self.dict['BROWSER'] = self._current_browser()    
        
    def clicking_add(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestDietary_Add"], 10, "add btn was not visible")
         self.click_button(self.objects['Diet_DietItemRequestDietary_Add'])
         self.dict['BROWSER'] = self._current_browser()           
        
    def clicking_save(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestDietary_Save"], 10, "save btn was not visible")
         self.click_button(self.objects['Diet_DietItemRequestDietary_Save'])
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Get_Message"], 5 , 'Msg Not Displayed')
         time.sleep(1)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Message"], 10, "Message was not visible")
         MSG4 = self._get_text(self.objects["Diet_DietItemRequestDietary_Message"])
         print MSG4
         self.dict['BROWSER'] = self._current_browser()      
         
    def entering_remarks(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestDietary_Remarks"], 10, "remarks was not visible")
         self.input_text(self.objects["Diet_DietItemRequestDietary_Remarks"], str(self.d[r]['Remarks']))   
         self.dict['BROWSER'] = self._current_browser()     
          
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
         
         
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietRequest_Dietary")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('///Dietary/DietetionRequest.aspx?Opt=1')   
r = 1  
InDietItemRequest_Dietary().entering_ipno()    
InDietItemRequest_Dietary().clicking_search()  
InDietItemRequest_Dietary().entering_next_screen_by_clicking_gridvalue()
InDietItemRequest_Dietary().selecting_type(r)
InDietItemRequest_Dietary().selecting_diet_item(r)
InDietItemRequest_Dietary().entering_quantity(r)
InDietItemRequest_Dietary().selecting_session(r) 
r = 2
InDietItemRequest_Dietary().selecting_session_again(r)
r = 1
InDietItemRequest_Dietary().selecting_reqday(r) 
InDietItemRequest_Dietary().selecting_urgency(r)  
InDietItemRequest_Dietary().selecting_charge(r)
InDietItemRequest_Dietary().clicking_add()
InDietItemRequest_Dietary().entering_remarks(r)
InDietItemRequest_Dietary().clicking_save()'''
        
        
        
        
class InDietItem_Issue(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("DietIssue")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(5)
         self.dict['BROWSER'] = self._current_browser() 
    
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['IPNO'] = "737"
         self.wait_until_element_is_visible(self.objects['Diet_DietItemIssue_IPNo'], 10, "ip no field was not visible")
         self.input_text(self.objects['Diet_DietItemIssue_IPNo'], self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser() 
         
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #time.sleep(1)
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemIssue_Search"], 10, "search was not visible")
         self.click_button(self.objects["Diet_DietItemIssue_Search"])
         time.sleep(2)
         #self.click_button(self.objects["Diet_DietItemIssue_Search"])
         #time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()      
         
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.set_selenium_implicit_wait(10)
         self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]/tr[1]', 10, "IP no in search grid is not visible")
         self.click_element('xpath=//*[@id="tblbdy"]/tr[1]')
         
         #self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['IPNO']+'"]/..', 10, "IP no in search grid is not visible")
         #self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['IPNO']+'"]/..')
         time.sleep(2)
         #self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['IPNO']+'"]')
         #time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
         
    def getting_date(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbldtl"]/tbody/tr[1]/td[4]', 10, "issue date was not visible")
        self.dict['DIET_ISSUE_DATE']=self.get_text('xpath=//*[@id="tbldtl"]/tbody/tr[1]/td[4]')
        print self.dict['DIET_ISSUE_DATE']
        self.dict['BROWSER'] = self._current_browser()   
            
    def selecting_checkbox(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(2)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemIssue_CheckBox"], 10, "checkbox was not visible")
         self.click_element(self.objects["Diet_DietItemIssue_CheckBox"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_issuebutton(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietItemIssue_ItemIssue'], 10, "issue btn was not enabled")
         self.click_button(self.objects['Diet_DietItemIssue_ItemIssue'])
         time.sleep(2)
         #pyautogui.hotkey('enter')     
         #self._handle_alert(False)
         #self.click_button(self.objects['Diet_DietItemIssue_ItemIssue'])
         self._handle_alert(True)
         time.sleep(2)
         self.wait_until_element_is_visible(self.objects["Diet_DietItemIssue_Message"], 7 , 'Msg Not Displayed')
         #time.sleep(1)
         MSG = self._get_text(self.objects["Diet_DietItemIssue_Message"])
         #print MSG
         #time.sleep(10)
         self.dict['BROWSER'] = self._current_browser()      
              
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()     
            
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
#Capturing().data_off("DietIssue")
FromConfigFile().logging("diet")
FromConfigFile().loading_menu_of_link('//Dietary/DietIssuePatSearch.aspx')   
r = 1  
InDietItem_Issue().selecting_frame()
InDietItem_Issue().entering_ipno() 
InDietItem_Issue().clicking_search()
InDietItem_Issue().entering_next_screen_by_clicking_gridvalue()
InDietItem_Issue().clicking_checkall()
InDietItem_Issue().clicking_issuebutton()'''

        
        
class InMultipleSessionIssue(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("MultipleSession")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(5)
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_ward(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_MultipleSessionIssue_ward"], 10, "ward was not visible")
         self.select_from_list_by_label(self.objects['Diet_MultipleSessionIssue_ward'],self.d[r]["Ward"])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_session(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects["Diet_AcknowledgeDietRecieve_Session"], 10, "session was not visible")
         self.select_from_list_by_label(self.objects["Diet_AcknowledgeDietRecieve_Session"] ,str(self.d[r]['Session']))
         self.dict['BROWSER'] = self._current_browser()  
    def entering_date(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.input_text(self.objects["Diet_MultipleSessionIssue_ReqDate"], str(self.d[r]['ReqDate']))
         self.press_key(self.objects["Diet_MultipleSessionIssue_ReqDate"], '\\09')
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_MultipleSessionIssue_Search"], 10, "search btn was not visible")
         self.click_button(self.objects["Diet_MultipleSessionIssue_Search"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()  
    def selecting_checkbox(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MultipleSessionIssue_Checkbox"], 10, "checkbox was not visible")
         self.click_element(self.objects['Diet_MultipleSessionIssue_Checkbox'])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()     
    def selecting_issuebtn(self):    
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_MultipleSessionIssue_Issue'], 10, "issues btn was not enabled")
         self.click_button(self.objects['Diet_MultipleSessionIssue_Issue'])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_MultipleSessionIssue_Message'], 10, "Message was not enabled")
         MSG6 = self._get_text(self.objects["Diet_MultipleSessionIssue_Message"])
         print MSG6
         self.dict['BROWSER'] = self._current_browser()         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
    
    
'''FromConfigFile().driving_browser_and_url()    
Capturing().backbone_objects()
Capturing().data_off("MultipleSession")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//Dietary/SessionIssue.aspx ')   
r = 1            
InMultipleSessionIssue().selecting_ward(r)   
InMultipleSessionIssue().selecting_session(r)
InMultipleSessionIssue().entering_date(r)    
InMultipleSessionIssue().clicking_search()
InMultipleSessionIssue().clicking_checkbox()
InMultipleSessionIssue().clicking_issue()'''
        
        
      
class InAcknowledgeDietReceive(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("DietReceive")   
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    
    def selecting_ward(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_AcknowledgeDietRecieve_Ward'], 10, "ward name was not visible")
         self.select_from_list(self.objects['Diet_AcknowledgeDietRecieve_Ward'],self.dict['WARD-NAME'])
         self.dict['BROWSER'] = self._current_browser()
          
    def selecting_session(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_AcknowledgeDietRecieve_Session'], 10, "acknowledge receive was not visible")
         self.select_from_list(self.objects['Diet_AcknowledgeDietRecieve_Session'],str(self.dict['DIET_SESSION']))
         self.dict['BROWSER'] = self._current_browser()
    
    def entering_date(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_AcknowledgeDietRecieve_ReqDate'], 10, "req date was not visible")
         self.input_text(self.objects["Diet_AcknowledgeDietRecieve_ReqDate"], str(self.dict['DIET_ISSUE_DATE']))
         self.press_key(self.objects["Diet_AcknowledgeDietRecieve_ReqDate"], '\\09')
         self.dict['BROWSER'] = self._current_browser() 
         
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_AcknowledgeDietRecieve_Search'], 10, "search btn was not visible")
         self.click_button(self.objects["Diet_AcknowledgeDietRecieve_Search"])
         self.dict['BROWSER'] = self._current_browser()  
         
    def selecting_checkbox(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_AcknowledgeDietRecieve_checkAll'], 10, "checkbox was not visible")
         self.click_element(self.objects['Diet_AcknowledgeDietRecieve_checkAll'])
         self.dict['BROWSER'] = self._current_browser() 
         
    def selecting_receivebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_AcknowledgeDietRecieve_Receive'], 10, "receive btn was not visible")
         self.click_button(self.objects['Diet_AcknowledgeDietRecieve_Receive'])
         self._handle_alert(True)
         self.wait_until_element_is_visible(self.objects['Diet_MultipleSessionIssue_Message'], 10, "Message was not visible")
         MSG7 = self._get_text(self.objects["Diet_MultipleSessionIssue_Message"])
         print MSG7         
         self.dict['BROWSER'] = self._current_browser() 
    
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()    
        
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("MultipleSession")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('/Dietary/DietItemReceiveAck.aspx')   
r = 1            
InAcknowledgeDietReceive().selecting_ward(r)   
InAcknowledgeDietReceive().selecting_session(r)
InAcknowledgeDietReceive().entering_date(r)    
InAcknowledgeDietReceive().clicking_search()
InAcknowledgeDietReceive().clicking_checkbox()
InAcknowledgeDietReceive().clicking_receive()'''
        
        
        
class InDietDirectBilling(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietRequest_Ward")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         #self.dict['IPNO']="0000009060"
         self.input_text(self.objects['Diet_DietDirectBilling_IPNo'], self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser()
         
    def clicking_search(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietDirectBilling_Search"], 10, "search is not visible")
         self.click_button(self.objects["Diet_DietDirectBilling_Search"])
         self.dict['BROWSER'] = self._current_browser()     
         
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(1)
         self.wait_until_element_is_visible(self.objects["Diet_DietDirectBilling_Table"], 10, "IP no in search grid is not visible")
         self.click_element(self.objects["Diet_DietDirectBilling_Table"])
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_type(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietDirectBilling_Type"], 5, "type is not visible")
         self.select_from_list(self.objects["Diet_DietDirectBilling_Type"] ,self.d[r]['Type'])
         self.dict['BROWSER'] = self._current_browser()     
         
    def selecting_diet_item(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Item"], 10, "dietary was not visible")
         self.click_element(self.objects['Diet_DietDirectBilling_Item'])
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Item_Textbox"], 10, "dietary entry was not visible")
         self.input_text(self.objects["Diet_DietDirectBilling_Item_Textbox"],self.d[r]["Item"])
         time.sleep(3)
         self.press_key(self.objects['Diet_DietDirectBilling_Item_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()
        
    def entering_quantity(self,r):   
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.input_text(self.objects['Diet_DietDirectBilling_Quantity'], str(self.d[r]["Quantity"]))
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_session(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #time.sleep(1)
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Session"], 10, "Session is not visible")
         self.click_element(self.objects["Diet_DietDirectBilling_Session"])
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Session_Textbox"], 10, "Session entry is not visible")
         self.input_text(self.objects["Diet_DietDirectBilling_Session_Textbox"] ,str(self.d[r]['Session']))
         #self.wait_until_element_is_visible(self.objects["Diet_DietItemRequestWard_Session_Textbox"], 10, "dietary entry was not visible")
         self.press_key(self.objects['Diet_DietDirectBilling_Session_Textbox'], '\\09')
         self.dict['BROWSER'] = self._current_browser()     
         #time.sleep(2)
     
    def  selecting_urgency(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_from_list_by_label(self.objects["Diet_DietDirectBilling_Session_Urgency"] ,self.d[r]['Urgency'])
         self.dict['BROWSER'] = self._current_browser()   
         
    def clicking_add(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietDirectBilling_Add'])
         self.dict['BROWSER'] = self._current_browser()
        
    def clicking_save(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietDirectBilling_Save'])
         #self.wait_until_element_is_visible(self.objects["Diet_DietDirectBilling_Message"], 5 , 'Msg Not Displayed')
         #time.sleep(1)
         MSG8 = self._get_text(self.objects["Diet_DietDirectBilling_Message"])
         print MSG8
         self.dict['BROWSER'] = self._current_browser()
    
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
    
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietRequest_Ward")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//Dietary/DirectIssuePatsearch.aspx')
r = 1    
InDietDirectBilling().entering_ipno()
InDietDirectBilling().clicking_search()
InDietDirectBilling().entering_next_screen_by_clicking_gridvalue()
InDietDirectBilling().selecting_type(r)
InDietDirectBilling().selecting_diet_item(r)
InDietDirectBilling().entering_quantity(r)
InDietDirectBilling().selecting_session(r)
InDietDirectBilling().selecting_urgency(r)
InDietDirectBilling().clicking_add()
InDietDirectBilling().clicking_save()'''
        
        
class InDietReturn(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietReturn")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])   
         time.sleep(3) 
         self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['IPNO'] = "Ip13323"
         self.wait_until_element_is_visible(self.objects["Diet_DietItemReturn_IPNo"], 10, "ipno was not visible")
         self.input_text(self.objects['Diet_DietItemReturn_IPNo'], str(self.dict['IPNO']))
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #time.sleep(1)
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemReturn_Search"], 10, "search btn was not visible")
         self.click_button(self.objects["Diet_DietItemReturn_Search"])
         time.sleep(2)
         self.click_button(self.objects["Diet_DietItemReturn_Search"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()     
         #time.sleep(2)
         
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietItemReturn_Table"], 10, "IP no in search grid is not visible")
         self.click_element(self.objects["Diet_DietItemReturn_Table"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    
    def selecting_checkbox(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['Diet_DietItemReturn_CheckBox'], 5, 'checkbox was not visible')
         self.click_element(self.objects['Diet_DietItemReturn_CheckBox'])
         self.dict['BROWSER'] = self._current_browser()         
                  
    def selecting_reason(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemReturn_Reason'], 10, "reason was not visible")
         self.select_from_list_by_label(self.objects['Diet_DietItemReturn_Reason'],self.d[r]['Reason'])
         self.dict['BROWSER'] = self._current_browser()
         
    def entering_remarks(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemReturn_Remarks'], 10, "remarks was not visible")
         self.input_text(self.objects['Diet_DietItemReturn_Remarks'],self.d[r]['Remarks']) 
         self.dict['BROWSER'] = self._current_browser()
            
    def selecting_cancelbutton(self):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietItemReturn_ItemCancellation'], 10, "cancel btn was not enabled")
         self.click_button(self.objects['Diet_DietItemReturn_ItemCancellation']) 
         self._handle_alert(True)
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects['Diet_DietItemReturn_Message'], 10, "message was not enabled")
         MSG9 = self._get_text(self.objects["Diet_DietItemReturn_Message"])
         print MSG9 
         self.dict['BROWSER'] = self._current_browser() 
            
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
        
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietReturn")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//Dietary/DietReturnWardPatSearch.aspx')
r = 1          
InDietReturn().entering_ipno()
InDietReturn().clicking_search()
InDietReturn().entering_next_screen_by_clicking_gridvalue()
InDietReturn().clicking_checkbox()
InDietReturn().selecting_reason(r)
InDietReturn().entering_remarks(r)
InDietReturn().clicking_cancelbutton()'''
        
        
class InDietLabelPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("DietReceive")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame was not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_ward(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietLabelPrint_Ward"], 10, "ward name was not visible")
         self.select_from_list_by_label(self.objects['Diet_DietLabelPrint_Ward'],self.dict['WARD-NAME'])
         self.dict['BROWSER'] = self._current_browser()
         
    def selecting_session(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietLabelPrint_Session"], 10, "session was not visible")
         self.select_from_list_by_label(self.objects['Diet_DietLabelPrint_Session'],self.dict['DIET_SESSION'])
         self.dict['BROWSER'] = self._current_browser() 
         
    '''def entering_date(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietLabelPrint_ReqDate"], 10, "reqdate was not visible")
         self.input_text(self.objects["Diet_DietLabelPrint_ReqDate"], str(self.d[r]['ReqDate']))
         self.press_key(self.objects["Diet_DietLabelPrint_ReqDate"], '\\09')
         self.dict['BROWSER'] = self._current_browser() '''
         
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #time.sleep(1)
         self.wait_until_element_is_enabled(self.objects["Diet_DietLabelPrint_Search"], 10, "search was not enabled")
         self.click_button(self.objects["Diet_DietLabelPrint_Search"])
         time.sleep(2)
         self.click_button(self.objects["Diet_DietLabelPrint_Search"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()  
         
    def selecting_printbtn(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietLabelPrint_LabelPrint"], 10, "print was not enabled")
         self.click_button(self.objects['Diet_DietLabelPrint_LabelPrint'])
         self.dict['BROWSER'] = self._current_browser()
         
    def getting_message(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["Diet_DietLabelPrint_Message"], 10, "message was not visible")
         MSG10 = self._get_text(self.objects["Diet_DietLabelPrint_Message"])
         print MSG10
         self.dict['BROWSER'] = self._current_browser()
         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
         
      
class InDietCounsellingRequest_OP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietCounselling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["Diet_DietCounsellingRequestOp_RegNo"], 10, "regno was not visible")
         self.input_text(self.objects['Diet_DietCounsellingRequestOp_RegNo'],str(self.dict['REGNO']))
         self.dict['BROWSER'] = self._current_browser()
    '''def entering_reqfromdate(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         self.input_text(self.objects['Diet_DietCounsellingRequestOp_ReqFromDate'], str("26-09-2022"))
         self.dict['BROWSER'] = self._current_browser()'''
                  
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietCounsellingRequestOp_Search"], 10, "search btn was not enabled")
         self.click_button(self.objects['Diet_DietCounsellingRequestOp_Search'])
         #time.sleep(2)
         #self.click_button(self.objects['Diet_DietCounsellingRequestOp_Search'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser() 
         
    def entering_next_screen_by_clicking_gridvalue(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietCounsellingRequestOp_Table"], 10, "Table was not enabled")
         self.click_element(self.objects['Diet_DietCounsellingRequestOp_Table'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser() 
            
    def selecting_doctor(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestOp_Doctor'], 3, 'doctor list was not visible')
         self.select_from_list_by_index(self.objects['Diet_DietCounsellingRequestOp_Doctor'],'3')
         time.sleep(0.5)
         self.dict['BROWSER'] = self._current_browser()          
          
    def selecting_type(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         #r = int (r) 
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestOp_DietCounsellingType'], 3, 'type was not visible')
         self.select_from_list_by_label(self.objects['Diet_DietCounsellingRequestOp_DietCounsellingType'],"BedSide")
         self.dict['BROWSER'] = self._current_browser()   
         
    def entering_diagnosis(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestOp_Diagnosis'], 3, 'Diagnosis was not visible')
         self.input_text(self.objects['Diet_DietCounsellingRequestOp_Diagnosis'],self.d[r]['Diagnosis'])
         self.dict['BROWSER'] = self._current_browser()   

    def entering_comments(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestOp_Comments'], 3, 'comments was not visible')
         self.input_text(self.objects['Diet_DietCounsellingRequestOp_Comments'],self.d[r]['Comments'])
         self.dict['BROWSER'] = self._current_browser()      
         
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietCounsellingRequestOp_Save'], 3, 'save btn was not enabled')
         self.click_button(self.objects['Diet_DietCounsellingRequestOp_Save'])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestOp_Message'], 3, 'Message was not visible')
         MSG11 = self._get_text(self.objects["Diet_DietCounsellingRequestOp_Message"])
         print MSG11
         self.dict['BROWSER'] = self._current_browser()   
         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()     
        
class InDietCounsellingRequest_IP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietCounselling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()        
    def entering_ipno(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['IPNO'] = "IP13315"
         self.wait_until_element_is_visible(self.objects["Diet_DietCounsellingRequestIp_IPNo"], 10, "ipno was not visible")
         self.input_text(self.objects['Diet_DietCounsellingRequestIp_IPNo'],self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser()  
                  
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietCounsellingRequestIp_Search"], 10, "search btn was not enabled")
         self.click_button(self.objects['Diet_DietCounsellingRequestIp_Search'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
         
    def entering_next_screen_by_clicking_gridvalue(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietCounsellingRequestIp_Table"], 10, "table was not visible")
         self.click_element(self.objects['Diet_DietCounsellingRequestIp_Table'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()     
             
    def selecting_doctor(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestIp_Doctor'], 13, 'doctor list is not visible')
         self.select_from_list_by_index(self.objects['Diet_DietCounsellingRequestIp_Doctor'],'2')
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()          
          
    def selecting_type(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestIp_DietCounsellingType'], 13, 'diet counselling type was not visible')
         self.select_from_list_by_label(self.objects['Diet_DietCounsellingRequestIp_DietCounsellingType'],"BedSide")
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()   
    def entering_diagnosis(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestIp_Diagnosis'], 13, 'diagnosis was not visible')
         self.input_text(self.objects['Diet_DietCounsellingRequestIp_Diagnosis'],self.d[r]['Diagnosis'])
         self.dict['BROWSER'] = self._current_browser()   
    def entering_comments(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestIp_Comments'], 13, 'comments was not visible')
         self.input_text(self.objects['Diet_DietCounsellingRequestIp_Comments'],self.d[r]['Comments'])
         self.dict['BROWSER'] = self._current_browser()      
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietCounsellingRequestIp_Save'], 13, 'save btn was not enabled')
         self.click_button(self.objects['Diet_DietCounsellingRequestIp_Save'])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingRequestIp_Message'], 13, 'Message was not visible')
         MSG12 = self._get_text(self.objects["Diet_DietCounsellingRequestIp_Message"])
         print MSG12
         self.dict['BROWSER'] = self._current_browser()    
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser() 
         
class InDietCounsellingComplete_IP(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietCounselling")         
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 10, "frame was not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser() 
    def entering_ipno(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietCounsellingCompleteIp_IPNo"], 10, "ipno was not visible")
         #self.dict['IPNO']="IP13315"
         self.input_text(self.objects['Diet_DietCounsellingCompleteIp_IPNo'],self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser()                    
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietCounsellingCompleteIp_Search"], 10, "search btn was not enabled")
         self.click_button(self.objects['Diet_DietCounsellingCompleteIp_Search'])
         self.dict['BROWSER'] = self._current_browser()    
    def entering_next_screen_by_clicking_gridvalue(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['Diet_DietCounsellingCompleteIp_Table'], 10, "patient detail in grid was not visible")
         self.click_element(self.objects['Diet_DietCounsellingCompleteIp_Table'])
         self.dict['BROWSER'] = self._current_browser()     
    def selecting_employee(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingCompleteIp_Employee'],10, 'employee list was not visible')
         self.select_from_list_by_index(self.objects['Diet_DietCounsellingCompleteIp_Employee'],'1')
         self.dict['BROWSER'] = self._current_browser()  
         
    def entering_diagnosis(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingCompleteIp_Diagnosis'], 10, 'diagnosis was not visible')
         self.input_text(self.objects['Diet_DietCounsellingCompleteIp_Diagnosis'],self.d[r]['Diagnosis'])
         self.dict['BROWSER'] = self._current_browser()  
         
    def entering_advice(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingCompleteIp_Advice'],10, 'advice was not visible')
         self.input_text(self.objects['Diet_DietCounsellingCompleteIp_Advice'],self.d[r]['Advice'])
         self.dict['BROWSER'] = self._current_browser()       
         
    def entering_remarks(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser() 
         r = int (r)
         self.wait_until_element_is_visible(self.objects['Diet_DietCounsellingCompleteIp_Remarks'],10, 'remarks was not visible')
         self.input_text(self.objects['Diet_DietCounsellingCompleteIp_Remarks'],self.d[r]['Remarks'])
         self.dict['BROWSER'] = self._current_browser()      
         
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.set_selenium_implicit_wait(15)
         self.wait_until_element_is_enabled(self.objects['Diet_DietCounsellingRequestIp_Save'], 10, "save btn was not enabled")
         self.click_button(self.objects['Diet_DietCounsellingRequestIp_Save'])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_DietCounsellingRequestIp_Message"], 10, "Message was not visible")
         MSG12 = self._get_text(self.objects["Diet_DietCounsellingRequestIp_Message"])
         print MSG12
         self.dict['BROWSER'] = self._current_browser() 
         
    def clicking_reject(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['Diet_DietCounsellingRequestIp_Reject'], 10, "reject btn was not enabled")
         self.click_button(self.objects['Diet_DietCounsellingRequestIp_Reject'])
         self._handle_alert(True)
         self.wait_until_element_is_visible(self.objects["Diet_DietCounsellingRequestIp_Message"], 10, "Message was not visible")
         MSG13 = self._get_text(self.objects["Diet_DietCounsellingRequestIp_Message"])
         print MSG13
         self.dict['BROWSER'] = self._current_browser()          
         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()
 
class InDietItemRequestPrint(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()        
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 30, "frame was not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         time.sleep(15)
         self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestPrint_IPNo'], 30, "ipno was not visible")
         self.input_text(self.objects['Diet_DietItemRequestPrint_IPNo'],str(self.dict['IPNO']))
         self.dict['BROWSER'] = self._current_browser()
   
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestPrint_Search"], 30, "search btn was not enabled")
         self.click_button(self.objects['Diet_DietItemRequestPrint_Search'])
         time.sleep(2)
         self.click_button(self.objects['Diet_DietItemRequestPrint_Search'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
         
    def entering_next_screen_by_clicking_gridvalue(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestPrint_Table'], 30, 'table is not visible')
         self.click_element(self.objects['Diet_DietItemRequestPrint_Table'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
         
    def selecting_printbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["Diet_DietItemRequestPrint_CopyPrint"], 30, "copy print was not enabled")
         self.click_button(self.objects['Diet_DietItemRequestPrint_CopyPrint'])
         self.dict['BROWSER'] = self._current_browser() 
         
    def getting_message(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['Diet_DietItemRequestPrint_Message'], 30, 'message was not visible')
         MSG14 = self._get_text(self.objects["Diet_DietItemRequestPrint_Message"])
         print MSG14
         self.dict['BROWSER'] = self._current_browser() 
         
    def unselecting_frame(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()         
'''         
FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//dietary/DietItemCopyRequestSearch.aspx')

InDietItemRequestPrint().entering_ipno()
InDietItemRequestPrint().clicking_search()
InDietItemRequestPrint().entering_next_screen_by_clicking_gridvalue()
InDietItemRequestPrint().clicking_print()'''
       
         

class InDietReturnAfterIssue(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DietReturn")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["Diet_MainFrame"], 30, "frame is not visible")
         self.select_frame(self.objects['Diet_MainFrame'])
         #time.sleep(2)
         self.input_text(self.objects['Diet_DietReturnAfterIssue_IPNo'], self.dict['IPNO'])
         self.dict['BROWSER'] = self._current_browser()
         
    def clicking_search(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #time.sleep(1)
         self.wait_until_element_is_enabled(self.objects["Diet_DietReturnAfterIssue_Search"], 30, "search is not visible")
         self.click_button(self.objects["Diet_DietReturnAfterIssue_Search"])
         self.dict['BROWSER'] = self._current_browser()     
         #time.sleep(2)
         
    def entering_next_screen_by_clicking_gridvalue(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(1)
         self.wait_until_element_is_visible(self.objects["Diet_DietReturnAfterIssue_Table"], 30, "IP no in search grid is not visible")
         self.click_element(self.objects["Diet_DietReturnAfterIssue_Table"])
         self.dict['BROWSER'] = self._current_browser()  
    
    def clicking_checkbox(self): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(2)
         self.wait_until_element_is_visible(self.objects['Diet_DietItemReturn_CheckBox'], 30, 'checkbox is not visible')
         self.click_element(self.objects['Diet_DietItemReturn_CheckBox'])
         self.dict['BROWSER'] = self._current_browser()         
                  
    def selecting_reason(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_from_list(self.objects['Diet_DietReturnAfterIssue_Reason'],self.d[r]['Reason'])
         self.dict['BROWSER'] = self._current_browser()
         
    def entering_remarks(self,r):
         r = int (r)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.wait_until_element_is_visible(self.objects['Diet_DietReturnAfterIssue_Remarks'], 10, 'remarks is not visible')
         self.input_text(self.objects['Diet_DietReturnAfterIssue_Remarks'],self.d[r]['Remarks']) 
         self.dict['BROWSER'] = self._current_browser()
            
    def clicking_cancelbutton(self):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.click_button(self.objects['Diet_DietReturnAfterIssue_ItemCancellation']) 
         self._handle_alert(True)
         time.sleep(1)
         MSG15 = self._get_text(self.objects["Diet_DietReturnAfterIssue_Message"])
         print MSG15 
         self.dict['BROWSER'] = self._current_browser() 
         
    def unselecting_frame(self): 
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()    
         self.unselect_frame()
         self.dict['BROWSER'] = self._current_browser()     
            
        
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("DietReturn")
FromConfigFile().logging("Diet")
FromConfigFile().loading_menu_of_link('//Dietary/dIETARYReturnPatsearch.aspx')
r = 1          
InDietReturnAfterIssue().entering_ipno()
InDietReturnAfterIssue().clicking_search()
InDietReturnAfterIssue().entering_next_screen_by_clicking_gridvalue()
InDietReturnAfterIssue().clicking_checkbox()
InDietReturnAfterIssue().selecting_reason(r)
InDietReturnAfterIssue().entering_remarks(r)
InDietReturnAfterIssue().clicking_cancelbutton()'''

class InWardHome_AssignToBed(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InAssgToBed_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        self.dict['WARD-NAME']='WARD'
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 20, 'No data present')
        #self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_AssignToBed(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(9)
        if self._is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]'):
           self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]')
           self.dict['AssgnToBed_Msg'] = self.get_alert_message()
           print self.dict['AssgnToBed_Msg']
           self.dict['BROWSER'] = self._current_browser()
        else:
           pass 
        self.dict['BROWSER'] = self._current_browser()


class InWardHome_WardOrders(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    
    def InWardOrders_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        #print self.dict['WARD-NAME']
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_IPNO(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "0000011154"
        time.sleep(7)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 25, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardorders_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_OrdersTab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        if self._is_visible('xpath=//*[@id="select2-drop"]//./input'):
           self.click_element('xpath=//*[@id="select2-drop"]//./input')
           #self.input_text('xpath=//*[@id="select2-drop"]//./input', "test")
           self.press_key('xpath=//*[@id="select2-drop"]//./input', '\\09')
        else:
           pass
        #if self._is_visible('xpath=//*[@id="select2-results-1"]//li'):
        #   self.press_key('xpath=//*[@id="select2-results-1"]//li', '\\09')
        #else:
        #   pass
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_Orders'], 30, 'Order Page is not loaded')
        time.sleep(3)
        self.click_element(self.objects['WARD_Orders'])
        self.dict['BROWSER'] = self._current_browser()
    def adding_diet_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['rad_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['rad_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_standard_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_culture_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_culture_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_pathology_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_pathology_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 10, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
        
