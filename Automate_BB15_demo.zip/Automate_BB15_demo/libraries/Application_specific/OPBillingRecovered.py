import sys
from Selenium2Library import Selenium2Library
'''sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')'''
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import pyautogui

class InOPBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def InOPBilling_ScreenshotOnFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624655"
        self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 10, "opbilling regno. was not visible")
        self.click_element(self.objects['OPB_OpBilling_RegNo'])
        self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 10, "opbilling regno. was not visible")
        self.input_text(self.objects["OPB_OpBilling_RegNo"],str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OpBilling_Search'], 10, "opbilling search was not visible")
        self.click_button(self.objects['OPB_OpBilling_Search'])
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceName'], 30, 'OP billing page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling standard service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_standard_service'])
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['Lab_standard_service'])+'"]', 30, 'searched standard service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_standard_service'])+'"]')
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling culture service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_culture_service'])
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['Lab_culture_service'])+'"]', 30, 'searched culture service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_culture_service'])+'"]')
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling pathology service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['Lab_pathology_service'])
        #time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['Lab_pathology_service'])+'"]', 30, 'searched pathology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['Lab_pathology_service'])+'"]')
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_glucometer_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling glucometer service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['lab_glucometer_service'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['lab_glucometer_service'])+'"]', 30, 'searched glucometer service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['lab_glucometer_service'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()        
    def adding_lab_peripheral_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling peripheral service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['lab_peripheral_service'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['lab_peripheral_service'])+'"]', 30, 'searched peripheral service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['lab_peripheral_service'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling  rad service search was not visible')
        self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['rad_service'])
        #time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['rad_service'])+'"]', 30, 'searched rad service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['rad_service'])+'"]')
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        #self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling  card service search was not visible')
        if self._is_visible('xpath=//*[@id="s2id_autogen16_search"]'):
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['card_service'])
        else:
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
            time.sleep(1)
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['card_service'])
        
        #time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['card_service'])+'"]', 30, 'searched card service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['card_service'])+'"]')
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_physio_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        if self._is_visible('xpath=//*[@id="s2id_autogen16_search"]'):
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['physio_service'])
        else:
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling  physio service search was not visible')
            self.input_text('xpath=//*[@id="s2id_autogen16_search"]', self.d[r]['physio_service'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.d[r]['physio_service'])+'"]', 30, 'searched physio service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.d[r]['physio_service'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def pressing_tabkey(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling  service search was not visible')
        self.press_key('xpath=//*[@id="s2id_autogen16_search"]', '\\09')
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 30, 'remarks was not visible')
        self.input_text('xpath=//*[@id="txtRemarks"]', 'test')
        #time.sleep(1) 
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.click_link(self.objects['OPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Save'], 30, 'op billing service save was not visible')
        self.click_element(self.objects['OPB_OPBilling_Services_Save'])
        #time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPRefundRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBRefund")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['REGNO'] = "625189"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Refund_Regno'], 20, "opbill refund regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Refund_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Refund_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_refundreq_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList1"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList1"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        #self.wait_until_element_is_visible('xpath=//button[@class="toast-close-button"]', 10, "info message at the middle of page was not visible")
        #self.click_button('xpath=//button[@class="toast-close-button"]')
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Refund_checkbox'], 10, "checkbox was not visible")
        try:
         self.click_element(self.objects['OPB_OPRefund_Refund_checkbox'])
        except UnexpectedAlertPresentException:
         print "inside alert flow"
         self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_Reason'], 10, "reason was not visible")
        self.select_from_list_by_index(self.objects['OPB_OPRefund_Refund_Reason'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_Remarks'], 10, "remarks was not visible")
        self.input_text(self.objects['OPB_OPRefund_Refund_Remarks'], self.d[r]['OPB_Refund_Remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_RequestBtn'], 10, "req btn was not visible")
        '''try:
          self.click_button(self.objects['OPB_OPRefund_Refund_RequestBtn'])
          self._handle_alert(True)
          #requestmsg = self.get_alert_message()
          #print requestmsg
          #time.sleep(1)
        except UnexpectedAlertPresentException:
            #self._handle_alert(True)
            requestmsg = self.get_alert_message()
            print requestmsg
        #self._handle_alert(True)'''
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPRefundApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624974"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Approve_Regno'], 20, "opbill approve regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Approve_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Approve_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_approve_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Approve_Approvebtn'], 10, "approve btn was not visible")
        self.click_button(self.objects['OPB_OPRefund_Approve_Approvebtn'])
        approvemsg = self.get_alert_message()
        print approvemsg
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPRefundIssue(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624975"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Issue_Regno'], 20, "opbill issue regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Issue_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Issue_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_issue_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_refundbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Issue_RefundBtn'], 10, "refund btn was not visible")
        self.click_button(self.objects['OPB_OPRefund_Issue_RefundBtn'])
        self._handle_alert(True)
        Issuemsg = self.get_alert_message()
        print Issuemsg
        self.dict['BROWSER'] = self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()