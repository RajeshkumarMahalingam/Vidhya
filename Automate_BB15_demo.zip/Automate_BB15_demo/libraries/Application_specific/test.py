for i in range(1,5):
    print i


''''n = "IP 562365"

print n[3:]'''




'''def datePicker(self,loc, r, sheetname):
        self.set_selenium_implicit_wait(10)
        r = int(r)
        date = self.d[r]['birthreg_date']
        today = date.today()
        print today.strftime('%d/%B/%Y')
        #print date
        print "today", today
        print type(today)
        
        picdate = date
        print picdate.strftime('%d/%B/%Y')
        
        print "picdate", picdate
        print type(picdate)
        
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        loc = 'xpath=//*[@id="txtRDt"]'
        self.click_element(loc)
        if picdate > today:        
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')              
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="next"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="next"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[(text()="'+day+'")]')
        else:
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="prev"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="prev"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[(text()="'+day+'")]')
'''