import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InPayMode(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['IPB_Paymode'], 30, 'IPB paymode was not visible')
        #self.click_link(self.objects['OPB_Paymode'])
        self.click_element(self.objects['IPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.select_frame(self.objects['IPB_Paymode_Frame'])
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['IPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['IPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['IPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InIPBillGeneration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def InIPBillGen_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(2)   
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000010748"
        self.click_element(self.objects['IPB_IP_Bill_Generation_Page'])
        self.input_text(self.objects['IPB_IP_Bill_Generation_IPNo'], str(self.dict['IPNO']))    
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_IPPatient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['IPB_IP_Bill_Generation_Search'])
        time.sleep(1)
        #self.dict['IPNO'] = "0000010748"
        self.wait_until_page_contains_element('xpath=//*[(text()="'+str(self.dict['IPNO'])+'")]', 30, 'No data available')
        self.click_element('xpath=//*[(text()="'+str(self.dict['IPNO'])+'")]')
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['IPB_IP_Bill_Generation_Page'], 30, 'IP Bill Generation page is not loaded')
        self.wait_until_element_is_visible('xpath=//*[@id="tblSummaryBill"]//tr[1]', 15, 'service name was not get loaded in patient grid')
        self.wait_until_element_is_enabled(self.objects['IPB_IP_Bill_Generation_Save'],7, 'Save button is not enabled')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        self.click_element(self.objects['IPB_IP_Bill_Generation_Save'])
        self._close_alert()
        time.sleep(7)
        self.dict['BROWSER'] =  self._current_browser() 
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()     
        
        
class InReceiptGeneration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_ReceiptGen")
    def InReceiptGen_ScreenshotonFailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(3)   
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip14444"
        self.wait_until_element_is_visible(self.objects['IPB_IP_Receipt_Generation_IPNo'], 30, "ipno was not visible")
        #self.click_element(self.objects['IPB_IP_Receipt_Generation_Page'])
        self.input_text(self.objects['IPB_IP_Receipt_Generation_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['IPB_IP_Receipt_Generation_Search'], 30, "search btn was not visible")
        self.click_button(self.objects['IPB_IP_Receipt_Generation_Search'])
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_IP_Patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000011072"
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient details was not visible in grid")
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient details was not visible in grid")
        self.click_element('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tblSummaryBill"]//tr[1]', 30, "summary bill details was not visible in grid")
        self.wait_until_element_is_visible('xpath=//*[@id="tblSummaryBill"]//tr[1]', 30, "summary bill details was not visible in grid")
        self.wait_until_element_is_visible('xpath=//*[@id="paymentDetailLink"]', 30, "payment detail link was not visible")
        self.click_element('xpath=//*[@id="paymentDetailLink"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame('xpath=//*[@id="iframe1"]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[text()="PAYMENT TYPE "]', 30, 'Payment type page is not loaded')        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="savecashdetails"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="savecashdetails"]')
        time.sleep(1)
        PaymodeSaveMsg = self.get_alert_message()
        print PaymodeSaveMsg
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="p-r-15 actions"]//button[@id="btnSave"]', 40, "ipbilling save btn was not enabled")
        self.click_element('xpath=//*[@class="p-r-15 actions"]//button[@id="btnSave"]')
        time.sleep(2)
        ReceiptGenMsg = self.get_alert_message()
        print ReceiptGenMsg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipbilling_withconcession_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="p-r-15 actions"]//button[@id="btnSave"]', 40, "ipbilling save btn was not enabled")
        self.click_element('xpath=//*[@class="p-r-15 actions"]//button[@id="btnSave"]')
        time.sleep(2)
        self._handle_alert(True)
        time.sleep(0.5)
        ReceiptGenMsg = self.get_alert_message()
        print ReceiptGenMsg
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_concessiontab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession'], 30, "cs tab was not visible")
        self.click_element(self.objects['IPB_Receipt_Generation_Concession'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cssourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession_Source_Name'], 30, "cs source was not visible")
        self.click_element(self.objects['IPB_Receipt_Generation_Concession_Source_Name'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_authorization(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession_Authorization'], 30, "cs authorization was not visible")
        self.click_element(self.objects['IPB_Receipt_Generation_Concession_Authorization'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()          
    def entering_csamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession_Amount'], 30, "os amount was not visible")
        self.input_text(self.objects['IPB_Receipt_Generation_Concession_Amount'], str(self.d[r]['csamount']))
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_cstype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession_Type'], 30, "cs type was not visible")
        self.select_from_list_by_label(self.objects['IPB_Receipt_Generation_Concession_Type'],self.d[r]['cstype'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_csremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Concession_Remarks'], 30, "cs remarks was not visible")
        self.clear_element_text(self.objects['IPB_Receipt_Generation_Concession_Remarks'])
        self.input_text(self.objects['IPB_Receipt_Generation_Concession_Remarks'], self.d[r]['csremarks'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_concessionapplybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_Receipt_Generation_Concession_Apply'], 30, "cs apply btn was not visible")
        self.click_button(self.objects['IPB_Receipt_Generation_Concession_Apply'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_outstandingtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Outstanding'], 30, "os tab was not visible")
        self.click_element(self.objects['IPB_Receipt_Generation_Outstanding'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ossourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Outstanding_SourceName'], 30, "os source was not visible")
        self.click_element(self.objects['IPB_Receipt_Generation_Outstanding_SourceName'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "os source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()   
    def entering_osamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Outstanding_Amount'], 30, "os amount was not visible")
        self.input_text(self.objects['IPB_Receipt_Generation_Outstanding_Amount'], str(self.d[r]['osamount']))
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_osaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_Receipt_Generation_Outstanding_Add'], 30, "os add btn was not visible")
        self.click_button(self.objects['IPB_Receipt_Generation_Outstanding_Add'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_osremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_Receipt_Generation_Outstanding_OSRemarks'], 30, "cs remarks was not visible")
        self.clear_element_text(self.objects['IPB_Receipt_Generation_Outstanding_OSRemarks'])
        self.input_text(self.objects['IPB_Receipt_Generation_Outstanding_OSRemarks'], self.d[r]['osremarks'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InServiceBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(3)    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_the_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "2926"
        self.wait_until_element_is_visible(self.objects['IPB_ServiceBilling_Regno'], 30, "regno was not visible")
        self.input_text(self.objects['IPB_ServiceBilling_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_ServiceBilling_Regno'], '\\13')
        self.dict['BROWSER'] =  self._current_browser()
    def entering_into_servicebillingpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyPatList"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "service billing page was not visible")
        self.click_element('xpath=//*[@id="tbodyPatList"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnSave"]', 30, "search btn was not visible")
        self.click_button('xpath=//*[@id="btnSave"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_servicename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 10, "input text for service name was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "service name list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        else:
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 30, "service name was not visible")
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "input text for service name was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[3]', 30, "service name list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[3]')
        self.dict['BROWSER'] =  self._current_browser()
    def entering_diet_servicename(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen3_search"]', 30, "diet service was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen3_search"]', self.d[r]["diet_service"])
        time.sleep(2)
        pyautogui.hotkey('enter')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="action"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@class="action"]//button[@id="btnSave"]')
        try:
            #self._handle_alert(True)#commented this line for release server
            #self._handle_alert(True)#commented this line for release server
            ## Added below lines for release server###############################
            self._handle_alert(True)
            time.sleep(7)#Release server
            #self._handle_alert(True)
            Msg = self.get_alert_message(True)
            print "Msg", Msg
            ##################################################################
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()    
    
class InAdvanceTransfer(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_AdvTransfer")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000425"
        #self.dict['REGNO'] = "1862"
        self.wait_until_element_is_visible(self.objects['IPB_AdvanceTransfer_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['IPB_AdvanceTransfer_RegNo'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_AdvanceTransfer_RegNo'], '\\13')
        self.dict['BROWSER'] =  self._current_browser()
    def entering_into_advancetransferpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="tblAdvSearch"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "advance transfer page was not visible")
        self.click_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_AdvanceTransfer_IPNoCombobox'], 30, "ipno was not visible")
        self.select_from_list_by_label(self.objects['IPB_AdvanceTransfer_IPNoCombobox'], str(self.dict['IPNO']))
        self.dict['BROWSER'] =  self._current_browser()    
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_AdvanceTransfer_Remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['IPB_AdvanceTransfer_Remarks'], str(self.d[r]['remarks']))
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_AdvanceTransfer_checkbox'], 30, "checkbox was not visible")
        self.click_element(self.objects['IPB_AdvanceTransfer_checkbox'])
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_transferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_AdvanceTransfer_transferbtn'], 30, "transfer btn was not enabled")
        self.click_button(self.objects["IPB_AdvanceTransfer_transferbtn"])
        time.sleep(1)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()  
    def getmessage_after_transfer(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_page_contains_element('xpath=//*[@id="toast-container"]', 20, 'issue message was not visible in page')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InAdvancePayment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_Advpayment")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_MainFrame'], 20, "IP billing frame was not visible")
        self.select_frame(self.objects['IPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625614"
        #self.dict['IPNO'] = "604"
        #self.wait_until_element_is_visible('xpath=//*[@id="divchkOPMultipleVisitPackage"]/label', 10, "page not loaded completely")
        self.wait_until_element_is_visible(self.objects['IPB_AdvancePayment_IPNo'], 20, "ipno was not visible")
        self.input_text(self.objects["IPB_AdvancePayment_IPNo"],str(self.dict['IPNO']))
        self.press_key(self.objects["IPB_AdvancePayment_IPNo"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in advance payment page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def entering_advanceamnt(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.dict['REGNO'] = "624975"
        self.wait_until_element_is_visible(self.objects['IPB_AdvancePayment_Amount'], 30, "advance amnt was not visible")
        self.input_text(self.objects["IPB_AdvancePayment_Amount"],str(self.d[r]['advanceamnt']))
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_billtype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_AdvancePayment_BillType'], 30, "bill type was not visible")
        self.select_from_list_by_label(self.objects["IPB_AdvancePayment_BillType"], self.d[r]['billtype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymodebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_enabled('xpath=//*[@id="paymentDetailLink"]', 30, 'OPB paymode link was not visible')
        self.click_button('xpath=//*[@id="paymentDetailLink"]')
        #self.click_element(self.objects['OPB_Paymode'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_AdvancePayment_Savebtn'], 20, "save btn was not enabled")
        self.click_button(self.objects["IPB_AdvancePayment_Savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InIPPostConcession(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_PostConcession")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_MainFrame'], 15, "IP billing frame was not visible")
        self.select_frame(self.objects['IPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "606595"
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Regno'], 30, "regno was not visible")
        self.input_text(self.objects['IPB_IPPostConcession_Regno'],str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_IPPostConcession_Regno'], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "216"
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tblPatDetail"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 20, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_concessiontab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Concession'], 30, "cs tab was not visible")
        self.click_element(self.objects['IPB_IPPostConcession_Concession'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cssourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcSourceName"]/a', 50, "cs source was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcSourceName"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 50, "cs source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_authorization(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcAuthorization"]/a', 50, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcAuthorization"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 50, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()          
    def entering_csamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Concession_Amount'], 50, "os amount was not visible")
        self.input_text(self.objects['IPB_IPPostConcession_Concession_Amount'], str(self.d[r]['csamount']))
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_cstype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Concession_Type'], 30, "cs type was not visible")
        self.select_from_list_by_label(self.objects['IPB_IPPostConcession_Concession_Type'],self.d[r]['cstype'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_csremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Concession_remarks'], 40, "cs remarks was not visible")
        self.clear_element_text(self.objects['IPB_IPPostConcession_Concession_remarks'])
        self.input_text(self.objects['IPB_IPPostConcession_Concession_remarks'], self.d[r]['csremarks'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_concessionapplybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPPostConcession_Concession_Apply'], 40, "cs apply btn was not visible")
        self.click_button(self.objects['IPB_IPPostConcession_Concession_Apply'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['IPB_IPPostConcession_Paymode'], 30, 'IPB post concession paymode was not visible')
        self.click_element(self.objects['IPB_IPPostConcession_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPPostConcession_Concession_Savebtn'], 40, "save btn was not enabled")
        self.click_button(self.objects['IPB_IPPostConcession_Concession_Savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()         
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InServiceCancellation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_MainFrame'], 10, "IP billing frame was not visible")
        self.select_frame(self.objects['IPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625766"
        self.wait_until_element_is_visible(self.objects['IPB_ServiceCancellation_Regno'], 20, "regno was not visible")
        self.input_text(self.objects['IPB_ServiceCancellation_Regno'],str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_ServiceCancellation_Regno'], '\\13')
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "610"
        self.wait_until_page_contains_element('xpath=//*[@id="tbodyPatList"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tbodyPatList"]/tr/*[text()="'+str(self.dict['IPNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cancellationtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['IPB_ServiceCancellation_cancellationtab'], 30, "cancellation tab was not visible")
        self.click_element(self.objects['IPB_ServiceCancellation_cancellationtab'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['IPB_ServiceCancellation_checkbox'], 30, "checkbox was not visible")
        self.click_element(self.objects['IPB_ServiceCancellation_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_ServiceCancellation_Remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['IPB_ServiceCancellation_Remarks'],"Not Applicable")
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_ServiceCancellation_Savebtn'], 30, "save btn was not enabled")
        self.click_element(self.objects["IPB_ServiceCancellation_Savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InIPBillCancellation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_BillCancellation")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_MainFrame'], 20, "IP billing frame was not visible")
        self.select_frame(self.objects['IPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "622664"
        self.wait_until_element_is_visible(self.objects['IPB_IPBillCancellation_RegNo'], 20, "regno was not visible")
        self.input_text(self.objects['IPB_IPBillCancellation_RegNo'],str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_IPBillCancellation_RegNo'], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "0000012378"
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient not visible in search result in page")
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['IPNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPBillCancellation_Remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['IPB_IPBillCancellation_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPBillCancellation_Savebtn'], 30, "save btn was not enabled")
        self.click_element(self.objects["IPB_IPBillCancellation_Savebtn"])
        #self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]',20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InIPBillPrintCopy(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_BillprintCopy_Regno'], 30, "regno was not visible")
        #self.dict['REGNO'] = "621743"
        self.input_text(self.objects['IPB_BillprintCopy_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_BillprintCopy_Regno'], '\\13')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def getting_billno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_BillprintCopy_Billno'], 30, "billno was not visible")
        BillNoWithDate = self.get_text(self.objects['IPB_BillprintCopy_Billno'])
        print "BillNoWithDate", BillNoWithDate
        self.dict['BROWSER'] = self._current_browser()   
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()   
    
class InIPCreditLimit(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_CreditLimit")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])    
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatDetail"]//tr', 30, "patients in search grid was not visible")
        #above wait given bze table content takes time to load before that regno field gets loaded
        self.wait_until_element_is_visible(self.objects['IPB_IPCreditLimit_Regno'], 30, "regno was not visible")
        #self.dict['REGNO'] = "625605"
        self.input_text(self.objects['IPB_IPCreditLimit_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_IPCreditLimit_Regno'], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_amount(self,r):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPCreditLimit_Amount'], 30, "amount was not visible")
        self.click_element(self.objects['IPB_IPCreditLimit_Amount'])
        self.clear_element_text(self.objects['IPB_IPCreditLimit_Amount'])
        self.input_text(self.objects['IPB_IPCreditLimit_Amount'], str(self.d[r]['amount']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_IPCreditLimit_checkbox'], 30, "checkbox was not visible")
        self.click_element(self.objects['IPB_IPCreditLimit_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPCreditLimit_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["IPB_IPCreditLimit_Savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
    
class InPackageAssignIP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_PackageAssignIP_Regno'], 20, "regno was not visible")
        #self.dict['REGNO'] = "625605"
        self.input_text(self.objects['IPB_PackageAssignIP_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_PackageAssignIP_Regno'], '\\13')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "600"
        self.wait_until_page_contains_element('xpath=//*[@id="tbodyPatList"]//td[text()="'+str(self.dict['IPNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tbodyPatList"]//td[text()="'+str(self.dict['IPNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_package(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_PackageAssignIP_Packagename'], 30, "package name was not visible")
        self.click_element(self.objects['IPB_PackageAssignIP_Packagename'])
        self.wait_until_element_is_visible('xpath=//*[@id="cboPackage_Header"]/..//li[2]', 30, "package name lists was not visible")
        self.click_element('xpath=//*[@id="cboPackage_Header"]/..//li[2]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_PackageAssignIP_Doctor'], 30, "doctor was not visible")
        self.click_element(self.objects['IPB_PackageAssignIP_Doctor'])
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor_cboDoctor_Header"]/..//li[2]', 30, "doctor lists was not visible")
        self.click_element('xpath=//*[@id="cboDoctor_cboDoctor_Header"]/..//li[2]')
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['IPB_PackageAssignIP_Doctor'], 30, "doctor was not visible")
        self.click_element(self.objects['IPB_PackageAssignIP_Doctor'])
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor_cboDoctor_Header"]/..//li[3]', 30, "doctor lists was not visible")
        self.click_element('xpath=//*[@id="cboDoctor_cboDoctor_Header"]/..//li[3]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_PackageAssignIP_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["IPB_PackageAssignIP_Savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()        
        
class InOutstandingPayment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_OustandingPayment")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_OutstandingPayment_Regno'], 20, "regno was not visible")
        #self.dict['REGNO'] = "625701"
        self.input_text(self.objects['IPB_OutstandingPayment_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_OutstandingPayment_Regno'], '\\13')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+str(self.dict['REGNO'])+'"]', 20, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 20, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_OutstandingPayment_checkbox'], 20, "checkbox was not visible")
        self.click_element(self.objects['IPB_OutstandingPayment_checkbox'])
        self.dict['BROWSER'] = self._current_browser()     
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_OutstandingPayment_remarks'], 20, "remarks was not visible")
        self.input_text(self.objects['IPB_OutstandingPayment_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_OutstandingPayment_paymode'], 20, "paymode was not visible")
        self.select_from_list_by_label(self.objects['IPB_OutstandingPayment_paymode'], self.d[r]['paymode'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_OutstandingPayment_Savebtn'], 20, "save btn was not enabled")
        self.click_button(self.objects['IPB_OutstandingPayment_Savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        
class InIPConcessionApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_ConcessinApproval")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_IPConcessionApproval_Regno'], 20, "regno was not visible")
        #self.dict['REGNO'] = "621923"
        self.input_text(self.objects['IPB_IPConcessionApproval_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_IPConcessionApproval_Regno'], '\\13')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not visible in search result page")
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in description was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_IPConcessionApproval_checkboxall'], 30, "checkbox all was not visible")
        self.click_element(self.objects['IPB_IPConcessionApproval_checkboxall'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['IPB_IPConcessionApproval_remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['IPB_IPConcessionApproval_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPConcessionApproval_approvebtn'], 30, "approve btn was not enabled")
        self.click_button(self.objects["IPB_IPConcessionApproval_approvebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()          
        
class InIPConcessionCancellation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("IPB_ConcessinApproval")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['IPB_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['IPB_IPConcessionCancellation_Regno'], 20, "regno was not visible")
        #self.dict['REGNO'] = "621923"
        self.input_text(self.objects['IPB_IPConcessionCancellation_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['IPB_IPConcessionCancellation_Regno'], '\\13')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not visible in search result in page")
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not visible in search result")
        self.click_element('xpath=//*[@id="tblPatDetail"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in description was not visible")
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['IPB_IPConcessionCancellation_Delete'], 30, "Delete btn was not enabled")
        self.click_element(self.objects["IPB_IPConcessionCancellation_Delete"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 20, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        