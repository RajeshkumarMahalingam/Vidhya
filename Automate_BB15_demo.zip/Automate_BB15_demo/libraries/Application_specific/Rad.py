import sys
from Selenium2Library import Selenium2Library
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Rad")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 20, "Rad mainframe was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def searching_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        if self._is_visible(self.objects['RAD_Request_Approve_RegNo']):
                self.wait_until_page_contains_element(self.objects['RAD_Request_Approve_RegNo'], 20, "Rad Request approve regno was not visible")
                self.input_text(self.objects['RAD_Request_Approve_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['RAD_Request_Approve_Search'], 20, "Rad request search was not visible")
                self.click_button(self.objects['RAD_Request_Approve_Search'])
                time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Request_Approve_CheckBox'], 20, "Rad request approve checkbox was not visible")
        self.click_element(self.objects['RAD_Request_Approve_CheckBox'])
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestreceive_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Request_Approve_Request_Receive'], 20, "Request receive button was not visible")
        self.click_element(self.objects['RAD_Request_Approve_Request_Receive'])
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message_afterrequestreceive(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Request_Approve_Message'], 30, 'Record was not saved')
        RadReqReceiveMsg = self._get_text(self.objects['RAD_Request_Approve_Message'])
        print RadReqReceiveMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Rad")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 20, "In res entry rad mainframe was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible(self.objects['RAD_Result_Entry_RegNo']):
                self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_RegNo'], 20, "In res entry rad regno was not visible")
                self.input_text(self.objects['RAD_Result_Entry_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_Search'], 20, "In res entry rad search button was not visible")
                self.click_button(self.objects['RAD_Result_Entry_Search'])
                time.sleep(2)
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 20, "In res entry rad search button was not visible")
                self.click_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
                time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.wait_until_page_contains_element('xpath=//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]', 20, 'No Tests available')
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 20, 'regno label was not available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_entry_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="tbltbdy"]//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]', 20, 'result entry was not available')
        self.click_element('xpath=//*[@id="tbltbdy"]//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]')
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_radiologist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_page_contains_element(self.objects['RAD_Result_Entry_Radiologist'], 20, 'radiologist was not visible')
        self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_Radiologist'], 20, 'radiologist was not visible')        
        self.select_from_list_by_index(self.objects['RAD_Result_Entry_Radiologist'], '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_template(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_Template'], 20, 'Template was not visible')
        self.select_from_list_by_index(self.objects['RAD_Result_Entry_Template'], '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_DoneByDoctor_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_DoneByDoc'], 20, 'DoneByDoc was not visible')
        self.select_from_list_by_index(self.objects['RAD_Result_Entry_DoneByDoc'], '2')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_enabled(self.objects['RAD_Result_Entry_Save'], 20, 'Save btn was not visible')
        self.click_element(self.objects['RAD_Result_Entry_Save'])
        try:
            self.wait_until_element_is_visible(self.objects['RAD_Result_Entry_Message'], 30, 'Record was not saved')
            RadResultEntryMsg = self._get_text(self.objects['RAD_Result_Entry_Message']) 
            print RadResultEntryMsg
        except:
            pass       
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Rad")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def validate_patient_test(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626577"
        if self._is_visible('xpath=//*[@id="tbltbdy"]//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]'):
            self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, 'regno label was not visible')
            Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
            if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
            else:
                pass
        elif self._is_visible(self.objects['RAD_Result_Approval_RegNo']):
             self.input_text(self.objects['RAD_Result_Approval_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['RAD_Result_Approval_Search'], 10, 'search btn was not enabled')
             self.click_button(self.objects['RAD_Result_Approval_Search'])     
             self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass
        self.dict['BROWSER'] = self._current_browser()

    
    def entering_into_request_details_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        if self._is_visible(self.objects['RAD_Result_Approval_RegNo']):
                self.input_text(self.objects['RAD_Result_Approval_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['RAD_Result_Approval_Search'], 10, "search btn was not visible")
                self.click_button(self.objects['RAD_Result_Approval_Search'])
                time.sleep(2)
                self.wait_until_element_is_visible('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 10, "REGNO was not visible")
                self.click_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
                time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 20, 'No regno label was not available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_approve_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(3)
        self.wait_until_page_contains_element('xpath=//*[@id="tbltbdy"]//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]', 20, "rad service name was not visible")
        self.click_element('xpath=//*[@id="tbltbdy"]//*[(text()="'+self.dict['RADIOLOGY_SERVICE']+'")]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approve_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Approval_Approve'], 30, 'approval btn was not saved')
        self.click_element(self.objects['RAD_Result_Approval_Approve'])
        self.wait_until_element_is_visible(self.objects['RAD_Result_Approval_Message'], 30, 'Record was not saved')    
        RadResultApprMsg = self._get_text(self.objects['RAD_Result_Approval_Message'])
        print RadResultApprMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultDispatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Rad")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_dispatch_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        #self.dict['REGNO'] = "643329"
        if self._is_visible(self.objects['RAD_Result_Dispatch_RegNo']):
                self.input_text(self.objects['RAD_Result_Dispatch_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_Search'], 10, "Search btn was not visible")
                self.click_button(self.objects['RAD_Result_Dispatch_Search'])
                time.sleep(1)
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 10, "regno was not visible")
                self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
                time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_report_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element(self.objects['RAD_Result_Dispatch_Report_checkbox'], 10, "report checkbox was not visible")
        self.select_checkbox(self.objects['RAD_Result_Dispatch_Report_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_xray_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_xray_checkbox'], 10, "x-ray checkbox was not visible")
        self.select_checkbox(self.objects['RAD_Result_Dispatch_xray_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_DigitalMedia_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_DigitalMedia_checkbox'], 10, "Digital media checkbox was not visible")
        self.select_checkbox(self.objects['RAD_Result_Dispatch_DigitalMedia_checkbox'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_remarks'], 10, "remarks was not visible")
        self.input_text(self.objects['RAD_Result_Dispatch_remarks'], self.d[r]['Remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ResultDispatch_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_ResultDispatch'], 30, 'Result Dispatch btn was not visible')
        self.click_button(self.objects['RAD_Result_Dispatch_ResultDispatch'])
        #time.sleep(2)
        time.sleep(5)
        self._handle_alert(True)
        self.wait_until_element_is_visible(self.objects['RAD_Result_Dispatch_Message'], 30, 'Record was not saved')    
        RadResultDispMsg = self._get_text(self.objects['RAD_Result_Dispatch_Message'])
        print RadResultDispMsg
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
class InApprovalRevert(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 20, "Rad mainframe was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def searching_patient_record(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        if self._is_visible(self.objects['RAD_Approval_Revert_RegNo']):
                self.wait_until_page_contains_element(self.objects['RAD_Approval_Revert_RegNo'], 20, "regno was not visible")
                self.input_text(self.objects['RAD_Approval_Revert_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['RAD_Approval_Revert_Search'], 20, "search was not visible")
                self.click_button(self.objects['RAD_Approval_Revert_Search'])
                time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Approval_Revert_Checkbox'], 20, "checkbox was not visible")
        self.click_element(self.objects['RAD_Approval_Revert_Checkbox'])
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestrevertbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['RAD_Approval_Revert_Request_Revert'], 20, "Request revert button was not visible")
        self.click_element(self.objects['RAD_Approval_Revert_Request_Revert'])
        self._handle_alert_with_text("NA", True)
        #self.input_text_into_prompt("NA")
        #pyautogui.click(780,212)
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element(self.objects['RAD_Approval_Revert_Message'], 30, 'Record was not saved')
        RadReqRevertMsg = self._get_text(self.objects['RAD_Approval_Revert_Message'])
        print RadReqRevertMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 20, "Rad mainframe was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "0000008993"
        self.wait_until_element_is_visible(self.objects['RAD_Result_Update_RegNo'], 10, "ipno was not visible")
        self.input_text(self.objects['RAD_Result_Update_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['RAD_Result_Update_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['RAD_Result_Update_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.d[r]['card_service'] = "Brain ECG updated"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_resultupdatepage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, "rad service name was not visible in result entry screen")
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'rad service name was not visible')
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_Result_Update_Updatebtn'], 30, "update btn was not visible")
        self.click_element(self.objects['RAD_Result_Update_Updatebtn'])        
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_Result_Update_Message'], 30, 'Record was not saved')    
        ResultUpdateMsg = self._get_text(self.objects['RAD_Result_Update_Message'])
        print ResultUpdateMsg
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()  
    
class InDigitalSignPrint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 20, "Rad mainframe was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "0000008993"
        self.wait_until_element_is_visible(self.objects['RAD_DigitalSignPrint_Regno'], 10, "ipno was not visible")
        self.input_text(self.objects['RAD_DigitalSignPrint_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['RAD_DigitalSignPrint_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['RAD_DigitalSignPrint_Searchbtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_printbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_DigitalSignPrint_Printbtn'], 10, "print btn was not visible")
        self.click_element(self.objects['RAD_DigitalSignPrint_Printbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()                     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InCancelRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 10, "Card main frame was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "2978"
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Regno'], 10, "regno was not visible")
        self.input_text(self.objects['RAD_CancelRequest_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['RAD_CancelRequest_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['RADIOLOGY_SERVICE'] = "X RAY CHEST PA VIEW"
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tbldtl"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno label was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reasonforcancellation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Reason'], 20, 'reason for cancellation was not visible')
        self.select_from_list_by_index(self.objects['RAD_CancelRequest_Reason'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Doctor'], 20, 'doctor was not visible')
        self.select_from_list_by_index(self.objects['RAD_CancelRequest_Doctor'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['RAD_CancelRequest_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.d = Capturing().data_off("CARD_CancelReq")
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Remarks'], 20, 'remarks was not visible')
        self.input_text(self.objects['RAD_CancelRequest_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_testcancelreqbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['RAD_CancelRequest_testcancelreqbtn'], 30, "cancel request btn was not visible")
        self.click_button(self.objects['RAD_CancelRequest_testcancelreqbtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequest_Message'], 30, 'Record was not saved')    
        TestCancelReqMsg = self._get_text(self.objects['RAD_CancelRequest_Message'])
        print TestCancelReqMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
        
class InCancelRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 10, "rad main frame was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "202306190007"
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestApproval_Regno'], 10, "regno was not visible")
        self.input_text(self.objects['RAD_CancelRequestApproval_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestApproval_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['RAD_CancelRequestApproval_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_requestapproval_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        '''if self._is_visible(self.objects['CARD_Result_Update_RegNo']):
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_RegNo'], 30, "result entry regno. was not visible")
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Update_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_Search'], 30, "card result entry search was not visible")
                self.click_button(self.objects['CARD_Result_Update_Search'])
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in result entry search grid")
                self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')'''
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.d[r]['rad_service'] = "CT BRAIN PLAIN"
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.d[r]['card_service']+'"]', 20, 'No Tests available')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tabledtl"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno label was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestApproval_Checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['RAD_CancelRequestApproval_Checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_testcancelapprovebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)#after checkbox selection delay has to be there before selecting testcancelapprov btn
        self.wait_until_element_is_enabled(self.objects['RAD_CancelRequestApproval_TestCancelReqbtn'], 30, "cancel approve btn was not visible")
        self.click_button(self.objects['RAD_CancelRequestApproval_TestCancelReqbtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestApproval_Message'], 30, 'Record was not saved')    
        TestCancelReqMsg = self._get_text(self.objects['RAD_CancelRequestApproval_Message'])
        print TestCancelReqMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
        
class InRequestCancelDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_MainFrame'], 10, "Rad main frame was not visible")
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['IPNO'] = "0000008993"
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_IPNo'], 10, "ipno was not visible")
        self.input_text(self.objects['CARD_RequestCancelDirect_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['CARD_RequestCancelDirect_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #self.d[r]['card_service'] = "Brain ECG updated"
        self.wait_until_page_contains_element('xpath=//*[@id="tbldtl"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno label was not visible")
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_checkboxall'], 10, "checkbox all was not visible")
        self.click_element(self.objects['CARD_RequestCancelDirect_checkboxall'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_reason'], 10, "reason was not visible")
        self.select_from_list_by_index(self.objects['CARD_RequestCancelDirect_reason'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_doctor'], 10, "doctor was not visible")
        self.select_from_list_by_index(self.objects['CARD_RequestCancelDirect_doctor'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("RAD_ReqCancelDirect")
        r = int(r)
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_remarks'], 10, "doctor was not visible")
        self.input_text(self.objects['CARD_RequestCancelDirect_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_directtestcancelbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['CARD_RequestCancelDirect_DirectTestCancelbtn'], 30, "direct test cancel btn was not visible")
        self.click_button(self.objects['CARD_RequestCancelDirect_DirectTestCancelbtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_Message'], 30, 'Record was not saved')    
        Msg = self._get_text(self.objects['CARD_RequestCancelDirect_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()            
        
class InCancelRequestprint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['RAD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "642343"
        #self.dict['IPNO'] = "Ip13022"
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestPrint_Regno'], 10, "regno was not visible")
        self.input_text(self.objects['RAD_CancelRequestPrint_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestPrint_Searchbtn'], 10, "search btn was not visible")
        self.click_button(self.objects['RAD_CancelRequestPrint_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.dict['RADIOLOGY_SERVICE'] = "CT BRAIN PLAIN"
        self.wait_until_page_contains_element('xpath=//*[@id="tbltbdy"]//td[text()="'+self.dict['RADIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblip_tool"]', 10, "ipno label was not visible")
        Patient = self.get_text('xpath=//*[@id="lblip_tool"]')
        Patient = Patient[3:]
        if str(self.dict['IPNO']).lower() != str(Patient).lower():
            raise AssertionError('Failed Ipno number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_printbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['RAD_CancelRequestPrint_Printbtn'], 20, 'Print Button was not visible')
        self.wait_until_element_is_enabled(self.objects['RAD_CancelRequestPrint_Printbtn'], 20, 'Print Button was not enabled')
        self.click_button(self.objects['RAD_CancelRequestPrint_Printbtn'])        
        self.dict['BROWSER'] = self._current_browser()     
    def getting_message(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects['RAD_CancelRequestPrint_Message'], 30, 'Request was not cancelled')    
            CanReqPrintMsg = self._get_text(self.objects['RAD_CancelRequestPrint_Message'])
            print CanReqPrintMsg
            if CanReqPrintMsg != "Cancel Copy Request Printed Successfully":
                raise AssertionError('Request not printed properly')
            else:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    