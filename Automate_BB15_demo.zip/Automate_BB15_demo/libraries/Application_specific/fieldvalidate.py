import sys
from Selenium2Library import Selenium2Library
from pip._vendor.distlib.locators import Locator
from openpyxl.cell.cell import TYPE_NULL
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
import pandas as pd 

class Validation(Selenium2Library):
        dict = admin.FromConfigFile.dict
        objects = common_reader.Capturing.objects
        d = Capturing().data_off("field_data1")
        def all(self):
#logging in
            for l in range(2,4):
                wb = load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                sheet = wb["field_data1"]
                loginname = (sheet.cell(row=l, column=3)).value
                print loginname
                FromConfigFile().logging(loginname)
                self._cache.current = self.dict['BROWSER']
                self.browser = self._current_browser()
####################################################################################################################
                if l==2:
                    startt=2
                    endd  =4
                if l ==3:
                    startt=4
                    endd  =5
####################################################################################################################
#loading module
                for k in range(startt,endd):
                    menu = (sheet.cell(row=k, column=2)).value
                    print menu
                    FromConfigFile().loading_menu_of_link(menu)
                    self._cache.current = self.dict['BROWSER']
                    self.browser = self._current_browser()
####################################################################################################################
                    if k==2:
                        start=16
                        end  =17
                    if k==3:
                        start=18
                        end  =20
                    if k==4:
                        start=21
                        end  =23
####################################################################################################################    
#Giving input to field
                    for i in range(start,end):
                        if self.d[i]['xpath']=='nextmenu':
                            pass
                        if i==16:
                            self.select_frame('xpath=//*[@id="frmMainPage"]')
                            self.mouse_down('xpath=//*[@id="HdrTitle"]')
                        if i ==18:
                            self.select_frame('xpath=//*[@id="frmMainPage"]')
                            self.mouse_down('xpath=//*[@id="form1"]/div[3]/div/div/div[6]/div/div/div[1]/div/div[1]/div/div[1]/span')
                                       
                        self.input_text(self.d[i]['xpath'], "a")
                        a="a"
                        a=a.lower()
                        b=self.get_value(self.d[i]['xpath'])
                        b=b.lower()
                        wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                        sheet= wb['field_data1']
                        if a==b:
                         sheet.cell(row=i+1,column=9).value ="YES"
                         self.input_text(self.d[i]['xpath'], "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
                         b=self.get_value(self.d[i]['xpath'])
                         b=b.lower()
                         c=len(b)
                         sheet.cell(row=i+1,column=13).value = c
                        else:
                         sheet.cell(row=i+1,column=9).value ="NO"
                        self.input_text(self.d[i]['xpath'], "1")
                        a="1"
                        b=self.get_value(self.d[i]['xpath'])
                        sheet= wb['field_data1']
                        self.dict['BROWSER'] = self._current_browser() 
                        if a==b:
                         sheet.cell(row=i+1,column=11).value ="YES"
                          
                         self.input_text(self.d[i]['xpath'], "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111")
                         b=self.get_value(self.d[i]['xpath'])
                         b=b.lower()
                         c=len(b)
                         sheet.cell(row=i+1,column=13).value = c
                         wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                         wb.close()             
                        else:
                         sheet.cell(row=i+1,column=11).value ="NO"
                         wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                         wb.close()             
                        for j in range (4,36):
                            self.input_text(self.d[i]['xpath'],str(self.d[2][j*2]) )
                            a=str(self.d[1][j*2])
                            b=self.get_value(self.d[i]['xpath'])
                            sheet= wb['field_data1']
                            self.dict['BROWSER'] = self._current_browser()
                            if a==b:
                                sheet.cell(row=i+1,column=((j+3)*2)+1).value ="YES"
                                wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                                wb.close()
    
                            else:
                                sheet.cell(row=i+1,column=((j+3)*2)+1).value ="NO" 
                                wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                                wb.close()
                    self.unselect_frame()                     
##############################################################################################################
#logging off                                     
                FromConfigFile().Logoff()       
##############################################################################################################    
##############################################################################################################
#printing result 
            if sheet.cell(row=i+1,column=8).value == sheet.cell(row=i+1,column=9).value:
             sheet.cell(row=i+1,column=78).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=78).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=10).value == sheet.cell(row=i+1,column=11).value:
             sheet.cell(row=i+1,column=79).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=79).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=12).value == sheet.cell(row=i+1,column=13).value:
             sheet.cell(row=i+1,column=80).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=80).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=14).value == sheet.cell(row=i+1,column=15).value:
             sheet.cell(row=i+1,column=81).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=81).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=16).value == sheet.cell(row=i+1,column=17).value:
             sheet.cell(row=i+1,column=82).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=82).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=18).value == sheet.cell(row=i+1,column=19).value:
             sheet.cell(row=i+1,column=83).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=83).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=20).value == sheet.cell(row=i+1,column=21).value:
             sheet.cell(row=i+1,column=84).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=84).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=22).value == sheet.cell(row=i+1,column=23).value:
             sheet.cell(row=i+1,column=85).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=85).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=24).value == sheet.cell(row=i+1,column=25).value:
             sheet.cell(row=i+1,column=86).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=86).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=26).value == sheet.cell(row=i+1,column=27).value:
             sheet.cell(row=i+1,column=87).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=87).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=28).value == sheet.cell(row=i+1,column=29).value:
             sheet.cell(row=i+1,column=88).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=88).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=30).value == sheet.cell(row=i+1,column=31).value:
             sheet.cell(row=i+1,column=89).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=89).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=32).value == sheet.cell(row=i+1,column=33).value:
             sheet.cell(row=i+1,column=90).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=90).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=34).value == sheet.cell(row=i+1,column=35).value:
             sheet.cell(row=i+1,column=91).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=91).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=36).value == sheet.cell(row=i+1,column=37).value:
             sheet.cell(row=i+1,column=92).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=92).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=38).value == sheet.cell(row=i+1,column=39).value:
             sheet.cell(row=i+1,column=93).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=93).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=40).value == sheet.cell(row=i+1,column=41).value:
             sheet.cell(row=i+1,column=94).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=94).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=42).value == sheet.cell(row=i+1,column=43).value:
             sheet.cell(row=i+1,column=95).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=95).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=44).value == sheet.cell(row=i+1,column=45).value:
             sheet.cell(row=i+1,column=96).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=96).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=46).value == sheet.cell(row=i+1,column=47).value:
             sheet.cell(row=i+1,column=97).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=97).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=48).value == sheet.cell(row=i+1,column=49).value:
             sheet.cell(row=i+1,column=98).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=98).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=50).value == sheet.cell(row=i+1,column=51).value:
             sheet.cell(row=i+1,column=99).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=99).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=52).value == sheet.cell(row=i+1,column=53).value:
             sheet.cell(row=i+1,column=100).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=100).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=54).value == sheet.cell(row=i+1,column=55).value:
             sheet.cell(row=i+1,column=101).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=101).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=56).value == sheet.cell(row=i+1,column=57).value:
             sheet.cell(row=i+1,column=102).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=102).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=58).value == sheet.cell(row=i+1,column=59).value:
             sheet.cell(row=i+1,column=103).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=103).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=60).value == sheet.cell(row=i+1,column=61).value:
             sheet.cell(row=i+1,column=104).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=104).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=62).value == sheet.cell(row=i+1,column=63).value:
             sheet.cell(row=i+1,column=105).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=105).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=64).value == sheet.cell(row=i+1,column=65).value:
             sheet.cell(row=i+1,column=106).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=106).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=66).value == sheet.cell(row=i+1,column=67).value:
             sheet.cell(row=i+1,column=107).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=107).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=68).value == sheet.cell(row=i+1,column=69).value:
             sheet.cell(row=i+1,column=108).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=108).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=70).value == sheet.cell(row=i+1,column=71).value:
             sheet.cell(row=i+1,column=109).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=109).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=72).value == sheet.cell(row=i+1,column=73).value:
             sheet.cell(row=i+1,column=110).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=110).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=74).value == sheet.cell(row=i+1,column=75).value:
             sheet.cell(row=i+1,column=111).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=111).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
             
            if sheet.cell(row=i+1,column=76).value == sheet.cell(row=i+1,column=77).value:
             sheet.cell(row=i+1,column=112).value ="PASS"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
            else:
             sheet.cell(row=i+1,column=112).value ="FAIL"
             wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
             wb.close()
                          
FromConfigFile().driving_browser_and_url()         
Validation().all() 
        