import sys
from Selenium2Library import Selenium2Library
#import pyautogui
#from pandas.core.arrays.integer import classname
from selenium import webdriver
#from test.test_multiprocessing import get_value
from selenium.common.exceptions import ElementNotInteractableException,\
    ElementClickInterceptedException
from ctypes.wintypes import MSG
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
#sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InNewOpRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_OPNewReg")
    dict['REDIRECTTOBILL'] = ""
    dict['REGBILLAPPROVAL'] = ""
    dict['BILLINGDATAS'] = ""
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1') or (str(ctrlvalue) == '2'):
            r = int (r)
            #self.wait_until_element_is_visible(self.objects["FO_MainFrame"], 10, "frame was not visible")
            #self.select_frame(self.objects["FO_MainFrame"])
            #time.sleep(2)
            #self.wait_until_page_contains_element('xpath=//*[@id="chkInsuranceCheckbox"]', 20, "insurance checkbox was not visible")
            #pyautogui.hotkey('esc')
            #self.wait_until_page_contains_element('xpath=//*[@id="chkInsuranceCheckbox"]', 20, "insurance checkbox was not visible")
            self.wait_until_page_contains_element(self.objects["FO_NewRegistration_Dept"], 30, "department was not visible")
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Dept"], 30, "department was not visible")
            self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["department"])
            print "dept selected"
        else:
            print "Department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1'):
            r = int (r)
            time.sleep(0.5)
            #self.d[r]["doctor"] = "BALAJI"
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 30, "doctor was not visible")
            self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["doctor"])
            print "doctor selected"
        else:
            print "Doctor field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()   
    #WF_21
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '2'):
            r = int (r)
            ########## Below two lines uncommented in Release Server #################################################################
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr', 30, "close mark in unit was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]', 30, "unit field was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "unit text field was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]["unit"])
            #self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen109_search"]', 30, "unit text field was not visible")
            #self.input_text('xpath=//*[@id="s2id_autogen109_search"]', self.d[r]["unit"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]', 30, "unit field list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]')
            time.sleep(2)
        else:
            print " Unit field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_onlydoctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '3'):
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            r = int (r)
            #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly"], 30, "doctor and department was not visible")
            #self.click_element(self.objects['FO_NewRegistration_DoctorOnly'])
            #time.sleep(2)
            self.wait_until_page_contains_element(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible in page")
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible")
            self.input_text(self.objects["FO_NewRegistration_DoctorOnly_Entry"],self.d[r]["doctor"])
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="BALAJI(CARDIOLOGY)"]', 30, "city list was present")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]', 60, "Doctor and department list was present")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]')
            time.sleep(1)
        else:
            print "Doctor and department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_patient_type_with_data(self,r): 
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        # Patient type is "Board Persons" for qabeta and "Camp" for release server
        self.page_should_contain_element(self.objects["FO_NewRegistration_PatType"], 30, "patient type was not visible")
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType"], 30, "patient type was not visible")
        self.select_from_list_by_label(self.objects['FO_NewRegistration_PatType'],self.d[r]['patient_type'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_camp_name_with_data(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType_CampName"], 30, "city was not visible")
        self.click_element(self.objects['FO_NewRegistration_PatType_CampName'])
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType_CampName_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_NewRegistration_PatType_CampName_Entry"],"%%%")
        self.wait_until_element_is_visible('xpath=(//*[@id="select2-drop"]//span)[1]', 30, "city list was present")
        self.click_element('xpath=(//*[@id="select2-drop"]//span)[1]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_campregno(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType_CampPatient'], 30, 'camp patient was not visible')
        self.click_element(self.objects['FO_NewRegistration_PatType_CampPatient'])
        self.input_text(self.objects['FO_NewRegistration_PatType_CampPatient_Entry'], str(self.dict['CAMP_REGNO']))
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+str(self.dict['CAMP_REGNO'])+'"]', 30, "camp regno was not present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+str(self.dict['CAMP_REGNO'])+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Sal"], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"],self.d[r]["sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 30, "name was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Name"],"Sharma FRS "+str(randint(100,999)))
        #self.input_text(self.objects["FO_NewRegistration_Name"],"Pranav rrv")
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        self.input_text(self.objects["FO_NewRegistration_Name"],str(self.d[r]["name"]))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Gender"], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"],self.d[r]["gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Age"], 30, "age was not visible")
        self.input_text(self.objects["FO_NewRegistration_Age"],self.d[r]["age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_MaritalStatus"], 30, "marital status was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],self.d[r]["marital_status"])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_relation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_NewRegistration_Relation'], "1")
        self.dict['BROWSER'] = self._current_browser()
                
    def entering_relationname_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.input_text(self.objects['FO_NewRegistration_RelationName'], self.d[r]['relname'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Address"], 30, "address was not visible")
        self.input_text(self.objects["FO_NewRegistration_Address"],self.d[r]["present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City"], 30, "city was not visible")
        self.click_element(self.objects['FO_NewRegistration_City'])
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_NewRegistration_City_Entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        #self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_mobile_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 30, "mobile no was not visible")
        self.input_text(self.objects["FO_NewRegistration_Mobile"],"9120000"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        #print self.d[r]["opnewreg_mobile"]
        #print(len(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_nationality_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs2']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Nationality"], 30, "nationality was not visible")
            #self.select_from_list_by_label(self.objects["FO_NewRegistration_Nationality"],self.d[r]["nationality"])
            self.select_from_list_by_index(self.objects["FO_NewRegistration_Nationality"], '2')
            time.sleep(1)
        else:
            print "Nationality Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_nationalityid_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs3']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_NationalityID"], 30, "nationality id field was not visible")
            self.input_text(self.objects["FO_NewRegistration_NationalityID"], "AFLRM"+str(randint(100,999))+"T")
        else:
            print "Nationality Mandatory ID field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_occupation_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs4']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Occupation"], 30, "occupation was not visible")
            self.select_from_list_by_index(self.objects["FO_NewRegistration_Occupation"], '2')
            time.sleep(1)
        else:
            print "Occupation Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Remarks"], 30, "remarks was not visible")
        self.input_text(self.objects["FO_NewRegistration_Remarks"],self.d[r]["remarks"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_referraldoctor_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs5']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor"], 30, "referral doctor was not visible")
            self.click_element(self.objects["FO_NewRegistration_Referraldoctor"])
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor_Entry"], 30, "referral doctor input field was not visible")
            self.input_text(self.objects["FO_NewRegistration_Referraldoctor_Entry"],"%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 60, "referraldoctor list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\13')
            time.sleep(1)
        else:
            print "referral doctor Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    def clicking_emailtextbox(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #ime.sleep(1)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Email"], 30, "email was not visible")
        self.click_element(self.objects["FO_NewRegistration_Email"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #ime.sleep(1)
        self.wait_until_element_is_enabled(self.objects["FO_NewRegistration_Save"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_NewRegistration_Save"])
        '''time.sleep(1)
        pyautogui.click(860,165)
        time.sleep(1)
        pyautogui.click(860,165)'''
        #self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
        
    def fetching_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        if (str(self.cs['cs10']) == '0') and ((str(self.cs['cs11']) == '0') or (str(self.cs['cs11']) == '1')) and (str(self.cs['cs9']) == '0'):
            print "1"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "False"
            self.dict['REGBILLAPPRROVAL'] = "FalseorTrue"
            self.dict['BILLINGDATAS'] = "True"
        elif (str(self.cs['cs10']) == '1') and (str(self.cs['cs11']) == '1') and (str(self.cs['cs9']) != '0'):
            print "2"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage'], 60, 'Record was not saved and pop up dialog was not visible')
            self.msg = self._get_text(self.objects['FO_NewRegistration_PopUpMessage'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            #RELEASE SERVER####################
            time.sleep(2)
            '''try:
                self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department msg opened along with pop up msg in release was not displayed")
                self.click_element('xpath=//*[@id="select2-drop"]//input')
                self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
            except:
                pass'''
            ##################################
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'], 30, 'ok btn was not visible')  
            self.click_button(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "True"
            self.dict['BILLINGDATAS'] = "True"
        elif (str(self.cs['cs10']) == '0') and (str(self.cs['cs11']) == '1') and (str(self.cs['cs9']) != '0'):
            print "3"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "False"
            self.dict['REGBILLAPPRROVAL'] = "True"
            self.dict['BILLINGDATAS'] = "True"
        elif ((str(self.cs['cs10']) == '1') or (str(self.cs['cs10']) == '0')) and (str(self.cs['cs11']) == '0') and (str(self.cs['cs9']) != '0'):
            print "4"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "False"
            self.dict['BILLINGDATAS'] = "True"
            time.sleep(10)
            pyautogui.click(1132,672)
        elif (str(self.cs['cs10']) == '1') and ((str(self.cs['cs11']) == '0') or (str(self.cs['cs11']) == '1')) and (str(self.cs['cs9']) == '0'):
            print "5"
            #pop up message displayed but no print preview and no need to save bill in billing screen
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage'], 60, 'Record was not saved and pop up dialog was not visible')
            self.msg = self._get_text(self.objects['FO_NewRegistration_PopUpMessage'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            #RELEASE SERVER####################
            time.sleep(2)
            try:
                self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department msg opened along with pop up msg in release was not displayed")
                self.click_element('xpath=//*[@id="select2-drop"]//input')
                self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
            except:
                pass
            ##################################   
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'], 30, 'ok btn was not visible')  
            self.click_button(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "FalseorTrue"
            self.dict['BILLINGDATAS'] = "False"
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
    def Cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        pyautogui.click(1131,672)
        self.dict['BROWSER'] = self._current_browser()
   
class InDoctorOpinionEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_OpinionEntry")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        #self.click_button('xpath=//*[@id="btn-ok"]')
        self.wait_until_page_contains_element('xpath=//*[@id="txtRegisterNo"]', 30, 'regno was not visible')
        self.input_text('xpath=//*[@id="txtRegisterNo"]', str(self.dict['REGNO']))
        self.press_key('xpath=//*[@id="txtRegisterNo"]', '\\13')
        time.sleep(5)
        self.dict['BROWSER'] =  self._current_browser()    
    def selecting_icdcode_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()  
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboICDCode"]', 30, "icd code was not visible")
        self.click_element('xpath=//*[@id="s2id_cboICDCode"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "search text box was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "list was not displayed")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.click_element('xpath=//*[.="Admit Diag(ICD Code) *"]')
        #self.input_text('xpath=//*[@id="s2id_autogen49_search"]',str(self.d[r]['icd_code']))
        #time.sleep(5)
        #pyautogui.hotkey('enter')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_add_button(self): 
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_DoctorOpinionEntry_ICDCode_Add'], 30, "list was not displayed")
        self.click_element(self.objects['FO_DoctorOpinionEntry_ICDCode_Add'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_duration_of_admission_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_DoctorOpinionEntry_duration'])
        self.input_text(self.objects['FO_DoctorOpinionEntry_duration'],str(self.d[r]['duration']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_tentative_days(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_DoctorOpinionEntry_tentative_admission'],str(self.d[r]['tentativedays']))
        time.sleep(1)
        self.press_key(self.objects['FO_DoctorOpinionEntry_tentative_admission'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_estimation_value(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.input_text(self.objects['FO_DoctorOpinionEntry_estimation'],str(self.d[r]['estimation']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_adviced_doctor_with_data(self):
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_DoctorOpinionEntry_adviceddoctor'], 30, "adviced doctor was not visible")
        self.select_from_list_by_index(self.objects['FO_DoctorOpinionEntry_adviceddoctor'],'1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bed_type_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_DoctorOpinionEntry_bedtype'], 30, "bed type was not visible")
        self.select_from_list_by_label(self.objects['FO_DoctorOpinionEntry_bedtype'],self.d[r]['bedtype'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ward_with_data(self,r):
        r = int (r)
        self._cache.current  = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_DoctorOpinionEntry_ward'], 30, "ward was not visible")
        self.select_from_list_by_label(self.objects['FO_DoctorOpinionEntry_ward'],self.d[r]['ward'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_add_admision_btn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_DoctorOpinionEntry_addadmission"], 30, "add admission btn was not enabled")
        self.click_button(self.objects["FO_DoctorOpinionEntry_addadmission"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_DoctorOpinionEntry_save"], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_DoctorOpinionEntry_save"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_DoctorOpinionEntry_Message_OK"], 30, "ok btn was not visible")
        self.click_button(self.objects["FO_DoctorOpinionEntry_Message_OK"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InOpinionConvertToIP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_OpinionConvertToIP")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame('xpath=//*[@id="frmMainPage"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def scroll_web_element_into_view(self, locator):
        self.set_selenium_implicit_wait(15)
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def entering_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        #self.click_button('xpath=//*[@id="btn-ok"]')
        self.wait_until_page_contains_element('xpath=//*[@id="txtRegisterNo"]', 30, 'regno was not visible')
        self.input_text('xpath=//*[@id="txtRegisterNo"]', str(self.dict['REGNO']))
        self.press_key('xpath=//*[@id="txtRegisterNo"]', '\\13')
        time.sleep(7)
        ### Commented below lines for Release server#############################
        '''try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass'''
        self.dict['BROWSER'] =  self._current_browser()

    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        time.sleep(3)
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Dept"],self.d[r]["department"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_Opinion_convert_to_IP_Doc"], 30, "opinion to ip was not visible")
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Doc"],self.d[r]["doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedtype_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_Opinion_convert_to_IP_BedType"], 30, "bed type was not visible")
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_BedType"],self.d[r]["bedtype"])
        time.sleep(3)
        self.dict['WARD-BEDTYPE'] = self.get_selected_list_label(self.objects["FO_Opinion_convert_to_IP_BedType"])
        print self.dict['WARD-BEDTYPE']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ward_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_Opinion_convert_to_IP_Ward"], 30, "ward was not visible")
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_Ward"],self.d[r]["ward"])
        time.sleep(3)
        self.dict['WARD-NAME'] = self.get_selected_list_label(self.objects["FO_Opinion_convert_to_IP_Ward"])
        print self.dict['WARD-NAME']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_Opinion_convert_to_IP_Bedno"], 30, "bed no was not visible")
        self.select_from_list_by_index(self.objects["FO_Opinion_convert_to_IP_Bedno"],'1')
        time.sleep(3)
        self.dict['WARD-BEDNO'] = self.get_selected_list_label(self.objects["FO_Opinion_convert_to_IP_Bedno"])
        print self.dict['WARD-BEDNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_icdcode_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()  
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboICDCode"]', 30, "icd code was not visible")
        self.click_element('xpath=//*[@id="s2id_cboICDCode"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "search text box was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "list was not displayed")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.click_element('xpath=//*[.="Admit Diag(ICD Code) *"]')
        #self.input_text('xpath=//*[@id="s2id_autogen49_search"]',str(self.d[r]['icd_code']))
        #time.sleep(5)
        #pyautogui.hotkey('enter')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_pharmacypaytype_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_Opinion_convert_to_IP_PharmacyPayType"], 30, "pharmacy paytype was not visible")
        self.select_from_list_by_label(self.objects["FO_Opinion_convert_to_IP_PharmacyPayType"],self.d[r]["pharmacypaytype"])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_Opinion_convert_to_IP_Save"], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_Opinion_convert_to_IP_Save"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def fetching_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects['FO_Opinion_convert_to_IP_Message'], 40, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_Opinion_convert_to_IP_Message'])
            #self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.dict['IPNO'] = self.IPno
            print("Registered IPNO is",self.dict['IPNO'])
        except:
            self.wait_until_element_is_visible(self.objects['FO_Opinion_convert_to_IP_Message'], 40, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_Opinion_convert_to_IP_Message'])
            #self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.IPno= ((self.msg).split('Record(s) Saved Successfully, ER No : '))[1].split(', Admission Date')[0]
            self.dict['IPNO'] = self.IPno
            print("Registered IPNO is",self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()     
        ######## Commented below lines and added above lines in Release Server for ER no fetching#######################
        '''self.wait_until_element_is_visible(self.objects['FO_Opinion_convert_to_IP_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_Opinion_convert_to_IP_Message'])
        self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
        self.dict['IPNO'] = self.IPno
        print self.IPno
        print("Registered IPNO is",self.dict['IPNO'])'''
        #########################################################
    def selecting_okbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_Opinion_convert_to_IP_Message_OK"], 30, 'ok btn was not enabled')
        self.click_button(self.objects["FO_Opinion_convert_to_IP_Message_OK"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

        
class InIPRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_IPRegistration")
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(5)
        self.dict['BROWSER'] =  self._current_browser()
    
    def scroll_web_element_into_view(self, locator):
        self.set_selenium_implicit_wait(15)
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    
    def entering_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        #self.dict['REGNO'] = "647409"
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        #self.click_button('xpath=//*[@id="btn-ok"]')
        self.wait_until_page_contains_element('xpath=//*[@id="txtRegisterNo"]', 30, 'regno was not visible')
        self.input_text('xpath=//*[@id="txtRegisterNo"]', str(self.dict['REGNO']))
        self.press_key('xpath=//*[@id="txtRegisterNo"]', '\\13')
        time.sleep(7)
        '''try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 10, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass'''
        #################    QA SERVER ALONE  and now added for RELEASE SERVER  #################################
        '''try:
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 4, "extra corner pop up msg was not displayed")
            self.click_element('xpath=//*[@id="select2-drop"]//input')
            self.press_key('xpath=//*[@id="select2-drop"]//input', '\\13')
        except:
            pass'''
        ########################################################################
        self.dict['BROWSER'] =  self._current_browser()
        
    def selecting_registered_op_patient(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Advance_Search'], 30, 'Advance search was not visible')
        #self.click_element(self.objects['FO_IPRegistration_Advance_Search'])
        try:
            self.click_element(self.objects['FO_IPRegistration_Advance_Search'])
        except ElementClickInterceptedException:
          self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "pop message was not displayed")
          self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
          if self.msg ==   "No Record(s) Found":
             self.wait_until_element_is_visible('xpath=//*[@id="btn-ok"]', 30, "ok-btn was not visible")
             self.click_button('xpath=//*[@id="btn-ok"]')
        self.click_element(self.objects['FO_IPRegistration_Advance_Search'])
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Advance_Search_Page'], 30, 'Advance search page is not open')
        self.input_text(self.objects['FO_IPRegistration_Patient_RegNo'], str(self.dict['REGNO']))
        self.click_element(self.objects['FO_IPRegistration_Patient_Search'])
        self.wait_until_page_contains_element('xpath=//*[(text()="'+self.dict['REGNO']+'")]', 30, 'No data available')
        self.click_element('xpath=//*[(text()="'+self.dict['REGNO']+'")]')
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
        
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1') or (str(ctrlvalue) == '2'):
            r = int (r)
            time.sleep(2)
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department text field was not visible")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department text field was not visible")
            self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Dept'], 30, 'dept was not visible')
            self.select_from_list_by_label(self.objects["FO_IPRegistration_Dept"],self.d[r]["department"])
        else:
            print "department field is not chosen in control settings"      
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1'):
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Doc"], 30, "doctor was not visible")
            self.select_from_list_by_label(self.objects["FO_IPRegistration_Doc"],self.d[r]["doctor"])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '2'):
            r = int (r)
            #self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr', 30, "close mark in unit was not visible")
            #self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]', 30, "unit field was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "unit text field was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]["unit"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]', 30, "unit field list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]')
            time.sleep(2)
        else:
            print " Unit field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
     
    def selecting_onlydoctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '3'):
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_DoctorOnly"], 30, "doctor and department was not visible")
            self.click_element(self.objects['FO_IPRegistration_DoctorOnly'])
            time.sleep(2)
            self.wait_until_page_contains_element(self.objects["FO_IPRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible in page")
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible")
            self.input_text(self.objects["FO_IPRegistration_DoctorOnly_Entry"],self.d[r]["doctor"])
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="BALAJI(CARDIOLOGY)"]', 30, "city list was present")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]', 60, "Doctor and department list was present")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]')
            time.sleep(1)
        else:
            print "Doctor and department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
     
    def selecting_referraldoctor_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs5']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Referraldoctor"], 30, "referral doctor was not visible")
            self.click_element(self.objects["FO_IPRegistration_Referraldoctor"])
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Referraldoctor_Entry"], 30, "referral doctor input field was not visible")
            self.input_text(self.objects["FO_IPRegistration_Referraldoctor_Entry"],"%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 60, "referraldoctor list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\13')
            time.sleep(2)
        else:
            print "referral doctor Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
     
    def selecting_casecoordinator_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs7']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_CaseCoordinator"], 30, "case coordinator was not visible")
            self.select_from_list_by_index(self.objects["FO_IPRegistration_CaseCoordinator"], '2')
            time.sleep(1)
        else:
            print "case coordinator field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_casemanager_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs7']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPRegistration_CaseManager"], 30, "case manager was not visible")
            self.select_from_list_by_index(self.objects["FO_IPRegistration_CaseManager"], '2')
            time.sleep(1)
        else:
            print "case manager field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
                    
    def selecting_bedtype_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_BedType'], 30, "bedtype was not visible")
        print self.d[r]['bedtype']
        print self.d[r]['ward']
        self.select_from_list_by_label(self.objects['FO_IPRegistration_BedType'], str(self.d[r]["bedtype"]))
        time.sleep(3)
        self.dict['WARD-BEDTYPE'] = self.get_selected_list_label(self.objects["FO_IPRegistration_BedType"])
        print self.dict['WARD-BEDTYPE']
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_wardname_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Ward'], 30, "ward name was not visible")
        self.select_from_list_by_label(self.objects['FO_IPRegistration_Ward'], str(self.d[r]["ward"]))
        #self.select_from_list_by_index(self.objects['FO_NewRegistration_Ward'], '1')
        time.sleep(2)
        self.dict['WARD-NAME'] = self.get_selected_list_label(self.objects["FO_IPRegistration_Ward"])
        print self.dict['WARD-NAME']
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPRegistration_BedNo'], 30, "bedno was not visible")
        self.select_from_list_by_index(self.objects['FO_IPRegistration_BedNo'], '1')
        time.sleep(5)
        self.dict['WARD-BEDNO'] = self.get_selected_list_label(self.objects["FO_IPRegistration_BedNo"])
        print self.dict['WARD-BEDNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_pharmacypaytype_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_IPRegistration_PharmPayType"], 30, "pharmacy paytype was not visible")
        self.select_from_list_by_label(self.objects["FO_IPRegistration_PharmPayType"],self.d[r]["IPreg_pharmacypaytype"])
        self.dict['BROWSER'] = self._current_browser()     
        
    def admit_diag_icd_code(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs6']
        if (str(ctrlvalue) == '1'):
            self.scroll_web_element_into_view('xpath=//*[@id="s2id_cboICDCode"]')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboICDCode"]', 30, "icd code was not visible")
            self.click_element('xpath=//*[@id="s2id_cboICDCode"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "search text box was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "list was not displayed")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.click_element('xpath=//*[.="Admit Diag(ICD Code) *"]')
            #self.input_text('xpath=//*[@id="s2id_autogen49_search"]',str(self.d[r]['icd_code']))
            #time.sleep(5)
            #pyautogui.hotkey('enter')
            time.sleep(1)
        else:
            "icd code in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()   
           
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.scroll_web_element_into_view(self.objects["FO_IPRegistration_Save"])
        self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Save"], 30, "save btn was not visible")
        self.click_button(self.objects['FO_IPRegistration_Save'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def fetching_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Message'], 40, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_IPRegistration_Message'])
            #self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.dict['IPNO'] = self.IPno
            print("Registered IPNO is",self.dict['IPNO'])
        except:
            self.wait_until_element_is_visible(self.objects['FO_IPRegistration_Message'], 40, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_IPRegistration_Message'])
            #self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.IPno= ((self.msg).split('Record(s) Saved Successfully, ER No : '))[1].split(', Admission Date')[0]
            self.dict['IPNO'] = self.IPno
            print("Registered IPNO is",self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_firstipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['FIRSTIPNO'] = self.dict['IPNO']
        self.dict['BROWSER'] = self._current_browser()
    def getting_secondipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['SECONDIPNO'] = self.dict['IPNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_IPRegistration_Message_Ok"], 30, "ok btn was not visible")
        self.click_button(self.objects["FO_IPRegistration_Message_Ok"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

        
class InPatientBlockAndUnblock(Selenium2Library):
    
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_BlockUnblock")
    
    def select_the_frame(self):  
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.select_frame(self.objects['FO_MainFrame'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
         
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_patient_block_unblock_regno'], 30, "regno was not visible")
        self.input_text(self.objects['FO_patient_block_unblock_regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['FO_patient_block_unblock_regno'], '\\13')
        #pyautogui.hotkey('enter')
        time.sleep(3)    
        self.dict['BROWSER'] = self._current_browser()
        
    def block_reason(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_block_unblock_patient_status'], 30, "block reason was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_block_unblock_patient_status'], self.d[r]['patient_status'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_block_unblock_remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['FO_patient_block_unblock_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
        
    def unlock(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_patient_block_unblock_patient_status'], 30, "remarks was not visible")      
        self.select_from_list_by_label(self.objects['FO_patient_block_unblock_patient_status'], 'UNLOCK')
        self.dict['BROWSER'] = self._current_browser()
        
    def save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_patient_block_unblock_save'], 30, "save btn was not enabled")
        self.click_button(self.objects['FO_patient_block_unblock_save'])
        self.dict['BROWSER'] = self._current_browser()
        
    def get_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_patient_block_unblock_message'], 30,'Success message not visible in page')
        self.wait_until_element_is_visible(self.objects['FO_patient_block_unblock_message'], 30,'Success message not visible ')        
        message=self.get_text(self.objects['FO_patient_block_unblock_message'])
        print message
        self.click_button(self.objects['FO_patient_block_unblock_message_ok_btn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
           
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("FO_BlockUnblock")
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('//FrontOfficeCS/tPatientBlockUnBlock.aspx') 
r=1        
InPatientBlockAndUnblock().select_the_frame()
InPatientBlockAndUnblock().entering_regno(r)
InPatientBlockAndUnblock().block_reason(r)
InPatientBlockAndUnblock().entering_remarks(r)
InPatientBlockAndUnblock().unlock()
InPatientBlockAndUnblock().save()
InPatientBlockAndUnblock().get_message()'''

        
class InCampRegistration(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_CampReg")
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_campname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_campname'], 30, "camp name was not visible")
        self.wait_until_element_is_visible(self.objects['FO_campname'], 30, "camp name was not visible")
        self.select_from_list_by_index(self.objects['FO_campname'], "1")
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_sal'], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects['FO_camp_sal'], self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_name'], 30, "name was not visible")
        self.input_text(self.objects['FO_camp_name'], self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_gender_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_gender'], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects['FO_camp_gender'], self.d[r]['gender'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_age_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_age'], 30, "age was not visible")
        self.input_text(self.objects['FO_camp_age'], str(self.d[1]['age']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_address'], 30, "camp address was not visible")
        self.input_text(self.objects['FO_camp_address'], self.d[r]['address'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_city_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects["FO_camp_city"], 30, "city was not visible")
        self.click_element(self.objects['FO_camp_city'])
        self.wait_until_element_is_visible(self.objects["FO_camp_city_entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_camp_city_entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_mobileno_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_camp_phno"], 30, "mobile was not visible")
        self.input_text(self.objects["FO_camp_phno"],"990462"+str(randint(1000,9999)))
#         self.input_text(self.objects['FO_camp_phno'], str(self.d[r]['phno']))
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_camp_save'])
        self.dict['BROWSER'] = self._current_browser()
    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.msg = self.get_text(self.objects['FO_camp_message'])
        print self.msg
        self.camp_rg_no= ((self.msg).split('Camp Reg No : '))[1]   
        print self.camp_rg_no
        self.dict['CAMP_REGNO'] = self.camp_rg_no
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
            
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("fo_camp_reg")
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('//FrontOfficeCS/CampRegistration.aspx') 
r=1
CampRegistration().select_the_frame()
CampRegistration().select_camp_name()
CampRegistration().selecting_sal_with_data(r)
CampRegistration().entering_name_with_data(r)
CampRegistration().selecting_gender_with_data(r)
CampRegistration().entering_age_with_data(r)
CampRegistration().entering_address_with_data(r)
CampRegistration().selecting_city_with_data(r)
CampRegistration().entering_phno_with_data(r)
CampRegistration().save()
CampRegistration().get_message()
CampRegistration().unselecting_the_frame()'''

class CampRegistrationModify(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_CampRegModify")
   
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
           
    def selecting_the_frame(self):        
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(15)
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_regno(self):        
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_camp_reg_modyi_regno'], 30, "regno was not visible")
        self.input_text(self.objects['FO_camp_reg_modyi_regno'], (self.dict['CAMP_REGNO']))
        self.press_key(self.objects['FO_camp_reg_modyi_regno'], '\\13')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    
    def select_camp_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_campname'], 30, "camp name was not visible")
        self.select_from_list_by_index(self.objects['FO_campname'], "1")
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_sal'], 30, "camp sal was not visible")
        self.select_from_list_by_label(self.objects['FO_camp_sal'], self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_camp_name'], 30, "camp name was not visible")
        self.input_text(self.objects['FO_camp_name'], self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_gender_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_camp_gender'], 30, "camp gender was not visible")
        self.select_from_list_by_label(self.objects['FO_camp_gender'], self.d[r]['gender'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_age_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_camp_age'], 30, "age was not visible")
        self.input_text(self.objects['FO_camp_age'], str(self.d[1]['age']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_camp_address'], 30, "address was not visible")
        self.input_text(self.objects['FO_camp_address'], self.d[r]['add'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_city_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_camp_city'], 30, "camp city was not visible")
        self.click_element(self.objects['FO_camp_city'])
        self.wait_until_element_is_visible(self.objects['FO_camp_city_entry'], 30, "camp entry was not visible")
        self.input_text(self.objects['FO_camp_city_entry'], self.d[r]['city'])
        self.press_key(self.objects['FO_camp_city_entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_phno_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_camp_phno"], 30, "mobile was not visible")
        self.input_text(self.objects['FO_camp_phno'], "911462"+str(randint(1000,9999)))
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['FO_camp_save'])
        self.dict['BROWSER'] = self._current_browser()
    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_camp_reg_modyi_message'], 40, 'message is not visible')
        self.wait_until_element_is_visible(self.objects['FO_camp_reg_modyi_message'], 40, 'message is not visible')
        message=self.get_text(self.objects['FO_camp_reg_modyi_message'])
        print message
        self.click_button(self.objects['FO_patient_block_unblock_message_ok_btn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
  
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("FO_CampRegModify")
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('//FrontOfficeCS/CampRegistration.aspx?OPT=UPDATE') 
r=1
FrontOffice.CampRegistrationModify.select_the_frame
FrontOffice.CampRegistrationModify.enter_regno
FrontOffice.CampRegistrationModify.select_camp_name
FrontOffice.CampRegistrationModify.selecting_sal_with_data
FrontOffice.CampRegistrationModify.entering_name_with_data
FrontOffice.CampRegistrationModify.selecting_gender_with_data
FrontOffice.CampRegistrationModify.entering_age_with_data
FrontOffice.CampRegistrationModify.entering_address_with_data
FrontOffice.CampRegistrationModify.selecting_city_with_data
FrontOffice.CampRegistrationModify.entering_phno_with_data
FrontOffice.CampRegistrationModify.save
FrontOffice.CampRegistrationModify.get_message'''
        
class PatientDetailUpdate(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_PatientDetailsUpdate")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()           
    def selecting_the_frame(self):        
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_regno(self):        
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_regno'], 30, "regno was not visible")
        self.input_text(self.objects['FO_patient_details_update_regno'],(self.dict['REGNO']))
        self.press_key(self.objects['FO_patient_details_update_regno'], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_sal'], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_details_update_sal'], self.d[1]['sal'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_name'], 30, "name was not visible")
        self.input_text(self.objects['FO_patient_details_update_name'], self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_age_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_age'], 30, "age was not visible")
        self.input_text(self.objects['FO_patient_details_update_age'], str(self.d[1]['age']))
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_gender_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_gender'], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_details_update_gender'], self.d[1]['gender'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_maritalstatus_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_maritalstatus'], 30, "marital status was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_details_update_maritalstatus'], self.d[r]['mar_status'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_relation_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_relation'], 30, "relation was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_details_update_relation'], self.d[1]['relation'])
        self.dict['BROWSER'] = self._current_browser()
                
    def entering_relationname_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_relationname'], 30, "relation name was not visible")
        self.input_text(self.objects['FO_patient_details_update_relationname'], self.d[r]['relname'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_address'], 30, "address was not visible")
        self.input_text(self.objects['FO_patient_details_update_address'],self.d[1]['add'])
        self.dict['BROWSER'] = self._current_browser()
        
    
    def selecting_country_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_country'], 30, "country was not visible")
        self.select_from_list_by_label(self.objects['FO_patient_details_update_country'], self.d[1]['country'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_patient_details_update_save'], 30, "save btn was not enabled")
        self.click_button(self.objects['FO_patient_details_update_save'])
        self.dict['BROWSER'] = self._current_browser()
    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_message'], 30, 'message was not visible')
        message=self.get_text(self.objects['FO_patient_details_update_message'])
        print message
        self.wait_until_element_is_visible(self.objects['FO_patient_details_update_message_okbtn'], 30, 'okbtn was not visible')
        self.click_button(self.objects['FO_patient_details_update_message_okbtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
  
class DoctorAppointment(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_DoctorAppointment")
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
                
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
        
    def select_doctor_for_new_patient_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.mouse_over('xpath=//*[text()="'+str(self.d[r]['doctor_for_new_pat'])+'"]')
        self.wait_until_element_is_enabled('xpath=//*[.="'+str(self.d[r]['doctor_for_review_pat'])+'"]', 30,'Doctor for review patient can not be selected')
        self.dict['FO_DOCTOR_APPOINTMENT'] = str(self.d[r]['doctor_for_new_pat'])
        print str(self.d[r]['doctor_for_new_pat'])
        time.sleep(3)
        self.click_element('xpath=//*[text()="'+str(self.d[r]['doctor_for_new_pat'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def select_doctor_for_review_patient_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.mouse_over('xpath=//*[.="'+str(self.d[r]['doctor_for_review_pat'])+'"]')
        self.wait_until_element_is_enabled('xpath=//*[.="'+str(self.d[r]['doctor_for_review_pat'])+'"]', 30,'Doctor for review patient can not be selected')
        self.dict['FO_DOCTOR_APPOINTMENT'] = self.d[r]['doctor_for_review_pat']
        print str(self.d[r]['doctor_for_review_pat'])
        time.sleep(3)
        self.click_element('xpath=//*[.="'+str(self.d[r]['doctor_for_review_pat'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def select_doctor_for_cancel_appointment(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.mouse_over('xpath=//*[.="'+str(self.d[r]['cancel_appointment_doctor'])+'"]')
        self.wait_until_element_is_enabled('xpath=//*[.="'+str(self.d[r]['cancel_appointment_doctor'])+'"]', 30,'Doctor for review patient can not be selected')
        self.dict['FO_DOCTOR_APPOINTMENT'] = self.d[r]['cancel_appointment_doctor']
        print str(self.d[r]['cancel_appointment_doctor'])
        time.sleep(3)
        self.click_element('xpath=//*[.="'+str(self.d[r]['cancel_appointment_doctor'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def select_doctor_for_all_appointment_transfer(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.mouse_over('xpath=//*[.="'+str(self.d[r]['all_toc_transfer_doctor'])+'"]')
        self.wait_until_element_is_enabled('xpath=//*[.="'+str(self.d[r]['all_toc_transfer_doctor'])+'"]', 30,'Doctor for review patient can not be selected')
        self.dict['FO_DOCTOR_APPOINTMENT'] = self.d[r]['all_toc_transfer_doctor']
        print str(self.d[r]['all_toc_transfer_doctor'])
        time.sleep(3)
        self.click_element('xpath=//*[.="'+str(self.d[r]['all_toc_transfer_doctor'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def select_date(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_date"], 30, "date was not visible")
        self.mouse_over(self.objects["FO_doctor_appointment_date"])
        self.click_element(self.objects["FO_doctor_appointment_date"])
        self.dict['BROWSER'] = self._current_browser()
        
    def select_time(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        ## below wait was added for release server############
        self.wait_until_page_contains_element(self.objects["FO_doctor_appointment_time"], 30, "time was not visible in page")
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_time"], 30, "time was not visible")
        self.mouse_over(self.objects["FO_doctor_appointment_time"])
        self.click_element(self.objects["FO_doctor_appointment_time"])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        time.sleep(10)
        try:
            self.wait_until_page_contains_element(self.objects["FO_doctor_appointment_sal"], 30, "sal was not visible")
            self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_sal"], 30, "sal was not visible")
            self.select_from_list_by_label(self.objects["FO_doctor_appointment_sal"], self.d[r]['sal'])
        except ElementNotInteractableException:
            self.click_element(self.objects['FO_doctor_appointment_ok'])
            time.sleep(1)
            self.click_element(self.objects["FO_doctor_appointment_time2"])
            time.sleep(3)
            self.select_from_list_by_label(self.objects["FO_doctor_appointment_sal"], self.d[r]['sal'])
        #pyautogui.hotkey('tab')
        self.press_key(self.objects["FO_doctor_appointment_sal"], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_enabled(self.objects["FO_doctor_appointment_name"], 30,'Name text box is not properly enabled')
        self.input_text(self.objects["FO_doctor_appointment_name"], self.d[r]['name'])
        #self.input_text(self.objects["FO_doctor_appointment_name"], "rocky")
        self.dict['BROWSER'] = self._current_browser()
        
    def clicking_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_doctor_appointment_save"], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_doctor_appointment_save"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_mobile_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        Tempmobile = randint(1000,9999)
        self.dict['PHNO']="900562"+str(Tempmobile)
        self.input_text(self.objects["FO_doctor_appointment_phno"],self.dict['PHNO'])
#         self.input_text(self.objects["FO_NewRegistration_Mobile"],self.d[r]['phno'])
        self.dict['BROWSER'] = self._current_browser()
     
    def get_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_message"], 30, "Message was not visible")
        self.msg=self.get_text(self.objects["FO_doctor_appointment_message"])
        try:
            self.toc= ((self.msg).split('Confirm No :'))[1].split(' / Appointment')[0]
            self.date= ((self.msg).split('/ Appointment Date :'))[1].split(' / Time :')[0] 
        except:
            self.click_button(self.click_element("FO_doctor_appointment_ok"))
        self.toc = int (self.toc)
        self.dict['TOKEN']=self.toc
        print self.msg
        print ('The token number generated is ',self.toc,'and The apointment is fixed on ',self.date)
        self.dict['DATE'] = self.date        
        self.click_button(self.objects['FO_doctor_appointment_ok'])
        self.dict['BROWSER'] = self._current_browser()
        
    def select_review_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(10)
        pyautogui. FAILSAFE = False
        pyautogui.hotkey('esc')
        self.wait_until_element_is_visible(self.objects['FO_doctor_appointment_review_radio_btn'], 30, "review radio btn was not visible")
        self.click_element(self.objects['FO_doctor_appointment_review_radio_btn'])
        time.sleep(0.5)
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_regno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.input_text(self.objects["FO_doctor_appointment_regno"], str(self.dict['REGNO']))
        self.press_key(self.objects["FO_doctor_appointment_regno"], '\\13')
        #pyautogui.hotkey('enter')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
     
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()         
        
   
class DoctorAppointmentCancellation(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_DoctorAppCancellation")
            
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()        
    def select_the_frame(self):         
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def select_date_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.input_text(self.objects["FO_doctor_appointment_cancellation_date"], str(self.dict['DATE']))
        self.press_key(self.objects["FO_doctor_appointment_cancellation_date"], '\\13')
        #pyautogui.hotkey('enter')
        self.dict['BROWSER'] = self._current_browser()
        
    def doctor_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 30, "doctor was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDoctor"]',self.dict['FO_DOCTOR_APPOINTMENT'])
        self.dict['BROWSER'] = self._current_browser()

#     def doctor_with_data(self,r): 
#         self._cache.current = self.dict['BROWSER']
#         self.browser = self._current_browser()
#         r = int (r)
#         self.dict['FO_DOCTOR_APPOINTMENT']='Jprabu'
#         self.double_click_element('xpath=//*[@id="select2-chosen-6"]')
#         self.input_text('xpath=//*[@id="s2id_autogen6_search"]', self.dict['FO_DOCTOR_APPOINTMENT'])
#         pyautogui.hotkey('enter')
#         self.dict['BROWSER'] = self._current_browser()
        
    def click_serch(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_cancellation_serch"], 30, "search btn was not visible")
        self.click_element(self.objects["FO_doctor_appointment_cancellation_serch"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def list_all(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_label(self.objects["FO_doctor_appointment_cancellation_list"],'All')
        self.dict['BROWSER'] = self._current_browser()    
        
    def select_token(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        for i in range (1,100):
            phno=self.get_text('xpath=//*[@id="tbodyshowdata"]//tr['+str(i)+']//td[9]')
            phno=int(phno)
            self.dict['PHNO'] = int (self.dict['PHNO'])
            if phno==self.dict['PHNO'] :
                self.click_element('xpath=//*[@id="tbodyshowdata"]/tr['+str(i)+']/td[1]/input')
                break;
        self.dict['BROWSER'] = self._current_browser()
        
    def click_appointment_cancel(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_cancellation_cancel"], 30, "appointment cancel was nto visble")
        self.click_element(self.objects["FO_doctor_appointment_cancellation_cancel"])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_ok(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_cancellation_yes"], 30, "ok btn was not visible")
        self.click_element(self.objects["FO_doctor_appointment_cancellation_yes"])
        self.dict['BROWSER'] = self._current_browser()
     
    def select_reason_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        #Release server ################################################
        #r = int (r)
        #self.wait_until_element_is_visible(self.objects["FO_doctor_appointment_cancellation_reason"], 30, "reason was not visible")
        #self.select_from_list_by_label(self.objects["FO_doctor_appointment_cancellation_reason"], self.d[r]['cancel_reason'])
        ##########################################################################
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboReason"]', 30, "Reason dropdown was not visible")
        self.click_element('xpath=//*[@id="s2id_cboReason"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[1]', 30, "first list item for reason dropdown was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[1]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
        
    def click_save(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_doctor_appointment_cancellation_save"], 30, "save btn was not enabled")
        self.click_element(self.objects["FO_doctor_appointment_cancellation_save"])
        self.dict['BROWSER'] = self._current_browser()
        
    def get_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        print self.get_text(self.objects["FO_doctor_appointment_cancellation_message"])
        self.click_element(self.objects["FO_doctor_appointment_cancellation_ok"])
        print ('The token number',self.dict['TOKEN'],'for the doctor named',self.dict['FO_DOCTOR_APPOINTMENT'] ,'is canceled')
        self.dict['BROWSER'] = self._current_browser()
    
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
          
        
class TokenTransferForDoctorAppointmentAll(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_TokenTransferAll")
    
    def select_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    
    def select_date_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        #self.dict['DATE'] = "15-08-2023"
        #self.dict['FO_DOCTOR_APPOINTMENT'] = "Abbas Mandhiri"
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_date"], 30, "date was not visible")
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_all_date"], str(self.dict['DATE']))
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_all_date"], '\\13')
        self.dict['BROWSER'] = self._current_browser()  
        
    def doctor_with_data(self,r): 
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_doctor_click"], 30, "doctor was not visible")
        self.double_click_element(self.objects["Token_transfer_for_doctor_appointment_all_doctor_click"])
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_all_doctor_text"], self.dict['FO_DOCTOR_APPOINTMENT'])
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_all_doctor_text"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
            
    def click_serch(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_serch"], 30, "search was not visible")
        self.click_button(self.objects["Token_transfer_for_doctor_appointment_all_serch"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def list_all(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_list"], 30, "list was not visible")
        self.select_from_list_by_label(self.objects["Token_transfer_for_doctor_appointment_individual_list"],'All')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
       
    def select_all_token(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_all_token"], 30, "all token transfer was not visible")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_all_token"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    
    def click_token_transfer(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_transfer_btn"], 30, "token transfer btn was not visible")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_transfer_btn"])
        time.sleep(1)
#         try:
#             self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_transfer_btn"])
#         except ValueError:
#             self.click_button('xpath=//*[@id="btn-ok"]')
#             self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_transfer_btn"])    
        self.dict['BROWSER'] = self._current_browser()
            
    def click_yes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_yes"], 30, "yes btn was not visible")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_yes"])
        self.dict['BROWSER'] = self._current_browser()
        
        
    def select_transfer_date_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_transfer_date"], 30, "date was not visible")
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_all_transfer_date"], self.d[r]['token_transfer_date'])
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_all_transfer_date"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
        
    def select_transfer_doctor_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser() 
        r = int (r)
        self.select_from_list_by_label(self.objects["Token_transfer_for_doctor_appointment_all_transfer_doctor"],self.d[r]['token_transfer_doctor'])
        self.wait_until_element_contains(self.objects["Token_transfer_for_doctor_appointment_all_transfer_doctor"], self.d[r]['token_transfer_doctor'], 30, 'doctor is not entered')
        self.dict['BROWSER'] = self._current_browser()
        
    def click_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["Token_transfer_for_doctor_appointment_all_save"], 30, "save btn was not enabled")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_save"])
        self.dict['BROWSER'] = self._current_browser()                                                           
           
    def get_message(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()  
        time.sleep(2)
        r = int (r)
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_all_ok"], 30, 'Ok btn is not visible')   
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_all_ok"])
        print self.get_text(self.objects["Token_transfer_for_doctor_appointment_all_message"])
        print ('The appointments against the doctor ',self.dict['FO_DOCTOR_APPOINTMENT'],' ware transfered to ',self.d[r]['token_transfer_doctor'])
       
        self.dict['BROWSER'] = self._current_browser()
           
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class TokenTransferForDoctorAppointmentIndividual(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_TokenTransferIndividual")
                
    def selecting_the_frame(self):         
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_date_with_data(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['DATE'] = "15-08-2023"
        #self.dict['FO_DOCTOR_APPOINTMENT'] = "Abbas Mandhiri"
        #self.dict['TOKEN'] = "1"
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_date"], 30, "date was not visible")
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_individual_date"], str(self.dict['DATE']))
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_individual_date"], '\\13')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()  
        
    def selecting_doctor_with_data(self): 
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.double_click_element(self.objects["Token_transfer_for_doctor_appointment_individual_doctor_click"])
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_individual_doctor_text"], self.dict['FO_DOCTOR_APPOINTMENT'])
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_individual_doctor_text"], '\\13')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_searchbtn(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_serch"], 30, "go  btn was not visible")
        self.click_button(self.objects["Token_transfer_for_doctor_appointment_individual_serch"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_list_all(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_list"], 30, "all option was not visible")
        self.select_from_list_by_label(self.objects["Token_transfer_for_doctor_appointment_individual_list"],'All')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
            
    def selecting_token(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.mouse_over(self.objects["Token_transfer_for_doctor_appointment_individual_bottom_element"])
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//tr[1]', 30, "appointment details in grid was not visible")
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//*[..="'+str(self.dict['TOKEN'])+'"]', 30, "token number was not visible in grid")
        self.click_element('xpath=//*[@id="tbodyshowdata"]//*[..="'+str(self.dict['TOKEN'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
            
    def selecting_yes(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_yes"], 30, "yes btn was not visible")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_individual_yes"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
        
    def selecting_transfer_date_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_date"], 30, "token transfer date was not visible")
        self.input_text(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_date"], self.d[r]['token_transfer_date'])
        #self.click_element('xpath=//*[@class="active day"]')
        self.press_key(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_date"], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_transfer_doctor_with_data(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser() 
        r = int(r)
        time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cbosearchDoctor"]//abbr', 30, "close doctor with x symbol was not visible")
        self.click_element('xpath=//*[@id="s2id_cbosearchDoctor"]//abbr')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cbosearchDoctor"]', 30, "token transfer doctor field was not visible")
        self.click_element('xpath=//*[@id="s2id_cbosearchDoctor"]')
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_doctor"], 30, "token transfer doctor was not visible")
        self.select_from_list_by_label(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_doctor"],self.d[r]['token_transfer_doctor'])
        self.dict['BROWSER'] = self._current_browser()

    def selecting_transfer_token(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        #self.wait_until_element_is_not_visible('xpath=//*[@class="dataTables_empty" and .="No data available in table"]', 10, "data of the available token is not loaded")
        self.wait_until_page_contains_element('xpath=//*[@id="tbodyTokenData"]//tr[1]', 30, "token data was not proper in page")
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyTokenData"]//tr[1]', 30, "token data was not proper")
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_token"], 30, "token transfer check box was not visible")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_individual_transfer_token"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["Token_transfer_for_doctor_appointment_individual_save"], 30, "save btn was not enabled")
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_individual_save"])
        self.dict['BROWSER'] = self._current_browser()
        
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser() 
        time.sleep(2) 
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_message"], 30, "Success message was not visible")
        Msg = self.get_text(self.objects["Token_transfer_for_doctor_appointment_individual_message"])
        print Msg
        self.wait_until_element_is_visible(self.objects["Token_transfer_for_doctor_appointment_individual_ok"], 30, 'Element was not visible') 
        self.click_element(self.objects["Token_transfer_for_doctor_appointment_individual_ok"])
        #print ('The appointments against the doctor ',self.dict['FO_DOCTOR_APPOINTMENT'],' ware transfered to ',self.d[r]['token_transfer_doctor'])
        self.dict['BROWSER'] = self._current_browser()
           
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
            
      
class DoctorAppointmentBlockAndUnblock(Selenium2Library): 
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_AppointmentBlockUnblock")
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()                
    def selecting_the_frame(self):         
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    
    def datepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(3)
        if (picdate.date() == today.date()) or (picdate.date() > today.date()):     
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td[@class="today active day" or @class="day" or @class="today day"][text()="'+day+'"]')
            time.sleep(2)            
        else:
            raise AssertionError ("Date should be current date or future date")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_date_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtFromDate"]', 30, "date was not visible")
        date = self.d[r]['date']
        print "date", date
        self.datepicker('xpath=//*[@id="txtFromDate"]', date)
        self.dict['BROWSER'] = self._current_browser()
    
    
    def selecting_date_with_data_old(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        #self.d[r]['date'] = "14-08-2023"
        #self.d[r]['doctor'] = "Abbas Mandhiri"
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_date"], 30, "date was not visible")
        self.input_text(self.objects["Fo_appoinment_block_unblock_date"], str(self.d[r]['date']))
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Fo_appoinment_block_unblock_date"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
    
    def selecting_date_with_data_old1(self,r):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.page_should_contain_element(self.objects["Fo_appoinment_block_unblock_date"], 30, "date was not visible")
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_date"], 30, "date was not visible")
        self.click_element(self.objects["Fo_appoinment_block_unblock_date"])
        for i in range (1,11):
            pyautogui.hotkey('backspace')
        self.input_text(self.objects["Fo_appoinment_block_unblock_date"], self.d[r]['date'])
        #pyautogui.hotkey('enter')
        self.press_key(self.objects["Fo_appoinment_block_unblock_date"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
        
    def selecting_doctor_with_data(self,r): 
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['Fo_appoinment_block_unblock_doctor_click'], 30, "doctor was not visible")
        self.click_element(self.objects['Fo_appoinment_block_unblock_doctor_click'])
        self.select_from_list_by_label(self.objects["Fo_appoinment_block_unblock_doctor"],self.d[r]['doctor'])
        self.wait_until_element_contains(self.objects['Fo_appoinment_block_unblock_doctor_click'], self.d[r]['doctor'], 30, 'Doctor is not selected')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
         
    def selecting_searchbtn(self):    
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["Fo_appoinment_block_unblock_serch"], 30, "search btn was not enabled")
        self.click_button(self.objects["Fo_appoinment_block_unblock_serch"])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()  
      
    def select_token_for_block(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//tr[1]', 30, "token details in grid was not retried")
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token1"], 30, "token 1 transfer was not visible")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token1"])
        self.dict['BROWSER'] = self._current_browser()
        
    def select_token_for_block_and_unblock(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//tr[1]', 30, "token details in grid was not retried")
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token2"], 30, "token 2 was not visible to block")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token2"])
        time.sleep(0.5)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_multiple_token_for_block(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token3"], 5, "token 3 was not visible")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token3"])
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token4"], 5, "token 4 was not visible")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token4"])
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token5"], 5, "token 5 was not visible")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token5"])
        except:
            self.click_element(self.objects["Fo_appoinment_block_unblock_token_all"])
        self.dict['BROWSER'] = self._current_browser()
    
    def select_multiple_token_for_block_and_unblock(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token6"], 5, "token 6 was not visible to block")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token6"])
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token7"], 5, "token 7 was not visible to block")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token7"])
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token8"], 5, "token 8 was not visible to block")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token8"])
        except:
            self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token_all"], 30, "multile token block")
            self.click_element(self.objects["Fo_appoinment_block_unblock_token_all"])
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_blockbtn(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnBlock"]', 30, "block btn was not enabled")
        self.click_button('xpath=//*[@id="btnBlock"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def unselect_token_for_block(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token1"], 30, "selected token1 was not visible to unselect")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token1"])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselect_token_for_block_and_unblock(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token2"], 30, "token 2 was not visible to unselect the blocked one")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token2"])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_multiple_token_for_block(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token3"], 30, "taken3 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token3"])
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token4"], 30, "taken4 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token4"])
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token5"], 30, "taken5 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token5"])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselect_multiple_token_for_block_and_unblock(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token6"], 30, "taken 6 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token6"])
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token7"], 30, "taken 7 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token7"])
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_token8"], 30, "taken 8 was not visible for unselecting")
        self.click_element(self.objects["Fo_appoinment_block_unblock_token8"])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_unblockbtn(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_block"], 30, "block btn was not visible to unblock")
        self.click_button(self.objects["Fo_appoinment_block_unblock_block"])
        self.dict['BROWSER'] = self._current_browser()  
            
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["Fo_appoinment_block_unblock_message"], 30, "message was not visible")
        Msg = self.get_text(self.objects["Fo_appoinment_block_unblock_message"])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_okbtn(self):  
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["Fo_appoinment_block_unblock_ok_btn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["Fo_appoinment_block_unblock_ok_btn"])
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
          
class InReviewRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_ReviewReg")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_MainFrame'], 50, 'Main Frame was not visible')
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "628907"
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.wait_until_element_contains(self.objects['FO_ReviewRegistration_Regno'], '', 30, "regno was not visible")
        #self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Regno_12se'], 50, 'Regno was not visible')
        self.input_text(self.objects['FO_ReviewRegistration_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['FO_ReviewRegistration_Regno'], '\\10')
        ## below lines added for Release server###################################################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        #########################################################################################
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_yesbtn_in_confirmationmsg(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs8']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "message alert box was not visible")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "Patient Already Registered today, Are you sure you want to continue ?":               
                self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Yesbtn"], 30, "yes btn was not visible")
                self.click_button(self.objects["FO_ReviewRegistration_Yesbtn"])
                time.sleep(1)
            else:
                print "print same day review alert msg box was not visible"
                print "Message displayed    :", self.msg
        else:
            print "Same day Review Registration alert was not visible"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_department_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1') or (str(ctrlvalue) == '2'):
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Dept"], 30, "department was not visible")
            self.select_from_list_by_label(self.objects["FO_ReviewRegistration_Dept"],self.d[r]["department"])
        else:
            "Department field was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1'):
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Doc"], 30, "doctor was not visible")
            self.select_from_list_by_label(self.objects["FO_ReviewRegistration_Doc"],self.d[r]["doctor"])
        else:
            "doctor field was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '2'):
            r = int (r)
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]', 30, "unit field was not visible")
            #self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "unit text field was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//input')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]["unit"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]', 30, "unit field list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]')
            time.sleep(1)
        else:
            print "Unit field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_onlydoctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '3'):
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            r = int (r)
            time.sleep(3)
            self.wait_until_page_contains_element(self.objects["FO_ReviewRegistration_DoctorOnly"], 30, "doctor and department was not visible in page")
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_DoctorOnly"], 30, "doctor and department was not visible")
            self.click_element(self.objects['FO_ReviewRegistration_DoctorOnly'])           
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "doctor and department entry input was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input',self.d[r]["doctor"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]', 60, "Doctor and department list was present")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]')
            time.sleep(1)
        else:
            print "Doctor and department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_referraldoctor_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs5']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Referraldoctor"], 30, "referral doctor was not visible")
            self.click_element(self.objects["FO_ReviewRegistration_Referraldoctor"])
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Referraldoctor_Entry"], 30, "referral doctor input field was not visible")
            self.input_text(self.objects["FO_ReviewRegistration_Referraldoctor_Entry"],"%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 60, "referraldoctor list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\13')
            time.sleep(5)
        else:
            print "referral doctor Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_occupation_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs4']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_ReviewRegistration_Occupation"], 30, "occupation was not visible")
            self.select_from_list_by_index(self.objects["FO_ReviewRegistration_Occupation"], '2')
            time.sleep(1)
        else:
            print "Occupation Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_ReviewRegistration_Save"], 50, 'save was not enabled')
        self.click_button(self.objects["FO_ReviewRegistration_Save"])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_ReviewRegistration_Message'], 40, 'Record was not saved')
        Msg = self._get_text(self.objects['FO_ReviewRegistration_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_ReviewRegistration_Okbtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_ReviewRegistration_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InOpRegistrationCancel(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_OPNewReg")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_OPRegistrationCancel_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['FO_OPRegistrationCancel_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPRegistrationCancel_Gobtn"], 30, "Go btn was not enabled")
        self.click_button(self.objects["FO_OPRegistrationCancel_Gobtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cancelbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPRegistrationCancel_Cancelbtn"], 30, "Cancel btn was not enabled")
        self.click_element(self.objects["FO_OPRegistrationCancel_Cancelbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_yesbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPRegistrationCancel_Cancel_Yes"], 30, "cancel yes btn was not enabled")
        self.click_button(self.objects["FO_OPRegistrationCancel_Cancel_Yes"])
        self._handle_alert_with_text("By Mistake", True)
        time.sleep(2)        
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_OPRegistrationCancel_Message'], 30, 'Record was not cancelled')
        Msg = self._get_text(self.objects['FO_OPRegistrationCancel_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPRegistrationCancel_Message_Okbtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_OPRegistrationCancel_Message_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InOpCaseSheetDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_OPNewReg")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "2842"
        self.wait_until_page_contains_element(self.objects['FO_OPCaseSheetDirect_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['FO_OPCaseSheetDirect_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_GoBtn"], 30, "Go btn was not enabled")
        self.click_button(self.objects["FO_OPCaseSheetDirect_GoBtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_casesheet(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_CS"], 30, "case sheet was not visible")
            self.click_element(self.objects["FO_OPCaseSheetDirect_CS"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetDirect_CS"])
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        ###########################################
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_registrationlabel(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_RegLabel"], 30, "registration label was not visible")
            self.click_element(self.objects["FO_OPCaseSheetDirect_RegLabel"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetDirect_RegLabel"])
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        ###########################################
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mrd(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_MRD"], 30, "mrd was not visible")
            self.click_element(self.objects["FO_OPCaseSheetDirect_MRD"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetDirect_MRD"])
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        #########################################
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientcard(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_PatientCard"], 30, "patient card was not visible")
            self.click_element(self.objects["FO_OPCaseSheetDirect_PatientCard"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetDirect_PatientCard"])
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        #########################################################
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bill(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetDirect_PrintBill"], 30, "Print Bill was not visible")
            self.click_element(self.objects["FO_OPCaseSheetDirect_PrintBill"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetDirect_PrintBill"])
        try:
            self.wait_until_element_is_visible(self.objects['FO_OPCaseSheetDirect_Message'], 30, "message was not visible")
            Msg = self._get_text(self.objects['FO_OPCaseSheetDirect_Message'])
            print "Message    :", Msg
            if Msg == "Bill Not Found":
                self.wait_until_element_is_visible(self.objects['FO_OPCaseSheetDirect_Message_Ok'], 30, "OK btn was not visible")
                self.click_button(self.objects['FO_IPRegistration_Message_Ok'])
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_OPRegistrationCancel_Message'], 30, 'Record was not cancelled')
        Msg = self._get_text(self.objects['FO_OPRegistrationCancel_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPRegistrationCancel_Message_Okbtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_OPRegistrationCancel_Message_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InOpCaseSheetPreview(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_OPNewReg")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626718"
        self.wait_until_page_contains_element(self.objects['FO_OPCaseSheetPreview_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['FO_OPCaseSheetPreview_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_GoBtn"], 30, "Go Btn was not enabled")
        self.click_button(self.objects["FO_OPCaseSheetPreview_GoBtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_casesheet(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_CS"], 30, "case sheet was not visible")
        self.click_element(self.objects["FO_OPCaseSheetPreview_CS"])
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_registrationlabel(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_RegLabel"], 30, "registration label was not visible")
        self.click_element(self.objects["FO_OPCaseSheetPreview_RegLabel"])
        self._handle_alert(True)
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mrd(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_MRD"], 30, "mrd was not visible")
        self.click_element(self.objects["FO_OPCaseSheetPreview_MRD"])
        self._handle_alert(True)
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientcard(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_PatientCard"], 30, "patient card was not visible")
        self.click_element(self.objects["FO_OPCaseSheetPreview_PatientCard"])
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bill(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        try:
            self.wait_until_element_is_enabled(self.objects["FO_OPCaseSheetPreview_PrintBill"], 30, "Print Bill was not enabled")
            self.click_element(self.objects["FO_OPCaseSheetPreview_PrintBill"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_OPCaseSheetPreview_PrintBill"])
        try:
            self.wait_until_element_is_visible(self.objects['FO_OPCaseSheetPreview_Message'], 30, "message was not visible")
            Msg = self._get_text(self.objects['FO_OPCaseSheetPreview_Message'])
            print "Message    :", Msg
            if Msg == "Bill Not Found":
                self.wait_until_element_is_visible(self.objects['FO_OPCaseSheetPreview_Message_Ok'], 30, "OK btn was not visible")
                self.click_button(self.objects['FO_OPCaseSheetPreview_Message_Ok'])
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InNewMhcRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_NewMhcReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_mhcpackage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_MhcPackage"], 30, "mhc package was not visible")
        self.select_from_list_by_index(self.objects["FO_NewMhcRegistration_MhcPackage"],"2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mhcdoctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_MhcDoctor"], 30, "mhc doctor was not visible")
        self.click_element(self.objects['FO_NewMhcRegistration_MhcDoctor'])
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_MhcDoctorTextbox"], 30, "mhc doctor was not visible")
        self.input_text(self.objects["FO_NewMhcRegistration_MhcDoctorTextbox"],"%%%")
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_MhcDoctorListitem"], 30, "mhc doctor list was not visible")
        self.click_element(self.objects["FO_NewMhcRegistration_MhcDoctorListitem"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Sal"], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_NewMhcRegistration_Sal"],self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_LastName"], 30, "name was not visible")
        #Tempname = randint(100,999)
        #self.input_text(self.objects["FO_NewMhcRegistration_LastName"],"hendry johns "+str(randint(100,999)))
        self.input_text(self.objects["FO_NewMhcRegistration_LastName"],self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Gender"], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_NewMhcRegistration_Gender"],self.d[r]["gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Age"], 30, "age was not visible")
        self.input_text(self.objects["FO_NewMhcRegistration_Age"],self.d[r]["age"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Address"], 30, "address was not visible")
        self.input_text(self.objects["FO_NewMhcRegistration_Address"],self.d[r]["present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_City"], 30, "city was not visible")
        self.click_element(self.objects['FO_NewMhcRegistration_City'])
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_City_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_NewMhcRegistration_City_Entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        #self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_occupation_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs4']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Occupation"], 30, "occupation was not visible")
            self.select_from_list_by_index(self.objects["FO_NewMhcRegistration_Occupation"], '2')
            time.sleep(1)
        else:
            print "Occupation Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    ############Release server##############################
    def selecting_maritalstatus_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_MaritalStatus"], 30, "marital status was not visible")
        self.select_from_list_by_label(self.objects["FO_NewMhcRegistration_MaritalStatus"],self.d[r]["marital_status"])
        self.dict['BROWSER'] = self._current_browser()
    ##################################################################   
    def entering_mobileno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_NewMhcRegistration_Mobile"], 30, "mobile no was not visible")
        self.input_text(self.objects["FO_NewMhcRegistration_Mobile"],"9005621"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        #print self.d[r]["opnewreg_mobile"]
        #print(len(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_NewMhcRegistration_Savebtn"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_NewMhcRegistration_Savebtn"])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewMhcRegistration_Message'], 40, 'Record was not saved')
        Msg = self._get_text(self.objects['FO_NewMhcRegistration_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def fetching_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewMhcRegistration_Message'], 40, 'Record was not saved')
        Msg = self._get_text(self.objects['FO_NewMhcRegistration_Message'])
        print "Msg    :", Msg
        self.reg= ((Msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0] 
        self.dict['REGNO'] = self.reg
        print self.dict['REGNO']
        print("Registered Reg number is",self.dict['REGNO']) 
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_NewMhcRegistration_OkBtn"], 30, "ok btn was not enabled")
        self.wait_until_page_contains_element(self.objects["FO_NewMhcRegistration_OkBtn"], 30, "ok btn was not visible")
        self.click_button(self.objects["FO_NewMhcRegistration_OkBtn"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InReviewMhcRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_NewMhcReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626718"
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg1 = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg1
            if self.msg1 == "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.wait_until_page_contains_element(self.objects['FO_ReviewMhcRegistration_Regno'], 30, "regno was not visible")
        self.input_text(self.objects['FO_ReviewMhcRegistration_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects['FO_ReviewMhcRegistration_Regno'], '\\13')
        #########################    RELEASE SERVER ################################################################
        '''try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 7, "no records found message displayed")
            self.msg2 = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg2
            if self.msg2 == "Previous Visit Bill not Generated":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass'''
        ###########################################################################################################
        '''try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 7, "no records found message displayed")
            self.msg2 = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg2
            if self.msg2 == "Patient Review Days Exceeded":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mhcpackage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_ReviewMhcRegistration_MhcPackage"], 30, "mhc package was not visible")
        self.select_from_list_by_index(self.objects["FO_ReviewMhcRegistration_MhcPackage"],"3")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mhcdoctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_ReviewMhcRegistration_MhcDoctor"], 30, "mhc doctor was not visible")
        self.click_element(self.objects['FO_ReviewMhcRegistration_MhcDoctor'])
        self.wait_until_element_is_visible(self.objects["FO_ReviewMhcRegistration_MhcDoctorTextbox"], 30, "mhc doctor text box was not visible")
        self.input_text(self.objects["FO_ReviewMhcRegistration_MhcDoctorTextbox"],"%%%")
        self.wait_until_element_is_visible(self.objects["FO_ReviewMhcRegistration_MhcDoctorListitem"], 30, "mhc doctor list was not visible")
        self.click_element(self.objects["FO_ReviewMhcRegistration_MhcDoctorListitem"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_ReviewMhcRegistration_Savebtn"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_ReviewMhcRegistration_Savebtn"])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_ReviewMhcRegistration_Message'], 40, 'Record was not saved')
        Msg = self._get_text(self.objects['FO_ReviewMhcRegistration_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_ReviewMhcRegistration_OkBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_ReviewMhcRegistration_OkBtn"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InTemporaryRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_TempReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()      
    def selecting_sal(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Sal"], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_TempRegistration_Sal"],self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Name"], 30, "name was not visible")
        #self.input_text(self.objects["FO_TempRegistration_Name"],"Raja roja "+str(randint(100,999)))
        self.input_text(self.objects["FO_TempRegistration_Name"],self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Gender"], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_TempRegistration_Gender"],self.d[r]["gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Age"], 30, "age was not visible")
        self.input_text(self.objects["FO_TempRegistration_Age"],str(self.d[r]["age"]))
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Mobileno"], 30, "mobile no was not visible")
        self.input_text(self.objects["FO_TempRegistration_Mobileno"],"9780021"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_TempRegistration_Mobileno"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_TempRegistration_Mobileno"],str(self.d[r]["mobile"]))
        #print self.d[r]["mobile"]
        #print(len(self.d[r]["mobile"]))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_City"], 30, "city was not visible")
        self.click_element(self.objects['FO_TempRegistration_City'])
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_TempRegistration_City_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_TempRegistration_City_Entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        #self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()    
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_TempRegistration_Savebtn"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_TempRegistration_Savebtn"])
        self.dict['BROWSER'] = self._current_browser()
    def fetching_otno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 40, 'Record was not saved')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 40, 'Record was not saved')
        Msg = self._get_text('xpath=//*[@id="lblregno_tool"]')
        print "Msg    :", Msg
        self.dict['OTNO'] = Msg[15:]
        print self.dict['OTNO']
        print("Registered OT number is",self.dict['OTNO'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InTempToOPConversion(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("FO_TempToOP")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()          
    def entering_otno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["FO_TempRegToOPConversion_OTNo"], 30, "OT no was not visible")
        self.input_text(self.objects["FO_TempRegToOPConversion_OTNo"],str(self.dict['OTNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_TempRegToOPConversion_Searchbtn"], 30, "search btn was not enabled")
        self.click_button(self.objects["FO_TempRegToOPConversion_Searchbtn"])
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_otnofromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatientSearch"]//td[text()="'+str(self.dict['OTNO'])+'"]', 30, "OT NO was not visible")
        self.click_element('xpath=//*[@id="tblPatientSearch"]//td[text()="'+str(self.dict['OTNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_department(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegToOPConversion_Department"], 30, "department was not visible")
        self.select_from_list_by_label(self.objects["FO_TempRegToOPConversion_Department"],self.d[r]["department"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegToOPConversion_Doctor"], 30, "doctor was not visible")
        self.select_from_list_by_label(self.objects["FO_TempRegToOPConversion_Doctor"],self.d[r]["doctor"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_TempRegToOPConversion_address"], 30, "address was not visible")
        self.input_text(self.objects["FO_TempRegToOPConversion_address"],self.d[r]["present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobile(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_TempRegToOPConversion_Mobile"], 30, "mobile no was not visible")
        self.click_element(self.objects["FO_TempRegToOPConversion_Mobile"])
        self.clear_element_text(self.objects["FO_TempRegToOPConversion_Mobile"])
        self.input_text(self.objects["FO_TempRegToOPConversion_Mobile"],"9785621"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_TempRegToOPConversion_Mobile"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_TempRegToOPConversion_Mobile"],str(self.d[r]["mobile"]))
        #print self.d[r]["mobile"]
        #print(len(self.d[r]["mobile"]))
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #ime.sleep(1)
        self.wait_until_element_is_enabled(self.objects["FO_TempRegToOPConversion_Savebtn"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_TempRegToOPConversion_Savebtn"])
        '''time.sleep(1)
        pyautogui.click(860,165)
        time.sleep(1)
        pyautogui.click(860,165)'''
        #self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
        
    def fetching_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['FO_TempRegToOPConversion_Message'], 50, 'Record was not saved')
        self.msg = self._get_text(self.objects['FO_TempRegToOPConversion_Message'])
        self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0] 
        self.dict['REGNO'] = self.reg
        print self.dict['REGNO']
        print("Registered Reg number is",self.dict['REGNO'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        

class InIPCaseSheetDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13284"
        self.wait_until_page_contains_element(self.objects['FO_IPCaseSheetDirect_IPNo'], 20, "ipno was not visible")
        self.input_text(self.objects['FO_IPCaseSheetDirect_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetDirect_GoBtn"], 30, "Go btn was not enabled")
        self.click_button(self.objects["FO_IPCaseSheetDirect_GoBtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_casesheet(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetDirect_CS"], 30, "case sheet was not visible")
            self.click_element(self.objects["FO_IPCaseSheetDirect_CS"])
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_IPCaseSheetDirect_CS"])
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_registrationlabel(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetDirect_RegLabel"], 30, "registration label was not visible")
            self.click_element(self.objects["FO_IPCaseSheetDirect_RegLabel"])
            self._handle_alert(True)
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_IPCaseSheetDirect_RegLabel"])
            self._handle_alert(True)
                ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mrd(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetDirect_MRD"], 30, "mrd was not visible")
            self.click_element(self.objects["FO_IPCaseSheetDirect_MRD"])
            self._handle_alert(True)
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_IPCaseSheetDirect_MRD"])
            self._handle_alert(True)
        ### Release Server####################
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "Message was not visible")
            Msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print "Msg", Msg
            if Msg == "Please Configure Printer Path":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wristband(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetDirect_WristBand"], 30, "patient card was not visible")
            self.click_element(self.objects["FO_IPCaseSheetDirect_WristBand"])
            self._handle_alert(True)
            time.sleep(2)
        except:
            time.sleep(4)
            print "after sleep"
            self.click_element(self.objects["FO_IPCaseSheetDirect_WristBand"])
            self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InIPCaseSheetPreview(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("FO_OPNewReg")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13285"
        self.wait_until_page_contains_element(self.objects['FO_IPCaseSheetPreview_IPNo'], 30, "regno was not visible")
        self.input_text(self.objects['FO_IPCaseSheetPreview_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetPreview_GoBtn"], 30, "Go Btn was not enabled")
        self.click_button(self.objects["FO_IPCaseSheetPreview_GoBtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_casesheet(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetPreview_CS"], 30, "case sheet was not visible")
        self.click_element(self.objects["FO_IPCaseSheetPreview_CS"])
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_registrationlabel(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetPreview_RegLabel"], 30, "registration label was not visible")
        self.click_element(self.objects["FO_IPCaseSheetPreview_RegLabel"])
        self._handle_alert(True)
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mrd(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetPreview_MRD"], 30, "mrd was not visible")
        self.click_element(self.objects["FO_IPCaseSheetPreview_MRD"])
        self._handle_alert(True)
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wristband(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPCaseSheetPreview_WristBand"], 30, "wrist band was not visible")
        self.click_element(self.objects["FO_IPCaseSheetPreview_WristBand"])
        self._handle_alert(True)
        time.sleep(7)
        pyautogui.click(1117,656)
        time.sleep(1)
        pyautogui.click(1250,72)
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InIPDirectAdmission(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_IPDirectAdm")
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(7)
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1') or (str(ctrlvalue) == '2'):
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Dept"], 30, "department was not visible")
            self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_Dept"],self.d[r]["department"])
        else:
            print "Department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1'):
            r = int (r)
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Doc"], 30, "doctor was not visible")
            self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_Doc"],self.d[r]["doctor"])
        else:
            print "Doctor field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()   

    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '2'):
            r = int (r)
            #self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr', 30, "close mark in unit was not visible")
            #self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]', 30, "unit field was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "unit text field was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]["unit"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]', 30, "unit field list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]')
            time.sleep(2)
        else:
            print "Unit field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_onlydoctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '3'):
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            r = int (r)
            #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly"], 30, "doctor and department was not visible")
            #self.click_element(self.objects['FO_NewRegistration_DoctorOnly'])
            #time.sleep(2)
            self.wait_until_page_contains_element(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible in page")
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible")
            self.input_text(self.objects["FO_NewRegistration_DoctorOnly_Entry"],self.d[r]["doctor"])
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="BALAJI(CARDIOLOGY)"]', 30, "city list was present")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]', 60, "Doctor and department list was present")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]')
            time.sleep(1)
        else:
            print "Doctor and department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_nationality_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs2']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Nationality"], 30, "nationality was not visible")
            #self.select_from_list_by_label(self.objects["FO_NewRegistration_Nationality"],self.d[r]["nationality"])
            self.select_from_list_by_index(self.objects["FO_IPDirectAdmission_Nationality"], '2')
            time.sleep(1)
        else:
            print "Nationality Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_nationalityid_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs3']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_NationalityID"], 30, "nationality id field was not visible")
            self.input_text(self.objects["FO_IPDirectAdmission_NationalityID"], "AMRRM"+str(randint(100,999))+"T")
        else:
            print "Nationality Mandatory ID field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_occupation_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs4']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Occupation"], 30, "occupation was not visible")
            self.select_from_list_by_index(self.objects["FO_IPDirectAdmission_Occupation"], '2')
            time.sleep(1)
        else:
            print "Occupation Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_referraldoctor_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs5']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Referraldoctor"], 30, "referral doctor was not visible")
            self.click_element(self.objects["FO_IPDirectAdmission_Referraldoctor"])
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Referraldoctor_Entry"], 30, "referral doctor input field was not visible")
            self.input_text(self.objects["FO_IPDirectAdmission_Referraldoctor_Entry"],"%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 60, "referraldoctor list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\13')
            time.sleep(5)
        else:
            print "referral doctor Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_casecoordinator_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs7']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_CaseCoordinator"], 30, "case coordinator was not visible")
            self.select_from_list_by_index(self.objects["FO_IPDirectAdmission_CaseCoordinator"], '2')
            time.sleep(1)
        else:
            print "case coordinator field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_casemanager_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs7']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_CaseManager"], 30, "case manager was not visible")
            self.select_from_list_by_index(self.objects["FO_IPDirectAdmission_CaseManager"], '2')
            time.sleep(1)
        else:
            print "case manager field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_sal_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Sal"], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_Sal"],self.d[r]["sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Name"], 30, "name was not visible")
        #self.input_text(self.objects["FO_IPDirectAdmission_Name"],"Dakshan raghav"+str(randint(100,999)))
        #self.input_text(self.objects["FO_IPDirectAdmission_Name"],"rakshan sr")
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        self.input_text(self.objects["FO_IPDirectAdmission_Name"],self.d[r]["name"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Gender"], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_Gender"],self.d[r]["gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Age"], 30, "age was not visible")
        self.input_text(self.objects["FO_IPDirectAdmission_Age"],self.d[r]["age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_MaritalStatus"], 30, "marital status was not visible")
        self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_MaritalStatus"],self.d[r]["marital_status"])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Address"], 30, "address was not visible")
        self.input_text(self.objects["FO_IPDirectAdmission_Address"],self.d[r]["present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_City"], 30, "city was not visible")
        self.click_element(self.objects['FO_IPDirectAdmission_City'])
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_City_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_IPDirectAdmission_City_Entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was not present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        #self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()

       
    def entering_mobile_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_Mobile"], 30, "mobile no was not visible")
        self.input_text(self.objects["FO_IPDirectAdmission_Mobile"],"9785621"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        #print self.d[r]["opnewreg_mobile"]
        #print(len(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()    
    
    def selecting_bedtype_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPDirectAdmission_BedType'], 30, "bedtype was not visible")
        print self.d[r]['bedtype']
        print self.d[r]['ward']
        self.select_from_list_by_label(self.objects['FO_IPDirectAdmission_BedType'], str(self.d[r]["bedtype"]))
        time.sleep(3)
        self.dict['WARD-BEDTYPE'] = self.get_selected_list_label(self.objects["FO_IPDirectAdmission_BedType"])
        print self.dict['WARD-BEDTYPE']
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_wardname_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPDirectAdmission_Ward'], 30, "ward name was not visible")
        self.select_from_list_by_label(self.objects['FO_IPDirectAdmission_Ward'], str(self.d[r]["ward"]))
        #self.select_from_list_by_index(self.objects['FO_NewRegistration_Ward'], '1')
        time.sleep(2)
        self.dict['WARD-NAME'] = self.get_selected_list_label(self.objects["FO_IPDirectAdmission_Ward"])
        print self.dict['WARD-NAME']
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedno_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['FO_IPDirectAdmission_BedNo'], 30, "bedno was not visible")
        self.select_from_list_by_index(self.objects['FO_IPDirectAdmission_BedNo'], '1')
        time.sleep(1)
        self.dict['WARD-BEDNO'] = self.get_selected_list_label(self.objects["FO_IPDirectAdmission_BedNo"])
        print self.dict['WARD-BEDNO']
        self.dict['BROWSER'] = self._current_browser()
    
    def admit_diag_icd_code(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs6']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboICDCode"]', 30, "icd code was not visible")
            self.click_element('xpath=//*[@id="s2id_cboICDCode"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "search text box was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "list was not displayed")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.click_element('xpath=//*[.="Admit Diag(ICD Code) *"]')
            #self.input_text('xpath=//*[@id="s2id_autogen49_search"]',str(self.d[r]['icd_code']))
            #time.sleep(5)
            #pyautogui.hotkey('enter')
            #time.sleep(2)
        else:
            print "IP Admit Diagnosis Mandatory field in control setting was not enabled"
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_pharmacypaytype_with_data(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["FO_IPDirectAdmission_PharmPayType"], 30, "pharmacy paytype was not visible")
        self.select_from_list_by_label(self.objects["FO_IPDirectAdmission_PharmPayType"],self.d[r]["pharmacypaytype"])
        self.dict['BROWSER'] = self._current_browser() 
    
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_IPDirectAdmission_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_IPDirectAdmission_Savebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def fetching_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible(self.objects['FO_IPDirectAdmission_Message'], 40, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_IPDirectAdmission_Message'])
            self.IPno= ((self.msg).split('Record(s) Saved Successfully, IP No : '))[1].split(', Admission Date')[0]
            self.dict['IPNO'] = self.IPno
            print self.IPno
            print("Registered IPNO is",self.dict['IPNO'])
        except StaleElementReferenceException:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPDirectAdmission_Message_Ok"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_IPDirectAdmission_Message_Ok"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InOTPatientUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_otno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['OTNO'] = "3107"
        self.wait_until_page_contains_element(self.objects['FO_OTPatientUpdate_OTNo'], 30, "otno was not visible")
        self.input_text(self.objects['FO_OTPatientUpdate_OTNo'], str(self.dict['OTNO']))
        self.press_key(self.objects["FO_OTPatientUpdate_OTNo"], '\\13')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_OTPatientUpdate_Updatebtn'], 30, "update btn was not enabled")
        self.click_button(self.objects["FO_OTPatientUpdate_Updatebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_OTPatientUpdate_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['FO_OTPatientUpdate_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_OTPatientUpdate_Message_OKBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_OTPatientUpdate_Message_OKBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()    
        
class InIPDoctorUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    ### Commented below function and recreated new one for release server########################
    '''def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13603"
        self.wait_until_page_contains_element('xpath=//button[@title="Advanced Search"]', 30, "advance search was not visible")
        self.click_button('xpath=//button[@title="Advanced Search"]')
        self.wait_until_page_contains_element('xpath=//*[@id="txtIPNo"]', 30, "ipno was not visible")
        self.input_text('xpath=//*[@id="txtIPNo"]', str(self.dict['IPNO']))
        self.click_button('xpath=//*[@id="btnPatientSearch"]')
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatientSearch"]//td[text()="'+self.dict['IPNO']+'"]', 30, "patient search was not visible")
        self.click_element('xpath=//*[@id="tblPatientSearch"]//td[text()="'+self.dict['IPNO']+'"]')
        #self.wait_until_page_contains_element(self.objects['FO_IPDoctorUpdate_IPNo'], 20, "ipno was not visible")
        #self.input_text(self.objects['FO_IPDoctorUpdate_IPNo'], str(self.dict['IPNO']))
        #self.press_key(self.objects["FO_IPDoctorUpdate_IPNo"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()'''
    ########################################################################################################################
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13603"
        self.wait_until_page_contains_element(self.objects['FO_IPDoctorUpdate_IPNo'], 20, "ipno was not visible")
        self.input_text(self.objects['FO_IPDoctorUpdate_IPNo'], str(self.dict['IPNO']))
        self.press_key(self.objects["FO_IPDoctorUpdate_IPNo"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipdoctorname(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['OTNO'] = "3107"
        #Release server added below time line########################
        time.sleep(5)
        self.wait_until_page_contains_element('xpath=//*[@id="s2id_cboDoctor"]//abbr', 30, "close btn was not visible")
        #self.click_element('xpath=//*[@id="s2id_cboDoctor"]//abbr')
        self.select_from_list_by_index('xpath=//*[@id="cboDoctor"]', '2')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_IPDoctorUpdate_Remarks'], 30, "remarks was not visible")
        self.click_element(self.objects["FO_IPDoctorUpdate_Remarks"])
        self.clear_element_text(self.objects["FO_IPDoctorUpdate_Remarks"])
        self.input_text(self.objects["FO_IPDoctorUpdate_Remarks"], "Doctor name updated")
        self.dict['BROWSER'] = self._current_browser() 
    
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_IPDoctorUpdate_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_IPDoctorUpdate_Savebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_IPDoctorUpdate_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['FO_IPDoctorUpdate_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_IPDoctorUpdate_Message_OKBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_IPDoctorUpdate_Message_OKBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()   
class InPharmacyPayTypeUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13523"  
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass      
        self.wait_until_page_contains_element(self.objects['FO_PharmacyPayTypeUpdate_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['FO_PharmacyPayTypeUpdate_IPNo'], str(self.dict['IPNO']))
        self.press_key(self.objects["FO_PharmacyPayTypeUpdate_IPNo"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_PharmacyPayTypeUpdate_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_PharmacyPayTypeUpdate_Savebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_PharmacyPayTypeUpdate_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['FO_PharmacyPayTypeUpdate_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_PharmacyPayTypeUpdate_Message_OKBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_PharmacyPayTypeUpdate_Message_OKBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
  
class InMHCPackageUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643334"  
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass      
        self.wait_until_page_contains_element(self.objects['FO_MHCPackageUpdate_Regno'], 30, "ipno was not visible")
        self.input_text(self.objects['FO_MHCPackageUpdate_Regno'], str(self.dict['REGNO']))
        self.press_key(self.objects["FO_MHCPackageUpdate_Regno"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_mhcpackage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_MHCPackageUpdate_Package"], 30, "mhc package was not visible")
        self.select_from_list_by_index(self.objects["FO_MHCPackageUpdate_Package"],"3")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobileno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_MHCPackageUpdate_Mobile"], 30, "mobile no was not visible")
        self.clear_element_text(self.objects["FO_MHCPackageUpdate_Mobile"])
        time.sleep(0.5)
        self.input_text(self.objects["FO_NewMhcRegistration_Mobile"],"9005621"+str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_MHCPackageUpdate_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_MHCPackageUpdate_Savebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_MHCPackageUpdate_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['FO_MHCPackageUpdate_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_MHCPackageUpdate_Message_OKBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_MHCPackageUpdate_Message_OKBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        
class InBillableBedTypeUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13433"  
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="bootstrap-dialog-message"]', 30, "no records found message displayed")
            self.msg = self.get_text('xpath=//*[@class="bootstrap-dialog-message"]')
            print self.msg
            if self.msg == "No Record(s) Found aaa" or "No Record(s) Found":
               self.click_button('xpath=//*[@id="btn-ok"]')
        except:
            pass      
        self.wait_until_page_contains_element(self.objects['FO_BillableBedTypeUpdate_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['FO_BillableBedTypeUpdate_IPNo'], str(self.dict['IPNO']))
        self.press_key(self.objects["FO_BillableBedTypeUpdate_IPNo"], '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_billablebedtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_BillableBedTypeUpdate_BillableBedType"], 30, "Billable bed type was not visible")
        self.select_from_list_by_index(self.objects["FO_BillableBedTypeUpdate_BillableBedType"], '2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['FO_BillableBedTypeUpdate_Savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["FO_BillableBedTypeUpdate_Savebtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['FO_BillableBedTypeUpdate_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['FO_BillableBedTypeUpdate_Message'])
        print Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["FO_BillableBedTypeUpdate_Message_OKBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["FO_BillableBedTypeUpdate_Message_OKBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()         
