import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import time
from webbrowser import Chrome
import common_importstatements
from common_importstatements import *
#import admin
#from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class loginscreen(Selenium2Library):
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("login_bb")
    def login(self):
        r = 3
        
        self.open_browser('http://192.168.0.232/BB15se/Backbone/admin/login.aspx', 'chrome', None, False, None, None)
        time.sleep(2)
        self.maximize_browser_window()
        time.sleep(2)
        self.click_button(self.objects['login_newsessionbtn'])
        time.sleep(2)
        self.input_text(self.objects['login_username'], self.d[r]['username'])
        time.sleep(2)
        self.input_password(self.objects['login_password'], self.d[r]['pwd'])
        time.sleep(2)
        self.click_button(self.objects['login_reloginbtn'])
        time.sleep(5)
        
loginscreen().login()