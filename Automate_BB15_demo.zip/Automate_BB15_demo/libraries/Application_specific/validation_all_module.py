import sys
from Selenium2Library import Selenium2Library
from pip._vendor.distlib.locators import Locator
from openpyxl.cell.cell import TYPE_NULL
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
import pandas as pd 
class Validation(Selenium2Library):
        dict = admin.FromConfigFile.dict
        objects = common_reader.Capturing.objects
        d = Capturing().data_off("field_data1")
        def all(self):
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data1']
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
####################################################################################################################
            for i in range(self.d[1]['link'],sheet.max_row):
####################################################################################################################                        
#logging in the module for the very first time 
                if i==self.d[1]['link'] :
                    FromConfigFile().logging(self.d[i+1]['module'])
                    self._cache.current = self.dict['BROWSER']
                    self.browser = self._current_browser()
 ####################################################################################################################
#loading menu for the very first time
                    FromConfigFile().loading_menu_of_link(self.d[i+1]['link'])
                    self._cache.current = self.dict['BROWSER']
                    self.browser = self._current_browser()
                    self.select_frame(self.d[i+1]['frame'])
                    if self.d[i]['click']=='needclick':
                        self.mouse_down(self.d[i+1]['click'])
                        continue
 ####################################################################################################################                        
#logging off and logging in the module 
                elif self.d[i]['xpath']=='nextmodule':
                    FromConfigFile().Logoff()
                    FromConfigFile().logging(self.d[i+1]['module'])
                    FromConfigFile().loading_menu_of_link(self.d[i+1]['link'])
                    self._cache.current = self.dict['BROWSER']
                    self.browser = self._current_browser()
                    self.select_frame(self.d[i+1]['frame'])
                    if self.d[i]['click']=='needclick':
                        self.mouse_down(self.d[i+1]['click'])
                    continue
 ####################################################################################################################
 #switching to the next menu
                elif self.d[i]['xpath']=='nextmenu':
                    self.unselect_frame()
                    FromConfigFile().loading_menu_of_link(self.d[i+1]['link'])
                    self._cache.current = self.dict['BROWSER']
                    self.browser = self._current_browser()
                    self.select_frame(self.d[i+1]['frame'])
                    if self.d[i]['click']=='needclick':
                        self.mouse_down(self.d[i+1]['click'])
                    continue
                if self.d[i]['click']=='needclose':
                    self.click_element(self.d[i+1]['click'])
####################################################################################################################
#Giving input to field
                self.input_text(self.d[i]['xpath'], "a")
                a="a"
                a=a.lower()
                b=self.get_value(self.d[i]['xpath'])
                b=b.lower()
                if a==b:
                 sheet.cell(row=i+1,column=9).value ="YES"
                 self.input_text(self.d[i]['xpath'], "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
                 b=self.get_value(self.d[i]['xpath'])
                 b=b.lower()
                 c=len(b)
                 sheet.cell(row=i+1,column=13).value = c
                else:
                 sheet.cell(row=i+1,column=9).value ="NO"
                self.input_text(self.d[i]['xpath'], "1")
                a="1"
                b=self.get_value(self.d[i]['xpath'])
                self.dict['BROWSER'] = self._current_browser() 
                if a==b:
                 sheet.cell(row=i+1,column=11).value ="YES"
                 self.input_text(self.d[i]['xpath'], "11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111")
                 b=self.get_value(self.d[i]['xpath'])
                 b=b.lower()
                 c=len(b)
                 sheet.cell(row=i+1,column=13).value = c
                 wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')           
                else:
                 sheet.cell(row=i+1,column=11).value ="NO"
                 wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')            
                for j in range (4,36):
                    self.input_text(self.d[i]['xpath'],str(self.d[2][j*2]) )
                    a=str(self.d[2][j*2])
                    b=self.get_value(self.d[i]['xpath'])
                    self.dict['BROWSER'] = self._current_browser()
                    if a==b:
                        sheet.cell(row=i+1,column=((j+3)*2)+1).value ="YES"
                        wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                    else:
                        sheet.cell(row=i+1,column=((j+3)*2)+1).value ="NO" 
                        wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                if sheet.cell(row=i+1,column=10).value == sheet.cell(row=i+1,column=11).value:
                 sheet.cell(row=i+1,column=79).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=79).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=12).value == sheet.cell(row=i+1,column=13).value:
                 sheet.cell(row=i+1,column=80).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=80).value ="FAIL"
    
                if sheet.cell(row=i+1,column=14).value == sheet.cell(row=i+1,column=15).value:
                 sheet.cell(row=i+1,column=81).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=81).value ="FAIL"
    
                if sheet.cell(row=i+1,column=16).value == sheet.cell(row=i+1,column=17).value:
                 sheet.cell(row=i+1,column=82).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=82).value ="FAIL"
    
                if sheet.cell(row=i+1,column=18).value == sheet.cell(row=i+1,column=19).value:
                 sheet.cell(row=i+1,column=83).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=83).value ="FAIL"
    
                if sheet.cell(row=i+1,column=20).value == sheet.cell(row=i+1,column=21).value:
                 sheet.cell(row=i+1,column=84).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=84).value ="FAIL"
    
                if sheet.cell(row=i+1,column=22).value == sheet.cell(row=i+1,column=23).value:
                 sheet.cell(row=i+1,column=85).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=85).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=24).value == sheet.cell(row=i+1,column=25).value:
                 sheet.cell(row=i+1,column=86).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=86).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=26).value == sheet.cell(row=i+1,column=27).value:
                 sheet.cell(row=i+1,column=87).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=87).value ="FAIL"
    
                if sheet.cell(row=i+1,column=28).value == sheet.cell(row=i+1,column=29).value:
                 sheet.cell(row=i+1,column=88).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=88).value ="FAIL"
    
                if sheet.cell(row=i+1,column=30).value == sheet.cell(row=i+1,column=31).value:
                 sheet.cell(row=i+1,column=89).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=89).value ="FAIL"
    
                if sheet.cell(row=i+1,column=32).value == sheet.cell(row=i+1,column=33).value:
                 sheet.cell(row=i+1,column=90).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=90).value ="FAIL"
    
                if sheet.cell(row=i+1,column=34).value == sheet.cell(row=i+1,column=35).value:
                 sheet.cell(row=i+1,column=91).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=91).value ="FAIL"
    
                if sheet.cell(row=i+1,column=36).value == sheet.cell(row=i+1,column=37).value:
                 sheet.cell(row=i+1,column=92).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=92).value ="FAIL"
    
                if sheet.cell(row=i+1,column=38).value == sheet.cell(row=i+1,column=39).value:
                 sheet.cell(row=i+1,column=93).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=93).value ="FAIL"
    
                if sheet.cell(row=i+1,column=40).value == sheet.cell(row=i+1,column=41).value:
                 sheet.cell(row=i+1,column=94).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=94).value ="FAIL"
    
                if sheet.cell(row=i+1,column=42).value == sheet.cell(row=i+1,column=43).value:
                 sheet.cell(row=i+1,column=95).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=95).value ="FAIL"
                
                if sheet.cell(row=i+1,column=44).value == sheet.cell(row=i+1,column=45).value:
                 sheet.cell(row=i+1,column=96).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=96).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=46).value == sheet.cell(row=i+1,column=47).value:
                 sheet.cell(row=i+1,column=97).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=97).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=48).value == sheet.cell(row=i+1,column=49).value:
                 sheet.cell(row=i+1,column=98).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=98).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=50).value == sheet.cell(row=i+1,column=51).value:
                 sheet.cell(row=i+1,column=99).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=99).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=52).value == sheet.cell(row=i+1,column=53).value:
                 sheet.cell(row=i+1,column=100).value ="PASS"            
                else:
                 sheet.cell(row=i+1,column=100).value ="FAIL"             
                     
                if sheet.cell(row=i+1,column=54).value == sheet.cell(row=i+1,column=55).value:
                 sheet.cell(row=i+1,column=101).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=101).value ="FAIL"      
                
                if sheet.cell(row=i+1,column=56).value == sheet.cell(row=i+1,column=57).value:
                 sheet.cell(row=i+1,column=102).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=102).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=58).value == sheet.cell(row=i+1,column=59).value:
                 sheet.cell(row=i+1,column=103).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=103).value ="FAIL"
    
                if sheet.cell(row=i+1,column=60).value == sheet.cell(row=i+1,column=61).value:
                 sheet.cell(row=i+1,column=104).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=104).value ="FAIL"
    
                if sheet.cell(row=i+1,column=62).value == sheet.cell(row=i+1,column=63).value:
                 sheet.cell(row=i+1,column=105).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=105).value ="FAIL"
    
                if sheet.cell(row=i+1,column=64).value == sheet.cell(row=i+1,column=65).value:
                 sheet.cell(row=i+1,column=106).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=106).value ="FAIL"
    
                if sheet.cell(row=i+1,column=66).value == sheet.cell(row=i+1,column=67).value:
                 sheet.cell(row=i+1,column=107).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=107).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=68).value == sheet.cell(row=i+1,column=69).value:
                 sheet.cell(row=i+1,column=108).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=108).value ="FAIL"
    
                if sheet.cell(row=i+1,column=70).value == sheet.cell(row=i+1,column=71).value:
                 sheet.cell(row=i+1,column=109).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=109).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=72).value == sheet.cell(row=i+1,column=73).value:
                 sheet.cell(row=i+1,column=110).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=110).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=74).value == sheet.cell(row=i+1,column=75).value:
                 sheet.cell(row=i+1,column=111).value ="PASS"
                else:
                 sheet.cell(row=i+1,column=111).value ="FAIL"
                 
                if sheet.cell(row=i+1,column=76).value == sheet.cell(row=i+1,column=77).value:
                 sheet.cell(row=i+1,column=112).value ="PASS"
                 wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                 wb.close()
                else:
                 sheet.cell(row=i+1,column=112).value ="FAIL"
                 wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                 wb.close()
                wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
                sheet= wb['field_data1']
                print sheet.cell(row=i,column=7).value
        
FromConfigFile().driving_browser_and_url()         
Validation().all() 
        