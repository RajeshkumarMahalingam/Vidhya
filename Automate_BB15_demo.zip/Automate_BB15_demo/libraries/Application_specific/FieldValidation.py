from Selenium2Library import Selenium2Library
import time
from webbrowser import Chrome

class Field_Validation(Selenium2Library):
    
    def field_validation(self):
        