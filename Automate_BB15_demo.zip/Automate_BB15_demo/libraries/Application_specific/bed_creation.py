import sys
from Selenium2Library import Selenium2Library
import pyautogui
from pandas.core.arrays.integer import classname
from selenium import webdriver
from test.test_multiprocessing import get_value
from selenium.common.exceptions import ElementNotInteractableException,\
    ElementClickInterceptedException
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class bedcreation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #reg = ""
    d = Capturing().data_off("bed creation")
    
    def bed(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_MainFrame"], 10, "frame was not visible")
        self.select_frame(self.objects["FO_MainFrame"])
        time.sleep(10)
        for i in range(1,51):
            r = i
            self.input_text('xpath=//*[@id="txtBedNo"]',str( self.d[r]['bn']))
            self.input_text('xpath=//*[@id="txtBedDesc"]', 'NA')
            self.select_from_list_by_label('xpath=//*[@id="cboBedType"]','GENERAL BED') 
            self.select_from_list_by_label('xpath=//*[@id="cboWard"]','WARD') 
            self.input_text('xpath=//*[@id="txtSortOrder"]', '1')
            self.select_from_list_by_index('xpath=//*[@id="cboCompany"]','1') 
            self.select_from_list_by_index('xpath=//*[@id="cboIntercomStatus"]','2') 
            self.input_text('xpath=//*[@id="txtIntercomNumber"]', str(self.d[r]['n']))
            self.click_button('xpath=//*[@id="btnsave"]')
            self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
d = Capturing().data_off("bed creation")
FromConfigFile().logging("ward")
bedcreation().bed()        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        