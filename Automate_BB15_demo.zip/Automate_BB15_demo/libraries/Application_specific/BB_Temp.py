 
"""FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("BB_PreDonorReg")
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/DonorPreRegistration.aspx')
r = 6
InDonarPreRegistration().selecting_sal_with_data(r)
InDonarPreRegistration().entering_name_with_data(r)
InDonarPreRegistration().selecting_gender_with_data(r)
InDonarPreRegistration().entering_age_with_data(r)
InDonarPreRegistration().entering_adress_with_data(r)
InDonarPreRegistration().selecting_city_with_data(r) 
InDonarPreRegistration().click_on_save_button(r)
InDonarPreRegistration().getting_msg_from_save(r)"""




class InPreRegistrationScreening(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BloodpreregistrationScreening")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_donar_reg_number(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.input_text(self.objects['BB_PreRegistrationScreening_regnumber'],str(self.dict['DREGNO']))
         self._cache.current = self.dict['BROWSER']
    def click_on_go_btn(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.click_button(self.objects['BB_PreRegistrationScreening_gobutton'])
         self.dict['BROWSER'] = self._current_browser()
    def select_regnum_fromgrid(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         time.sleep(2)
         #self.wait_until_element_is_visible(self.objects['BB_PreRegistrationScreening_griddonornumber3'], 10, 'grid notvisible')
         self.click_element(self.objects['BB_PreRegistrationScreening_griddonornumber3'])
         self.dict['BROWSER'] = self._current_browser() 
         
    def selecting_blood_donate_status(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r) 
        #self.select_frame(self.objects['BB_PreRegistrationScreening_redirectMainframe'])  
        time.sleep(2)
        self.click_element(self.objects['BB_PreRegistrationScreening_blooddonorstatuscombo'])
        self.input_text(self.objects['BB_PreRegistrationScreening_blooddonorstatustext'], self.d[r]['bb_prereg_screening_blooddonate_status'])
        self.press_key(self.objects['BB_PreRegistrationScreening_blooddonorstatustext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks_with_data(self,r):
        self._cache.current = self.dict['BROWSER']  
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_Remarks'], self.d[r]['bb_prereg_screening_remarks'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_resultvalue_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_testnameresultvalue'], self.d[r]['bb_prereg_screening_resultvalue'])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_save_button(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_savebtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_bloodbag_type_withdata(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typecombo'])
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typetext'], self.d[r]['bb_prereg_screening_bloodbagtype'])
        self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_weight_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_weight'], str(self.d[r]['bb_prereg_screening_weight']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_bloodpressure_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodpressure'], str(self.d[r]['bb_prereg_screening_bloodpressure']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_donortype_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypecombo'])
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], self.d[r]['bb_prereg_screening_donortype'])
        self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_regdate_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_regdate'], str(self.d[r]['bb_prereg_screening_regdate']))
        self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_regdate'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_bloodunitnum_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodunit_num'],str( self.d[r]['bb_prereg_screening_bloodunitnum']))
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_segmentnum_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_segmentnumber'], str(self.d[r]['bb_prereg_screening_segmentnum']))
        self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_segmentnumber'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_blood_component_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponentcombo2'])
        self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], self.d[r]['bb_prereg_screening_componentname'])
        self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_bloodcomponent_addbtn(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_addbtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_bloodcomponent_deletebtn(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_deletebtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_delete_msg_ok(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_deletebtn_msg_okbtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_delete_msg_cancell(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_deletebtn_msg_cancellbtn'])
        self.dict['BROWSER'] = self._current_browser()    
           
        
    def click_on_savebtn(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_savebtn'])
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_save_msg_okbtn(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponent_save_msg_okbtn'])
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
       
"""FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("BB_PreDonorReg")
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/DonorPreRegistration.aspx')
r = 1
InDonarPreRegistration().selecting_sal_with_data(r)
InDonarPreRegistration().entering_name_with_data(r)
InDonarPreRegistration().selecting_gender_with_data(r)
InDonarPreRegistration().entering_age_with_data(r)
InDonarPreRegistration().entering_adress_with_data(r)
InDonarPreRegistration().selecting_city_with_data(r) 
InDonarPreRegistration().click_on_save_button(r)
InDonarPreRegistration().get_msg_from_save(r)
Capturing().data_off("BloodpreregistrationScreening")
r = 1
FromConfigFile().loading_menu_of_link('//BloodBank/ScreenTestListPreDonor.aspx')
InPreRegistrationScreening().entering_donar_reg_number(r)
InPreRegistrationScreening().click_on_go_btn(r) 
InPreRegistrationScreening().select_regnum_fromgrid(r)
InPreRegistrationScreening().selecting_blood_donate_status(r)
InPreRegistrationScreening().entering_remarks_with_data(r)
InPreRegistrationScreening().entering_resultvalue_with_data(r)
InPreRegistrationScreening().click_on_save_button(r)
InPreRegistrationScreening().entering_bloodbag_type_withdata(r)
InPreRegistrationScreening().entering_weight_with_data(r)
InPreRegistrationScreening().entering_bloodpressure_with_data(r)
InPreRegistrationScreening().entering_donortype_with_data(r)
InPreRegistrationScreening().entering_regdate_with_data(r)
InPreRegistrationScreening().entering_bloodunitnum_with_data(r)
InPreRegistrationScreening().entering_segmentnum_with_data(r)
InPreRegistrationScreening().selecting_blood_component_with_data(r)
InPreRegistrationScreening().click_on_bloodcomponent_addbtn(r)
#InPreRegistrationScreening().click_on_bloodcomponent_deletebtn(r)
#InPreRegistrationScreening().click_on_delete_msg_ok(r)
#InPreRegistrationScreening().click_on_delete_msg_cancell(r)
InPreRegistrationScreening().click_on_savebtn(r)
InPreRegistrationScreening().click_on_save_msg_okbtn(r)"""


class Inmainscreening(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BloodpreregistrationScreening")
    
    
    def entering_unitnum_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["BB_Mainframe"], 10, "frame was not visible")
        self.select_frame(self.objects["BB_Mainframe"])
        self.input_text(self.objects['BB_main_screening_bloodunit'],str(self.d[r]['bb_prereg_screening_bloodunitnum']))
        self.dict['BROWSER'] = self._current_browser()
        
    def click_on_gobtn(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_main_screening_go'])
        self.dict['BROWSER'] = self._current_browser()
    
    def select_record_frm_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['BB_PreRegistrationScreening_griddonornumber3'], 10, 'grid notvisible')
        self.click_element(self.objects['BB_main_screening_grid_select'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_bloodgroup_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_main_screening_Bloodgroupcombo'])
        self.input_text(self.objects['BB_main_screening_Bloodgrouptext'], self.d[r]['bb_mainscreen_bloodgroup'])
        self.press_key(self.objects['BB_main_screening_Bloodgrouptext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_rhtype_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_main_screening_rhtypecombo'])
        self.input_text(self.objects['BB_main_screening_rhtypetext'], self.d[r]['bb_mainscreen_rhtype'])
        self.press_key(self.objects['BB_main_screening_rhtypetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_blood_donate_status_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_element(self.objects['BB_main_screening_blooddonorStatuscombo'])
        self.input_text(self.objects['BB_main_screening_blooddonorStatustext'], self.d[r]['bb_mainscreen_blood_donate_status'])
        self.press_key(self.objects['BB_main_screening_blooddonorStatustext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_remarks'], self.d[r]['bb_mainscreen_remarks'])
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue1_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_testnamet1'], str(self.d[r]['bb_mainscreen_resultvalue1']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue2_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_testnamet2'], str(self.d[r]['bb_mainscreen_resultvalue2']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue3_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_testnamet3'], str(self.d[r]['bb_mainscreen_resultvalue3']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue4_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_testnamet4'], str(self.d[r]['bb_mainscreen_resultvalue4']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue5_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening _testnamet5'], str(self.d[r]['bb_mainscreen_resultvalue5']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_resultvalue6_in_grid(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_main_screening_testnamet6'], str(self.d[r]['bb_mainscreen_resultvalue6']))
        self.dict['BROWSER'] = self._current_browser()
        
        
    def click_on_save_button(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_main_screening_save'])
        self.dict['BROWSER'] = self._current_browser()
        
        
    def click_on_sucessmsg_ok_button(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_main_screening_sucessmsg_okbtn'])
        self.dict['BROWSER'] = self._current_browser()
   

class InMainDonarRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_PreDonorReg")
    
    def selecting_sal_with_data(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('BB_predonorregistration_mainframe', 10, 'main frame not visible')
        self.select_frame(self.objects['BB_Mainframe'])
        #self.wait_until_element_is_visible("BB_predonorregistration_salcombo", 10, 'sal not visible' )
        self.select_from_list_by_label(self.objects['BB_predonorregistration_salcombo'], self.d[r]['bb_prereg_sal'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_name_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_predonorregistration_donarname'], self.d[r]['bb_prereg_name'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.select_from_list_by_label(self.objects['BB_predonorregistration_gendertextbox'], self.d[r]['bb_prereg_gender'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_age_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_predonorregistration_age'],str(self.d[r]['bb_prereg_age']) )
        self.dict['BROWSER'] = self._current_browser()
    def entering_adress_with_data(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text(self.objects['BB_predonorregistration_address'], self.d[r]['bb_prereg_address'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r =  int(r)
         self.click_element(self.objects['BB_predonorregistration_citytextbox'])
         self.input_text(self.objects['BB_predonorregistration_cityselect'], self.d[r]['bb_prereg_city'])
         time.sleep(2)
         #self.wait_until_element_is_visible('BB_predonorregistration_cityselect', 10, 'city not visible')
         self.press_key(self.objects['BB_predonorregistration_cityselect'], '\\09')
         self.dict['BROWSER'] = self._current_browser()
    
    
      
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
"""FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/DonorRegistration.aspx')
Capturing().data_off("BloodpreregistrationScreening")
r = 1
InMainDonarRegistration().selecting_sal_with_data(r)
InMainDonarRegistration().entering_name_with_data(r)
InMainDonarRegistration().selecting_gender_with_data(r)
InMainDonarRegistration().entering_age_with_data(r)
InMainDonarRegistration().entering_adress_with_data(r)
InMainDonarRegistration().selecting_city_with_data(r)"""






"""FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/DonorPreRegistration.aspx')
Capturing().data_off("BloodpreregistrationScreening")
r = 1
InDonarPreRegistration().selecting_sal_with_data(r)
InDonarPreRegistration().entering_name_with_data(r)
InDonarPreRegistration().selecting_gender_with_data(r)
InDonarPreRegistration().entering_age_with_data(r)
InDonarPreRegistration().entering_adress_with_data(r)
InDonarPreRegistration().selecting_city_with_data(r) 
InDonarPreRegistration().click_on_save_button(r)
InDonarPreRegistration().get_msg_from_save(r)
Capturing().data_off("BloodpreregistrationScreening")
r = 1
FromConfigFile().loading_menu_of_link('//BloodBank/ScreenTestListPreDonor.aspx')
InPreRegistrationScreening().entering_donar_reg_number(r)
InPreRegistrationScreening().click_on_go_btn(r) 
InPreRegistrationScreening().select_regnum_fromgrid(r)
InPreRegistrationScreening().selecting_blood_donate_status(r)
InPreRegistrationScreening().entering_remarks_with_data(r)
InPreRegistrationScreening().entering_resultvalue_with_data(r)
InPreRegistrationScreening().click_on_save_button(r)
InPreRegistrationScreening().entering_bloodbag_type_withdata(r)
InPreRegistrationScreening().entering_weight_with_data(r)
InPreRegistrationScreening().entering_bloodpressure_with_data(r)
InPreRegistrationScreening().entering_donortype_with_data(r)
InPreRegistrationScreening().entering_regdate_with_data(r)
InPreRegistrationScreening().entering_bloodunitnum_with_data(r)
InPreRegistrationScreening().entering_segmentnum_with_data(r)
InPreRegistrationScreening().selecting_blood_component_with_data(r)
InPreRegistrationScreening().click_on_bloodcomponent_addbtn(r)
#InPreRegistrationScreening().click_on_bloodcomponent_deletebtn(r)
#InPreRegistrationScreening().click_on_delete_msg_ok(r)
#InPreRegistrationScreening().click_on_delete_msg_cancell(r)
InPreRegistrationScreening().click_on_savebtn(r)
InPreRegistrationScreening().click_on_save_msg_okbtn(r)
FromConfigFile().loading_menu_of_link('//BloodBank/ScreenTestEntryDonorSearch.aspx')
r = 1
Capturing().data_off("BB_PreDonorReg")
Inmainscreening().entering_unitnum_with_data(r)
Inmainscreening().click_on_gobtn(r)
Inmainscreening().select_record_frm_grid(r)
Inmainscreening().selecting_bloodgroup_with_data(r)
Inmainscreening().selecting_rhtype_with_data(r)
Inmainscreening().selecting_blood_donate_status_with_data(r)
Inmainscreening().entering_remarks_with_data(r)
#Inmainscreening().entering_resultvalue1_in_grid
#Inmainscreening().entering_resultvalue2_in_grid
#Inmainscreening().entering_resultvalue3_in_grid
#Inmainscreening().entering_resultvalue4_in_grid
#Inmainscreening().entering_resultvalue5_in_grid
#Inmainscreening().entering_resultvalue6_in_grid
Inmainscreening().click_on_save_button(r)
Inmainscreening().click_on_sucessmsg_ok_button(r)"""


        
        
        
class InDiscardStocks(Selenium2Library):  
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("DiscardStocks") 
    
    def entering_regnum_with_data(self,r): 
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["BB_Mainframe"], 10, "frame was not visible")
        self.select_frame(self.objects["BB_discardstock_mainframe"])
        self.input_text(self.objects['BB_discardstock_Registernuber'],str(self.dict['DREGNO']))
        self._cache.current = self.dict['BROWSER']
        
    def clicking_on_go_button(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.click_button(self.objects['BB_main_screening_go'])
        self.dict['BROWSER'] = self._current_browser()
       
     
        
        
        
     
        
        
        
        
        
FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/StockDiscardSave.aspx')
Capturing().data_off("DiscardStocks")
r = 1       
        