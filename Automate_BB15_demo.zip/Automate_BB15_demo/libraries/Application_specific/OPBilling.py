import sys
from Selenium2Library import Selenium2Library
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InPayMode(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        #####Release server######################################
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="lblPayableAmt"]', 10, "payable amount was not displayed")
        except:
            self.wait_until_element_is_visible('xpath=//*[@id="lblTotalRefundAmt"]', 10, "refund amount was not displayed")
        ######################################################################
        self.wait_until_element_is_enabled('xpath=//a[@id="paymentDetailLink"]', 30, 'OPB paymode link was not visible')
        self.click_link('xpath=//a[@id="paymentDetailLink"]')
        #self.click_element(self.objects['OPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode_Frame'], 30, 'OPB paymode frame was not visible')
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        ### cOMMENTED ABOVE FOR RELEASE SERVER AND ADDED FOR BELOW LINE FOR RELEASE SERVER
        #self.select_frame('xpath=//*[@id="iframe2"]')
        time.sleep(5)
        self.wait_until_page_contains_element(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()   
            
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    
    '''def selecting_cash_payment(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["OPB_Paymode_CashLink"], 15, "cash link was not visible")
        self.click_element(self.objects["OPB_Paymode_CashLink"])
        print "cash link clicked"
        paymentmsgcash = "cash,"
        return paymentmsgcash
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cashsavebtn(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["OPB_Paymode_CashSavebtn"], 15, "cash save btn was not enabled")
        self.click_button(self.objects['OPB_Paymode_CashSavebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cheque_payment(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["OPB_Paymode_ChequeLink"], 15, "cheque link was not visible")
        self.click_element(self.objects["OPB_Paymode_ChequeLink"])
        print "cheque link clicked"
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeAmount"], 15, "payment cheque amnt was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_ChequeAmount"], self.d[r]['cheque'])
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeNo"], 15, "payment cheque no was not visible")
        chequeno = randint(100000000,999999999)
        self.input_text(self.objects["Pharm_Sales_payment_ChequeNo"], str(chequeno))
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeDate"], 15, "payment cheque date was not visible")
        currentdate = date.today()
        chequedate = str(currentdate)[8:10]+"-"+str(currentdate)[5:7]+"-"+str(currentdate)[0:4]
        self.input_text(self.objects["Pharm_Sales_payment_ChequeDate"], str(chequedate))
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeBankName"], 15, "payment bank name was not visible")
        self.select_from_list_by_index(self.objects["Pharm_Sales_payment_ChequeBankName"], '1')
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeBranch"], 15, "payment branch name was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_ChequeBranch"], "Besant Nagar")
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ChequeCity"], 15, "payment city name was not visible")
        self.select_from_list_by_index(self.objects["Pharm_Sales_payment_ChequeCity"], '1')
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_ToBank"], 15, "payment To Bank name was not visible")
        self.select_from_list_by_index(self.objects["Pharm_Sales_payment_ToBank"], '1')
        paymentmsgcheque = "cheque"
        return paymentmsgcheque
        self.dict['BROWSER'] = self._current_browser()
    def selecting_card_payment(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_card"], 15, "payment card was not visible")
        self.click_element(self.objects["Pharm_Sales_payment_card"])
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_card_amount"], 15, "card amount was not visible")
        self.clear_element_text(self.objects["Pharm_Sales_payment_card_amount"])
        self.input_text(self.objects["Pharm_Sales_payment_card_amount"], str(self.d[r]['card']))
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_card_cardno"], 15, "card number was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_card_cardno"], str(self.d[r]['salespharm_card_no']))
        print "card link clicked"
        paymentmsgcard = "card,"
        return paymentmsgcard
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dd_payment(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_DD"], 15, "payment dd was not visible")
        self.click_element(self.objects["Pharm_Sales_payment_DD"])
        print "dd link clicked"
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_DD_amnt"], 15, "DD amount was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_DD_amnt"], str(self.d[r]['salespharm_dd_amnt']))
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_DD_no"], 15, "DD number was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_DD_no"], str(self.d[r]['salespharm_dd_no']))
        self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_DD_date"], 15, "DD date was not visible")
        self.input_text(self.objects["Pharm_Sales_payment_DD_date"], str(self.d[r]['salespharm_dd_date']))
        self.press_key(self.objects["Pharm_Sales_payment_DD_date"], '\\09')
        self.selecting_payment_dd_bank(r)
        #self.wait_until_element_is_visible(self.objects["Pharm_Sales_payment_DD_branchname"], 15, "DD branch name was not visible")
        #self.input_text(self.objects["Pharm_Sales_payment_DD_branchname"], self.d[r]['salespharm_dd_branch'])
        self.selecting_payment_dd_city(r)
        paymentmsgdd = "DD"
        return paymentmsgdd
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_eft_payment(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        pass
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_paymenttype(self,mode):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        if mode == Cash:
           self.selecting_cash_payment()
        if mode == Cheque:
           self.selecting_cheque_payment(r)
        if mode == Card:
            self.selecting_card_payment(r)
        if mode == DD:
            self.selecting_dd_payment(r)
        if mode == EFT:
            self.selecting_eft_payment(r)
        if mode == all:
            self.selecting_cheque_payment(r)
            self.selecting_card_payment(r)
            self.selecting_dd_payment(r)
            self.selecting_eft_payment(r)
            self.selecting_cash_payment()
            self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 10, 'cash details save was not visible')
            self.click_button(self.objects['OPB_CashDetails_Save'])
            #time.sleep(2)
            MSG1 = self.get_alert_message()
            print MSG1
        self.dict['BROWSER'] = self._current_browser()   '''
        
    
#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    



class InOPBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 30, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "1323"
        #time.sleep(2)
        #### Release server commented below two lines###############
        #self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 30, "opbilling regno. was not visible")
        #self.click_element(self.objects['OPB_OpBilling_RegNo'])
        #time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 30, "opbilling regno. was not visible")
        #self.input_text(self.objects["OPB_OpBilling_RegNo"],str(self.dict['REGNO']))
        #time.sleep(1)
        if self._is_visible('xpath=//*[@id="lblregno_tool"]'):
           print "1"
           self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 7, 'regno label was not visible')
           Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
           if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg. number is not matching')
           else:
                pass
        elif self._is_visible(self.objects['OPB_OpBilling_RegNo']):
             print "2"
             self.input_text(self.objects['OPB_OpBilling_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['OPB_OpBilling_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['OPB_OpBilling_Search'])     
             time.sleep(3)
             '''self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass'''
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OpBilling_Search'], 30, "opbilling search was not visible")
        self.click_button(self.objects['OPB_OpBilling_Search'])
        time.sleep(3)
        # commented below line for release server
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceName'], 30, 'OP billing page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_servicename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="s2id_txtServiceName"]/a', 30, "service name was not visible")
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
   
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_STANDARD_SERVICE'] = self.d[r]['Lab_standard_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched standard service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_STANDARD_SERVICE'])+'"]', 30, 'searched standard service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_STANDARD_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_diet_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['DIET_SERVICE'] = self.d[r]['diet_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched diet service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]', 15, 'searched diet service was not visible')
        #self.click_element('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//div[text()="'+str(self.dict['DIET_SERVICE'])+'"]', 30, 'searched diet service was not visible')
        self.click_element('xpath=//*[@id="select2-drop"]//div[text()="'+str(self.dict['DIET_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 15, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()

    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched culture service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'"]', 30, 'searched culture service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched pathology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        

    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched radiology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['RADIOLOGY_SERVICE'])+'"]', 30, 'searched radiology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['RADIOLOGY_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, 'searched pathology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['CARDIOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['CARDIOLOGY_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
       
        
    def adding_lab_peripheral_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PERIPHERAL_SERVICE'] = self.d[r]['Lab_peripheral_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        else:
            self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PERIPHERAL_SERVICE'])+'"]', 30, 'searched peripheral service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PERIPHERAL_SERVICE'])+'"]', 30, 'searched peripheral service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_PERIPHERAL_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()  
        
        
    def adding_physio_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['PHYSIO_SERVICE'] = self.d[r]['physio_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        else:
            self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]', 30, 'searched peripheral service was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]', 30, 'searched peripheral service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 30, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()
        
    def pressing_tabkey(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 30, 'opbilling  service search was not visible')
        self.press_key('xpath=//*[@id="s2id_autogen16_search"]', '\\09')
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 30, 'remarks was not visible')
        self.input_text('xpath=//*[@id="txtRemarks"]', 'test')
        #time.sleep(1) 
        self.dict['BROWSER'] = self._current_browser()
    def selecting_outstandingtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding'], 10, "os tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_Outstanding'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ossource(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboOSSource"]/a', 10, "os source was not visible")
        self.click_element('xpath=//*[@id="s2id_cboOSSource"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10, "os source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ossourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_SourceName'], 10, "os source name was not visible")
        self.click_element(self.objects['OPB_OPBilling_Outstanding_SourceName'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "os source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()   
    def entering_osamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Amount'], 30, "os amount was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Outstanding_Amount'])
        self.input_text(self.objects['OPB_OPBilling_Outstanding_Amount'], str(self.d[r]['osamount']))
        self.dict['BROWSER'] = self._current_browser()  
    def entering_osremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_remarks'], 30, "os remarks was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Outstanding_remarks'])
        self.input_text(self.objects['OPB_OPBilling_Outstanding_remarks'], self.d[r]['osremarks'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_outstandingaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="divaddOSbApplybtn"]/a', 30, "os add btn was not visible")
        self.click_element('xpath=//*[@id="divaddOSbApplybtn"]/a')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Add'], 10, "os add btn was not visible")
        #self.click_button(self.objects['OPB_OPBilling_Outstanding_Add'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_concessiontab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession'], 30, "cs tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_Services_Concession'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cssourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcSourceName"]/a', 30, "cs source was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcSourceName"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_authorization(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcAuthorization"]/a', 30, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcAuthorization"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()          
    def entering_csamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Amount'], 30, "os amount was not visible")
        self.input_text(self.objects['OPB_OPBilling_Services_Concession_Amount'], str(self.d[r]['csamount']))
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_cstype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Type'], 30, "cs type was not visible")
        self.select_from_list_by_label(self.objects['OPB_OPBilling_Services_Concession_Type'],self.d[r]['cstype'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_csremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_remarks'], 30, "cs remarks was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Services_Concession_remarks'])
        self.input_text(self.objects['OPB_OPBilling_Services_Concession_remarks'], self.d[r]['csremarks'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_concessionapplybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Concession_Apply'], 30, "cs apply btn was not visible")
        self.click_button(self.objects['OPB_OPBilling_Services_Concession_Apply'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        #self.click_link(self.objects['OPB_Paymode'])
        self.click_button(self.objects['OPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def get_opbillpayableamount(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_PayableAmount'], 30, "payable amount was not visible")
        self.dict['OPBILLPAYABLEAMOUNT'] =  self.get_text(self.objects['OPB_OPBilling_PayableAmount'])
        print self.dict['OPBILLPAYABLEAMOUNT']
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_opbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Save'], 30, 'op billing service save was not visible')
        self.click_element(self.objects['OPB_OPBilling_Services_Save'])
        #RELEASE SERVER########################
        try:
            self._handle_alert(True)
        except:
            pass
        ###########################################
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_doctor(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 20, 'doctor list is not visible')
         self.select_from_list_by_index('xpath=//*[@id="cboDoctor"]','2')
         self.dict['BROWSER'] = self._current_browser()    
        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        
class InAdvancePayment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_Advpayment")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 30, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "3153"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_Regno'], 30, "regno was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_AdvancePayment_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in advance payment page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def entering_advanceamnt(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.dict['REGNO'] = "624975"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_advamnt'], 30, "advance amnt was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_advamnt"],str(self.d[r]['advanceamnt']))
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_billtype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_BillType'], 30, "bill type was not visible")
        self.select_from_list_by_label(self.objects["OPB_AdvancePayment_BillType"], self.d[r]['billtype'])
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_paymodebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_enabled('xpath=//*[@id="paymentDetailLink"]', 30, 'OPB paymode link was not visible')
        self.click_button('xpath=//*[@id="paymentDetailLink"]')
        #self.click_element(self.objects['OPB_Paymode'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["OPB_AdvancePayment_savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InAdvancePaymentRefundReq(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_AdvpayRefund")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 30, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "3135"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundReq_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_RefundReq_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_AdvancePayment_RefundReq_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentrefundreqpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]', 10, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in advance refund req page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymentmode(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundReq_paymentmode'], 30, "paymentmode was not visible")
        self.select_from_list_by_label(self.objects["OPB_AdvancePayment_RefundReq_paymentmode"],str(self.d[r]['paymentmode']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[@id="iframe2"]', 30, 'OPB paymode frame was not visible')
        self.select_frame('xpath=//*[@id="iframe2"]')
        time.sleep(5)
        self.wait_until_page_contains_element(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()                
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundReq_remarks'], 30, "remarks was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_RefundReq_remarks"],str(self.d[r]['remarks']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["OPB_AdvancePayment_savebtn"])
        #self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()    
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()   
        
class InAdvancePaymentRefundAppr(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625593"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundReqApprov_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_RefundReqApprov_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_AdvancePayment_RefundReqApprov_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentrefundreqapprovepage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]', 10, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundReqApprov_checkbox'], 10, "checkbox was not visible")
        self.click_element(self.objects['OPB_AdvancePayment_RefundReqApprov_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_RefundReqApprov_apprvbtn'], 20, "approve btn was not enabled")
        self.click_button(self.objects["OPB_AdvancePayment_RefundReqApprov_apprvbtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InAdvancePaymentRefundIssue(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "3144"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundIssue_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_RefundIssue_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_AdvancePayment_RefundIssue_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentrefundissuepage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]', 10, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvRefundSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundIssue_checkbox'], 10, "checkbox was not visible")
        self.click_element(self.objects['OPB_AdvancePayment_RefundIssue_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymentmode(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_RefundIssue_paymentmode'], 10, "paymentmode was not visible")
        self.select_from_list_by_index(self.objects["OPB_AdvancePayment_RefundIssue_paymentmode"],'2')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_issuebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_RefundIssue_issuebtn'], 20, "issue btn was not enabled")
        self.click_button(self.objects["OPB_AdvancePayment_RefundIssue_issuebtn"])
        self.dict['BROWSER'] = self._current_browser()    
    def getmessage_after_issue(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'issue message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InUserSettlementPhysicalCash(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def entering_cashdetails_qty(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="mbl_tblBody"]//tr[1]', 20, "cash details section was not visible")
        self.wait_until_element_is_visible('xpath=(//*[@id="PD_Qty"])[1]', 10, "first qty was not visible")
        self.input_text('xpath=(//*[@id="PD_Qty"])[1]', "1")
        self.press_key('xpath=(//*[@id="PD_Qty"])[1]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_paymode_qty(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        for i in range (1,5):
            i = str(i)
            self.wait_until_element_is_visible('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+i+']//td[2]//input', 20, "qty was not visible")
            qtyvalue = self.get_value('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+i+']//td[2]//input')
            print "qtyvalue", qtyvalue
            print i
            print type(qtyvalue)
            if str(qtyvalue) == '0':
                print "Need to enter qty"
                self.clear_element_text('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+i+']//td[2]//input')
                self.input_text('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+i+']//td[2]//input', "1")
            else:
                pass
        for j in range (1,5):
            j = str(j)
            self.wait_until_element_is_visible('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+j+']//td[3]//input', 20, "qty was not visible")
            amount = self.get_value('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+j+']//td[3]//input')
            print "amount", amount
            print j
            print type(amount)
            if str(amount) == '0':
                print "Need to enter qty"
                self.clear_element_text('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+j+']//td[3]//input')
                self.input_text('xpath=//*[@id="mbl_tblBody_Desv"]//tr['+j+']//td[3]//input', "5000")
            else:
                pass
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_UserSettlementPhysicalCash_Savebtn'], 10, "save btn was not visible")
        self.click_button(self.objects['OPB_UserSettlementPhysicalCash_Savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'issue message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InUserSettlementReceive(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_usersettlreceive")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_user(self,r):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled('xpath=//*[@id="s2id_cboUser"]', 10, "user field was not visible")
        self.click_element('xpath=//*[@id="s2id_cboUser"]')
        self.wait_until_element_is_enabled('xpath=//*[@id="select2-drop"]//input', 10, "user text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]['user']+" -")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li', 10, "searched user was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['OPB_UserSettlementReceive_checkbox'], 10, "checkbox was not visible")
        self.click_element(self.objects['OPB_UserSettlementReceive_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_UserSettlementReceive_savebtn'], 10, "save btn was not visible")
        self.click_element(self.objects['OPB_UserSettlementReceive_savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'issue message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

class InUserSettlementView(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_usersettlview")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_user(self,r):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled('xpath=//*[@id="s2id_cboUser"]', 10, "user field was not visible")
        self.click_element('xpath=//*[@id="s2id_cboUser"]')
        self.wait_until_element_is_enabled('xpath=//*[@id="select2-drop"]//input', 10, "user text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]['user']+" -")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li', 10, "searched user was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_viewbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_UserSettlementView_viewbtn'], 10, "view btn was not visible")
        self.click_element(self.objects['OPB_UserSettlementView_viewbtn'])
        self.wait_until_element_is_visible('xpath=//h4[@class="pHeader" and text()="User Settlement Details"]', 10, "user settlement page was not viewable")
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_closebtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_UserSettlementView_closebtn'], 10, "close btn was not visible")
        self.click_button(self.objects['OPB_UserSettlementView_closebtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()        

class InOPBillPrintCopy(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_BillPrintCopy_Regno'], 10, "regno was not visible")
        self.input_text(self.objects['OPB_BillPrintCopy_Regno'], self.dict['REGNO'])
        self.press_key(self.objects['OPB_BillPrintCopy_Regno'], '\\13')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def getting_billno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboVoucherNo"]', 10, "billno was not visible")
        ele = self._element_find('xpath=//*[@id="cboVoucherNo"]',True, False)
        BillNoWithDate = self.get_text('xpath=//*[@id="cboVoucherNo"]')
        print "BillNoWithDate", BillNoWithDate
        self.dict['BROWSER'] = self._current_browser()   
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        
class InOPRefundRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBRefund")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "647410"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Refund_Regno'], 20, "opbill refund regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Refund_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Refund_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_refundreq_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList1"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        try:
            self._handle_alert(True)
        except:
            pass
        #self.wait_until_element_is_visible('xpath=//button[@class="toast-close-button"]', 10, "info message at the middle of page was not visible")
        #self.click_button('xpath=//button[@class="toast-close-button"]')
        self.wait_until_element_is_visible('xpath=//*[@id="tblServiceDetail"]//tr[1]', 30, "service details was not visible in op refund page")
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Refund_checkbox'], 30, "checkbox was not visible")
        self.click_element(self.objects['OPB_OPRefund_Refund_checkbox'])
        try:
            self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_Reason'], 30, "reason was not visible")
        self.select_from_list_by_index(self.objects['OPB_OPRefund_Refund_Reason'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_Remarks'], 30, "remarks was not visible")
        self.input_text(self.objects['OPB_OPRefund_Refund_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Refund_RequestBtn'], 30, "req btn was not visible")
        self.click_button(self.objects['OPB_OPRefund_Refund_RequestBtn'])
        try:
            first_alert = self.get_alert_message(True)
            print "first_alert msg", first_alert
            time.sleep(5)
            pyautogui.click(860,165)
            try:
                time.sleep(2)
                second_alert = self.get_alert_message(True)
                print "second_alert msg", second_alert
            except:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPRefundApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624974"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Approve_Regno'], 20, "opbill approve regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Approve_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Approve_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_approve_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Approve_Approvebtn'], 10, "approve btn was not visible")
        self.click_button(self.objects['OPB_OPRefund_Approve_Approvebtn'])
        #approvemsg = self.get_alert_message()
        #print "approvemsg", approvemsg
        #time.sleep(5)
        #pyautogui.click(860,165)
        try:
            first_alert = self.get_alert_message(True)
            print "first_alert msg", first_alert
            time.sleep(5)
            pyautogui.click(860,165)
            try:
                time.sleep(2)
                second_alert = self.get_alert_message(True)
                print "second_alert msg", second_alert
            except:
                pass
        except:
            pass  
        self.dict['BROWSER'] = self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPRefundIssue(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624975"
        self.wait_until_element_is_visible(self.objects['OPB_OPRefund_Issue_Regno'], 20, "opbill issue regno was not visible")
        self.input_text(self.objects["OPB_OPRefund_Issue_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPRefund_Issue_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_issue_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_refundbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPRefund_Issue_RefundBtn'], 10, "refund btn was not visible")
        self.click_button(self.objects['OPB_OPRefund_Issue_RefundBtn'])
        Issuemsg = self.get_alert_message()
        print "Issuemsg", Issuemsg
        self.dict['BROWSER'] = self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
class InOPServiceBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624975"
        self.wait_until_element_is_visible(self.objects['OPB_OPServiceBilling_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_OPServiceBilling_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OPServiceBilling_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_servicebilling_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_servicename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 10, "service name was not visible")
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 10, "service name text box was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input',"%%%")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10, "service names list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPServiceBilling_savebtn'], 10, "refund btn was not visible")
        self.click_button(self.objects['OPB_OPServiceBilling_savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        
class InOPPostConcession(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPPostConcession")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625685"
        self.wait_until_element_is_visible(self.objects['OPB_PostCS_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_PostCS_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_PostCS_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_postcs_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_page_contains_element(self.objects['OPB_PostCS_sourcename'], 10, "source name was not visible")
        #self.select_from_list_by_index(self.objects['OPB_PostCS_sourcename'], '2')
        self.wait_until_element_is_visible('xpath=//*[@id="tblServiceDetail"]/tr[1]//input[@id="chkConcession"]', 10, "checkbox in service names list was not visible")
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcSourceName"]', 10, "source name was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcSourceName"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 10, "source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_authorization(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_PostCS_authorization'], 10, "authorization was not visible")
        self.select_from_list_by_index(self.objects['OPB_PostCS_authorization'], '2')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_csamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_PostCS_csamount'], 10, "cs amount was not visible")
        self.input_text(self.objects['OPB_PostCS_csamount'], str(self.d[r]['csamount']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cstype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_PostCS_cstype'], 10, "cs type was not visible")
        self.select_from_list_by_label(self.objects['OPB_PostCS_cstype'], self.d[r]['cstype'])
        self.dict['BROWSER'] = self._current_browser()          
    def selecting_applybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_PostCS_applybtn'], 10, "apply btn was not enabled")
        self.click_button(self.objects['OPB_PostCS_applybtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_PostCS_remarks'], 10, "remarks was not visible")
        self.input_text(self.objects['OPB_PostCS_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_PostCS_savebtn'], 10, "save btn was not enabled")
        self.click_button(self.objects['OPB_PostCS_savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()         
class InOutstandingPayment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPOutstandingPayment")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 10, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "625686"
        self.wait_until_element_is_visible(self.objects['OPB_OutstandingPayment_Regno'], 20, "regno was not visible")
        self.input_text(self.objects["OPB_OutstandingPayment_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_OutstandingPayment_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_ospayment_page(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]', 10, "opbilling search was not visible")
        self.click_element('xpath=//*[@id="tblPatList"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 10, "regno in request page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible(self.objects['OPB_OutstandingPayment_checkbox'], 10, "checkbox was not visible")
        #self.click_element(self.objects['OPB_OutstandingPayment_checkbox'])        
        self.wait_until_element_is_visible(self.objects['OPB_OutstandingPayment_checkbox'], 10, 'checkbox was not visible')
        self.click_element(self.objects['OPB_OutstandingPayment_checkbox'])
        element = self._get_checkbox('xpath=//*[@id="chkSelect"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element('xpath=//*[@id="chkSelect"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OutstandingPayment_remarks'], 10, "remarks was not visible")
        self.input_text(self.objects['OPB_OutstandingPayment_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OutstandingPayment_paymode'], 10, "paymode was not visible")
        self.select_from_list_by_label(self.objects['OPB_OutstandingPayment_paymode'], self.d[r]['paymode'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OutstandingPayment_savebtn'], 10, "save btn was not enabled")
        self.click_button(self.objects['OPB_OutstandingPayment_savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()        