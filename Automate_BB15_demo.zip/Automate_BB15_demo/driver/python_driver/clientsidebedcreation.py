import sys
from Selenium2Library import Selenium2Library
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class bedcreation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def wardbedcreation(self,bedtype,wardname,companyname,startbedno,endbedno):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        x = 1
        currentbedno = int(startbedno)
        noofbeds = (endbedno-startbedno) + 1
        for x in range(noofbeds):
            self.wait_until_element_is_visible('xpath=//*[@id="txtBedNo"]', 10, "bedno was not visible")
            self.input_text('xpath=//*[@id="txtBedNo"]', "AUTOBED"+str(currentbedno))
            #self.input_text('xpath=//*[@id="txtBedNo"]', "GENBED"+str(currentbedno))
            self.wait_until_element_is_visible('xpath=//*[@id="txtBedDesc"]', 10, "bed desc was not visible")
            self.input_text('xpath=//*[@id="txtBedDesc"]', "AB"+str(currentbedno))
            #self.input_text('xpath=//*[@id="txtBedDesc"]', "GEN"+str(currentbedno))
            self.wait_until_element_is_visible('xpath=//*[@id="cboBedType"]', 10, "bed type was not visible")
            self.select_from_list_by_label('xpath=//*[@id="cboBedType"]',str(bedtype))
            self.wait_until_element_is_visible('xpath=//*[@id="cboWard"]', 10, "ward name was not visible")
            self.select_from_list_by_label('xpath=//*[@id="cboWard"]',str(wardname))
            self.wait_until_element_is_visible('xpath=//*[@id="txtSortOrder"]', 10, "sort order was not visible")
            self.input_text('xpath=//*[@id="txtSortOrder"]', str(currentbedno))
            self.wait_until_element_is_visible('xpath=//*[@id="cboCompany"]', 10, "company name was not visible")
            self.select_from_list_by_label('xpath=//*[@id="cboCompany"]',str(companyname))
            self.wait_until_element_is_enabled('xpath=//*[@id="btnsave"]', 10, "save btn was not enabled")
            self.click_button('xpath=//*[@id="btnsave"]')
            self._handle_alert(True)
            time.sleep(2)
            x = x + 1
            currentbedno = int(currentbedno) + 1
        self.dict['BROWSER'] = self._current_browser()

 
admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(2)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link('//Ward/mBedMaster.aspx')
bedcreation().wardbedcreation('GENERAL BED','DONTUSEAUTOMATIONWARD','ASSURED BEST CARE HOSPITAL',131,150)

#bedcreation().wardbedcreation('GENERAL BED','GENERAL','USHAHKAL ABHINAV SPECIALITY HOSPITAL L L P',771,799)
admin.FromConfigFile().Logoff()