from robot.libraries.BuiltIn import BuiltIn
from SeleniumLibrary import SeleniumLibrary

class CustomSeleniumLibrary(SeleniumLibrary):

    def capture_screenshot_with_custom_name(self, file_name='selenium-screenshot.png'):
        """Captures a screenshot of the current page and saves it with the specified file name."""
        self.capture_page_screenshot(file_name)

# Create an instance of your custom library
custom_library = CustomSeleniumLibrary()

# Get the BuiltIn library instance
builtin_lib = BuiltIn()

# Register the custom keyword to run on failure
builtin_lib.register_keyword_to_run_on_failure(custom_library.capture_screenshot_with_custom_name, 'custom_failure_screenshot.png')


def admin_screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        filename = BuiltIn().get_variable_value("${TEST_NAME}")
        print "filename", filename
        self.capture_page_screenshot(filename+".png")
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
 
def admin_screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        filename = BuiltIn().get_variable_value("${TEST_NAME}")
        print "filename", filename
        self.capture_page_screenshot(filename+'-{index}'+".png")
        self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()