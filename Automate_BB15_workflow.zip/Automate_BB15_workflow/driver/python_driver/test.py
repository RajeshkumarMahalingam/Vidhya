import Selenium2Library

text="IP AND PHARMACY : 77000.000 "
newtext = text.split(': ')[1]
print newtext.strip()



'''test = "4898 - SERVICE BILL - BIJU KUMARA"
print "test"
print test[:4]'''




'''##### TEst Result####

a = u'\xd7\nTest Result Dispatched'
#a = u'regno'
#print a
if '\n' in a:
    a = (a.split("\n"))[1]
    print a
else:
    print a
#(s.split(start))[1].split(end)[0]'''


'''from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Set Chrome options
chrome_options = Options()

# Set the device scale factor to achieve 60% zoom
chrome_options.add_argument("--force-device-scale-factor=0.6")

# Start Chrome with the specified options
driver = webdriver.Chrome(options=chrome_options)

# Navigate to a website
driver.get("http://192.168.0.232/bb15se/Backbone/admin/login.aspx")

# Rest of your automation code here...

# Close the browser
driver.quit()
'''