import sys
from selenium import webdriver
from lib2to3.pgen2.driver import Driver
from selenium.webdriver.chrome.webdriver import WebDriver
from lib2to3.tests.test_util import Test_Name

sys.path.append('../standard')
sys.path.append('../../libraries/standard')
#newly added
from Selenium2Library import Selenium2Library
import common_reader
from common_reader import Capturing
import common_importstatements
from common_importstatements import *
import admin
import os
from selenium.webdriver import ChromeOptions as chromeoptions
from selenium.webdriver.common.by import By


class opsales(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Sheet70")
    def multiple_op_sales(self):
        self.set_selenium_implicit_wait(30)
        wb = load_workbook('D:\workspace\Automate_BB15_release\datas\Bb_datas.xlsx')
        ws = wb["Sheet70"]
        num_rows = ws.max_row
        self.r = 1
        while self.r <= num_rows:
         self.r = self.r + 1
         statusvalue = ws.cell(row=(self.r),column=2).value         
         if statusvalue == "yes":           
           rwno = self.r - 1
           if self.d[rwno]['Concession_flg'] == 1:
              print "rwno", rwno
              print "Click Concession button"
              print "Concession bill amount", self.d[rwno]['Concession']
           if self.d[rwno]['Deposit usage_flg'] == 1:
              print "rwno", rwno
              print "click Deposit button"
              print "Deposit bill amount", self.d[rwno]['Deposit usage']
           if self.d[rwno]['Os_flg'] == 1:
              print "rwno", rwno
              print "click Os button"
              print "Os bill amount", self.d[rwno]['Os']
           if self.d[rwno]['Payable'] == 1:
              print "rwno", rwno
              print "click payable button"
              print "simple bill amount", self.d[rwno]['Simple'] 
        wb.close()


opsales().multiple_op_sales()