import sys
from selenium import webdriver
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_specific')
from Selenium2Library import Selenium2Library
import common_reader
from common_reader import Capturing
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import OPBilling
from OPBilling import InPayMode
from OPBilling import InOPBilling
from OPBilling import InAdvancePayment


class opsales(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_MultipleOPBill")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] =  self._current_browser()
    def multiple_op_sales(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        wb = load_workbook('D:\workspace\Automate_BB15_workflow\datas\BB_Datas_WF.xlsx')
        ws = wb["OPB_MultipleOPBill"]
        num_rows = ws.max_row
        self.r = 1
        OPBilling.InOPBilling().screenshotonfailure()
        OPBilling.InOPBilling().selecting_opbilling_frame()
        OPBilling.InOPBilling().entering_regno_with_data()
        while self.r <= num_rows:
             self.r = self.r + 1
             statusvalue = ws.cell(row=(self.r),column=2).value         
             if statusvalue == "yes":           
               rwno = self.r - 1
               if self.d[rwno]['service1_flag'] == 1 and self.d[rwno]['service2_flag'] == 0:
                  self.dict['SERVICE'] = self.d[rwno]['servicename1'] 
                  OPBilling.InOPBilling().adding_service(rwno,"OPB_MultipleOPBill")
               elif self.d[rwno]['service1_flag'] == 0 and self.d[rwno]['service2_flag'] == 1:
                  self.dict['SERVICE'] = self.d[rwno]['servicename2'] 
                  OPBilling.InOPBilling().adding_service(rwno,"OPB_MultipleOPBill")
               elif self.d[rwno]['service1_flag'] == 1 and self.d[rwno]['service2_flag'] == 1:
                  self.dict['SERVICE'] = self.d[rwno]['servicename1'] 
                  OPBilling.InOPBilling().adding_service(rwno,"OPB_MultipleOPBill")
                  OPBilling.InOPBilling.pressing_tabkey
                  OPBilling.InOPBilling.selecting_servicename
                  self.dict['SERVICE'] = self.d[rwno]['servicename2'] 
                  OPBilling.InOPBilling().adding_service(rwno,"OPB_MultipleOPBill")
               else:
                   print "provide valid data in service flag"
               OPBilling.InOPBilling().pressing_tabkey()
               OPBilling.InOPBilling().entering_remarks()           
               if self.d[rwno]['Concession_flg'] == 1:
                  OPBilling.InOPBilling().selecting_concessiontab()
                  OPBilling.InOPBilling().selecting_cssourcename()
                  OPBilling.InOPBilling().selecting_authorization()
                  OPBilling.InOPBilling().entering_csamount(rwno)
                  OPBilling.InOPBilling().selecting_cstype()
                  OPBilling.InOPBilling().entering_csremarks()
                  OPBilling.InOPBilling().selecting_concessionapplybtn()
               if self.d[rwno]['Deposit_usage_flg'] == 1:
                  OPBilling.InOPBilling().selecting_advancetab()
                  OPBilling.InOPBilling().entering_advanceamount(rwno)
                  OPBilling.InOPBilling().selecting_advanceapplybtn()                  
               if self.d[rwno]['Os_flg'] == 1:
                  OPBilling.InOPBilling().selecting_outstandingtab()
                  OPBilling.InOPBilling().selecting_ossource()
                  OPBilling.InOPBilling().selecting_ossourcename()
                  OPBilling.InOPBilling().entering_osamount(rwno)
                  OPBilling.InOPBilling().entering_osremarks(rwno)
                  OPBilling.InOPBilling().selecting_outstandingaddbtn()
               if self.d[rwno]['Payable'] == 1:        
                  OPBilling.InPayMode().selecting_paymode_link()
                  OPBilling.InPayMode().selecting_paymode_frame()
                  OPBilling.InPayMode().selecting_paymenttype_save_button()
                  OPBilling.InPayMode().unselecting_the_frame()
                  OPBilling.InOPBilling().selecting_opbilling_frame()
               print "OP Bill final Save"
               OPBilling.InOPBilling().selecting_opbilling_save_button()
               OPBilling.InOPBilling().selecting_backbtn()
               OPBilling.InOPBilling().entering_regno_with_data()
               OPBilling.InOPBilling().pressing_tabkey()
               OPBilling.InOPBilling().selecting_previousbillhistorytab()#current bill number should get from the previous bill history section
               CurrentBillNumber = OPBilling.InOPBilling().selecting_fetchingopbillno()
               print "CurrentBillNumber", CurrentBillNumber
               ws.cell(row=(int(rwno) + 1),column=5).value = CurrentBillNumber
               OPBilling.InOPBilling().selecting_servicetab()
               time.sleep(5)# Post the bill with 90seconds time delay between each bill
               #testdata = testdata + 1
        wb.save('D:\workspace\Automate_BB15_workflow\datas\BB_Datas_WF.xlsx')
        wb.close()
        print "All the bills mentioned in entire excel sheet are generated"
        self.dict['BROWSER'] =  self._current_browser()
            


#opsales().multiple_op_sales()