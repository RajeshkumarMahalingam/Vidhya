import sys
from Selenium2Library import Selenium2Library
#import pyautogui
#from pandas.core.arrays.integer import classname
from selenium import webdriver
#from test.test_multiprocessing import get_value
from selenium.common.exceptions import ElementNotInteractableException,\
    ElementClickInterceptedException
from ctypes.wintypes import MSG
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InNewOpRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("FO_OPNewReg")
    dict['REDIRECTTOBILL'] = ""
    dict['REGBILLAPPROVAL'] = ""
    dict['BILLINGDATAS'] = ""
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.select_frame(self.objects["FO_MainFrame"])        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1') or (str(ctrlvalue) == '2'):
            r = int (r)
            #self.wait_until_element_is_visible(self.objects["FO_MainFrame"], 10, "frame was not visible")
            #self.select_frame(self.objects["FO_MainFrame"])
            #time.sleep(2)
            #self.wait_until_page_contains_element('xpath=//*[@id="chkInsuranceCheckbox"]', 20, "insurance checkbox was not visible")
            #pyautogui.hotkey('esc')
            #self.wait_until_page_contains_element('xpath=//*[@id="chkInsuranceCheckbox"]', 20, "insurance checkbox was not visible")
            self.wait_until_page_contains_element(self.objects["FO_NewRegistration_Dept"], 30, "department was not visible")
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Dept"], 30, "department was not visible")
            self.select_from_list_by_label(self.objects["FO_NewRegistration_Dept"],self.d[r]["department"])
            print "dept selected"
        else:
            print "Department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '1'):
            r = int (r)
            time.sleep(0.5)
            #self.d[r]["doctor"] = "BALAJI"
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Doc"], 30, "doctor was not visible")
            self.select_from_list_by_label(self.objects["FO_NewRegistration_Doc"],self.d[r]["doctor"])
            print "doctor selected"
        else:
            print "Doctor field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()   
    #WF_21
    def selecting_unit_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '2'):
            r = int (r)
            ########## Below two lines uncommented in Release Server #################################################################
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr', 30, "close mark in unit was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]//abbr')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctorUnit"]', 30, "unit field was not visible")
            self.click_element('xpath=//*[@id="s2id_cboDoctorUnit"]')
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "unit text field was not visible")
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.d[r]["unit"])
            #self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen109_search"]', 30, "unit text field was not visible")
            #self.input_text('xpath=//*[@id="s2id_autogen109_search"]', self.d[r]["unit"])
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]', 30, "unit field list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["unit"]+'"]')
            time.sleep(2)
        else:
            print " Unit field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_onlydoctor_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs1']
        if (str(ctrlvalue) == '3'):
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            r = int (r)
            #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly"], 30, "doctor and department was not visible")
            #self.click_element(self.objects['FO_NewRegistration_DoctorOnly'])
            #time.sleep(2)
            self.wait_until_page_contains_element(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible in page")
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_DoctorOnly_Entry"], 30, "doctor and department entry input was not visible")
            self.input_text(self.objects["FO_NewRegistration_DoctorOnly_Entry"],self.d[r]["doctor"])
            #self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="BALAJI(CARDIOLOGY)"]', 30, "city list was present")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]', 60, "Doctor and department list was present")
            self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["doctor"]+'('+self.d[r]["department"]+')"]')
            time.sleep(1)
        else:
            print "Doctor and department field is not chosen in control settings"
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_patient_type_with_data(self,r): 
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        # Patient type is "Board Persons" for qabeta and "Camp" for release server
        self.page_should_contain_element(self.objects["FO_NewRegistration_PatType"], 30, "patient type was not visible")
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType"], 30, "patient type was not visible")
        self.select_from_list_by_label(self.objects['FO_NewRegistration_PatType'],self.d[r]['patient_type'])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_camp_name_with_data(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType_CampName"], 30, "city was not visible")
        self.click_element(self.objects['FO_NewRegistration_PatType_CampName'])
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_PatType_CampName_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_NewRegistration_PatType_CampName_Entry"],"%%%")
        self.wait_until_element_is_visible('xpath=(//*[@id="select2-drop"]//span)[1]', 30, "city list was present")
        self.click_element('xpath=(//*[@id="select2-drop"]//span)[1]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_campregno(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PatType_CampPatient'], 30, 'camp patient was not visible')
        self.click_element(self.objects['FO_NewRegistration_PatType_CampPatient'])
        self.input_text(self.objects['FO_NewRegistration_PatType_CampPatient_Entry'], str(self.dict['CAMP_REGNO']))
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+str(self.dict['CAMP_REGNO'])+'"]', 30, "camp regno was not present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+str(self.dict['CAMP_REGNO'])+'"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_sal_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Sal"], 30, "sal was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Sal"],self.d[r]["sal"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 30, "name was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Name"],"Sharma FRS "+str(randint(100,999)))
        #self.input_text(self.objects["FO_NewRegistration_Name"],"Pranav rrv")
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Name"], 10, "name was not visible")
        self.input_text(self.objects["FO_NewRegistration_Name"],str(self.d[r]["name"]))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Gender"], 30, "gender was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_Gender"],self.d[r]["gender"])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Age"], 30, "age was not visible")
        self.input_text(self.objects["FO_NewRegistration_Age"],self.d[r]["age"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_maritalstatus_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_MaritalStatus"], 30, "marital status was not visible")
        self.select_from_list_by_label(self.objects["FO_NewRegistration_MaritalStatus"],self.d[r]["marital_status"])
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_relation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_from_list_by_index(self.objects['FO_NewRegistration_Relation'], "1")
        self.dict['BROWSER'] = self._current_browser()
                
    def entering_relationname_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.input_text(self.objects['FO_NewRegistration_RelationName'], self.d[r]['relname'])
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_address_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Address"], 30, "address was not visible")
        self.input_text(self.objects["FO_NewRegistration_Address"],self.d[r]["present_address"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City"], 30, "city was not visible")
        self.click_element(self.objects['FO_NewRegistration_City'])
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_City_Entry"], 30, "city entry was not visible")
        self.input_text(self.objects["FO_NewRegistration_City_Entry"],self.d[r]["city"])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 30, "city list was present")
        self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
        time.sleep(1)
        #self.press_key(self.objects['FO_NewRegistration_City_Entry'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_mobile_with_data(self,r):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        Tempmobile = randint(100,999)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 30, "mobile no was not visible")
        self.input_text(self.objects["FO_NewRegistration_Mobile"],"9120000"+str(Tempmobile))
        #self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Mobile"], 10, "mobile was not visible")
        #self.input_text(self.objects["FO_NewRegistration_Mobile"],str(self.d[r]["mobile"]))
        #print self.d[r]["opnewreg_mobile"]
        #print(len(self.d[r]["opnewreg_mobile"]))
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_nationality_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs2']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Nationality"], 30, "nationality was not visible")
            #self.select_from_list_by_label(self.objects["FO_NewRegistration_Nationality"],self.d[r]["nationality"])
            self.select_from_list_by_index(self.objects["FO_NewRegistration_Nationality"], '2')
            time.sleep(1)
        else:
            print "Nationality Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_nationalityid_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs3']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_NationalityID"], 30, "nationality id field was not visible")
            self.input_text(self.objects["FO_NewRegistration_NationalityID"], "AFLRM"+str(randint(100,999))+"T")
        else:
            print "Nationality Mandatory ID field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_occupation_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs4']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Occupation"], 30, "occupation was not visible")
            self.select_from_list_by_index(self.objects["FO_NewRegistration_Occupation"], '2')
            time.sleep(1)
        else:
            print "Occupation Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
        
    def entering_remarks_with_data(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Remarks"], 30, "remarks was not visible")
        self.input_text(self.objects["FO_NewRegistration_Remarks"],self.d[r]["remarks"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_referraldoctor_with_data(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs5']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor"], 30, "referral doctor was not visible")
            self.click_element(self.objects["FO_NewRegistration_Referraldoctor"])
            self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Referraldoctor_Entry"], 30, "referral doctor input field was not visible")
            self.input_text(self.objects["FO_NewRegistration_Referraldoctor_Entry"],"%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 60, "referraldoctor list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
            #self.press_key(self.objects["FO_NewRegistration_Referraldoctor"], '\\13')
            time.sleep(1)
        else:
            print "Referral doctor Mandatory field in control settings was not enabled"
        self.dict['BROWSER'] = self._current_browser()
    def clicking_emailtextbox(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #ime.sleep(1)
        self.wait_until_element_is_visible(self.objects["FO_NewRegistration_Email"], 30, "E-mail was not visible")
        self.click_element(self.objects["FO_NewRegistration_Email"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #ime.sleep(1)
        self.wait_until_element_is_enabled(self.objects["FO_NewRegistration_Save"], 30, "save btn was not visible")
        self.click_button(self.objects["FO_NewRegistration_Save"])
        '''time.sleep(1)
        pyautogui.click(860,165)
        time.sleep(1)
        pyautogui.click(860,165)'''
        #self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
        
    def fetching_regno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        if (str(self.cs['cs10']) == '0') and ((str(self.cs['cs11']) == '0') or (str(self.cs['cs11']) == '1')) and (str(self.cs['cs9']) == '0'):
            print "1"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "False"
            self.dict['REGBILLAPPRROVAL'] = "FalseorTrue"
            #self.dict['BILLINGDATAS'] = "True"
            self.dict['BILLINGDATAS'] = "False"
        elif (str(self.cs['cs10']) == '1') and (str(self.cs['cs11']) == '1') and (str(self.cs['cs9']) != '0'):
            print "2"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage'], 60, 'Record was not saved and pop up dialog was not visible')
            self.msg = self._get_text(self.objects['FO_NewRegistration_PopUpMessage'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            #RELEASE SERVER####################
            time.sleep(2)
            '''try:
                self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department msg opened along with pop up msg in release was not displayed")
                self.click_element('xpath=//*[@id="select2-drop"]//input')
                self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
            except:
                pass'''
            ##################################
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'], 30, 'ok btn was not visible')  
            self.click_button(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "True"
            self.dict['BILLINGDATAS'] = "True"
        elif (str(self.cs['cs10']) == '0') and (str(self.cs['cs11']) == '1') and (str(self.cs['cs9']) != '0'):
            print "3"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "False"
            self.dict['REGBILLAPPRROVAL'] = "True"
            self.dict['BILLINGDATAS'] = "True"
        elif ((str(self.cs['cs10']) == '1') or (str(self.cs['cs10']) == '0')) and (str(self.cs['cs11']) == '0') and (str(self.cs['cs9']) != '0'):
            print "4"
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_Message'], 50, 'Record was not saved')
            self.msg = self._get_text(self.objects['FO_NewRegistration_Message'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "False"
            self.dict['BILLINGDATAS'] = "True"
            time.sleep(10)
            pyautogui.click(1132,672)
        elif (str(self.cs['cs10']) == '1') and ((str(self.cs['cs11']) == '0') or (str(self.cs['cs11']) == '1')) and (str(self.cs['cs9']) == '0'):
            print "5"
            #pop up message displayed but no print preview and no need to save bill in billing screen
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage'], 60, 'Record was not saved and pop up dialog was not visible')
            self.msg = self._get_text(self.objects['FO_NewRegistration_PopUpMessage'])
            self.reg= ((self.msg).split('Record(s) Saved Successfully, Reg No : '))[1].split(', Token')[0]
            self.dict['REGNO'] = self.reg
            print self.dict['REGNO']
            print("Registered Reg number is",self.dict['REGNO'])
            #RELEASE SERVER####################
            time.sleep(2)
            try:
                self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "department msg opened along with pop up msg in release was not displayed")
                self.click_element('xpath=//*[@id="select2-drop"]//input')
                self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
            except:
                pass
            ##################################   
            self.wait_until_element_is_visible(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'], 30, 'ok btn was not visible')  
            self.click_button(self.objects['FO_NewRegistration_PopUpMessage_Okbtn'])
            self.dict['REDIRECTTOBILL'] = "True"
            self.dict['REGBILLAPPRROVAL'] = "FalseorTrue"
            self.dict['BILLINGDATAS'] = "False"
        #self.Test_Results[(self.dict['Executed_Test_Name'])]['REGNO'] = self.dict['REGNO']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        #self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
    def Cancelling_print_preview(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        pyautogui.click(1131,672)
        self.dict['BROWSER'] = self._current_browser()
   
