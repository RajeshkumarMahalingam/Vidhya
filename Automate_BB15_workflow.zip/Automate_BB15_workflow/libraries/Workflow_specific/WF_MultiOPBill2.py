import sys
from selenium import webdriver
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_specific')
from Selenium2Library import Selenium2Library
import common_reader
from common_reader import Capturing
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import OPBilling
from OPBilling import InPayMode
from OPBilling import InOPBilling


class opsales(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_MultipleOPBill")
    def multiple_op_sales(self):
        self.set_selenium_implicit_wait(30)
        admin.FromConfigFile().driving_browser_and_url()
        admin.FromConfigFile().logging("opbilling")
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #admin.FromConfigFile.loading_menu_of_link_test("//Billing/OPBillTransaction/OPSearch.aspx?opt=2","opbilling")        
        OPBilling.InOPBilling().selecting_opbilling_frame()
        OPBilling.InOPBilling().entering_regno_with_data()
        OPBilling.InOPBilling().pressing_tabkey()
        OPBilling.InOPBilling().selecting_previousbillhistorytab()
        OPBilling.InOPBilling().selecting_fetchingopbillno()
        print "all are bills generated"
        self.dict['BROWSER'] =  self._current_browser()


opsales().multiple_op_sales()