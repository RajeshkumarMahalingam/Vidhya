import sys
from Selenium2Library import Selenium2Library
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
from lxml import etree
from selenium import webdriver

class InPayMode(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(5)
        #####Release server######################################
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="lblPayableAmt"]', 10, "payable amount was not displayed")
        except:
            self.wait_until_element_is_visible('xpath=//*[@id="lblTotalRefundAmt"]', 10, "refund amount was not displayed")
        ######################################################################
        self.wait_until_element_is_enabled('xpath=//a[@id="paymentDetailLink"]', 30, 'OPB paymode link was not visible')
        self.click_link('xpath=//a[@id="paymentDetailLink"]')
        #self.click_element(self.objects['OPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode_Frame'], 30, 'OPB paymode frame was not visible')
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        ### cOMMENTED ABOVE FOR RELEASE SERVER AND ADDED FOR BELOW LINE FOR RELEASE SERVER
        #self.select_frame('xpath=//*[@id="iframe2"]')
        time.sleep(5)
        self.wait_until_page_contains_element(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()   

class InOPBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 30, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "8639"
        #time.sleep(2)
        #### Release server commented below two lines###############
        #self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 30, "opbilling regno. was not visible")
        #self.click_element(self.objects['OPB_OpBilling_RegNo'])
        #time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['OPB_OpBilling_RegNo'], 30, "opbilling regno. was not visible")
        #self.input_text(self.objects["OPB_OpBilling_RegNo"],str(self.dict['REGNO']))
        #time.sleep(1)
        if self._is_visible('xpath=//*[@id="lblregno_tool"]'):
           print "1"
           self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 7, 'regno label was not visible')
           Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
           if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg. number is not matching')
           else:
                pass
        elif self._is_visible(self.objects['OPB_OpBilling_RegNo']):
             print "2"
             self.input_text(self.objects['OPB_OpBilling_RegNo'], str(self.dict['REGNO']))
             self.wait_until_element_is_enabled(self.objects['OPB_OpBilling_Search'], 30, 'search btn was not enabled')
             self.click_button(self.objects['OPB_OpBilling_Search'])     
             time.sleep(5)
             '''self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, 'regno label was not visible')
             Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')    
             if str(self.dict['REGNO']) != Patient:
                raise AssertionError('Failed Reg number is not matching')
             else:
                pass'''
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OpBilling_Search'], 100, "opbilling search was not visible")
        self.click_button(self.objects['OPB_OpBilling_Search'])
        time.sleep(3)
        # commented below line for release server
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceName'], 30, 'OP billing page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_servicename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="s2id_txtServiceName"]/a', 100, "service name was not visible")
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
   
    def adding_lab_standard_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_STANDARD_SERVICE'] = self.d[r]['Lab_standard_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched standard service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_STANDARD_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_STANDARD_SERVICE'])+'"]', 100, 'searched standard service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_STANDARD_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_diet_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['DIET_SERVICE'] = self.d[r]['diet_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'service name was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched diet service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['DIET_SERVICE'])
        #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]', 15, 'searched diet service was not visible')
        #self.click_element('xpath=//*[text()="'+str(self.dict['DIET_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//div[text()="'+str(self.dict['DIET_SERVICE'])+'"]', 100, 'searched diet service was not visible')
        self.click_element('xpath=//*[@id="select2-drop"]//div[text()="'+str(self.dict['DIET_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()

    def adding_lab_culture_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched culture service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_CULTURE_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'"]', 100, 'searched culture service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_CULTURE_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_lab_pathology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched pathology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PATHOLOGY_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 100, 'searched pathology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        

    def adding_radiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(3)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'Input text box was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['RADIOLOGY_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['RADIOLOGY_SERVICE'])+'"]', 100, 'searched radiology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['RADIOLOGY_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_cardiology_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched cardiology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['CARDIOLOGY_SERVICE'])
        time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['CARDIOLOGY_SERVICE'])+'"]', 100, 'searched cardiology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['CARDIOLOGY_SERVICE'])+'"]')
        time.sleep(5)
        try:
            self._handle_alert(True)
        except:
            pass
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        try:
            self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
       
        
    def adding_lab_peripheral_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PERIPHERAL_SERVICE'] = self.d[r]['Lab_peripheral_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
           self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        else:
           self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'searched peripheral service was not visible')
           self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
           time.sleep(2)
           self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['LAB_PERIPHERAL_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PERIPHERAL_SERVICE'])+'"]', 100, 'searched peripheral service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['LAB_PERIPHERAL_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()  
        
        
    def adding_physio_service(self, r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['PHYSIO_SERVICE'] = self.d[r]['physio_service']
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]', 30, 'searched physio service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'service name was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(2)
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['PHYSIO_SERVICE'])
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]', 100, 'searched physio service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['PHYSIO_SERVICE'])+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]')
        self.dict['BROWSER'] = self._current_browser()
     
    def adding_service(self, r, sheetname):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off(''+sheetname+'')
        r = int(r)
        if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['SERVICE'])
        else:
            #self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'"]', 30, 'searched pathology service was not visible')
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]/a', 100, 'servicename was not visible')
            self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
            time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'searched cardiology service was not visible')
            self.input_text('xpath=//*[@id="select2-drop"]//input', self.dict['SERVICE'])
        time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[text()="'+str(self.dict['SERVICE'])+'"]', 100, 'searched cardiology service was not visible')
        self.click_element('xpath=//*[text()="'+str(self.dict['SERVICE'])+'"]')
        time.sleep(5)
        try:
            self._handle_alert(True)
        except:
            pass
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_txtServiceName"]', 100, 'service name was not visible')
        self.click_element('xpath=//*[@id="s2id_txtServiceName"]/a')
        try:
            self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser() 
        
    def pressing_tabkey(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen16_search"]', 100, 'opbilling  service search was not visible')
        self.press_key('xpath=//*[@id="s2id_autogen16_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRemarks"]', 100, 'remarks was not visible')
        self.input_text('xpath=//*[@id="txtRemarks"]', 'remarks')
        #time.sleep(1) 
        self.dict['BROWSER'] = self._current_browser()
    def selecting_outstandingtab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding'], 30, "os tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_Outstanding'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ossource(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboOSSource"]/a', 30, "os source was not visible")
        self.click_element('xpath=//*[@id="s2id_cboOSSource"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "os source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ossourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_SourceName'], 30, "os source name was not visible")
        self.click_element(self.objects['OPB_OPBilling_Outstanding_SourceName'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "os source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()   
    def entering_osamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPB_MultipleOPBill")
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Amount'], 30, "os amount was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Outstanding_Amount'])
        self.input_text(self.objects['OPB_OPBilling_Outstanding_Amount'], str(self.d[r]['Os']))
        self.dict['BROWSER'] = self._current_browser()  
    def entering_osremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_remarks'], 30, "os remarks was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Outstanding_remarks'])
        self.input_text(self.objects['OPB_OPBilling_Outstanding_remarks'], "Os Remarks")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_outstandingaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="divaddOSbApplybtn"]/a', 30, "os add btn was not visible")
        self.click_element('xpath=//*[@id="divaddOSbApplybtn"]/a')
        time.sleep(1)
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Add'], 10, "os add btn was not visible")
        #self.click_button(self.objects['OPB_OPBilling_Outstanding_Add'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_concessiontab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession'], 30, "cs tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_Services_Concession'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cssourcename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcSourceName"]/a', 30, "cs source was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcSourceName"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs source name list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        #self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Outstanding_Source'], 10, "os source was not visible")
        #self.select_from_list_by_index(self.objects['OPB_OPBilling_Outstanding_Source'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_authorization(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboConcAuthorization"]/a', 30, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="s2id_cboConcAuthorization"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 30, "cs authorization was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
        self.dict['BROWSER'] = self._current_browser()          
    def entering_csamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPB_MultipleOPBill")
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Amount'], 30, "os amount was not visible")
        self.input_text(self.objects['OPB_OPBilling_Services_Concession_Amount'], str(self.d[r]['Concession']))
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_cstype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_Type'], 30, "cs type was not visible")
        self.select_from_list_by_label(self.objects['OPB_OPBilling_Services_Concession_Type'],"Amount")
        self.dict['BROWSER'] = self._current_browser()
    def entering_csremarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Services_Concession_remarks'], 30, "cs remarks was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Services_Concession_remarks'])
        self.input_text(self.objects['OPB_OPBilling_Services_Concession_remarks'], "CS Remarks")
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_concessionapplybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Concession_Apply'], 30, "cs apply btn was not visible")
        self.click_button(self.objects['OPB_OPBilling_Services_Concession_Apply'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_advancetab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Advance'], 30, "advance tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_Advance'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_advanceamount(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPB_MultipleOPBill")
        r = int(r)
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_Advance_Amount'], 30, "advance amount was not visible")
        self.clear_element_text(self.objects['OPB_OPBilling_Advance_Amount'])
        self.input_text(self.objects['OPB_OPBilling_Advance_Amount'], str(self.d[r]['Deposit_usage']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_advanceapplybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Advance_Applybtn'], 30, "advance apply btn was not visible")
        self.click_button(self.objects['OPB_OPBilling_Advance_Applybtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_previousbillhistorytab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_PreviousBillHistoryTab'], 30, "previous bill history tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_PreviousBillHistoryTab'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fetchingopbillno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        count = 0
        try:
         for i in range(1, 100):
             BillNumber = self.get_text('xpath=//*[@id="tblPreviousBillSummary"]//tr['+str(i)+']//td[2]')
             if len(BillNumber)!=0:
                count = count + 1
                i = int(i)
                i = i + 1
        except ValueError:
                pass
        OPBillNumber = self.get_text('xpath=(//*[@id="tblPreviousBillSummary"]//td[2])['+str(count)+']')
        print OPBillNumber[:4]
        return OPBillNumber[:4]
        self.dict['BROWSER'] = self._current_browser()
    def selecting_backbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_BackBtn'], 30, "back btn was not visible")
        self.click_button(self.objects['OPB_OPBilling_BackBtn'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_servicetab(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_ServiceTab'], 30, "service tab was not visible")
        self.click_element(self.objects['OPB_OPBilling_ServiceTab'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_link(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        #self.click_link(self.objects['OPB_Paymode'])
        self.click_button(self.objects['OPB_Paymode'])
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymode_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.wait_until_element_is_visible(self.objects['OPB_Paymode'], 30, 'OPB paymode was not visible')
        self.select_frame(self.objects['OPB_Paymode_Frame'])
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['OPB_PaymentType'], 30, 'Payment type page is not loaded')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_paymenttype_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.page_should_contain_element(self.objects['OPB_CashDetails_Save'], 30, 'cash details save was not visible')
        self.click_button(self.objects['OPB_CashDetails_Save'])
        #time.sleep(2)
        MSG1 = self.get_alert_message()
        print MSG1
        self.dict['BROWSER'] = self._current_browser()
    def get_opbillpayableamount(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_OPBilling_PayableAmount'], 30, "payable amount was not visible")
        self.dict['OPBILLPAYABLEAMOUNT'] =  self.get_text(self.objects['OPB_OPBilling_PayableAmount'])
        print self.dict['OPBILLPAYABLEAMOUNT']
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_opbilling_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_enabled(self.objects['OPB_OPBilling_Services_Save'], 30, 'op billing service save was not visible')
        self.click_element(self.objects['OPB_OPBilling_Services_Save'])
        ####RELEASE SERVER########################
        try:
          self._handle_alert(True)
        except:
            pass
        ###########################################
        time.sleep(15)
        '''time.sleep(1)
        try:
            self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 5, "message was not visible")
            self.Msg = self.get_text('xpath=//div[@class="toast-message"]')  
            if self.Msg[:32] == "Message: Record Already Exist(s)":
               raise AssertionError('Bill not saved')          
        except:
             pass
        time.sleep(6)
        self.dict['BROWSER'] = self._current_browser()'''        
        
    
    def selecting_doctor(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 20, 'doctor list is not visible')
         self.select_from_list_by_index('xpath=//*[@id="cboDoctor"]','2')
         self.dict['BROWSER'] = self._current_browser()    
        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()
        
class InAdvancePayment(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opbilling_frames(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OPB_MainFrame'], 30, "op billing frame was not visible")
        self.select_frame(self.objects['OPB_MainFrame'])
        #self.select_frame(self.objects['OPB_OpBilling_Tab1'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "3153"
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_Regno'], 30, "regno was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_Regno"],str(self.dict['REGNO']))
        self.press_key(self.objects["OPB_AdvancePayment_Regno"], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_advpaymentpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient details was not visible")
        self.click_element('xpath=//*[@id="tblAdvSearch"]//td[text()="'+self.dict['REGNO']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="lblregno_tool"]', 30, "regno in advance payment page was not visible")
        self.dict['BROWSER'] = self._current_browser()
    def entering_advanceamnt(self,r,sheetname):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off(''+sheetname+'')
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_advamnt'], 30, "advance amnt was not visible")
        self.input_text(self.objects["OPB_AdvancePayment_advamnt"],str(self.d[r]['advance_amt']))
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_billtype(self,r,sheetname):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off(''+sheetname+'')
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_BillType'], 30, "bill type was not visible")
        self.select_from_list_by_label(self.objects["OPB_AdvancePayment_BillType"], str(self.d[r]['bill_type']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_advancetype(self,r,sheetname):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off(''+sheetname+'')
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_AdvanceTypeCloseMark'], 30, "advance type close mark was not visible")
        self.click_element(self.objects['OPB_AdvancePayment_AdvanceTypeCloseMark'])
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_AdvanceType'], 30, "advance type was not visible")
        self.select_from_list_by_label(self.objects["OPB_AdvancePayment_AdvanceType"], str(self.d[r]['advance_type']))
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_tdsamount(self,r,sheetname):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off(''+sheetname+'')
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OPB_AdvancePayment_TdsAmt'], 30, "advance tds amt was not visible")
        self.clear_element_text(self.objects['OPB_AdvancePayment_TdsAmt'])
        time.sleep(1)
        self.input_text(self.objects["OPB_AdvancePayment_TdsAmt"], str(self.d[r]['tds_amt']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_homebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_Homebtn'], 30, 'advance home btn was not visible')
        self.click_button(self.objects['OPB_AdvancePayment_Homebtn'])
        #self.click_element(self.objects['OPB_Paymode'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def fetching_depositbalance(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_DepositBalance'], 30, 'deposit balance was not visible')
        depositbalancetext = self.get_text(self.objects['OPB_AdvancePayment_DepositBalance'])
        if depositbalancetext != "":
            DepositBalance = depositbalancetext.split(': ')[1]
            DepositBalance = DepositBalance.strip()
            self.dict['DepositBalance'] = DepositBalance
        else:
            pass            
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_paymodebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.wait_until_element_is_enabled('xpath=//*[@id="paymentDetailLink"]', 30, 'OPB paymode link was not visible')
        self.click_button('xpath=//*[@id="paymentDetailLink"]')
        #self.click_element(self.objects['OPB_Paymode'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OPB_AdvancePayment_savebtn'], 30, "save btn was not enabled")
        self.click_button(self.objects["OPB_AdvancePayment_savebtn"])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 5, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()  
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()    
        self.dict['BROWSER'] = self._current_browser()

