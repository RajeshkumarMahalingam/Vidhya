import sys
from selenium import webdriver
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_specific')
from Selenium2Library import Selenium2Library
import common_reader
from common_reader import Capturing
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import OPBilling
from OPBilling import InPayMode
from OPBilling import InOPBilling
from OPBilling import InAdvancePayment
import xlrd


class OPAdvance(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPB_MultipleAdvance")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] =  self._current_browser()
        
    def multiple_trial(self):
        self.set_selenium_implicit_wait(30)
        #self._cache.current = self.dict['BROWSER']
        #self.browser = self._current_browser()
        wb = load_workbook('D:\workspace\Automate_BB15_workflow\datas\BB_Datas_WF.xlsx',data_only=True)
        ws = wb["OPB_MultipleAdvance"]
        num_rows = ws.max_row
        statusvalue = ws.cell(row=1,column=2).value
        DecimalBalance = ws.cell(row=2,column=9).value
        print statusvalue
        print DecimalBalance
        wb.close()
        #print "All the bills mentioned in entire excel sheet are generated"
        self.dict['BROWSER'] =  self._current_browser()    
        
        
    '''def multiple_op_advance(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        wb = load_workbook('D:\workspace\Automate_BB15_workflow\datas\BB_Datas_WF.xlsx',data_only=True)
        ws = wb["OPB_MultipleAdvance"]
        num_rows = ws.max_row
        self.r = 1
        OPBilling.InAdvancePayment().screenshotonfailure()
        OPBilling.InAdvancePayment().selecting_opbilling_frames()
        OPBilling.InAdvancePayment().entering_regno_with_data()
        OPBilling.InAdvancePayment().entering_into_advpaymentpage()
        while self.r <= num_rows:
             self.r = self.r + 1
             statusvalue = ws.cell((row=self.r),column=2).value       
             if statusvalue == "yes":           
                rwno = self.r - 1
                OPBilling.InAdvancePayment().entering_advanceamnt(rwno,"OPB_MultipleAdvance")
                OPBilling.InAdvancePayment().selecting_billtype(rwno,"OPB_MultipleAdvance")
                OPBilling.InAdvancePayment().selecting_advancetype(rwno,"OPB_MultipleAdvance") 
                OPBilling.InAdvancePayment().selecting_tdsamount(rwno,"OPB_MultipleAdvance")           
                OPBilling.InOPBilling().selecting_paymode_link()
                OPBilling.InPayMode().selecting_paymode_frame()
                OPBilling.InPayMode().selecting_paymenttype_save_button()
                OPBilling.InPayMode().unselecting_the_frame()
                OPBilling.InAdvancePayment().selecting_opbilling_frames()
                OPBilling.InAdvancePayment().selecting_savebtn()
                OPBilling.InAdvancePayment().selecting_homebtn()
                OPBilling.InAdvancePayment().entering_regno_with_data()
                OPBilling.InAdvancePayment().entering_into_advpaymentpage()
                OPBilling.InAdvancePayment().fetching_depositbalance()
                print "self.dict['DepositBalance']", self.dict['DepositBalance']
                print "rwno", rwno
                #print "Excel value", ws.cell(row=(int(rwno) + 1),column=9).value
                
                if self.dict['DepositBalance'] == str(ws.cell(row=(int(rwno) + 1),column=9).value):
                   ws.cell(row=(int(rwno) + 1),column=10).value = "Posted"
                   pass
                else:
                    raise AssertionError('Advance amount is not saved properly')
        OPBilling.InAdvancePayment().unselecting_the_frame()         
        wb.save('D:\workspace\Automate_BB15_workflow\datas\BB_Datas_WF.xlsx')
        wb.close()
        print "All the bills mentioned in entire excel sheet are generated"
        self.dict['BROWSER'] =  self._current_browser()'''
     
     
        

OPAdvance().multiple_trial()