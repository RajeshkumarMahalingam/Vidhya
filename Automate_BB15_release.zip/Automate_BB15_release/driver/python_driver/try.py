from Selenium2Library import Selenium2Library
from selenium import webdriver
import time
import pyautogui


class TestBrowser(Selenium2Library):
    dict = {}
    def opening_browser(self):
        self.open_browser('http://192.168.0.232/qabetabb15se/Backbone/admin/login.aspx', 'Chrome', None, False, None, None)
        cookieslist = self.get_cookies()
        print "before", cookieslist
        self.delete_all_cookies()
        cookieslist = self.get_cookies()
        print "after", cookieslist      
        time.sleep(10)
        self.browser = self._current_browser()
        self.dict['BROWSER'] = self._current_browser()
        print self.dict['BROWSER']
        print self._cache.current
        
    def opening_browser_new(self):
        driver = webdriver.Chrome(executable_path='D:\workspace\Automate_BB15_local\chromedriver.exe')
        print "1", driver
        driver.get('http://192.168.0.232/qabetabb15se/Backbone/admin/login.aspx')
        print "2", driver
        print self._cache.current
        
        #driver.delete_all_cookies()
    def zoom_out_page(self, times):
         #self._cache.current = self.dict['BROWSER']
         #self.browser = self._current_browser()
         time.sleep(5)
         #self.execute_javascript("document.body.style.zoom='50%'")
         self.execute_javascript("document.body.style.zoom='"+str(times)+"%'")
         time.sleep(3)
         #self.dict['BROWSER'] = self._current_browser()
         
    def test_zoom(self):
        self.open_browser('http://192.168.0.232/qabetabb15se/Backbone/admin/login.aspx', 'Chrome', None, False, None, None)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 50, 'relogin  button not visible')
        self.maximize_browser_window()
        self.zoom_out_page(50)
        #self.dict['BROWSER'] = self._current_browser()
        #self.click_element('xpath=//*[@class="fa fa-power-off"]')
        ''' #pyautogui. FAILSAFE = False
        times = 4
        times = int(times)
        x = 0
        for x in range(times):
            #pyautogui.hotkey('ctrl', '-')
             self.execute_javascript("document.body.style.zoom='80%'")
        time.sleep(3)'''
        #self.close_all_browsers()
          

#TestBrowser().opening_browser()
TestBrowser().test_zoom()
#TestBrowser().opening_browser_new()

'''servername = "QASERVER\QABETA"
print servername
server = "Server="+servername+";"
print server'''


'''name = " White Blood cells"
print name[1:]'''