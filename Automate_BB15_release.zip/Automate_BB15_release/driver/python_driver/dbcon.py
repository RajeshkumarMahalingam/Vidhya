import pypyodbc
import pandas as pd
#import xlsxwriter
import openpyxl
from openpyxl import load_workbook
import time

wrkbk = load_workbook('D:\workspace\Automate_BB15_local\Config\Prerequsiteconfig.xlsx')
sheet = wrkbk["ServerDetails"]
servername = sheet.cell(row=2,column=1).value
userid = sheet.cell(row=2,column=2).value
pwd = sheet.cell(row=2,column=3).value
print servername
print userid
print pwd
wrkbk.close()
cnxn = pypyodbc.connect("Driver={SQL Server};" "Server="+servername+";" "Database=kmch_frontoffice;" "uid="+userid+"; pwd="+pwd+"")
print "db connected"
df = pd.read_sql_query('select count(*) from Mast_Patient', cnxn)
print df
cursor = cnxn.cursor()
cursor.execute("ALTER INDEX ALL ON Mast_OP_Admission REBUILD;", None, False, False)
time.sleep(20)
df = pd.read_sql_query('select count(*) from Mast_OP_Admission', cnxn)
print df
cnxn.commit()
cnxn.close()
print "table index rebuilding done"


'''cnxn = pypyodbc.connect("Driver={SQL Server};"
                        "Server=QASERVER\QABETA;"
                        "Database=kmch_frontoffice;"
                        "uid=sa;pwd=Aosta@123")
print "connected"
#df = pd.read_sql_query('select count(*) from Mast_Patient', cnxn)
df = pd.read_sql_query('select * from dbo.Control_Panel_Frontoffice', cnxn)
file_name = 'SQLoutputfile.xlsx'
df.to_excel(file_name)
print('Exported to Excel File')'''

