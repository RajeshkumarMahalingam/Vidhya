from Selenium2Library import Selenium2Library
import sys
import os
import os.path
sys.path.append('..\..\libraries\standard') 
sys.path.append('..\..\libraries\Application_specific')
#from Selenium2Library import Selenium2Library
#sys.path.append('..\..\libraries\Workflow_Specific')
import openpyxl
from openpyxl import load_workbook
import time
import pyautogui
import logging
from random import randint
logging.getLogger("RobotFramework").addHandler(logging.StreamHandler())
from webbrowser import Chrome 
from robot.libraries.BuiltIn import BuiltIn
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import StaleElementReferenceException  
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import ElementNotInteractableException
from selenium.common.exceptions import UnexpectedAlertPresentException
from datetime import date # @UnusedImport
import datetime # @UnusedImport
from time import strftime # @UnusedImport
import math
import random
import re  # @UnusedImport
import string
from openpyxl.styles import Font, PatternFill

#import MySQLdb
