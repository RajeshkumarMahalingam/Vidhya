"""
Class Name           : (1)launching browser to menu load
Contains 3 functions : (2)drive_browser_and_url 
                           Step 1 : Get browser which is marked as "1" from excell SHEET
                           step 2 : Get Url which is marked as "1" from excell SHEET
                           step 3 : Launch browser and url
                     : (3)login_module(Module to be be logged in)
                           Step 1 : Get user name and password from excell for which module to login
                           Step 2 : Login module with user name and password
                     : (4)load_menu
                           Step 1 : Get Sub menu name and menu name from excel for the specified link
                           Step 2 : Load menu
"""
#from  .standard import importstatements 
import sys
from Tix import COLUMN
from PIL.TiffImagePlugin import MM
from pip._vendor.distlib._backport.tarfile import pwd
from fileinput import filename
import pyautogui
from selenium import webdriver
from lib2to3.pgen2.driver import Driver
from selenium.webdriver.chrome.webdriver import WebDriver
from lib2to3.tests.test_util import Test_Name
#from pyautogui import moveRel
#from selenium.webdriver.common.keys import Keys
sys.path.append('../standard')
sys.path.append('../../libraries/standard')
#newly added
from Selenium2Library import Selenium2Library
import common_reader
from common_reader import Capturing
import common_importstatements
from common_importstatements import *
from robot.libraries.BuiltIn import BuiltIn
import pypyodbc
import pandas as pd
import os
import shutil
from selenium.webdriver import ChromeOptions as chromeoptions
from selenium.webdriver.common.by import By


class FromConfigFile(Selenium2Library):
 i = 1
 j = 1
 k = 1
 l = 1
 temp = 0
 dict = {}  
 result = {}
 telement = ""
 cs = common_reader.Capturing.cs
 Test_Results = {}
 #Test_Results['TestCaseName'] = {}
 #Test_Results = {}
 #Executed_Test_Name = "DummyName"
 #filename = BuiltIn().get_variable_value("${TEST_NAME}")
 
 '''def capture_page_screenshot(self, filename='test-{index}.png'):
     return Selenium2Library.capture_page_screenshot(self, filename=filename)'''
 
 '''def capture_page_screenshot_backbone(self):
     filename = (BuiltIn().get_variable_value("${TEST_NAME}"))+'.png'
     print "filename", filename
     self.capture_page_screenshot(filename)
     custom_library = FromConfigFile()
     builtin_lib = BuiltIn()
     builtin_lib.register_keyword_to_run_on_failure(custom_library.capture_page_screenshot_backbone, 'custom_failure_screenshot.png')'''
 '''def capture_page_screenshot(self, 
     filename='selenium-screenshot-{index}.png'):
     return Selenium2Library.capture_page_screenshot(self, filename=filename)'''
 
 def capturing_screenshot_on_failure(self):
     Executed_Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
     self.set_screenshot_directory('D:\workspace\Automate_BB15_release\screenshots_failure', True)
     self.capture_page_screenshot(''+Executed_Test_Name+'.png')
 
 def admin_screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #filename = BuiltIn().get_variable_value("${TEST_NAME}")
        #print "filename", filename
        #self.capture_page_screenshot(filename+'-{index}'+".png")
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        #self.register_keyword_to_run_on_failure('admin.FromConfigFile.Capture Page Screenshot')
        self.dict['BROWSER'] = self._current_browser()
 
 def loading_menu_of_link_test(self, link, modulename):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #Release server added new sleep time below
        time.sleep(3)
        self.modulename = modulename
        self.link = link        
        y = len(self.link)
        for z in range(y):
            t = (self.link[z:z+1])
            if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
                flink = (self.link[z:])
                z = 0
                break
        z = z + 1
        try : 
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')   
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         xlmodulename = sheet.cell(row=(self.i),column=5).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         if flink == xllink and self.modulename == xlmodulename:
          tm = sheet.cell(row=(self.i),column=2).value
          sm =  sheet.cell(row=(self.i),column=3).value
          mm = sheet.cell(row=(self.i),column=4).value
          wrkbk.close()
          i = 0
          break
        else:
         print "Link does not exists in excel sheet"
        if tm is not None:
            print "top menu is", tm
            time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="menulist"]', 30, 'Menu list is not loaded')
            print "1"
            self.mouse_over('xpath=//*[text()="'+tm+'"]/..')
            print "2"
            time.sleep(1)
            self.dict['BROWSER'] = self._current_browser()
            print "3"
            if sm is not None:
                print "4"
                print "sub menu is", sm
                print "5"
                self.click_element('xpath=//*[text()="'+sm+'"]')
                time.sleep(1)
                self.dict['BROWSER'] = self._current_browser()
                if mm is not None:
                    print "main menu is",  mm
                    self.wait_until_element_is_visible('xpath=//a[text()="'+mm+'"]', 20, "mm was not visible")
                    time.sleep(1)
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.click_element('xpath=//*[(text()="'+sm+'")]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]') 
                    self.dict['BROWSER'] = self._current_browser()
            else:
                if mm is not None:
                    print "else part main menu is", mm
                    self.wait_until_element_is_visible('xpath=//a[text()="'+mm+'"]', 20, "mm was not visible")
                    time.sleep(1)
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    time.sleep(1)
                    self.dict['BROWSER'] = self._current_browser()
        else:
            print "top menu not found"
        #time.sleep(3)
        #Commneted above timing and incresed the time for release server bleow
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
              
 def loading_menu_of_link_test_old(self, link):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.link = link
        y = len(self.link)
        for z in range(y):
            t = (self.link[z:z+1])
            if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
                flink = (self.link[z:])
                z = 0
                break
        z = z + 1
        try : 
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')   
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2).value
          sm =  sheet.cell(row=(self.i),column=3).value
          mm = sheet.cell(row=(self.i),column=4).value
          wrkbk.close()
          i = 0
          break
        else:
         print "Link does not exists in excel sheet"
        if tm is not None:
            print "top menu is", tm
            time.sleep(2)
            self.wait_until_element_is_visible('xpath=//*[@id="menulist"]', 30, 'Menu list is not loaded')
            self.mouse_over('xpath=//*[text()="'+tm+'"]/..')
            time.sleep(1)
            self.dict['BROWSER'] = self._current_browser()
            if sm is not None:
                print "sub menu is", sm
                self.click_element('xpath=//*[text()="'+sm+'"]')
                time.sleep(1)
                self.dict['BROWSER'] = self._current_browser()
                if mm is not None:
                    print "main menu is",  mm
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.click_element('xpath=//*[(text()="'+sm+'")]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]') 
                    self.dict['BROWSER'] = self._current_browser()
            else:
                if mm is not None:
                    print "else part main menu is", mm
                    self.wait_until_element_is_visible('xpath=//a[text()="'+mm+'"]', 10, "mm was not visible")
                    self.click_element('xpath=//a[text()="'+mm+'"]')
                    time.sleep(1)
                    self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                    time.sleep(1)
                    self.dict['BROWSER'] = self._current_browser()
        else:
            print "top menu not found"
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
 def loading_menu_of_link(self,link):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.i = 1
        self.temp = 0
        self.telement = ""
        self.link = link
        y = len(self.link)
        for z in range(y):
         t = (self.link[z:z+1])
         if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
          flink = (self.link[z:])
          print "flink value"
          print flink
          z = 0
          break
         z = z + 1
        #Step 1 : Get Sub menu name and menu name from excel for the specified link
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        try : 
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')   
        sheet = wrkbk["menuload_sheet"]
        number_rows = sheet.max_row
        xllink = "test"
        while self.i <= number_rows:
         self.i = self.i + 1
         xllink = sheet.cell(row=(self.i),column=1).value
         y = len(xllink)
         for z in range(y):
          t = (xllink[z:z+1])
          if((t>='a' and t<= 'z') or (t>='A' and t<='Z')):
           xllink = (xllink[z:])
           z = 0
           break
         z = z + 1
         
         if flink == xllink:
          tm = sheet.cell(row=(self.i),column=2)
          sm =  sheet.cell(row=(self.i),column=3)
          mm = sheet.cell(row=(self.i),column=4)
          print tm
          print sm
          print mm
          
          wrkbk.close()
          i = 0
          break
        else:
         print "Link does not exists in excel sheet" 
         i = 0 
        
        #Step 2 : Load Menu
        while i <= 6 and flink == xllink:
         #i = i + 1
         self.temp = self.temp + 1
         x = str(self.temp)
         t1 = '"menulist"]/li['
         t2 = ']'
         x = t1 + x + t2 
         #time.sleep(1)
         telement = self._element_find('xpath=//*[@id='+x+'', True, False)
         time.sleep(1)
         #element = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "myDynamicElement")) 
         if telement  is not None:
            time.sleep(1)
            if (telement.is_displayed()) == True:
             #time.sleep(2)
             self.mouse_over('xpath=//*[@id='+x+'')
             #time.sleep(1)
             if sm.value is not None:
              #time.sleep(2)
              selement = self._element_find('xpath=//*[(text()="'+sm.value+'")]', True, False)
              #print selement
              time.sleep(1)
              melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
              #print melement
              time.sleep(2)
              if selement is not None:
               #time.sleep(2)
               if (selement.is_displayed()) == True:
                #print "hello"
                self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                if melement is not None :
                  time.sleep(2)
                  if (melement.is_displayed()) == True:
                   self.click_element('xpath=//*[(text()="'+mm.value+'")]') 
                   #time.sleep(5)
                   self.click_element('xpath=//*[(text()="'+sm.value+'")]')
                   #time.sleep(3)
                   self.mouse_over('xpath=//*[@id="chkNewwindow"]') 
                   #pyautogui.moveRel(100, 100)
                   self.dict['BROWSER'] = self._current_browser()
                   return self.dict
                   break         
             elif sm.value is None:
                melement = self._element_find('xpath=//*[(text()="'+mm.value+'")]', True, False)
                if melement is not None:
                     if (melement.is_displayed()) == True:
                      time.sleep(2)
                      self.click_element('xpath=//*[(text()="'+mm.value+'")]')
                      time.sleep(3)
                      self.mouse_over('xpath=//*[@id="chkNewwindow"]')
                      #pyautogui.moveRel(0, 20)
                      #time.sleep(2) 
                      #pyautogui.moveRel(100, 100)
                      self.dict['BROWSER'] = self._current_browser()
                      return self.dict
                      break
         else: 
              print "top menu not found"
         i = i + 1  
 
 def driving_browser_and_url(self):
        self.set_selenium_implicit_wait(30)
        self.j = 1
        self.k = 1
        #Step 1 : Get browser which is marked as "1" from excell SHEET
        try :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        except NameError :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        except :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')        
        #wrkbk = load_workbook('..//config/configfile.xlsx')
        sheet = wrkbk["browser_sheet"] 
        number_rows = sheet.max_row
               
        while self.j <= number_rows:
         self.j = self.j + 1
         if sheet.cell(row=(self.j),column=2).value == 1:
          bwr = sheet.cell(row=(self.j),column=1)
        #step 2 : Get Url which is marked as "1" from excell SHEET
        sheet = wrkbk["url_sheet"]
        number_rows = sheet.max_row
        while self.k <= number_rows:
         self.k = self.k + 1
         if sheet.cell(row=(self.k),column=2).value == 1:
          url = sheet.cell(row=(self.k),column=1)
          wrkbk.close()
        if bwr.value == "Chrome":
            chrome_options = chromeoptions() 
            chrome_options.add_argument("--force-device-scale-factor=0.6") #Zooming
            driver = webdriver.Chrome(options=chrome_options)
            driver.set_page_load_timeout(200)
            driver.get(str(url.value))
            print "url.value", url.value
            #print(driver.find_element(By.XPATH, "/html/body").text)
            #get_source = driver.page_source
            #print "get_source Msg:    ",  get_source
            #search_txt = "VIDHYA"
            #print search_txt in get_source
        elif bwr.value == "Opera":
            print "yet to be implemented"
        self.dict['DRIVER'] = driver
        self.dict['BROWSER'] = driver
        self._cache.current = self.dict['BROWSER']  
        #step 3 : Launch browser and url
        #self.open_browser(''+url.value+'',''+bwr.value+'', None, False, None, None)
        #newly added
        #self.delete_all_cookies()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 50, 'relogin  button not visible')
        #newly commented
        #time.sleep(5)
        self.maximize_browser_window()
        self.browser = self._current_browser()
        self.dict['BROWSER'] = self._current_browser()
        #self._cache.empty_cache()
        #print "self.browser", self.browser
        #print "self._current_browser()", self._current_browser()
        #print "self.dict['BROWSER']", self.dict['BROWSER']
 def capturing_exception_screenshot(self,filename,exceptionstring):
     self._cache.current = self.dict['BROWSER']
     self.browser = self._current_browser()
     print "start"
     self.set_screenshot_directory('D:\workspace\Automate_BB15_release\screenshots_exceptiontext', True)
     Filename = str(filename)+"_"+exceptionstring
     self.capture_page_screenshot(''+Filename+'.png')
     #self.capture_page_screenshot(''+str(filename)[8:]+'.png')
     print "end"
     self.dict['BROWSER'] = self._current_browser()
 
 
 def capturingexceptiontextpages(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        exception_str_list = ["new", "Undefined", "Null", "Error", "Object Reference", "Parser invalid object", "Server Error", "Not part of the model", "DBNull", "Sub Query"]
        current_page_str = self.dict['DRIVER'].find_element(By.XPATH, "/html/body").text
        updated_current_page_str = current_page_str.encode('utf-8')
        #print "updated_current_page_str", updated_current_page_str
        #common_reader.Capturing.capture_screenshot(self, 'sampletest')
        #self.capture_screenshot
        for string in exception_str_list:
            #print "current string in list", string
            status =  str(string).lower() in str(updated_current_page_str).lower()
            #print "status", status
            if status == False:
               #print "No Exception text in this page"
               pass
            else:
               print "Exception string", string
               Executed_Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
               Executed_library = BuiltIn().get_variable_value("${library}")
               print "Executed_library", Executed_library
               TestCaseName = ((Executed_Test_Name).split('Running '))[1].split(' Test Case')[0]
               self.capturing_exception_screenshot(''+TestCaseName+'',string)       
               #screeninst.capture_screenshot(''+Executed_Test_Name+'')
               #raise AssertionError ('Exception text present in this page')
        self.dict['BROWSER'] = self._current_browser()
 
 
 
 def findexceptiontext_old(self,search_txt):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        print ".................FIRST METHOD......................"
        #print(self.dict['DRIVER'].find_element(By.XPATH, "/html/body").text)
        page_text = self.dict['DRIVER'].find_element(By.XPATH, "/html/body").text
        textresults =  str(search_txt).lower() in str(page_text).lower()
        #print "str(search_txt).lower()", str(search_txt).lower()
        #print "str(page_text).lower()", str(page_text).lower()
        print textresults
        '''print ".................SECOND METHOD......................"
        get_source = self.dict['DRIVER'].page_source
        #print "get_source Msg:    ", get_source
        textresults = search_txt in get_source
        print textresults'''
        #print search_txt in get_source
        if str(textresults) == "False":
            raise AssertionError ("There is no exception text in this page")
        else:
            print "textresults", textresults
        self.dict['BROWSER'] = self._current_browser()
      
 def logging(self,loginmod):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.l = 1
        #Step 1 : Get user name and password from excell for which module to login
        try : 
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        except NameError :
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        except :  
          wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')  
        sheet = wrkbk["login_sheet"] 
        number_rows = sheet.max_row
        while self.l <= number_rows:
         self.l = self.l + 1
         if sheet.cell(row=(self.l),column=1).value == loginmod:
             user = sheet.cell(row=(self.l),column=2)
             pw =   sheet.cell(row=(self.l),column=3)
        #Step 2 : Login module with user name and password
        wrkbk.close()
        self.click_element('xpath=//a[@href="#divNewSession"]')
        #time.sleep(5)
        #newly added
        self.wait_until_element_is_visible('xpath=//*[@id="newuname"]', 100, 'login button not visible')
        # newly commented
        #time.sleep(5)
        self.input_text('xpath=//*[@id="newuname"]',''+user.value+'')
        self.input_text('xpath=//*[@id="txtrepassword"]',''+pw.value+'')
        self.click_button('xpath=//*[@id="btnrelogin"]')
        #Newly commented
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()
 
 def Logoff(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(30)
        self.unselect_frame()
        self.wait_until_element_is_visible('xpath=//*[@class="fa fa-power-off"]', 30, 'Log out was not visible')
        self.click_element('xpath=//*[@class="fa fa-power-off"]')
        self.wait_until_element_is_visible('id=uname', 30, 'Log out is not successful')
        self.wait_until_element_is_visible('xpath=//a[@href="#divNewSession"]', 100, 'login button not visible')
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()

 def scroll_web_element_into_view(self, locator):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
        self.dict['BROWSER'] = self._current_browser()
    
 '''def zoom_out_page(self, percent):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(5)
         self.execute_javascript("document.body.style.zoom='"+str(percent)+"%'")
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()'''
               
 def zoom_out_page(self,times):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(5)
         pyautogui. FAILSAFE = False
         times = int(times)
         x = 0
         for x in range(times):
             pyautogui.hotkey('ctrl', '-')
             pyautogui.PAUSE = 0.5
         time.sleep(3)
         #pyautogui. FAILSAFE = False
         self.dict['BROWSER'] = self._current_browser()
 def zoom_in_page(self,times):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         times = int(times)
         x = 0
         for x in range(times):
             pyautogui.hotkey('ctrl', '+')          
         self.dict['BROWSER'] = self._current_browser()  
 def close_the_browsers(self):
        self.set_selenium_implicit_wait(30)
        #self._cache.current = self.dict['BROWSER']
        #self.browser = self._current_browser()
        #self.close_browser()
        self.close_all_browsers()
        
     
 def exportingfiles(self,filename):
        time.sleep(10)
        print "start file uploading"
        if filename == "FirstBatchResult":
          try:
            origin = r'D:\workspace\Automate_BB15_release\driver'
            target = r'D:\FileUpload\FirstBatchResult'
            files = os.listdir(origin)
            for file_name in files:
                shutil.copytree(origin, target)
                print("Files are copied successfully for FirstBatchResult")
          except WindowsError:
            print("Files are copied along with windows error for FirstBatchResult")
            pass
          print "end file uploading"
          FilesList = os.listdir(r'D:\FileUpload\FirstBatchResult')
          print FilesList
          screenshotcount = str(FilesList).count('selenium-screenshot')
          print str(FilesList).count('selenium-screenshot')
          if screenshotcount > 3:
            upload_status = "files are uploaded successfully for FirstBatchResult"
            print upload_status
          time.sleep(10)
        if filename == "SecondBatchResult":
          try:
            origin = r'D:\workspace\Automate_BB15_release\driver'
            target = r'D:\FileUpload\SecondBatchResult'
            files = os.listdir(origin)
            files = os.listdir(origin)
            for file_name in files:
                shutil.copytree(origin, target)
                print("Files are copied successfully for SecondBatchResult")
          except WindowsError:
            print("Files are copied along with windows error for SecondBatchResult")
            pass
          print "end file uploading"
          FilesList = os.listdir(r'D:\FileUpload\SecondBatchResult')
          print FilesList
          screenshotcount = str(FilesList).count('selenium-screenshot')
          print str(FilesList).count('selenium-screenshot')
          if screenshotcount > 3:
            upload_status = "files are uploaded successfully for SecondBatchResult"
            print upload_status
          time.sleep(10)
       
 def db_indexrebuilding(self):
     wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
     sheet = wrkbk["ServerDetails"]
     servername = sheet.cell(row=2,column=1).value
     userid = sheet.cell(row=2,column=2).value
     pwd = sheet.cell(row=2,column=3).value
     wrkbk.close()
     cnxn = pypyodbc.connect("Driver={SQL Server};" "Server="+servername+";" "Database=kmch_frontoffice;" "uid="+userid+"; pwd="+pwd+"")
     print "db connected"
     cursor = cnxn.cursor()
     cursor.execute("ALTER INDEX ALL ON Mast_OP_Admission REBUILD;", None, False, False)
     time.sleep(20)
     cursor.close()
     cnxn.commit()
     cnxn.close()
     print "table index rebuilding done"
        
         
 def db_statupdate(self):
        wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        sheet = wrkbk["ServerDetails"]
        servername = sheet.cell(row=2,column=1).value
        userid = sheet.cell(row=2,column=2).value
        pwd = sheet.cell(row=2,column=3).value
        print servername
        print userid
        print pwd
        wrkbk.close()
        cnxn = pypyodbc.connect("Driver={SQL Server};" "Server="+servername+";" "uid="+userid+"; pwd="+pwd+"")
        print "db connected"
        cursor = cnxn.cursor()
        cursor.execute("Sp_ExecStatUpdate", None, False, False)
        time.sleep(60)      
        cursor.close()        
        cnxn.commit()
        cnxn.close()
        #time.sleep(10)
        print "stat update done"
 '''def getcurrenttestcase_name(self):     
     self.Executed_Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
     self.Test_Results[self.Executed_Test_Name] = {}
     print "Executed_Test_Name", self.Executed_Test_Name
     self.Test_Results[self.Executed_Test_Name]['DummyName'] = 'Dummy Name'
     #print "self.Test_Results[Executed_Test_Name]['name']", self.Test_Results[str(Executed_Test_Name)]['name']
     print "self.Test_Results", self.Test_Results
     print "self.Test_Results[Executed_Test_Name]", self.Test_Results[self.Executed_Test_Name]
     return self.Test_Results
     return self.Executed_Test_Name'''
 def Get_Test_Case_Name(self):
        self.dict['Executed_Test_Name'] = BuiltIn().get_variable_value("${TEST_NAME}")
        #print self.dict['Executed_Test_Name']
        #print "self.Test_Results", self.Test_Results
        self.Test_Results['TestCaseName'] = {}
        self.Test_Results[self.dict['Executed_Test_Name']] = self.Test_Results.pop('TestCaseName')        
        #print "self.Test_Results", self.Test_Results
        return self.dict['Executed_Test_Name']
 def Test_Teardown(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.close_browser()
        #self.close_all_browsers()
        driver = self.dict['DRIVER']
        driver.quit()
        Executed_Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
        Executed_Test_Status = BuiltIn().get_variable_value("${TEST_STATUS}")        
        Executed_Test_Message = BuiltIn().get_variable_value("${TEST_MESSAGE}")        
        print Executed_Test_Name
        print Executed_Test_Status
        print Executed_Test_Message
        #self.Test_Results['TestCaseName'] = self.Test_Results[Executed_Test_Name]
        #print "self.Test_Results['TestCaseName']", self.Test_Results['TestCaseName']
        #values_list = ['"'+Executed_Test_Status+'"', '"'+Executed_Test_Message+'"']
        #self.result['"'+Executed_Test_Name+'"'] = values_list
        values_list = [Executed_Test_Status, Executed_Test_Message]
        self.result[Executed_Test_Name] = values_list
        print self.result
        if Executed_Test_Name == "Running OPFLOW-CARD-SERVICES Test Case" or "Running test results1 Test Case" :
           self.dict['TESTCASECOUNT'] = 0                 
        if Executed_Test_Name == "Running OT booking request process simple flow with approval":
           self.dict['TESTCASECOUNT'] = 0
        if Executed_Test_Name == "Running FO-IPRegistration through OP Test Case":
           self.dict['EQUIPMENTBILLINGIPNO'] = self.dict['IPNO']  
           print "self.dict['IPNO']", self.dict['IPNO']
           print "self.dict['EQUIPMENTBILLINGIPNO']", self.dict['EQUIPMENTBILLINGIPNO']
           #self.dict['TESTCASECOUNT'] = 0
        self.dict['TESTCASECOUNT'] = self.dict['TESTCASECOUNT'] + 1
        print "CURRENT TEST CASE COUNT:    ", self.dict['TESTCASECOUNT']
        #self.db_statupdate()
        print "End of test case"
        
        #self.result = {'"'+Executed_Test_Name+'"': ['"'+Executed_Test_Status+'"', '"'+Executed_Test_Message+'"']}
        #print self.result
        #self.result['"'+Executed_Test_Name+'"'] = ['"'+Executed_Test_Status+'"', '"'+Executed_Test_Message+'"']
        
        '''wb = load_workbook('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
        ws = wb["TestExecutionControl"]
        self.r=1
        number_rows = ws.max_row
        self.dict['PRECONFIG-WB'] = wb
        while self.r <= number_rows:
         self.r = self.r + 1
         if ws.cell(row=(self.r),column=2).value == Executed_Test_Name:
             Excel_Test_Name = ws.cell(row=(self.r),column=2).value
             break
        print "Excel_Test_Name", Excel_Test_Name
        print "self.r", self.r         
        if Executed_Test_Name == Excel_Test_Name:
           print "yes"
           self.dict['"'+Executed_Test_Name+'"'] = Executed_Test_Status
           if Executed_Test_Status == "FAIL":
               ws.cell(row=(self.r),column=4).value = Executed_Test_Status
               ws.cell(row=(self.r),column=4).font = Font(color="FF0000")
           elif Executed_Test_Status == "PASS":
               ws.cell(row=(self.r),column=4).value = Executed_Test_Status
               ws.cell(row=(self.r),column=4).font = Font(color="00FF00")
           ws.cell(row=(self.r),column=5).value = Executed_Test_Message
           #wb.save('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
           #wb.close()
        else:
            print "There is no such test case name in excel sheet"
        if Executed_Test_Name == "Running OPFLOW-CARD-SERVICES Test Case" or Executed_Test_Name == "Running Test Trial":
           self.dict['TESTCASECOUNT'] = 0                 
        if Executed_Test_Name == "Running OT booking request process simple flow with approval":
           self.dict['TESTCASECOUNT'] = 0
        if Executed_Test_Name == "Running IP Registration through OP test case":
           self.dict['EQUIPMENTBILLINGIPNO'] = self.dict['IPNO']  
           print "self.dict['IPNO']", self.dict['IPNO']
           print "self.dict['EQUIPMENTBILLINGIPNO']", self.dict['EQUIPMENTBILLINGIPNO']
           #self.dict['TESTCASECOUNT'] = 0
        self.dict['TESTCASECOUNT'] = self.dict['TESTCASECOUNT'] + 1
        print "CURRENT TEST CASE COUNT:    ", self.dict['TESTCASECOUNT']
        self.close_all_browsers()
        #self.db_statupdate()
        print self.dict['"'+Executed_Test_Name+'"']
        print "End of test case"'''
 
 def save_allresults(self):
        print "This function helps to save the entire result values"
        for outer_key, inner_dict in self.Test_Results.items():
            #print str(outer_key)
            wb = load_workbook('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
            ws = wb["TestExecutionControl"]
            self.r=1
            number_rows = ws.max_row
            while self.r <= number_rows:
                  self.r = self.r + 1
                  Excel_Test_Name = ws.cell(row=(self.r),column=2).value
                  if str(Excel_Test_Name).strip() == str(outer_key).strip():
                      self.c = 6                                        
                      for inner_key, value in inner_dict.items():                          
                          #print str(inner_key)+"  :"+ str(value)
                          ws.cell(row=(self.r),column=(self.c)).value = str(inner_key)+"  :"+ str(value)
                          wb.save('D:\workspace\Automate_BB15_release\Config\Results.xlsx')                          
                          self.c = self.c + 1
        wb.close()        

        
 def saving_testresult(self):
     #print "saving test result"
     #print self.result
     key_count = len(self.result)
     for x in range (0, key_count):
         #print x
         wb = load_workbook('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
         ws = wb["TestExecutionControl"]
         self.r=1
         number_rows = ws.max_row
         Executed_Test_Name = list(self.result.keys())[int(x)]
         while self.r <= number_rows:
             self.r = self.r + 1
             excelvalue = ws.cell(row=(self.r),column=2).value
             if str(excelvalue).strip() == str(Executed_Test_Name).strip():
                #print "executed test name present in excel sheet"
                Excel_Test_Name = ws.cell(row=(self.r),column=2).value
                #print "Excel_Test_Name", Excel_Test_Name
                if str(Executed_Test_Name) == str(Excel_Test_Name):                  
                    #print "yes executed test case name stored in dictionary file present in excel sheet"
                    Executed_Test_Status = self.result[Executed_Test_Name][0] #Test Status
                    Executed_Test_Message = self.result[Executed_Test_Name][1] #Test Message
                    if  Executed_Test_Status == "FAIL":
                        #print "inside fail case"
                        ws.cell(row=(self.r),column=4).value = Executed_Test_Status
                        ws.cell(row=(self.r),column=4).font = Font(color="FF0000")
                    elif Executed_Test_Status == "PASS":
                         #print "inside pass case"
                         ws.cell(row=(self.r),column=4).value = Executed_Test_Status
                         ws.cell(row=(self.r),column=4).font = Font(color="00FF00")
                    ws = wb["TestExecutionControl"]
                    ws.cell(row=(self.r),column=5).value = Executed_Test_Message
                    wb.save('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
                    wb.close()
     # outer_key = executed test case name
     # inner_dict = all the get message which is related to 
     for outer_key, inner_dict in self.Test_Results.items():
            #print str(outer_key)
            #print self.Test_Results.items()
            wb = load_workbook('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
            ws = wb["TestExecutionControl"]
            self.r=1
            number_rows = ws.max_row
            while self.r <= number_rows:
                  self.r = self.r + 1
                  Excel_Test_Name = ws.cell(row=(self.r),column=2).value
                  if str(Excel_Test_Name).strip() == str(outer_key).strip():
                      self.c = 6                                   
                      for inner_key, value in inner_dict.items():
                          #print "inside for loop"
                          #value = value.replace('\xd7', '').replace('\n', '')
                          if '\n' in value:
                              value = (value.split("\n"))[1]
                          #print str(inner_key)+"  :"+ str(value)
                          ws.cell(row=(self.r),column=(self.c)).value = str(inner_key)+"  :"+ str(value)
                          wb.save('D:\workspace\Automate_BB15_release\Config\Results.xlsx')                          
                          self.c = self.c + 1
     wb.close()
     
     
     
     
     #wb = self.dict['PRECONFIG-WB']
     #wb.save('D:\workspace\Automate_BB15_release\Config\Results.xlsx')
     #wb.close()        
 
 '''def Test_Teardown_old(self):
        self.set_selenium_implicit_wait(30)
        Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
        if Test_Name == "Running OPFLOW-CARD-SERVICES Test Case":
           self.dict['TESTCASECOUNT'] = 0                        
        if Test_Name == "Running OT booking request process simple flow with approval":
           self.dict['TESTCASECOUNT'] = 0
        if Test_Name == "Running IP Registration through OP test case":
           self.dict['EQUIPMENTBILLINGIPNO'] = self.dict['IPNO']  
           print "self.dict['IPNO']", self.dict['IPNO']
           print "self.dict['EQUIPMENTBILLINGIPNO']", self.dict['EQUIPMENTBILLINGIPNO']
           #self.dict['TESTCASECOUNT'] = 0
        self.dict['TESTCASECOUNT'] = self.dict['TESTCASECOUNT'] + 1
        print "CURRENT TEST CASE COUNT:    ", self.dict['TESTCASECOUNT']
        if self.dict['TESTCASECOUNT']!=0 and self.dict['TESTCASECOUNT'] % 50 == 0:
           #self.db_indexrebuilding()           
           self.db_statupdate()                 
           time.sleep(300)
        Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
        if Test_Name == "Running TC1 Test Case":
           self.dict['TESTCASECOUNT'] = 0           
        self.dict['TESTCASECOUNT'] = self.dict['TESTCASECOUNT'] + 1
        print "CURRENT TEST CASE COUNT:    ", self.dict['TESTCASECOUNT']
        if self.dict['TESTCASECOUNT']!=0 and self.dict['TESTCASECOUNT'] % 3 == 0:
           time.sleep(300)
        #print self.Get_Test_Case_Name()        
        #print self.Get_Test_Case_Tags()
        #print self.Get_Test_Case_Status()
        #print self.Get_Test_Case_Documentation()
        #print self.Get_Test_Case_Message()
        #self.dict[TestCaseCount] = 0
        #self.dict[TestCaseCount] = self.dict[TestCaseCount] + 1
        #print "Test Case execution count: ", self.dict[TestCaseCount]
        self.close_all_browsers()
        #self.db_statupdate()
        #time.sleep(30)
        print "End of test case"'''
        
       
        
 '''def Get_Test_Case_Name(self):
        Test_Name = BuiltIn().get_variable_value("${TEST_NAME}")
        if Test_Name == "Running OPFLOW-CARD-SERVICES Test Case":
           self.dict['TESTCASECOUNT'] = 0           
        self.dict['TESTCASECOUNT'] = self.dict['TESTCASECOUNT'] + 1
        print "CURRENT TEST CASE COUNT:    ", self.dict['TESTCASECOUNT']
        if self.dict['TESTCASECOUNT']!=0 and self.dict['TESTCASECOUNT'] % 20 == 0:
        return Test_Name
 def Get_Test_Case_Tags(self):
        Test_Tags = BuiltIn().get_variable_value("${TEST_TAGS}")
        return Test_Tags
 def Get_Test_Case_Status(self):
        Test_Status = BuiltIn().get_variable_value("${TEST_STATUS}")
        return Test_Status
 def Get_Test_Case_Documentation(self):
        Test_Documentation = BuiltIn().get_variable_value("${TEST_DOCUMENTATION}")
        return Test_Documentation
 def Get_Test_Case_Message(self):
        Test_Message = BuiltIn().get_variable_value("${TEST_MESSAGE}")
        return Test_Message
 def Get_Test_Case_Count(self):
        Test_Counts = BuiltIn().get_variable_value("${TEST_COUNT}")
        return Test_Counts'''
 
 def reading_labmastersettings(self, procedurename):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.procedurename = procedurename
        fprocedurename = self.procedurename
        print fprocedurename
        wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        sheet = wrkbk["LabMasterSettings"]
        number_rows = sheet.max_row
        xlprocedurename = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xlprocedurename = sheet.cell(row=(self.i),column=1).value
         if fprocedurename == xlprocedurename:
          labprocedureapprstatus = sheet.cell(row=(self.i),column=2).value
          print labprocedureapprstatus
          wrkbk.close()
          i = 0
          break
         else:
             print "Given procedure name does not exists in excel sheet"
             labprocedureapprstatus = 0
        time.sleep(3)
        print labprocedureapprstatus
        self.dict['labprocedureapprstatus'] = labprocedureapprstatus
        self.dict['BROWSER'] = self._current_browser()
 
 def reading_bloodcomponentmastersettings(self, bbservicename):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.bbservicename = bbservicename
        fbbservicename = self.bbservicename
        print fbbservicename
        wrkbk = load_workbook('D:\workspace\Automate_BB15_release\Config\Prerequsiteconfig.xlsx')
        sheet = wrkbk["BBComponentMasterSettings"]
        number_rows = sheet.max_row
        xlbbservicename = "test"
        self.i = 1
        while self.i <= number_rows:
         self.i = self.i + 1
         xlbbcomponentname = sheet.cell(row=(self.i),column=1).value #blood Component Name
         xlbbservicename = sheet.cell(row=(self.i),column=3).value #blood bank Service Name
         if (fbbservicename == xlbbservicename) and (xlbbcomponentname  == "Whole Blood"):
          crossmatchstatus = sheet.cell(row=(self.i),column=2).value
          print crossmatchstatus
          wrkbk.close()
          i = 0
          break
        else:
         print "Given procedure name does not exists in excel sheet"
         time.sleep(3)
        print crossmatchstatus
        self.dict['crossmatchstatus'] = crossmatchstatus
        self.dict['BROWSER'] = self._current_browser()
 
 def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()          
