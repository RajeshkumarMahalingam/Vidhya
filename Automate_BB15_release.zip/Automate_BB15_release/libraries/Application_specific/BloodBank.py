import sys
from Selenium2Library import Selenium2Library
from datetime import datetime
from random import randint
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InDonarPreRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_PreDonorReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_sal(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['BB_predonorregistration_sal'], 20, 'sal not visible' )
        self.select_from_list_by_label(self.objects['BB_predonorregistration_sal'], self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.d[r]['name'] = "joseph"
        self.wait_until_element_is_visible(self.objects['BB_predonorregistration_donarname'], 20, 'donor name was not visible' )
        self.input_text(self.objects['BB_predonorregistration_donarname'], self.d[r]['name'])        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_predonorregistration_gender'], 20, 'gender was not visible' )
        self.select_from_list_by_label(self.objects['BB_predonorregistration_gender'], self.d[r]['gender'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_predonorregistration_age'], 20, 'age was not visible')
        self.input_text(self.objects['BB_predonorregistration_age'],str(self.d[r]['age']))
        self.press_key(self.objects['BB_predonorregistration_age'], "\\09")
        self.press_key(self.objects['BB_predonorregistration_age'], "\\27")
        time.sleep(0.5)
        self.click_element(self.objects['BB_predonorregistration_age'])
        #self.press_key(self.objects['BB_predonorregistration_age'], "\\09")
        #self.press_key(self.objects['BB_predonorregistration_age'], "\\27")
        self.dict['BROWSER'] = self._current_browser()
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_predonorregistration_address'], 20, 'address was not visible')
        self.input_text(self.objects['BB_predonorregistration_address'], self.d[r]['address'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city(self,r): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #r =  int(r)
         #self.click_element(self.objects['BB_predonorregistration_citytextbox'])
         #self.input_text(self.objects['BB_predonorregistration_cityselect'], self.d[r]['city'])
         #time.sleep(2)
         #self.press_key(self.objects['BB_predonorregistration_cityselect'], '\\09')
         
         r = int (r)
         self.wait_until_element_is_visible(self.objects["BB_predonorregistration_City"], 20, "city was not visible")
         self.click_element(self.objects['BB_predonorregistration_City'])
         #time.sleep(2)
         self.wait_until_element_is_visible(self.objects["BB_predonorregistration_City_Entry"], 20, "city entry was not visible")
         self.input_text(self.objects["BB_predonorregistration_City_Entry"],self.d[r]["city"])
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]', 20, "city list was present")
         self.click_element('xpath=//*[@id="select2-drop"]//span[text()="'+self.d[r]["city"]+'"]')
         time.sleep(1)     
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["BB_predonorregistration_save"], 20, "Save btn was not visible")
         self.click_button(self.objects["BB_predonorregistration_save"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_predonorregistration_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['BB_predonorregistration_Message'])
        print "get msg", self.msg
        self.dict['DREGNO'] = self.msg[51:]
        print self.dict['DREGNO']
        #self.donarregnum =((self.msg).split('Donor Pre-Registered Successfully , '))[1].split('Donor Reg No :')[1]
        #self.dict['DREGNO'] = self.donarregnum
        #print("donar reg num is",self.dict['DREGNO'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_predonorregistration_saveokbutton"], 20, "OK btn was not visible")
        self.click_button(self.objects["BB_predonorregistration_saveokbutton"])
        #############     Release server    ##################################################
        time.sleep(7)
        pyautogui. FAILSAFE = False
        pyautogui.click(1250,72)
        ##################################################################################
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InPreRegistrationScreening(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("BB_PreRegScreening")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_donarregno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_donorregno'], 30, 'donor regno was not visible')
         self.input_text(self.objects['BB_PreRegScreening_donorregno'],str(self.dict['DREGNO']))
         self._cache.current = self.dict['BROWSER']
    def selecting_gobtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_gobutton'], 30, 'go btn was not visible')
         self.click_button(self.objects['BB_PreRegScreening_gobutton'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_regnofromgrid(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="tbodyshowdata"]//td[text()="'+str(self.dict['DREGNO'])+'"]', 20, 'grid no. was not visible')
         self.click_element('xpath=//*[@id="tbodyshowdata"]//td[text()="'+str(self.dict['DREGNO'])+'"]')
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_blooddonatestatus(self, status):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        status = str(status)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_blooddonatestatus'], 20, 'blood donate status was not visible')
        self.select_from_list_by_label(self.objects['BB_PreRegScreening_blooddonatestatus'], status)
        #self.click_element(self.objects['BB_PreRegistrationScreening_blooddonorstatuscombo'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_blooddonorstatustext'], self.d[r]['bb_prereg_screening_blooddonate_status'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_blooddonorstatustext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']  
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_remarks'], 20, 'remarks was not visible')
        self.input_text(self.objects['BB_PreRegScreening_remarks'], self.d[r]['bb_prereg_screening_remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_resultvalue(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_resultvalue'], 20, 'result value was not visible')
        self.input_text(self.objects['BB_PreRegScreening_resultvalue'], self.d[r]['bb_prereg_screening_resultvalue'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_PreRegScreening_savebtn'], 20, 'save btn was not visible')
        self.click_button(self.objects['BB_PreRegScreening_savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodbagtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_BloodBagType'], 20, "bloodbagtype was not visible")
        self.select_from_list_by_index(self.objects['BB_PreRegScreening_redirectscreen_BloodBagType'], '2')
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typecombo'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typetext'], self.d[r]['bb_prereg_screening_bloodbagtype'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodbag_typetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_Weight'], 20, "weight was not visible")
        self.input_text(self.objects['BB_PreRegScreening_redirectscreen_Weight'], str(self.d[r]['bb_prereg_screening_weight']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodpressure(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_BloodPressure'], 20, "blood pressure was not visible")
        self.input_text(self.objects['BB_PreRegScreening_redirectscreen_BloodPressure'], str(self.d[r]['bb_prereg_screening_bloodpressure']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_donortype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_DonorType'], 20, "donor type was not visible")
        self.select_from_list_by_index(self.objects['BB_PreRegScreening_redirectscreen_DonorType'], '2')
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypecombo'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], self.d[r]['bb_prereg_screening_donortype'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_regdate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_RegDate'], 20, "regdate was not visible")
            self.click_element(self.objects['BB_PreRegScreening_redirectscreen_RegDate'])
            time.sleep(1)           
            self.click_element('xpath=//*[@class="datepicker-days"]//td[@class="today day"]')
            time.sleep(10)
            ###################################commented below for avoiding excel sheet date picking for current date##################
            #self.input_text(self.objects['BB_PreRegScreening_redirectscreen_RegDate'], str(self.d[r]['bb_prereg_screening_regdate']))
            #self.press_key(self.objects['BB_PreRegScreening_redirectscreen_RegDate'], '\\09')
            ###########################################################################################################################
        else:
            print "Regdate was not enabled in control panel settings "
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodunitno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            BloodUN = randint(100,999)
            self.dict['BLOODUNITNO'] = "3"+str(BloodUN)
            #self.dict['BLOODUNITNO'] = self.d[r]['bb_prereg_screening_bloodunitnum']
            self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_BloodUnitNo'], 20, "blood unit no was not visible")
            self.input_text(self.objects['BB_PreRegScreening_redirectscreen_BloodUnitNo'],str(self.dict['BLOODUNITNO']))
        else:
            print "Blood unit number was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def entering_segmentno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_SegmentNo'], 20, "segment no was not visible")
        self.input_text(self.objects['BB_PreRegScreening_redirectscreen_SegmentNo'], str(self.d[r]['bb_prereg_screening_segmentnum']))
        self.press_key(self.objects['BB_PreRegScreening_redirectscreen_SegmentNo'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponent(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_ComponentName'], 20, "component name was not visible")
        self.select_from_list_by_label(self.objects['BB_PreRegScreening_redirectscreen_ComponentName'], self.d[r]['bb_prereg_screening_componentname'])
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponentcombo2'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], self.d[r]['bb_prereg_screening_componentname'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_conversionbloodcomponent(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_ComponentName'], 20, "component name was not visible")
        self.select_from_list_by_label(self.objects['BB_PreRegScreening_redirectscreen_ComponentName'], self.dict['BLOODCOMPONENTNAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_bloodcomponentaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_PreRegScreening_redirectscreen_ComponentAddbtn'], 20, "component addbtn was not visible")
        self.click_button(self.objects['BB_PreRegScreening_redirectscreen_ComponentAddbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_PreRegScreening_redirectscreen_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['BB_PreRegScreening_redirectscreen_Message'])
        print "Message:    ", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreRegScreening_redirectscreen_Okbtn"], 30, "ok btn was not visible")
        self.click_button(self.objects["BB_PreRegScreening_redirectscreen_Okbtn"])
        #################     Release server    #################################################
        pyautogui. FAILSAFE = False
        time.sleep(7)
        pyautogui.click(1250,72)
        #########################################################################################
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InMainDonorRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("BB_MainDonorReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_sal(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int (r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Sal'], 20, 'sal was not visible')
        self.select_from_list_by_label(self.objects['BB_MainDonorReg_Sal'], self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_donorname(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_DonorName'], 20, 'donor name was not visible')
        self.input_text(self.objects['BB_MainDonorReg_DonorName'], str(self.d[r]['name']))
        #self.input_text(self.objects['BB_MainDonorReg_DonorName'], "John hendry RH")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Gender'], 20, 'donor gender was not visible')
        self.select_from_list_by_label(self.objects['BB_MainDonorReg_Gender'], self.d[r]['gender'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Age'], 20, 'age was not visible')
        self.input_text(self.objects['BB_MainDonorReg_Age'],str(self.d[r]['age']) )
        self.dict['BROWSER'] = self._current_browser()
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Address'], 20, 'address was not visible')
        self.input_text(self.objects['BB_MainDonorReg_Address'], self.d[r]['address'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_city(self,r): 
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r =  int(r)
         self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_City'], 20, "city was not visible")
         self.click_element(self.objects['BB_MainDonorReg_City'])
         self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_CityInput'], 20, "city text field was not visible")
         #self.input_text(self.objects['BB_MainDonorReg_CityInput'], self.d[r]['city'])
         self.input_text(self.objects['BB_MainDonorReg_CityInput'], "%%%")
         self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[2]', 20, "cities lists was not visible")
         self.click_element('xpath=//*[@id="select2-drop"]//li[2]')
         self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodbagtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_BloodBagType'], 20, "bloodbag type was not visible")
        self.select_from_list_by_index(self.objects['BB_MainDonorReg_BloodBagType'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Weight'], 20, "weight was not visible")
        self.input_text(self.objects['BB_MainDonorReg_Weight'], str(self.d[r]['weight']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodpressure(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_BloodPressure'], 20, "blood pressure was not visible")
        self.input_text(self.objects['BB_MainDonorReg_BloodPressure'], str(self.d[r]['bloodpressure']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_donortype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_DonorType'], 20, "donor type was not visible")
        self.select_from_list_by_index(self.objects['BB_MainDonorReg_DonorType'], '2')
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypecombo'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], self.d[r]['bb_prereg_screening_donortype'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_regdate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_RegDate'], 20, "regdate was not visible")
            self.click_element(self.objects['BB_MainDonorReg_RegDate'])
            time.sleep(1)
            self.click_element('xpath=//*[@class="datepicker-days"]//td[@class="today day"]')
            ################################################# commented this to avoid reg date retrieved from excel shet#################
            #self.input_text(self.objects['BB_MainDonorReg_RegDate'], str(self.d[r]['regdate']))
            #self.press_key(self.objects['BB_MainDonorReg_RegDate'], '\\09')
            ############################################################################################################################
        else:
            print "Registration date was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodunitno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            BloodUN = randint(100,999)
            self.dict['BLOODUNITNO'] = "3"+str(BloodUN)
            #self.dict['BLOODUNITNO'] = self.d[r]['bloodunitno']
            self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_BloodUnitNo'], 20, "blood unit no was not visible")
            self.input_text(self.objects['BB_MainDonorReg_BloodUnitNo'],str(self.dict['BLOODUNITNO']))
        else:
            print "Blood unit no. was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def entering_segmentno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_SegmentNo'], 20, "segment no was not visible")
        self.input_text(self.objects['BB_MainDonorReg_SegmentNo'], str(self.d[r]['segmentno']))
        self.press_key(self.objects['BB_MainDonorReg_SegmentNo'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponent(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_ComponentName'], 20, "component name was not visible")
        self.select_from_list_by_label(self.objects['BB_MainDonorReg_ComponentName'], self.d[r]['componentname'])        
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponentcombo2'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], self.d[r]['bb_prereg_screening_componentname'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_bloodcomponenttext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponentaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_MainDonorReg_ComponentAddbtn'], 20, "component addbtn was not visible")
        self.click_button(self.objects['BB_MainDonorReg_ComponentAddbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_MainDonorReg_Savebtn'], 20, 'save btn was not visible')
        self.click_button(self.objects['BB_MainDonorReg_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_MainDonorReg_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['BB_MainDonorReg_Message'])
        print "Message:    ", self.msg
        self.dict['DREGNO'] = self.msg[47:]
        print "donor reg no: ", self.dict['DREGNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_MainDonorReg_Okbtn"], 20, "ok btn was not visible")
        self.click_button(self.objects["BB_MainDonorReg_Okbtn"])
        ############# Release server#########################
        time.sleep(7)
        pyautogui. FAILSAFE = False
        pyautogui.click(1250,72)
        #########################################################
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InMainScreening(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("BB_MainScreening")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_Mainframe"], 20, "frame was not visible")
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()    
    def entering_donorregnoinsearchbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['DREGNO'] = "2126"        
        self.wait_until_page_contains_element('xpath=//input[@type="search"]', 20, "search box was not visible")
        self.wait_until_element_is_visible('xpath=//input[@type="search"]', 20, "search box was not visible")
        self.input_text('xpath=//input[@type="search"]',str(self.dict['DREGNO']))        
        #self.wait_until_page_contains_element(self.objects["BB_MainScreening_Searchbox"], 10, "search box was not visible")
        #self.wait_until_element_is_visible(self.objects["BB_MainScreening_Searchbox"], 10, "search box was not visible")
        #self.input_text(self.objects['BB_MainScreening_Searchbox'],str(self.dict['DREGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_bloodunitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            BloodUN = randint(100,999)
            self.dict['BLOODUNITNO'] = "3"+str(BloodUN)
            self.wait_until_element_is_visible(self.objects['BB_MainScreening_bloodunit'], 20, "blood unit no was not visible")
            self.input_text(self.objects['BB_MainScreening_bloodunit'],str(self.dict['BLOODUNITNO']))
        else:
            "Blood unit no. field was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    '''def entering_bloodunitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="txtFromDate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtFromDate"]', "01-02-2023")
        #self.press_key('xpath=//*[@id="txtFromDate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtFromDate"]', '\\09')
        #time.sleep(1)
        #self.dict['BLOODUNITNO'] = "221"
        #self.dict['DREGNO'] = "1945"
        #self.dict['BLOODUNITNO'] = self.d[r]['bloodunitno']
        self.wait_until_element_is_visible(self.objects["BB_MainScreening_bloodunit"], 10, "blood unit was not visible")
        self.input_text(self.objects['BB_MainScreening_bloodunit'],str(self.dict['BLOODUNITNO']))
        self.dict['BROWSER'] = self._current_browser()'''
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_MainScreening_Gobtn'], 20, "go btn was not visible")
        self.click_button(self.objects['BB_MainScreening_Gobtn'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def getting_bloodunitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//td[text()="'+str(self.dict['DREGNO'])+'"]/..//td[1]', 20, "blood unit no was not in grid")
        self.dict['BLOODUNITNO'] = self._get_text('xpath=//*[@id="tbodyshowdata"]//td[text()="'+str(self.dict['DREGNO'])+'"]/..//td[1]')
        print self.dict['BLOODUNITNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_donorregnofromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['DREGNO'] = "2103"
        self.wait_until_element_is_visible('xpath=//*[@id="tbodyshowdata"]//td[text()="'+self.dict['DREGNO']+'"]', 20, "patient details not in grid")
        self.click_element('xpath=//*[@id="tbodyshowdata"]//td[text()="'+self.dict['DREGNO']+'"]')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodgroup(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["BB_MainScreening_bloodgroup"], 20, "blood group was not visible")
        self.select_from_list_by_label(self.objects["BB_MainScreening_bloodgroup"], self.d[r]['bloodgroup'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_rhtype(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["BB_MainScreening_rhtype"], 20, "blood rhtype was not visible")
        self.select_from_list_by_label(self.objects["BB_MainScreening_rhtype"], self.d[r]['rhtype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_blooddonatestatus(self, status):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        status = str(status)
        self.wait_until_element_is_visible(self.objects["BB_MainScreening_blooddonatestatus"], 20, "blood donate status was not visible")
        self.select_from_list_by_label(self.objects["BB_MainScreening_blooddonatestatus"], status)
        if status == "Reject":
            self.wait_until_element_is_visible(self.objects["BB_MainScreening_Remarks"], 20, "remarks was not visible")
            self.input_text(self.objects['BB_MainScreening_Remarks'],"Rejected remarks")
        self.dict['BROWSER'] = self._current_browser()
    def getting_resultvalue(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #print "start", datetime.now()
        count = 0
        try:
         for i in range(1, 100):
             i = str(i)
             Testname = self._get_text('xpath=//*[@id="tblBind"]//tr['+i+']/td[1]')
             if len(Testname)!=0:
                print Testname
                count = count + 1
                i = int(i)
                i = i + 1
        except ValueError:
                print count
                pass
        print "Total number of test name:     ", count
        for j in range(1, count+1):
            j = str(j)
            try:
                #self.click_element('xpath=(//input[@id="cboResult"])['+j+']')
                self.input_text('xpath=(//input[@id="cboResult"])['+j+']', "123")               
                #self.click_element('xpath=//*[@id="tblBind"]//tr['+j+']/td[2]//input[@id="cboResult"]')
                #self.input_text('xpath=//*[@id="tblBind"]//tr['+j+']/td[2]//input[@id="cboResult"]', "123")
            except ValueError:
                break
            else:
                j = int(j)
                j = j + 1
        print "end"
        #print datetime.now()
        self.dict['BROWSER'] = self._current_browser()
        
        '''    def getting_resultvalue(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        print "start", datetime.now()
        count = 0
        try:
         for i in range(1, 100):
             i = str(i)
             Testname = self._get_text('xpath=//*[@id="tblBind"]//tr['+i+']/td[1]')
             if len(Testname)!=0:
                print Testname
                count = count + 1
                i = int(i)
                i = i + 1
        except ValueError:
                print count
                pass
        for j in range(1, count+1):
            j = str(j)
            try:
                self.click_element('xpath=//*[@id="tblBind"]//tr['+j+']/td[2]//input[@id="cboResult"]')
                self.input_text('xpath=//*[@id="tblBind"]//tr['+j+']/td[2]//input[@id="cboResult"]', "123")
            except ValueError:
                j = int(j)
                j = j + 1
            else:
                j = int(j)
                j = j + 1
        print "end"
        print datetime.now()
        self.dict['BROWSER'] = self._current_browser()'''
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_button(self.objects['BB_MainScreening_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_MainScreening_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['BB_MainScreening_Message'])
        print "Message:    ", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_MainScreening_Okbtn"], 20, "ok btn was not visible")
        self.click_button(self.objects["BB_MainScreening_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InConvertWBToComponents(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def searching_unitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['BLOODUNITNO'] = "1548"
        self.wait_until_element_is_visible(self.objects['BB_ConvertWBToComponent_Searchbox'], 20, 'searchbox was not visible')
        self.input_text(self.objects['BB_ConvertWBToComponent_Searchbox'], str(self.dict['BLOODUNITNO']))
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_unitnofromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td/a[text()="'+str(self.dict['BLOODUNITNO'])+'"]', 20, 'blood unit no was not visible')
        self.click_element('xpath=//*[@id="tblLoaddata"]//td/a[text()="'+str(self.dict['BLOODUNITNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def getting_conversioncomponentname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtBldConversion1"]/../..//td[3]', 20, "conversion component was not visible")
        coversioncomponentname = self._get_text('xpath=//*[@id="txtBldConversion1"]/../..//td[3]')
        print "coversioncomponentname", coversioncomponentname
        self.dict['BLOODCOMPONENTNAME'] = str(coversioncomponentname)
        print "self.dict['coversioncomponentname']", self.dict['BLOODCOMPONENTNAME']
        self.dict['BROWSER'] = self._current_browser()
    def entering_componentqty(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_ConvertWBToComponent_componentqty'], 20, 'component qty was not visible')
        self.input_text(self.objects['BB_ConvertWBToComponent_componentqty'],str(self.d[r]['qty']))
        self.dict['BROWSER'] = self._current_browser()   
    def entering_ml(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_ConvertWBToComponent_ML'], 20, 'ML was not visible')
        self.input_text(self.objects['BB_ConvertWBToComponent_ML'],str(self.d[r]['ml']))
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ConvertWBToComponent_Updatebtn"], 20, "update btn was not visible")
        self.click_button(self.objects["BB_ConvertWBToComponent_Updatebtn"])
        self.dict['BROWSER'] = self._current_browser()   
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_ConvertWBToComponent_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_ConvertWBToComponent_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ConvertWBToComponent_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_ConvertWBToComponent_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InDiscardStock(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['DREGNO'] = "2122"
        self.wait_until_element_is_visible(self.objects['BB_DiscardStock_Regno'], 20, 'Donor Regno was not visible')
        self.input_text(self.objects['BB_DiscardStock_Regno'], str(self.dict['DREGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DiscardStock_Gobtn"], 30, "Go btn was not visible")
        self.click_button(self.objects["BB_DiscardStock_Gobtn"])
        self.dict['BROWSER'] = self._current_browser()            
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['DREGNO'])+'"]/..//input', 20, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['DREGNO'])+'"]/..//input')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_discardbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DiscardStock_Discardbtn"], 20, "discard btn was not visible")
        self.click_button(self.objects["BB_DiscardStock_Discardbtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_incinerationtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["BB_DiscardStock_Incinerationtype"], 20, "Incineration type was not visible")
        self.select_from_list_by_index(self.objects["BB_DiscardStock_Incinerationtype"],'2')
        self.dict['BROWSER'] = self._current_browser()    
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_DiscardStock_Remarks'], 20, 'Donor Regno was not visible')
        self.input_text(self.objects['BB_DiscardStock_Remarks'], "Not Applicable")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_closebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DiscardStock_closebtn"], 30, "close btn was not visible")
        self.click_element(self.objects["BB_DiscardStock_closebtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()            
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_DiscardStock_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_DiscardStock_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DiscardStock_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_DiscardStock_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  


class InRequestReceive(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        self.wait_until_element_is_visible(self.objects['BB_RequestReceive_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_RequestReceive_Regno'], str(self.dict['REGNO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_user(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["BB_RequestReceive_User"], 20, "user was not visible")
        self.select_from_list_by_index(self.objects["BB_RequestReceive_User"],'1')
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_RequestReceive_Gobtn"], 30, "Go btn was not visible")
        self.click_button(self.objects["BB_RequestReceive_Gobtn"])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_RequestReceive_Checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['BB_RequestReceive_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_RequestReceive_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_RequestReceive_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_receivebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_RequestReceive_Receivebtn"], 30, "request receive btn was not visible")
        self.click_button(self.objects["BB_RequestReceive_Receivebtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DiscardStock_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_DiscardStock_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  

class InCrossMatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        #self.dict['BLOODUNITNO'] = "3803"
        self.wait_until_element_is_visible(self.objects['BB_CrossMatch_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_CrossMatch_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_CrossMatch_Gobtn"], 30, "Go btn was not enabled")
        self.click_button(self.objects["BB_CrossMatch_Gobtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_crossmatchpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[4]/a', 30, "patient details not visible in grid")
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[4]/a')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def searching_bloodunitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_CrossMatch_Searchtextbox'], 30, "search box was not visible")
        self.input_text(self.objects['BB_CrossMatch_Searchtextbox'],str(self.dict['BLOODUNITNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_CrossMatch_Checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['BB_CrossMatch_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_compatability(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_CrossMatch_Compatability"], 20, "compatability was not visible")
        self.select_from_list_by_index(self.objects["BB_CrossMatch_Compatability"],'1')
        self.dict['BROWSER'] = self._current_browser()          
    def selecting_status(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_CrossMatch_Status"], 20, "status was not visible")
        self.select_from_list_by_label(self.objects["BB_CrossMatch_Status"],"Compatible")
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_crossmatchtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_CrossMatch_CrossMatchType"], 20, "cross match type was not visible")
        self.select_from_list_by_index(self.objects["BB_CrossMatch_CrossMatchType"],'2')
        self.dict['BROWSER'] = self._current_browser()         
    def selecting_user(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_CrossMatch_User"], 20, "user was not visible")
        self.select_from_list_by_index(self.objects["BB_CrossMatch_User"],'1')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_crossmatchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_CrossMatch_CrossMatchbtn"], 20, "cross match btn was not enabled")
        self.click_button(self.objects["BB_CrossMatch_CrossMatchbtn"])
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_CrossMatch_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_CrossMatch_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_CrossMatch_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_CrossMatch_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InIssueBloodUnit(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_IssueBloodUnit_Gobtn"], 20, "Go btn was not enabled")
        self.click_button(self.objects["BB_IssueBloodUnit_Gobtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        #self.dict['BLOODUNITNO'] = "3633"
        self.wait_until_element_is_visible(self.objects['BB_IssueBloodUnit_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_IssueBloodUnit_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()    
    def entering_into_issuebloodunitspage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[4]/a', 30, "patient details not visible in grid")
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[4]/a')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()      
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_IssueBloodUnit_Checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['BB_IssueBloodUnit_Checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_user(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["BB_IssueBloodUnit_User"], 20, "user was not visible")
        self.select_from_list_by_index(self.objects["BB_IssueBloodUnit_User"],'1')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_issuebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_IssueBloodUnit_Issuebtn"], 20, "Issue btn was not enabled")
        self.click_button(self.objects["BB_IssueBloodUnit_Issuebtn"])
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_IssueBloodUnit_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_IssueBloodUnit_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_IssueBloodUnit_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_IssueBloodUnit_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InReturnRequestBloodUnit(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        #self.dict['BLOODUNITNO'] = "3633"
        self.wait_until_element_is_visible(self.objects['BB_IssueBloodUnit_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_IssueBloodUnit_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRequestBloodUnit_Gobtn"], 30, "Go btn was not enabled")
        self.click_button(self.objects["BB_ReturnRequestBloodUnit_Gobtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_returnrequestbloodunitspage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[6]/a', 30, "patient details not visible in grid")
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//td[6]/a')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_returnreason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["BB_ReturnRequestBloodUnit_ReturnReason"], 20, "return reason was not visible")
        self.select_from_list_by_index(self.objects["BB_ReturnRequestBloodUnit_ReturnReason"],'1')
        self.dict['BROWSER'] = self._current_browser()     
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_ReturnRequestBloodUnit_Remarks'], 20, 'remarks was not visible')
        self.input_text(self.objects['BB_ReturnRequestBloodUnit_Remarks'], "Not Applicable")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_ReturnRequestBloodUnit_checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['BB_ReturnRequestBloodUnit_checkbox'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRequestBloodUnit_savebtn"], 20, "Save btn was not enabled")
        self.click_button(self.objects["BB_ReturnRequestBloodUnit_savebtn"])
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_IssueBloodUnit_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_IssueBloodUnit_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRequestBloodUnit_saveokbutton"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_ReturnRequestBloodUnit_saveokbutton"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
         
class InReturnApproveBloodUnit(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "624893"
        #self.dict['BLOODUNITNO'] = "3633"
        self.wait_until_element_is_visible(self.objects['BB_ReturnApproveBloodUnit_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_ReturnApproveBloodUnit_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnApproveBloodUnit_Gobtn"], 20, "Go btn was not enabled")
        self.click_button(self.objects["BB_ReturnApproveBloodUnit_Gobtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input', 20, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnApproveBloodUnit_Approvebtn"], 20, "Approve btn was not enabled")
        self.click_button(self.objects["BB_ReturnApproveBloodUnit_Approvebtn"])
        self._handle_alert_with_text("Not Applicable", True)
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_ReturnApproveBloodUnit_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_ReturnApproveBloodUnit_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnApproveBloodUnit_okbtn"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_ReturnApproveBloodUnit_okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  

class InReturnRejectBloodUnit(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_WBToComp")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="txtFromDate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtFromDate"]', "25-06-2023")
        #self.press_key('xpath=//*[@id="txtFromDate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtFromDate"]', '\\09')
        #self.dict['REGNO'] = "623231"
        self.wait_until_element_is_visible(self.objects['BB_ReturnRejectBloodUnit_Regno'], 20, 'Regno was not visible')
        self.input_text(self.objects['BB_ReturnRejectBloodUnit_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRejectBloodUnit_Gobtn"], 20, "Go btn was not enabled")
        self.click_button(self.objects["BB_ReturnRejectBloodUnit_Gobtn"])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input', 20, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tblLoaddata"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_rejectbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRejectBloodUnit_Rejectbtn"], 20, "Reject btn was not enabled")
        self.click_button(self.objects["BB_ReturnRejectBloodUnit_Rejectbtn"])
        self._handle_alert_with_text("Not Applicable", True)
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['BB_ReturnRejectBloodUnit_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_ReturnRejectBloodUnit_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_ReturnRejectBloodUnit_okbtn"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_ReturnRejectBloodUnit_okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  

class InDonorPreDemoEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_DonorPreDemoEntry")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sal(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Sal'], 20, 'Sal was not visible')
        self.select_from_list_by_label(self.objects['BB_DonorPreDemoEntry_Sal'], self.d[r]['sal'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_name(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.d[r]['name'] = "RAMCHARAN GEETHA"
        self.dict['DNAME'] = self.d[r]['name']
        print str(self.dict['DNAME'])
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_DonorName'], 20, 'Name was not visible')
        self.input_text(self.objects['BB_DonorPreDemoEntry_DonorName'], self.d[r]['name'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gender(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Gender'], 20, 'gender was not visible')
        self.select_from_list_by_label(self.objects['BB_DonorPreDemoEntry_Gender'], self.d[r]['gender'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_age(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Age'], 20, 'Age was not visible')
        self.input_text(self.objects['BB_DonorPreDemoEntry_Age'], str(self.d[r]['age']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_city(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_City'], 30, 'city was not visible')
        self.click_element(self.objects['BB_DonorPreDemoEntry_City'])
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_CityTextField'], 30, "city input field was not visible")
        self.input_text(self.objects['BB_DonorPreDemoEntry_CityTextField'], self.d[r]['city'])
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[1]//span[text()="'+self.d[r]['city']+'"]', 30, "searched city was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//li[1]//span[text()="'+self.d[r]['city']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_address(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Address'], 20, 'address was not visible')
        self.input_text(self.objects['BB_DonorPreDemoEntry_Address'], self.d[r]['address'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_mobileno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.d[r]['mobileno'] = self.dict['DONORPREDEMOMOBILENO']
        self.dict['DONORPREDEMOMOBILENO'] = "9005621"+str(randint(100,999))
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Mobile'], 20, 'mobile was not visible')
        self.input_text(self.objects['BB_DonorPreDemoEntry_Mobile'], str(self.dict['DONORPREDEMOMOBILENO']))
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DonorPreDemoEntry_Savebtn"], 20, "save btn was not enabled")
        self.click_button(self.objects["BB_DonorPreDemoEntry_Savebtn"])
        self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_DonorPreDemoEntry_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_DonorPreDemoEntry_Message'])
        print "Msg    :", Msg
        print "donor reg no:  ", Msg[53:]
        self.dict['DREGNO'] = Msg[53:]
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_DonorPreDemoEntry_Okbtn"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_DonorPreDemoEntry_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser() 
        
class InPreDonorQuestionnaire(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_PreDonorQuestionnaire")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()         
    def selecting_gobtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_Gobtn"], 30, "Go btn was not enable")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_Gobtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def searching_mobileno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['DONORPREDEMOMOBILENO'] = "9995621"+str(randint(100,999))
        #self.dict['DONORPREDEMOMOBILENO'] = "9965465400"
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_SearchText'], 20, 'searchbox was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_SearchText'], str(self.dict['DONORPREDEMOMOBILENO']))
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser() 
    def entering_into_donorevaluationpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddataSearch"]//td[text()="'+str(self.dict['DONORPREDEMOMOBILENO'])+'"]/..//td[2]/a', 30, "patient details not visible in grid")
        self.click_element('xpath=//*[@id="tblLoaddataSearch"]//td[text()="'+str(self.dict['DONORPREDEMOMOBILENO'])+'"]/..//td[2]/a')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_donortestdetails(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        for i in range(1, 12):
          try:
            i = str(i)
            self.click_element('xpath=(//*[@id="tblLoaddata"]//td[4]//input)['+i+']')
            self.wait_until_element_is_visible('xpath=(//*[@name="txtValue"])['+i+']', 30, "result value was not visible")
            self.input_text('xpath=(//*[@name="txtValue"])['+i+']', str(randint(10,99)))
            self.wait_until_element_is_visible('xpath=(//*[@name="txtDescription"])['+i+']', 30, "description was not visible")
            self.input_text('xpath=(//*[@name="txtDescription"])['+i+']', "Not Applicable")              
          except ValueError:
            break
          else:
            i = int(i)
            i = i + 1
        self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_Weight'], 20, 'weight was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_Weight'], str(self.d[r]['weight']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_hb(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_HB'], 20, 'HB was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_HB'], str(self.d[r]['hb']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_systolic(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_Systolic'], 20, 'Systolic was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_Systolic'], str(self.d[r]['systolic']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_diastolic(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_Diastolic'], 20, 'diastolic was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_Diastolic'], str(self.d[r]['diastolic']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_pulse(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_Pulse'], 20, 'pulse was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_Pulse'], str(self.d[r]['pulse']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_bodytemp(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_BodyTemp'], 20, 'bodytemp was not visible')
        self.input_text(self.objects['BB_PreDonorQuestionnaire_BodyTemp'], str(self.d[r]['bodytemp']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_healthcondition(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_HealthCondition'], 20, 'healthcondition was not visible')
        self.select_from_list_by_label(self.objects['BB_PreDonorQuestionnaire_HealthCondition'], self.d[r]['healthcondition'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_phlebotomy(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_PreDonorQuestionnaire_Phlebotomyskin'], 20, 'phlebotomy was not visible')
        self.select_from_list_by_label(self.objects['BB_PreDonorQuestionnaire_Phlebotomyskin'], self.d[r]['phlebotomy'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_acceptbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_Acceptbtn"], 20, "accept btn was not enabled")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_Acceptbtn"])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_permanentdeferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_PermanentDeferbtn"], 20, "permanent defer btn was not enabled")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_PermanentDeferbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_permanentdeferyesbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["BB_PreDonorQuestionnaire_PermanentDeferYesBtn"], 20, "permanent defer yes btn was not enabled")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_PermanentDeferYesBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_temporarydeferbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferBtn"], 20, "temporary defer btn was not enabled")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferBtn"])
        self.dict['BROWSER'] = self._current_browser()   
    def entering_temporarydeferdays(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.wait_until_page_contains_element(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferDays"], 20, "temporary defer days was not enabled")
        self.input_text(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferDays"], str(self.d[r]['deferdays']))
        time.sleep(0.5)
        self.dict['BROWSER'] = self._current_browser()
    def entering_temporarydeferremarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferRemarks"], 20, "temporary defer remarks was not enabled")
        self.input_text(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferRemarks"],self.d[r]['deferremarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_temporarydeferclosebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferClosebtn"], 30, "close btn was not visible")
        self.click_element(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferClosebtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_temporarydeferyesbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferYesBtn"], 30, "yes btn was not visible in page")
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferYesBtn"], 30, "yes btn was not visible")
        self.click_element(self.objects["BB_PreDonorQuestionnaire_TemporaryDeferYesBtn"])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_page_contains_element(self.objects['BB_PreDonorQuestionnaire_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_PreDonorQuestionnaire_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_Okbtn"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_acceptbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_PreDonorQuestionnaire_Acceptbtn"], 30, "accept btn was not enabled")
        self.click_button(self.objects["BB_PreDonorQuestionnaire_Acceptbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()           
     

class InRepeatRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("BB_RepeatRegistration")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_donorregno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['BB_RepeatRegistration_DonorRegno'], 15, 'donor regno was not visible')
         #self.dict['DREGNO'] = "2152"
         self.input_text(self.objects['BB_RepeatRegistration_DonorRegno'],str(self.dict['DREGNO']))
         self._cache.current = self.dict['BROWSER']
    def selecting_gobtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['BB_RepeatRegistration_Gobtn'], 30, 'Go btn was not enabled')
         self.click_button(self.objects['BB_RepeatRegistration_Gobtn'])
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def entering_into_repeatregistrationscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td/a[text()="'+str(self.dict['DREGNO'])+'"]', 10, "donor regno was not visible in grid")
        self.click_element('xpath=//*[@id="tblLoaddata"]//td/a[text()="'+str(self.dict['DREGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_blooddonatestatus(self,status):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        status = str(status)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_BloodDonateStatus'], 10, 'blood donate status was not visible')
        self.select_from_list_by_label(self.objects['BB_RepeatRegistration_BloodDonateStatus'],status)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_Remarks'], 20, 'Remarks was not visible')
        self.input_text(self.objects['BB_RepeatRegistration_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_result(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_Result'], 20, 'Result was not visible')
        self.input_text(self.objects['BB_RepeatRegistration_Result'], str(self.d[r]['result']))
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects['BB_RepeatRegistration_Savebtn'], 30, 'Save btn was not enabled')
         self.click_button(self.objects['BB_RepeatRegistration_Savebtn'])
         self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_Weight'], 10, "weight was not visible")
        self.input_text(self.objects['BB_RepeatRegistration_Weight'], str(self.d[r]['weight']))
        self.dict['BROWSER'] = self._current_browser()     
    def entering_bloodpressure(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_BloodPressure'], 10, "blood pressure was not visible")
        self.input_text(self.objects['BB_RepeatRegistration_BloodPressure'], str(self.d[r]['bp']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodbagtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_BloodBagType'], 10, "bloodbagtype was not visible")
        self.select_from_list_by_index(self.objects['BB_RepeatRegistration_BloodBagType'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_donortype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_DonorType'], 10, "donor type was not visible")
        self.select_from_list_by_index(self.objects['BB_RepeatRegistration_DonorType'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodunitno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs504']
        if (str(ctrlvalue) == '1'):
            self.dict['BLOODUNITNO'] = "3"+str(randint(100,999))
            self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_BloodUnitNo'], 10, "blood unit no was not visible")
            self.input_text(self.objects['BB_RepeatRegistration_BloodUnitNo'],str(self.dict['BLOODUNITNO']))
        else:
            print "Bloodunitno. was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_bloodcomponent(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_RepeatRegistration_ComponentName'], 10, "component name was not visible")
        self.select_from_list_by_label(self.objects['BB_RepeatRegistration_ComponentName'], self.d[r]['componentname'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponentaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_RepeatRegistration_ComponentAddbtn'], 10, "component addbtn was not visible")
        self.click_button(self.objects['BB_RepeatRegistration_ComponentAddbtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_page_contains_element(self.objects['BB_RepeatRegistration_Message'], 30, 'Message was not visible')
        Msg = self._get_text(self.objects['BB_RepeatRegistration_Message'])
        print "Msg    :", Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_RepeatRegistration_Okbtn"], 30, "OK btn was not visible")
        self.click_button(self.objects["BB_RepeatRegistration_Okbtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser() 
    
        
'''FromConfigFile().driving_browser_and_url()
Capturing().backbone_objects()
Capturing().data_off("BB_MainScreening")
FromConfigFile().logging("bloodbank")
FromConfigFile().loading_menu_of_link('//BloodBank/ScreenTestEntryDonorSearch.aspx')
r = 1
InMainScreening().screenshotonfailure()
InMainScreening().selecting_the_frame()
InMainScreening().entering_bloodunitno()
InMainScreening().selecting_gobtn()
InMainScreening().selecting_donorregnofromgrid()
InMainScreening().selecting_bloodgroup(r)
InMainScreening().selecting_rhtype(r)
InMainScreening().get_resulttablesize()
InMainScreening().selecting_savebtn()
InMainScreening().getting_message()
InMainScreening().unselecting_the_frame()
FromConfigFile().Logoff()'''
        
'''FromConfigFile().driving_browser_and_url()
FromConfigFile().zoom_out_page('5')
FromConfigFile().logging('bloodbank')    
FromConfigFile().loading_menu_of_link('//BloodBank/BloodConversion.aspx')
InConvertWBToComponents().screenshotonfailure()
InConvertWBToComponents().selecting_the_frame()
InConvertWBToComponents().searching_unitno()
InConvertWBToComponents().selecting_unitnofromgrid()
InConvertWBToComponents().entering_componentqty('1')
InConvertWBToComponents().entering_ml('1')
InConvertWBToComponents().selecting_updatebtn()
InConvertWBToComponents().getting_message()
InConvertWBToComponents().selecting_okbtn()
InConvertWBToComponents().unselecting_the_frame()
FromConfigFile().Logoff()'''


'''class InBloodCollection(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("BB_BloodCollection")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()    
    def collectionstartdate(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def collectionenddate(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def pvcbagexpirydate(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    
    def donorleftbloodbankdate(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[text()="'+day+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
    
    
    
    def entering_donorregno(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['DREGNO'] = "2159"
         self.wait_until_element_is_visible(self.objects['BB_BloodCollection_DonorRegno'], 30, 'donor regno. was not visible')
         self.input_text(self.objects['BB_BloodCollection_DonorRegno'],str(self.dict['DREGNO']))
         self.press_key(self.objects['BB_BloodCollection_DonorRegno'], '\\13')
         self._cache.current = self.dict['BROWSER']
    
    def selecting_collectionstarttime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_CollectionStartTime'], 10, "collection start time was not visible")
        self.click_element(self.objects['BB_BloodCollection_CollectionStartTime'])
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "start hour was not visible")
        self.click_element('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "start minute was not visible")
        self.click_element('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        self.dict['BROWSER'] = self._current_browser()
    
    
    def selecting_collectionendtime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_CollectionEndTime'], 10, "collection end time was not visible")
        self.click_element(self.objects['BB_BloodCollection_CollectionEndTime'])
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "end hour was not visible")
        self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        try:
          count = 0
          for i in range(1, 100):
              i = str(i)
              MinuteDisplayed = self._get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span['+i+']')
              if len(MinuteDisplayed)!=0:
                 print MinuteDisplayed
                 count = count + 1
                 i = int(i)
                 i = i + 1
        except ValueError:
                    print count
                    pass
        print "total number of test name:     ", count
        count = str(count)
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span['+count+']', 10, "active mins not visible")
        lastminutedisplayed = self._get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span['+count+']')
        print lastminutedisplayed
        try:
            self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]', 10, "active mins not visible")
            activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
            print activemins
            if lastminutedisplayed != activemins:
                self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]/following-sibling::span[1]')
                time.sleep(2)
            else:
                self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="next"]')
                self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
                self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        except:
                self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="next"]')
                self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
                self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')          
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_donorleftbbtime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_DonorLeftBBTime'], 10, "collection start time was not visible")
        self.click_element(self.objects['BB_BloodCollection_DonorLeftBBTime'])
        self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "start hour was not visible")
        self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "start minute was not visible")
        self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_bloodbagtype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_BloodBagType'], 10, "bloodbag type was not visible")
        self.select_from_list_by_index(self.objects['BB_BloodCollection_BloodBagType'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_donortype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_DonorType'], 10, "donor type was not visible")
        self.select_from_list_by_index(self.objects['BB_BloodCollection_DonorType'], '2')
        #self.click_element(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypecombo'])
        #self.input_text(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], self.d[r]['bb_prereg_screening_donortype'])
        #self.press_key(self.objects['BB_PreRegistrationScreening_redirectscreen_donortypetext'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_segmentno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_SegmentNo'], 10, "segment no was not visible")
        #self.input_text(self.objects['BB_BloodCollection_SegmentNo'], str(self.d[r]['segmentno']))
        self.input_text(self.objects['BB_BloodCollection_SegmentNo'], str(randint(100,999)))
        self.press_key(self.objects['BB_BloodCollection_SegmentNo'], '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def entering_batchno(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_BatchNo'], 10, "batch no was not visible")
        self.input_text(self.objects['BB_BloodCollection_BatchNo'], str(self.d[r]['batchno']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_pvcbagexpiry(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_PVCBagExpiry'], 10, "pvc bag expiry was not visible")
        loc = self.objects['BB_BloodCollection_PVCBagExpiry']
        date = self.d[r]['pvcbagexpiry']
        self.pvcbagexpirydate(loc, date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_adequatevolume(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_AdequateVolume'], 10, "adequatevolume was not visible")
        self.select_from_list_by_label(self.objects['BB_BloodCollection_AdequateVolume'], self.d[r]['adequatevolume'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_donorreaction(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_DonorReaction'], 10, "donorreaction was not visible")
        self.select_from_list_by_label(self.objects['BB_BloodCollection_DonorReaction'], self.d[r]['donorreaction'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponent(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_ComponentName'], 10, "component name was not visible")
        self.select_from_list_by_label(self.objects['BB_BloodCollection_ComponentName'], self.d[r]['componentname'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bloodcomponentaddbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_BloodCollection_ComponentAddbtn'], 10, "component addbtn was not visible")
        self.click_button(self.objects['BB_BloodCollection_ComponentAddbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodcollectionstartdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_CollectionStartDate'], 10, "collection start date was not visible")
        loc = self.objects['BB_BloodCollection_CollectionStartDate']
        date = self.d[r]['collectionstartdate']
        self.collectionstartdate(loc, date)
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodcollectionenddate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_CollectionEndDate'], 10, "collection end date was not visible")
        loc = self.objects['BB_BloodCollection_CollectionEndDate']
        date = self.d[r]['collectionenddate']
        self.collectionenddate(loc, date)
        self.dict['BROWSER'] = self._current_browser()    
    
    def entering_donorleftbloodbankdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_DonorLeftBBDate'], 10, "donorleft bloodbank date was not visible")
        loc = self.objects['BB_BloodCollection_DonorLeftBBDate']
        date = self.d[r]['donorleftbbdate']
        self.donorleftbloodbankdate(loc, date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_BloodCollection_Savebtn'], 20, 'save btn was not visible')
        self.click_button(self.objects['BB_BloodCollection_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_BloodCollection_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['BB_BloodCollection_Message'])
        print "Message:    ", self.msg
        self.dict['DREGNO'] = self.msg[53:]
        print "donor reg no: ", self.dict['DREGNO']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects["BB_BloodCollection_OkBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["BB_BloodCollection_OkBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()'''
class InConvertWBToComponent(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("BB_PreDonorReg")
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def searching_donorname(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.dict['DNAME'] = "GURU"
         self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_Searchbox'], 30, 'search box was not visible')
         self.input_text(self.objects['BB_WBToComponentConvert_Searchbox'],str(self.dict['DNAME']))
         time.sleep(2)
         self._cache.current = self.dict['BROWSER']
    def selecting_donordetailsfromgrid(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.wait_until_element_is_visible('xpath=//*[@id="tblLoaddata"]//td[contains(text(),"'+str(self.dict['DNAME'])+'")]/..//td[1]/a', 30, 'donor name was not in grid')
         #self.click_link('xpath=//*[@id="tblLoaddata"]//td[contains(text(),"'+str(self.dict['DNAME'])+'")]/..//td[1]/a')
         
         self.wait_until_page_contains_element('xpath=//*[@id="tblLoaddata"]//a', 30, 'donor name was not in grid')
         self.click_element('xpath=//*[@id="tblLoaddata"]//a')
         self._cache.current = self.dict['BROWSER'] 
    def entering_componentandmlqty(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_ComponentQty_First'], 30, 'first component qty was not visible')
         #self.input_text(self.objects['BB_WBToComponentConvert_ComponentQty_First'],"1")
         for i in range(1,3):
            i = str(i)
            self.wait_until_page_contains_element('xpath=//*[@id="txtBldConversion'+i+'"]', 30, 'component qty was not visible')
            self.click_element('xpath=//*[@id="txtBldConversion'+i+'"]')
            self.clear_element_text('xpath=//*[@id="txtBldConversion'+i+'"]')
            self.input_text('xpath=//*[@id="txtBldConversion'+i+'"]', "1")
            self.wait_until_element_is_visible('xpath=//*[@id="txtQty'+i+'"]', 20, "ml qty was not visible")
            self.input_text('xpath=//*[@id="txtQty'+i+'"]', "150")
            i = int(i)
            i = i + 1
         time.sleep(10)
         self._cache.current = self.dict['BROWSER']
    def entering_secondcomponentqty(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_ComponentQty_Second'], 30, 'first component qty was not visible')
         self.input_text(self.objects['BB_WBToComponentConvert_ComponentQty_Second'],"1")
         self._cache.current = self.dict['BROWSER']
    def entering_firstml(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_ML_First'], 30, 'first ml qty was not visible')
         self.input_text(self.objects['BB_WBToComponentConvert_ML_First'],"100")
         self._cache.current = self.dict['BROWSER']
    def entering_secondml(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_ML_Second'], 30, 'second ml qty was not visible')
         self.input_text(self.objects['BB_WBToComponentConvert_ML_Second'],"150")
         self._cache.current = self.dict['BROWSER']
    def selecting_updatebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['BB_WBToComponentConvert_Updatebtn'], 20, 'update btn was not enabled')
        self.click_button(self.objects['BB_WBToComponentConvert_Updatebtn'])
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['BB_WBToComponentConvert_Message'], 40, 'Record was not saved')
        self.msg = self._get_text(self.objects['BB_WBToComponentConvert_Message'])
        print "Message:    ", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_okbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.wait_until_element_is_enabled(self.objects["BB_WBToComponentConvert_OkBtn"], 30, "ok btn was not enabled")
        self.click_button(self.objects["BB_WBToComponentConvert_OkBtn"])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()