import sys
from Selenium2Library import Selenium2Library
from _ast import If
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
import pandas as pd

class Validation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("field_data")
   
    def in_fo_name(self,r):
        r = int (r)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['FO_MainFrame'])
        time.sleep(2)          
        self.select_from_list_by_label(self.objects['FO_NewRegistration_Dept'], self.d[1]['department'])
        d = Capturing().data_off("field_data1")
        
     
     
#         
#         list1=[]
#         list2=[]
#         for i in range(1,8):
#             print (i)
#             print self.d[1][i]
#             print "passed input"
#             self.input_text(self.objects['FO_NewRegistration_Name'], str(self.d[1][i]))
#            
#     
#             
#             a=self.d[1][i]
#             list1.append(a)
#             b=self.get_value(self.objects['FO_NewRegistration_Name'])
#             
#             list2.append(b)
#             print list2
#             df=pd.DataFrame({'list1':list1,'list2':list2})
#             df['Match']=df['list1']==df['list2']
#             df.to_excel(r'C:\Users\surya\Desktop\check\Bb_datas.xlsx',sheet_name="field_data1",index=False,rows=['list1','Match'])
#             #df.to_excel(r'D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx',sheet_name="field_data1",index=False,columns=['list1','list2','Match'])
#            
#             print "Observed input"
#             print (self.get_value(self.objects['FO_NewRegistration_Name']))
#             
#             self.clear_element_text(self.objects['FO_NewRegistration_Name'])
#             
#             
#             print (self.get_value(self.objects['FO_NewRegistration_Name']) )
#             
#             self.dict['BROWSER'] = self._current_browser() 
#            
#             
#             if a==b:
#                 print "PASS" 
#                 print "----------------------"
#                 
#             else:
#                 print "FAIL"
#                 print "----------------------"
#             
             
      
FromConfigFile().driving_browser_and_url()
Capturing().data_off("field_data")
r = 1
FromConfigFile().logging("frontoffice")
FromConfigFile().loading_menu_of_link('/FrontOfficeCS/tOPNewRegistration.aspx')
Validation().in_fo_name(r)

