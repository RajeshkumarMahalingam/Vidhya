import sys
from Selenium2Library import Selenium2Library
import pyautogui
from Tkconstants import CURRENT
#import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
#from lxml import etree
from datetime import date
#from pynput.keyboard import Key, Controller 

class InWardHome_AssignToBed(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        #self.dict['WARD-NAME']="AUTOMATIONCREDITWARD"
        self.wait_until_page_contains_element(self.objects['WARD_Select_Ward'], 100, 'Ward name was not visible')
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        #self.dict['IPNO'] = "IP00001634"
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 100, 'No ward search box present')
        self.click_element(self.objects['WARD_Search_Box'])
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 100, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_AssignToBed(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(9)
        if self._is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]'):
           self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[text()="Assign To Bed"]')
           try:
               self._handle_alert(True)
           except:
               pass
           #self.dict['AssgnToBed_Msg'] = self.get_alert_message()
           #print self.dict['AssgnToBed_Msg']
           self.dict['BROWSER'] = self._current_browser()
        else:
           pass 
        self.dict['BROWSER'] = self._current_browser()
        
    def clearing_ipnoinsearchbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 100, 'Search box was not visible')
        self.wait_until_page_contains_element(self.objects['WARD_Search_Box'], 100, 'Search box was not visible in page')
        #self.click_element(self.objects['WARD_Search_Box'])
        self.clear_element_text(self.objects['WARD_Search_Box'])
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()    
        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        
class InWardHome_WardOrders(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def InWardOrders_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(7)
        self.select_frame(self.objects['WARD_MainFrame'])        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(7)
        #time.sleep(7) #Release server
        #self.dict['WARD-NAME']="AUTOMATIONCREDITWARD"
        time.sleep(3)#Release server
        #print self.dict['WARD-NAME']
        self.wait_until_element_is_visible(self.objects['WARD_Select_Ward'], 100, 'ward drop down list was not present') #release server
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "IP00002338"
        #self.dict['IPNO']= "IP13371"
        time.sleep(7)
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 100, 'No ward search box present')
        self.click_element(self.objects['WARD_Search_Box'])
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 100, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardorders_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]', 100, "order icon was not visible")
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_OrdersTab(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(15)
        time.sleep(10)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        if self._is_visible('xpath=//*[@id="select2-drop"]//./input'):
           self.click_element('xpath=//*[@id="select2-drop"]//./input')
           #self.input_text('xpath=//*[@id="select2-drop"]//./input', "test")
           self.press_key('xpath=//*[@id="select2-drop"]//./input', '\\09')
        else:
           pass
        #if self._is_visible('xpath=//*[@id="select2-results-1"]//li'):
        #   self.press_key('xpath=//*[@id="select2-results-1"]//li', '\\09')
        #else:
        #   pass
        #time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select2_Lab"]/a', 200, 'Order Page is not loaded')        
        self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['BROWSER'] = self._current_browser()
    def adding_diet_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
    def adding_cardiology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #time.sleep(2)
        #self.d[r]['card_service'] = "ECG - ECG"
        #self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        #self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.d[r]['card_service']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        #time.sleep(1) 
        #self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['card_service'])+'")]')
        #time.sleep(3)
        #self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        #self.dict['BROWSER'] = self._current_browser()
        time.sleep(2)
        #self.d[r]['card_service'] = "Brain ECG updated"
        #self.wait_until_page_contains_element('xpath=//*[@id="s2id_select2_Lab"]/a', 10, "order service tab was not visible")
        #self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['CARDIOLOGY_SERVICE']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]', 100, "searched card service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['RADIOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]', 100, "searched rad service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
        
    def adding_lab_glucometer_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_GLUCOMETER_SERVICE'] = self.d[r]['Lab_glucometer_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_GLUCOMETER_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_GLUCOMETER_SERVICE'])+'")]', 100, "searched service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_GLUCOMETER_SERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_standard_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_STANDARD_SERVICE'] = self.d[r]['Lab_standard_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_STANDARD_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_STANDARD_SERVICE'])+'")]', 100, "searched lab std service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_STANDARD_SERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_CULTURE_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 100, "culture service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_PATHOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]', 100, "pathology service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]')        #time.sleep(3)
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        #self.d[r]['bloodbank_service'] = "Whole blood Charges"
        self.dict['BLOODBANKSERVICE'] = self.d[r]['bloodbank_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODBANKSERVICE']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]', 100, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_componentservice(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.dict['BLOODCOMPONENTNAME'] = self.d[r]['bloodcomponent_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODCOMPONENTNAME'])) #This dict value is assigned from the function (getting_conversioncomponentname) in bloodbank module 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODCOMPONENTNAME'])+'")]', 100, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODCOMPONENTNAME'])+'")]')
        self.wait_until_element_is_visible('xpath=//div[@class="toast-message"]', 100, "service added successfully message was not visible")
        Msg = self.get_text('xpath=//div[@class="toast-message"]')
        print Msg
        if Msg == "Added Successfully":
           print "services added successfully before clicking on save btn"
           pass
        else:
            raise AssertionError ("Service orders are not added successfully")
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')        
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_meds_tab(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        self.select_frame(self.objects['WARD_MainFrame'])        
        self.wait_until_element_is_visible(self.objects['WARD_Orders_MedsTab'], 100, 'Med Tab is not selected')
        #time.sleep(3)
        self.click_element(self.objects['WARD_Orders_MedsTab'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()

    def selecting_medicine(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['WARD_Meds_Select'], 100, 'Not Found')
        self.click_element(self.objects['WARD_Meds_Select'])
        self.wait_until_element_is_visible(self.objects["WARD_Meds_Txtbox"], 100, "item text box was not visible")
        itemname = re.findall(r'\w+', self.d[r]["Med_1"])
        itemname = " ".join(itemname)
        self.input_text(self.objects["WARD_Meds_Txtbox"], itemname)
        self.wait_until_element_is_visible(self.objects["WARD_Meds_Medicine"])
        self.click_element(self.objects["WARD_Meds_Medicine"])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_meds_dispqty(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects["WARD_Meds_DispenseQty"], 100,"add button was not visible")
        self.clear_element_text(self.objects['WARD_Meds_DispenseQty'])
        self.input_text(self.objects['WARD_Meds_DispenseQty'], str(self.d[r]['Meds_1_DispQty']))
        self.dict['BROWSER'] = self._current_browser()
    
    def entering_meds_days(self,r):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(1)        
        self.wait_until_element_is_visible(self.objects["WARD_Meds_Days"], 100,"meds days was not visible")
        days = self.get_text(self.objects["WARD_Meds_Days"])
        print "days", days
        print type(days)
        if (str(days) == "0") or (str(days)==""):
           print "inside"
           self.clear_element_text(self.objects['WARD_Meds_Days'])    
           self.input_text(self.objects['WARD_Meds_Days'], str(self.d[r]['Meds_1_Days']))
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    
    
    def selecting_addbtn(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects["WARD_Meds_Medicine_addbtn"], 100,"add button was not visible")
        self.click_element(self.objects["WARD_Meds_Medicine_addbtn"])
        try:
            self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_meds_tab_savebtn(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100,"item text box was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//input')
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.wait_until_element_is_visible(self.objects["WARD_Meds_Medicine_savebtn"], 100,"Save button was not visible")
        self.click_element(self.objects["WARD_Meds_Medicine_savebtn"])
        self.wait_until_element_is_visible(self.objects['Ward_Pharmacy_Msg'], 100, 'Bill was not saved')
        Prescripmsg = self.get_text(self.objects['Ward_Pharmacy_Msg'])
        print(Prescripmsg)
        self.dict['BROWSER'] = self._current_browser()    
            
    def selecting_save_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_element_is_enabled(self.objects['WARD_Orders_Save'], 100, "save btn was not enabled")
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 100, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.Test_Results[(self.dict['Executed_Test_Name'])]['WardOrderMsg'] = self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()         
        
class InWardHome_DischargeIntimation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("WardHome_DischargeIntim")
    Test_Results = admin.FromConfigFile.Test_Results
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        self.select_frame(self.objects['WARD_MainFrame'])        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="DONTUSEAUTOMATIONWARD"
        #print self.dict['WARD-NAME']
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00002338"
        time.sleep(3)
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 100, 'No data present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimation_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_enabled('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//div[3]//div[2]//button[4]//span', 100, 'No data present')
        #self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button/span[@id="spnbtnOrder"]')
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//div[3]//div[2]//button[4]//span')
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintim_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_Discharge_Intimation_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeintimType(self,dischargetype):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.select_from_list_by_index(self.objects['WARD_Discharge_Intimation_Type'], '1')
        #self.click_element('xpath=//*[@id="cboDischargeType"]')
        time.sleep(5)
        self.wait_until_page_contains_element('xpath=//*[@id="cboDischargeType"]', 120, "discharge type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDischargeType"]', dischargetype)
        #seldischargetype = self.get_selected_list_label('xpath=//*[@id="cboDischargeType"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_save_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        try:
            self.wait_until_element_is_enabled(self.objects['WARD_Discharge_Intimation_Save'], 100, "save btn was not enabled")
            self.click_element(self.objects['WARD_Discharge_Intimation_Save'])
        except:
            self.wait_until_element_is_visible('xpath=//a[@data-action="incrementHour"]', 100, "increment hour was not visible")
            self.click_element('xpath=//a[@data-action="incrementHour"]')
            self.wait_until_element_is_visible('xpath=//*[@id="spnBedtype"]', 100, "bedtype in label section was not visible")
            self.click_element('xpath=//*[@id="spnBedtype"]')
            self.wait_until_element_is_enabled(self.objects['WARD_Discharge_Intimation_Save'], 100, "save btn was not enabled")
            self.click_element(self.objects['WARD_Discharge_Intimation_Save'])
        finally:
            self._handle_alert(True)
            self.wait_until_page_contains_element(self.objects['WARD_Discharge_Intimation_Message'], 100, 'Record was not saved')
            self.wait_until_element_is_visible(self.objects['WARD_Discharge_Intimation_Message'], 100, 'Record was not saved')
            self.dict['DischgIntimMsg'] = self._get_text(self.objects['WARD_Discharge_Intimation_Message'])
            print self.dict['DischgIntimMsg']
            self.Test_Results[(self.dict['Executed_Test_Name'])]['DischgIntimMsg'] = self.dict['DischgIntimMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser() 
class InDirectOrder(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    Test_Results = admin.FromConfigFile.Test_Results
     
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #self.dict['IPNO'] = '406'
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 100, 'ipno was not visible')
        self.wait_until_page_contains_element('xpath=//*[@id="txtIPno"]', 100, 'ipno was not visible')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnGo"]', 100, 'Go btn was not enabled')
        self.click_button('xpath=//*[@id="btnGo"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_directorderspage(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]', 100, "patient details not in grid")
        self.wait_until_page_contains_element('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]', 100, "patient details not in grid")
        self.click_element('xpath=//*[@id="patTableDirOrder"]//td[text()="'+self.dict['IPNO']+'"]/..//td[1]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_orderservices(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        print "1"
        self.wait_until_page_contains_element('xpath=//*[@id="s2id_select2_Lab"]/a', 100, "service name was not visible in page")
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select2_Lab"]/a', 100, "service name was not visible")
        self.click_element('xpath=//*[@id="s2id_select2_Lab"]/a')
        self.dict['BROWSER'] = self._current_browser()
    def adding_diet_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['diet_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['diet_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
    def adding_cardiology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['CARDIOLOGY_SERVICE'] = self.d[r]['card_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['CARDIOLOGY_SERVICE']))
        #self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['card_service']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]', 100, "searched card service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['CARDIOLOGY_SERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_radiology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['RADIOLOGY_SERVICE'] = self.d[r]['rad_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['RADIOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]', 100, "searched rad service was not visible") 
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['RADIOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_standard_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['Lab_standard_service']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]', 100, "searched lab std service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['Lab_standard_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_lab_culture_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_CULTURE_SERVICE'] = self.d[r]['Lab_culture_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_CULTURE_SERVICE']))
        time.sleep(1) 
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]', 100, "culture service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_CULTURE_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()    
    def adding_lab_pathology_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.dict['LAB_PATHOLOGY_SERVICE'] = self.d[r]['Lab_pathology_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.dict['LAB_PATHOLOGY_SERVICE']))
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]', 100, "pathology service list was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['LAB_PATHOLOGY_SERVICE'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_physiotherapy_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.input_text('xpath=//*[@id="s2id_autogen2_search"]', str(self.d[r]['physio_service']))
        time.sleep(1) 
        self.click_element('xpath=//span[contains(text(),"'+str(self.d[r]['physio_service'])+'")]')
        time.sleep(3)
        self.press_key('xpath=//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def adding_bloodbank_service(self, r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.dict['BLOODBANKSERVICE'] = self.d[r]['bloodbank_service']
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, "order service text field was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', str(self.dict['BLOODBANKSERVICE']))
        self.wait_until_element_is_visible('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]', 100, "searched bb service was not visible")
        self.click_element('xpath=//span[contains(text(),"'+str(self.dict['BLOODBANKSERVICE'])+'")]')
        time.sleep(2)
        self.press_key('xpath=//*[@id="select2-drop"]//input', '\\09')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.click_element(self.objects['WARD_Orders_Save'])
        self.wait_until_element_is_visible(self.objects['WARD_Orders_Message'], 100, 'Record was not saved')
        self.dict['WardOrderMsg'] = self._get_text(self.objects['WARD_Orders_Message'])
        print self.dict['WardOrderMsg']
        self.Test_Results[(self.dict['Executed_Test_Name'])]['WardDirectOrderMsg'] = self.dict['WardOrderMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()       
        
                     
class InWardDischarge(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    def InWardDisch_ScreenshotOnFailure(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(15)
        self.select_frame(self.objects['WARD_MainFrame'])        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
            self.click_element('xpath=//a[text()="Skip"]')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_IPNO(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.wait_until_page_contains_element('xpath=//*[@id="txtIPno"]', 100, 'ipno was not visible')
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 100, 'ipno was not visible')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_view_button(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="trdiscbo"][1]', 100, "patient details was not visible in page")
        self.wait_until_element_is_visible('xpath=//*[@id="trdiscbo"][1]', 100, "patient details was not visible")
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[text()="View "]', 100, "view button was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[text()="View "]')
        time.sleep(2)
        self.dict['BROWSER'] =  self._current_browser()   
    def selecting_discharge_checkbox(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000011184"
        self.wait_until_element_is_visible('xpath=//*[@id="trdiscbo"]/td[text()="'+str(self.dict['IPNO'])+'"]//..//span[3]', 100, 'patient was not visible in grid')
        self.click_element('xpath=//*[@id="trdiscbo"]/td[text()="'+str(self.dict['IPNO'])+'"]//..//span[3]')
        time.sleep(2)
        if self._is_visible('xpath=//*[@id="txtDelayRmks"]'):
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "due to billing")
            time.sleep(1)
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]/../..//div[2]/button[1]', 100, "delay remarks btn was not visible")
            self.click_button('xpath=//*[@id="txtDelayRmks"]/../..//div[2]/button[1]')
            time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()     
    def selecting_discharge_button(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnDischarge"]', 100, 'discharge btn was not enabled')
        self.click_button('xpath=//*[@id="btnDischarge"]')
        #time.sleep(1)
        self._handle_alert(True)
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]/div/div', 100, 'Message not received')
        self.dict['WardDischMsg'] = self._get_text('xpath=//*[@id="toast-container"]/div/div')
        print self.dict['WardDischMsg']
        self.Test_Results[(self.dict['Executed_Test_Name'])]['WardDischMsg'] = self.dict['WardDischMsg']
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InWardquicklinks(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_page_contains_element('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        #self.wait_until_element_is_visible('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        #self.wait_until_page_contains_element('xpath=(//*[@data-original-title="Click to view Patient Details"])[2]', 20, "entire home page was not refreshed properly")
        time.sleep(10)
        self.wait_until_page_contains_element(self.objects['WARD_Search_Box'], 100, "search box was not visible")
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        time.sleep(3)
        self.wait_until_page_contains_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 100, 'No patient gets viewed in home page')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_toviewpatientdetails(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        self.wait_until_page_contains_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i', 100, "ip patient was not visible")
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i', 100, "ip patient was not visible")
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        time.sleep(2)
        self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../..//*[@class="popOver1"]/i')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_quicklink(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_QuickLinks'], 100, 'Quick links was not visible')
        self.mouse_over(self.objects['WARD_QuickLinks'])
        time.sleep(2)
        self.click_element(self.objects['WARD_QuickLinks_Link'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physiorequest(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy'], 100, 'WARD_QuickLinks_Physiotherapy was not visible')
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physioframe(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy_Frame'], 100, 'Physio frame was not visible')
        self.select_frame(self.objects['WARD_QuickLinks_Physiotherapy_Frame'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_physio_diagnosis(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_page_contains_element(self.objects['WARD_QuickLinks_Physiotherapy_Physio'], 100, 'WARD_QuickLinks_Physiotherapy_Physio  was not visible')
        self.input_text(self.objects['WARD_QuickLinks_Physiotherapy_Physio'], "uft testing")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cboDoctor"]', 100, 'doctor name was not visible')
        self.click_element('xpath=//*[@id="s2id_cboDoctor"]')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', 100, 'doctor name was not visible')
        self.click_element('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]')
        time.sleep(1)
        self.input_text('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', "%%%")
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]/../..//li[2]//span', 30, "doctors name list was not visible")
        self.click_element('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]/../..//li[2]//span')
        #self.press_key('xpath=//*[@id="select2-results-2"]/li/../..//*[@id="s2id_autogen2_search"]', '\\09')
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_QuickLinks_Physiotherapy_Save'], 100, 'physio save btn was not visible')
        self.click_element(self.objects['WARD_QuickLinks_Physiotherapy_Save'])
        try:
         self._handle_alert(True)
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InBirthRegister(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_BirthReg')
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def dob_datepicker(self,loc, date):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        today = date.today()
        print today.strftime('%d/%B/%Y')
        #print date
        print "today", today
        print type(today)
        
        picdate = date
        print picdate.strftime('%d/%B/%Y')
        
        print "picdate", picdate
        print type(picdate)
        
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        #loc = 'xpath=//*[@id="txtRDt"]'
        self.click_element(loc)
        
        if picdate > today:        
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                self.wait_until_element_is_visible('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]', 10, "calender was not visible")
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')              
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="next"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="next"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
        else:
            while(True):
                #seldate = self.get_text('xpath=//*[@class="datepicker-switch"]')
                seldate = self.get_text('xpath=//*[@class="datepicker-days"]//th[@class="datepicker-switch"]')
                if pdate == seldate:
                    break
                else:
                    #self.click_element('xpath=//*[@class="prev"]')
                    self.click_element('xpath=//*[@class="datepicker-days"]//th[@class="prev"]')
            self.click_element('xpath=/html/body/div/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        time.sleep(3)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 100, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        #self.dict['IPNO'] = 'IP00002419'
        self.wait_until_element_is_visible('xpath=//*[@id="txtipregno"]', 100, 'ipno was not visible')
        self.click_element('xpath=//*[@id="txtipregno"]')
        self.input_text('xpath=//*[@id="txtipregno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtipregno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_babydob(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="txtRDt"]', 100, "baby dob date was not visible")
        self.click_element('xpath=//*[@id="txtRDt"]')
        print "1"
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@class="datepicker-days"]//td[@class="day"][text()="'+str(date.today())[8:]+'"]', 30, 'current date was not visible')
        '''html_content = self.dict['DRIVER'].page_source
        print "html content", html_content
        tree = etree.HTML(html_content)
        xpath_locator = '//*[@class="datepicker-days"]//td[@class="day"]'
        elements = tree.xpath(xpath_locator)
        element_count = len(elements)
        print "element_count", element_count'''
        #xpathcount = self.get_matching_xpath_count('//*[@class="datepicker-days"]//td[@class="day"]')
        #print "xpathcount", xpathcount
        self.click_element('xpath=//*[@class="datepicker-days"]//td[@class="day"][text()="'+str(date.today())[8:]+'"]') #this xpath helps to select current date FOR RELEASE SERVER
        time.sleep(2)
        print "2"
        #########################################################################################################
        #r = int(r)
        #time.sleep(1)
        #self.wait_until_page_contains_element('xpath=//*[@id="txtRDt"]', 30, "baby dob date was not visible")
        #self.click_element('xpath=//*[@id="txtRDt"]')
        #####self.click_element('xpath=(//*[@class="day"])[6]')
        #date = self.d[r]['birthregdate']
        #self.dob_datepicker('xpath=//*[@id="txtRDt"]', date)
        #########################################################################################################
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_babygeneraldocinfotab(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@href="#portlet_tab3"]', 100, 'baby gen&doc info tab was not enabled')
        self.click_element('xpath=//*[@href="#portlet_tab3"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_birthtype(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboBirthType"]', 100, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboBirthType"]', '1')
        self.dict['BROWSER'] = self._current_browser()
    def entering_nationality(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtNationality"]', 100, 'nationality was not visible')
        self.click_element('xpath=//*[@id="txtNationality"]')
        self.input_text('xpath=//*[@id="txtNationality"]', "Indian")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_religion(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboReligion"]', 100, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_weeksofpregnancy(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboWks"]', 100, 'baby gen&doc info tab was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboWks"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_consultunder(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctorattended"]', 100, 'consult under was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboDoctorattended"]', '2')
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_deliveredby(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDeldoc"]', 100, 'delivered by was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboDeldoc"]', '2')
        self.dict['BROWSER'] = self._current_browser()          
    def selecting_babyandparentdetailtab(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@href="#portlet_tab5"]', 100, 'baby & parent detail info tab was not enabled')
        self.click_element('xpath=//*[@href="#portlet_tab5"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_weight(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtWht"]', 100, 'weight was not visible')
        self.input_text('xpath=//*[@id="txtWht"]', "3")
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_maturity(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboMat"]', 100, 'Maturity was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMat"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_babygender(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboBabysex"]', 100, 'baby gender was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboBabysex"]', '2')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_calender(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtRDt"]', 100, 'calender was not enabled')
        self.click_element('xpath=//*[@id="txtRDt"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_fathername(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.press_key('xpath=//*[@id="txtRDt"]', '\\09')
        self.press_key('xpath=//*[@id="txtRDt"]', '\\09')
        self.wait_until_element_is_visible('xpath=//*[@id="txtFatherName"]', 100, 'father name was not visible')
        self.click_element('xpath=//*[@id="txtFatherName"]')
        self.input_text('xpath=//*[@id="txtFatherName"]', self.d[r]['fathername'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_ageatmarriage(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtmAge"]', 100, 'ageatmarriage was not visible')
        self.input_text('xpath=//*[@id="txtmAge"]', str(self.d[r]['ageatmarriage']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_motherqualification(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboMQual"]', 100, 'Mother qualification was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMQual"]', '2')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_motheroccupation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboMotherOccupation"]', 100, 'Mother occupation was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMotherOccupation"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_motherreligion(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboMReligion"]', 100, 'Mother religion was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboMReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_mothernationality(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtMNationality"]', 100, 'Mother nationality was not visible')
        self.input_text('xpath=//*[@id="txtMNationality"]', self.d[r]['mothernationality'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fatherqualification(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboFQual"]', 100, 'father qualification was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFQual"]', '2')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_fatheroccupation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboFatherOccupation"]', 100, 'Father occupation was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFatherOccupation"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fatherreligion(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboFReligion"]', 100, 'Father religion was not enabled')
        self.select_from_list_by_index('xpath=//*[@id="cboFReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_fathernationality(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtFNationality"]', 100, 'Father nationality was not visible')
        self.input_text('xpath=//*[@id="txtFNationality"]', self.d[r]['fathernationality'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//*[@id="btnSave"]', 100, 'save btn was not enabled')
        self.click_button('xpath=//*[@class="actions"]//*[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()   
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="toast-container"]', 100, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['BirthRegisterMsg'] = self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InBirthRegisterSentToCorporation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off('Ward_BirthReg')
    Test_Results = admin.FromConfigFile.Test_Results
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        self.select_frame(self.objects['WARD_MainFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_ipnoradiobtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="rdoIPno"]/..//span[3]', 100, 'ipno btn was not visible')
        self.click_element('xpath=//*[@id="rdoIPno"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.dict['IPNO'] = '406'
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPRegNO"]', 100, 'ipno was not visible')
        self.click_element('xpath=//*[@id="txtIPRegNO"]')
        self.input_text('xpath=//*[@id="txtIPRegNO"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPRegNO"]', '\\13')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblPatdata"]//label[@for="checkAll"]/span[3]', 100, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="tblPatdata"]//label[@for="checkAll"]/span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_internalrefno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtMRDno"]', 100, 'internal ref no was not visible')
        self.click_element('xpath=//*[@id="txtMRDno"]')
        self.input_text('xpath=//*[@id="txtMRDno"]', str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()
    def entering_corporationackno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtCorpAckno"]', 100, 'ack no was not visible')
        self.click_element('xpath=//*[@id="txtCorpAckno"]')
        self.input_text('xpath=//*[@id="txtCorpAckno"]', "ACK"+str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 100, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 100, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['BirthRegSenttoCorpMsg'] = self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InDeathRegistration(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_DeathReg')
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 100, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ipnoradiobtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000712"
        try:
          msg = self.get_text('xpath=//*[@class="toast-message"]')
          if msg == "Select IPNO OR OPNO Option":
             self.click_element('xpath=//button[@class="toast-close-button"]') 
        except:
            time.sleep(2)
        else:
            pass
        self.wait_until_element_is_visible('xpath=//*[@id="rdoip"]/..//span[3]', 100, "ipno radio btn was not visible")
        self.click_element('xpath=//*[@id="rdoip"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboipno"]', 100, "ipno dropdown was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboipno"]', self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_deathinfotab(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.wait_until_element_is_visible('xpath=//*[@href="#portlet_tab2"]', 100, "death info tab was not visible")
        self.click_element('xpath=//*[@href="#portlet_tab2"]')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_religion(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboReligion"]', 100, "religion was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboReligion"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_diagnosis(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtDiagnosis"]', 100, "diagnosis was not visible")
        self.input_text('xpath=//*[@id="txtDiagnosis"]', self.d[r]['diagnosis'])
        self.dict['BROWSER'] = self._current_browser()   
    def entering_causeofdeath(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtCauseofDeath"]', 100, "cause of death was not visible")
        self.input_text('xpath=//*[@id="txtCauseofDeath"]', self.d[r]['cause'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_declaredby(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDeclaredBy"]', 100, "declared by was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDeclaredBy"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 100, "savebtn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_page_contains_element('xpath=//*[@id="toast-container"]', 10, 'save message was not visible')
        #self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        #print self.msg
        self._handle_alert(True)
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 100, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['DeathRegMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InDeathRegistrationSentToCorp(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def searching_patientdetails(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13047"
        self.wait_until_element_is_enabled('xpath=//*[@id="tblPatdata_filter"]//input', 100, 'search box was not enabled')
        self.input_text('xpath=//*[@id="tblPatdata_filter"]//input', "IP "+str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="checkAll"]/..//span[3]', 100, 'checkbox all was not visible')
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()    
    def entering_corporationackno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="txtCorpAckno"]', 100, 'ack no was not visible')
        self.click_element('xpath=//*[@id="txtCorpAckno"]')
        self.input_text('xpath=//*[@id="txtCorpAckno"]', str(randint(100,999)))
        self.dict['BROWSER'] = self._current_browser()         
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 100, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 100, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@id="toast-container"]')
        print self.msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['DeathRegSentToCorp'] = self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(2)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tDeathCorpEntry.aspx")
InWardHome_AssignToBed().InAssgToBed_ScreenshotOnFailure()               
InWardHome_AssignToBed().selecting_the_frame()
InWardHome_AssignToBed().selecting_skip()
InWardHome_AssignToBed().selecting_wardname()
InWardHome_AssignToBed().entering_and_searching_registered_ipno()
InWardHome_AssignToBed().selecting_AssignToBed()
InWardHome_DischargeIntimation().screenshotonfailure()
InWardHome_DischargeIntimation().selecting_the_frame()
InWardHome_DischargeIntimation().selecting_skip()
InWardHome_DischargeIntimation().selecting_wardname()
InWardHome_DischargeIntimation().entering_and_searching_registered_ipno()
InWardHome_DischargeIntimation().selecting_dischargeintimation_button()
InWardHome_DischargeIntimation().selecting_dischargeintim_frame()
InWardHome_DischargeIntimation().selecting_dischargeintimType('1')
InWardHome_DischargeIntimation().selecting_save_button()
InDeathRegistration().screenshotonfailure()
InDeathRegistration().selecting_the_frame()
InDeathRegistration().selecting_newbtn()
InDeathRegistration().selecting_ipnoradiobtn()
InDeathRegistration().selecting_ipno()
InDeathRegistration().selecting_deathinfotab()
InDeathRegistration().selecting_religion()
InDeathRegistration().entering_diagnosis('1')
InDeathRegistration().entering_causeofdeath('1')
InDeathRegistration().selecting_declaredby()
InDeathRegistration().selecting_savebtn()
InDeathRegistration().getmessage_after_save()
InDeathRegistration().unselecting_the_frame()
InDeathRegistrationSentToCorp().screenshotonfailure()
InDeathRegistrationSentToCorp().selecting_the_frame()
InDeathRegistrationSentToCorp().searching_patientdetails()
InDeathRegistrationSentToCorp().selecting_allcheckbox()
InDeathRegistrationSentToCorp().entering_corporationackno()
InDeathRegistrationSentToCorp().selecting_savebtn()
InDeathRegistrationSentToCorp().getmessage_after_save()
InDeathRegistrationSentToCorp().unselecting_the_frame()'''
class InAccidentRegister(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off('Ward_AccidentReg')
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnNew"]', 100, 'new btn was not enabled')
        self.click_button('xpath=//*[@id="btnNew"]')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000712"
        time.sleep(15)
        self.wait_until_element_is_visible('xpath=//*[@id="txtSrch"]', 100, 'text search box was not enabled')
        self.wait_until_page_contains_element('xpath=//*[@id="txtSrch"]', 100, 'text search box was not enabled in page')
        self.input_text('xpath=//*[@id="txtSrch"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtSrch"]', '\\13')
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def entering_accidentplace(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="txtAccplace"]', 100, 'accident place was not visible')
        self.input_text('xpath=//*[@id="txtAccplace"]',self.d[r]['place'])
        self.dict['BROWSER'] = self._current_browser()
    #### Release server included below function###############################
    def entering_accidentnumber(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs501']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible('xpath=//*[@id="txtAcdno"]', 100, 'brought by was not visible')
            self.input_text('xpath=//*[@id="txtAcdno"]',"A2B000"+str(randint(100,999)))
        else:
            print "Accident number was not enabled in control panel settings"
        self.dict['BROWSER'] = self._current_browser()
    def entering_broughtby(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtBrghtname"]', 100, 'brought by was not visible')
        self.input_text('xpath=//*[@id="txtBrghtname"]',self.d[r]['broughtby'])
        self.dict['BROWSER'] = self._current_browser()   
        
    def selecting_relation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboRel"]', 100, 'relation was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboRel"]', '3')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_policeinfo(self,status):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboPcInf"]', 100, 'police info was not visible')
        self.select_from_list_by_label('xpath=//*[@id="cboPcInf"]', status)
        '''try:
            r = int(r)
          #self.select_from_list_by_label('xpath=//*[@id="cboPcInf"]', self.d[r]['policeinfo'])          
          msg = self.get_text('xpath=//*[@class="toast-message"]')
          if msg == "Select Police Station Name":
             self.click_element('xpath=//button[@class="toast-close-button"]')
        except:
          time.sleep(5)
        else:
            pass'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_policestationname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboPCname"]', 100, 'police station name was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboPCname"]', '3')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_attendingdoctor(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctorattend"]', 100, 'attending doctor was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cboDoctorattend"]', '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_opinionreserved(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="chkResv"]/..//span[3]', 100, 'opinion reserved was not visible')
        self.click_element('xpath=//*[@id="chkResv"]/..//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 100, 'save btn was not visible')
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        time.sleep(2)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()     
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'save message was not visible')
        self.msg = self.get_text('xpath=//*[@class="toast-message"]')
        print self.msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['AccidentRegMsg'] = self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InDischargeIntimationDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_DischargeDirect")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        self.select_frame(self.objects['WARD_MainFrame'])        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13062"
        self.wait_until_element_is_enabled('xpath=//*[@id="txtIPno"]', 100, 'text search box was not enabled')
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 100, 'Patient was not enabled')
        try:
          self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        except:
         try:
           self._handle_alert(True)
         except:
             time.sleep(2)
             self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        else:
          pass    
        self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargeType(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(3)
        self.wait_until_page_contains_element('xpath=//*[@id="cboDischargeType"]', 100, "discharge type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDischargeType"]', self.d[r]['dischargetype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 100, 'save btn was not visible')
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_un8til_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['DischargeIntimationDirectMsg'] = msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
#Discharge Intimation direct
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?Opt=6")
InDischargeIntimationDirect().screenshotonfailure()
InDischargeIntimationDirect().selecting_the_frame()
InDischargeIntimationDirect().entering_ipno()
InDischargeIntimationDirect().selecting_patientdetails()
InDischargeIntimationDirect().selecting_dischargeType('1')
InDischargeIntimationDirect().selecting_savebtn()
InDischargeIntimationDirect().unselecting_the_frame()
admin.FromConfigFile().Logoff()'''



class InCancelIntimation(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipnoinsearchbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000733"
        try:
           if self._is_visible('xpath=//*[@id="select2-drop"]//input'):
              self.click_element('xpath=//*[@id="select2-drop"]//input')
              self.press_key('xpath=//*[@id="select2-drop"]//input', '\\27')
           else:
               pass
        except:
           pass
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge_filter"]//input', 100, 'text search box was not enabled')
        self.input_text('xpath=//*[@id="tblDischarge_filter"]//input', str(self.dict['IPNO']))
        #self.press_key('xpath=//*[@id="tblDischarge_filter"]//input', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge"]//td[text()="'+str(self.dict['IPNO'])+'"]', 10, 'Patient was not enabled')
        #self.wait_until_element_is_visible('xpath=//*[@id="chkdis0"]/..//span[3]', 10, 'checkbox was not visible')
        self.wait_until_element_is_visible('xpath=//*[@name="chkdis"]', 100, 'checkbox was not visible')
        #self.click_element('xpath=//*[@id="chkdis0"]/..//span[3]')
        self.click_element('xpath=//*[@name="chkdis"]')
        time.sleep(1)
        ###################    Added below lines for release server   ###################################
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]', 100, "delay remarks was not displayed")
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "Not applicable")
            self.click_button('xpath=//button[@name="btnVOk"]')
        except:
            pass
        ################################################################################################      
        self.dict['BROWSER'] = self._current_browser()

    def selecting_cancelintimationbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        #self.wait_until_element_is_visible('xpath=//*[@id="tblDischarge"]//td[text()="'+str(self.dict['IPNO'])+'"]', 10, 'Patient was not enabled')
        self.wait_until_element_is_enabled('xpath=//*[@id="btnDischarge"]', 100, 'cancel intimation btn was not enabled')
        self.click_element('xpath=//*[@id="btnDischarge"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['CancelIntimationDirect'] = msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser        


#Cancel Discharge Intimation
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//ward/tDisCancel.aspx")
print "menu loaded"
InCancelIntimation().screenshotonfailure()
InCancelIntimation().selecting_the_frame()
InCancelIntimation().entering_ipnoinsearchbox()
InCancelIntimation().selecting_checkbox()
InCancelIntimation().selecting_cancelintimationbtn()
InCancelIntimation().unselecting_the_frame()'''


class InDirectBedTransfer(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13205"
        time.sleep(5)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 100, "ipno was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 100, 'Patient was not present')
        self.click_element('xpath=//*[@class="gradeX odd"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_ward(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'ward input text box was not visible')
        self.select_from_list_by_index('xpath=//*[@id="cbowardlist"]',"1")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allocatebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="rdoAlloc0"]/..//span[3]', 100, 'allocate btn was not visible')
        try:
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        except ElementClickInterceptedException:
          time.sleep(3)
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transferbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]', 100, 'transfer btn was not visible')
        self.click_button('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['DirectBedTransferMsg'] = msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser      

#Direct Bed Transfer
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?Opt=10&Bedtrans=0")
print "menu loaded"
InDirectBedTransfer().screenshotonfailure()
InDirectBedTransfer().selecting_the_frame()
InDirectBedTransfer().entering_ipno()
InDirectBedTransfer().selecting_patientdetails()
InDirectBedTransfer().selecting_ward()
InDirectBedTransfer().selecting_allocatebtn()
InDirectBedTransfer().selecting_transferbtn()
InDirectBedTransfer().unselecting_the_frame()'''

class InWardHomeBedTransfer(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_skip(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible('xpath=//a[text()="Skip"]'):
           self.click_element('xpath=//a[text()="Skip"]')
        else:
           pass        
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        #self.dict['WARD-NAME']="DONT USE AUTOMATION WARD"
        #print self.dict['WARD-NAME']
        self.wait_until_element_is_visible(self.objects['WARD_Select_Ward'], 100, 'Ward name was not visible')
        self.select_from_list_by_label(self.objects['WARD_Select_Ward'], self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()    
    def entering_and_searching_registered_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']= "Ip14305"
        time.sleep(7)
        self.wait_until_element_is_visible(self.objects['WARD_Search_Box'], 100, 'No data present')
        self.input_text(self.objects['WARD_Search_Box'], str(self.dict['IPNO']))
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]', 100, 'Patient not present')
        self.mouse_over('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bedtransferbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button[@title="BED TRANSFER"]', 25, 'bedtransfer btn was not present')
        try:
          self.click_element('xpath=//h5[(text()="'+str(self.dict['IPNO'])+'")]/../../../../div[3]/div[2]/button[@title="BED TRANSFER"]')
        except:
          self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardnewwindow_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_NewWindowFrame'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardforbedtransfer(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 100, 'ward input text box was not visible')
        #self.select_from_list_by_index('xpath=//*[@id="cbowardlist"]',"1")
        self.select_from_list_by_label('xpath=//*[@id="cbowardlist"]', self.dict['WARD-NAME'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allocatebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="rdoAlloc0"]/..//span[3]', 100, 'allocate btn was not visible')
        try:
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        except ElementClickInterceptedException:
          time.sleep(3)
          self.click_element('xpath=//*[@id="rdoAlloc0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transferbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]', 100, 'transfer btn was not visible')
        self.click_button('xpath=//*[@class="form-group pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['WardHomeBedTransferMsg'] = msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
#admin.FromConfigFile().loading_menu_of_link("//WARD/tBedAcknowledge.aspx")
#print "menu loaded"
InWardHomeBedTransfer().screenshotonfailure()
InWardHomeBedTransfer().selecting_the_frame()
InWardHomeBedTransfer().selecting_skip()
InWardHomeBedTransfer().selecting_wardname()
InWardHomeBedTransfer().entering_and_searching_registered_ipno()
InWardHomeBedTransfer().selecting_bedtransferbtn()
InWardHomeBedTransfer().selecting_wardnewwindow_frame()
InWardHomeBedTransfer().selecting_wardforbedtransfer()
InWardHomeBedTransfer().selecting_allocatebtn()
InWardHomeBedTransfer().selecting_transferbtn()
InWardHomeBedTransfer().unselecting_the_frame()'''

class InBedTransferAcknowledge(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="Ip14305"
        self.wait_until_element_is_visible('xpath=//*[@id="txtipno"]', 100, "ipno search was not visible")
        self.input_text('xpath=//*[@id="txtipno"]', str(self.dict['IPNO']))
        self.press_key('xpath=//*[@id="txtipno"]', '\\13')
        time.sleep(7)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_approvebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@title="Approve"]', 100, "approve btn was not visible")
        self.click_element('xpath=//*[@title="Approve"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['BedTransferAcknowledgeMsg'] = msg
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser  
         
#BED ACKNOWLDEGE
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(4)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tBedAcknowledge.aspx")
print "menu loaded"
InBedTransferAcknowledge().screenshotonfailure()
InBedTransferAcknowledge().selecting_the_frame()
InBedTransferAcknowledge().entering_ipno()
InBedTransferAcknowledge().selecting_approvebtn()
InBedTransferAcknowledge().unselecting_the_frame()'''

#ward:
#//*[@id="selWard"]

#checkbox
#//*[@id="tblBedclean"]//td[2][contains(text(),"Ip13033")]/preceding-sibling::td//span[3]

#employee
#//*[@id="tblBedclean"]//td[2][contains(text(),"Ip13033")]/following-sibling::td//select[@id="cboEmp"]

class InBedClean(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_wardname(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO']="0000009924"
        #self.dict['WARD-NAME']= "DONTUSEAUTOMATIONWARD"
        #self.dict['WARD-BEDNO'] = "AUTOBED62"
        self.wait_until_element_is_visible('xpath=//*[@id="selWard"]', 100, "ward name was not visible")
        self.select_from_list_by_label('xpath=//*[@id="selWard"]', self.dict['WARD-NAME'])
        time.sleep(2)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_bednointosearchbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean_filter"]//input[@type="search"]', 100, "search box was not visible")
        self.input_text('xpath=//*[@id="tblBedclean_filter"]//input[@type="search"]', str(self.dict['WARD-BEDNO']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/preceding-sibling::td//span[3]', 10, "checkbox was not visible")
        #self.click_element('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/preceding-sibling::td//span[3]')
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/preceding-sibling::td//span[3]', 100, "checkbox was not visible")
        self.click_element('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/preceding-sibling::td//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_employee(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/following-sibling::td//select[@id="cboEmp"]', 10, "employee was not visible")
        #self.select_from_list_by_index('xpath=//*[@id="tblBedclean"]//td[2][contains(text(),"'+str(self.dict['IPNO'])+'")]/following-sibling::td//select[@id="cboEmp"]', '2')
        self.wait_until_element_is_visible('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/following-sibling::td//select[@id="cboEmp"]', 100, "employee was not visible")
        self.select_from_list_by_index('xpath=//*[@id="tblBedclean"]//td[4][text()="'+str(self.dict['WARD-BEDNO'])+"   "'"]/following-sibling::td//select[@id="cboEmp"]', '2')
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_timedelayremarks(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="txtDelayRmks"]', 5, "delay remarks was not visible")
            self.click_element('xpath=//*[@id="txtDelayRmks"]')
            self.input_text('xpath=//*[@id="txtDelayRmks"]', "Not Applicable")
            self.wait_until_element_is_enabled('xpath=//*[@name="btnVOk"]', 100, "okbtn in timedelay remarks was not visible")
            self.click_button('xpath=//*[@name="btnVOk"]')
            time.sleep(1)
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()
    def selecting_cleanbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnSave"]', 100, "clean btn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        try:
          self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 100, 'Record was not saved')
          msg = self._get_text('xpath=//*[@class="toast-message"]')
          print "msg", msg
          self.Test_Results[(self.dict['Executed_Test_Name'])]['BedCleanMsg'] = msg
        except:
            pass
        self.dict['BROWSER'] =  self._current_browser()     
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

class InFumigationRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()        
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])        
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 100, "department was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDept"]','5' )
        self.dict['FumigationDeptName'] = self.get_selected_list_label('xpath=//*[@id="cboDept"]')
        print self.dict['FumigationDeptName']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigationreqbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnFumigation"]', 100, "fumigation btn was not enabled")
        self.click_button('xpath=//*[@id="btnFumigation"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigationreason(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]', 10, error)
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_page_contains_element('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', 30, "Fumigation reason was not visible")
        self.select_from_list_by_index('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', '1')
        #time.sleep(1)
        #self.press_key('xpath=//*[@style="display: block;"]//select[@id="cboFumReason"]', '\\09')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_preinfectiondetails(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]', 30, "pre-infection details was not visible")
        self.click_element('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]')
        self.input_text('xpath=//*[@style="display: block;"]//textarea[@id="txtPreinfection"]', "None")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//button[@id="btnfumSave"]', 30, "Save btn was not visible")
        self.click_button('xpath=//*[@style="display: block;"]//button[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['FumigationReqMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()   
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
#Fumigation Request        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//WARD/tFumigationDeptEntry.html")
print "menu loaded"
InFumigationRequest().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationRequest().selecting_the_frame()
InFumigationRequest().selecting_department()
InFumigationRequest().selecting_fumigationreqbtn()
InFumigationRequest().selecting_fumigationreason()
InFumigationRequest().entering_preinfectiondetails()
InFumigationRequest().selecting_savebtn()
InFumigationRequest().getmessage_after_save()
InFumigationRequest().unselecting_the_frame()'''

class InFumigationScheduleSearch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_FumigSchedSearch")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def reopendatepicker(self, loc, date):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(15)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        picdate = picdate.date()
        today = today.date()
        print "picdate", picdate
        print "today", today
        if (picdate > today) or (picdate == today):
            print "picdate>=today"       
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                print "pdate", pdate
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[@class="next"]')
            #self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day" or @class = "day active"][text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                print "picdate! >=today"  
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                print "exception occurs"
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded
        time.sleep(4)   
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['FumigationDeptName'] = "BIOCHEMISTRY"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_fumigationschedulescreen(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+'"]')
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_typeoffumigation(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]', 10, error)
        #self.click_element('xpath=//*[@style="display: block;"]//h4[@id="fumWard"]')
        self.wait_until_page_contains_element('xpath=//*[@id="cboFumtype"]', 30, "fumigation type was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboFumtype"]', '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reopendate(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)        
        #date = self.d[r]['reopendate']
        self.wait_until_page_contains_element('xpath=//*[@id="txtReopenDt"]', 30, "fumigation reopen date was not visible")
        #self.reopendatepicker('xpath=//*[@id="txtReopenDt"]', date)
        self.click_element('xpath=//*[@id="txtReopenDt"]')
        time.sleep(1)
        #self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class = "day active"]/following-sibling::td[3]')
        self.click_element('xpath=(//td[@class="day active"])[2]/../following-sibling::tr[1]/td[1]')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print activehrs
        self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print activemins
        self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        time.sleep(2)       
        self.dict['BROWSER'] = self._current_browser()
    def entering_approvedby(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="txtApprvby"]', 30, "approved by was not visible")
        self.input_text('xpath=//*[@id="txtApprvby"]', self.d[r]['approvedby'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="btnfumSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['FumigationScheduleSearchMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
#fumigation Schedule Search
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/Ward/tFumigationsearch.html")
print "menu loaded"
InFumigationScheduleSearch().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationScheduleSearch().screenshotonfailure()
InFumigationScheduleSearch().selecting_the_frame()
InFumigationScheduleSearch().selecting_department()
InFumigationScheduleSearch().entering_into_fumigationschedulescreen()
InFumigationScheduleSearch().selecting_typeoffumigation()
InFumigationScheduleSearch().selecting_reopendate('1')
InFumigationScheduleSearch().entering_approvedby('1')
InFumigationScheduleSearch().selecting_savebtn()
InFumigationScheduleSearch().getmessage_after_save()
InFumigationScheduleSearch().unselecting_the_frame()'''

class InFumigationEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_FumigEntry")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_fumigationentryscreen(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(6)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]', 60, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_precleaning(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboPreclean"]', 30, "pre-clean was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboPreclean"]','1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_fumigant(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboFumigant"]', 30, "fumigant was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboFumigant"]','1')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_fumigatedby(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtFumigantby"]', 30, "fumigatedBy was not visible")
        self.input_text('xpath=//*[@id="txtFumigantby"]',self.d[r]['fumigatedby'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtRmks"]', 30, "remarks was not visible")
        self.input_text('xpath=//*[@id="txtRmks"]',self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="btnfumSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnfumSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['FumigationEntryBeforePostInfecMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def entering_into_fumigationpostinfecscreen(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(10)
        self.wait_until_element_is_visible('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblFumigation"]//td[2][text()="'+self.dict['FumigationDeptName']+' "]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_postinfection(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtPostinfection"]', 30, "postinfection was not visible")
        self.input_text('xpath=//*[@id="txtPostinfection"]',self.d[r]['postinfection'])
        self.dict['BROWSER'] = self._current_browser() 
    def selecting_postinfecsavebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="form-group p-t-15 pull-right"]//button[@id="btnSave"]', 30, "post infec save btn was not visible")
        self.click_button('xpath=//*[@class="form-group p-t-15 pull-right"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
        
#Fumigation Entry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/WARD/tFumigationentry.html")
print "menu loaded"
InFumigationScheduleSearch().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationEntry().screenshotonfailure()
InFumigationEntry().selecting_the_frame()
InFumigationEntry().selecting_department()
InFumigationEntry().entering_into_fumigationentryscreen()
InFumigationEntry().selecting_precleaning()
InFumigationEntry().selecting_fumigant()
InFumigationEntry().entering_fumigatedby('1')
InFumigationEntry().entering_remarks('1')
InFumigationEntry().selecting_savebtn()
InFumigationEntry().getmessage_after_save()
InFumigationEntry().selecting_department()
InFumigationEntry().entering_into_fumigationpostinfecscreen()
InFumigationEntry().entering_postinfection('1')
InFumigationEntry().selecting_postinfecsavebtn()
InFumigationEntry().getmessage_after_save()
InFumigationEntry().unselecting_the_frame()'''

class InFumigationApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['FumigationDeptName'] = "ABCD"
        self.wait_until_element_is_visible('xpath=//*[@id="cboDept"]', 30, "department was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboDept"]',self.dict['FumigationDeptName'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkboxall(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="checkAll"]/..//span[3]', 30, "checkbox all was not visible")
        self.click_element('xpath=//*[@id="checkAll"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[@id="btnApprove"]', 30, "approve btn was not visible")
        self.click_button('xpath=//*[@class="pull-right"]//button[@id="btnApprove"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['FumigationApprovalMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#Fumigation Approval
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("Ward/tFumigationApprv.html")
print "menu loaded"
InFumigationApproval().screenshotonfailure()
admin.FromConfigFile().zoom_in_page(4)
InFumigationApproval().screenshotonfailure()
InFumigationApproval().selecting_the_frame()
InFumigationApproval().selecting_department()
InFumigationApproval().selecting_checkboxall()
InFumigationApproval().selecting_approvebtn()
InFumigationApproval().getmessage_after_save()
InFumigationApproval().unselecting_the_frame()'''

class InIncidentEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_IncidentEntry")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def incidentdatepicker(self, loc, date):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="next"]')
            #self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active" or @class="day" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active" or @class="day" and text()="'+day+'"]')            
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def notifieddatepicker(self, loc, date):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            #self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr[5]/td[text()="'+day+'"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="prev"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def reportingdatepicker(self, loc, date):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=//*[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day active" and text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 10, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 10, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
        
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00002836"
        self.wait_until_element_is_visible('xpath=//*[@id="txtEMPIP"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtEMPIP"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtEMPIP"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_newbtn(self):        
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_element_is_visible('xpath=//*[@id="btnNew"]', 30, "new btn was not visible")
        self.click_button('xpath=//*[@id="btnNew"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_incidenttype(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="cboInctype"]', 30, "incident type was not visible")
        self.select_from_list_by_label('xpath=//*[@id="cboInctype"]', self.d[r]['incidenttype'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_incidentdate(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #date = self.d[r]['incidentdate']
        # Below line commented and new line added to select current date bydefault and not from data sheet
        #self.incidentdatepicker('xpath=//*[@id="txtIncdate"]', date) 
        self.click_element('xpath=//*[@id="txtIncdate"]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-days"])[1]//td[@class="day today active"]', 30, "active day was not visible")
        self.click_element('xpath=(//*[@class="datetimepicker-days"])[1]//td[@class="day today active"]')
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]', 30, "active hrs not visible")
        #activehrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]')
        #print activehrs
        #self.click_element('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]')
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[1]//span[text()="0:00"]', 30, "0:00 hr not visible")
        activehrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[1]//span[text()="0:00"]')
        print activehrs
        self.click_element('xpath=(//*[@class="datetimepicker-hours"])[1]//span[text()="0:00"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute active"]')
        print activemins
        self.click_element('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute active"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_location(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboLocation"]', 30, "Location was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboLocation"]','2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nature(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboNature"]', 30, "Nature was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboNature"]','2')
        self.dict['BROWSER'] = self._current_browser()  
    def entering_descripofincident(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncdesc"]', 30, "incident description was not visible")
        self.input_text('xpath=//*[@id="txtIncdesc"]',self.d[r]['incidentdescription'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_harmresulted(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncresult"]', 30, "harm was not visible")
        self.input_text('xpath=//*[@id="txtIncresult"]',self.d[r]['harm'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_witness(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtIncwitness"]', 30, "witness was not visible")
        self.input_text('xpath=//*[@id="txtIncwitness"]',self.d[r]['witness'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_otherstext(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@id="txtNTOthers"]', 30, "witness was not visible")
        self.input_text('xpath=//*[@id="txtNTOthers"]',self.d[r]['otherstext'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_employee(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboEmployee"]', 30, "employee was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboEmployee"]','2')
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_notifieddate(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #date = self.d[r]['notifieddate']
        # Below line commented and new line added to select current date bydefault and not from data sheet
        #self.notifieddatepicker('xpath=//*[@id="txtIncNotifydt"]', date)
        self.click_element('xpath=//*[@id="txtIncNotifydt"]')
        time.sleep(2)
        #self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day active"]')
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-days"])[2]//td[@class="day active"]', 30, "active day was not visible")
        self.click_element('xpath=(//*[@class="datetimepicker-days"])[2]//td[@class="day active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]')
        print activehrs
        self.click_element('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]')
        print activemins
        self.click_element('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]')
        time.sleep(2)
        '''self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print activehrs
        self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print activemins
        self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        time.sleep(2)'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reportingdate(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #date = self.d[r]['reportingdate']
        # Below line commented and new line added to select current date bydefault and not from data sheet
        #self.reportingdatepicker('xpath=//*[@id="txtEmprptdt"]', date)
        self.click_element('xpath=//*[@id="txtEmprptdt"]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-days"])[3]//td[@class="day active"]', 30, "active day was not visible")
        self.click_element('xpath=(//*[@class="datetimepicker-days"])[3]//td[@class="day active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[3]//span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[3]//span[@class="hour active"]')
        print activehrs
        self.click_element('xpath=(//*[@class="datetimepicker-hours"])[3]//span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-minutes"])[3]//span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=(//*[@class="datetimepicker-minutes"])[3]//span[@class="minute active"]')
        print activemins
        self.click_element('xpath=(//*[@class="datetimepicker-minutes"])[3]//span[@class="minute active"]')
        time.sleep(2)
        '''self.click_element('xpath=/html/body/div[4]/div[3]/table/tbody/tr/td[@class="day active"]')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print activehrs
        self.click_element('xpath=/html/body/div[4]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print activemins
        self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        time.sleep(2) '''       
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        self._wait_alert()
        SavePopupMsg = self.get_alert_message(False)
        print SavePopupMsg
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['IncidentEntryMsg'] = self.msg
        except:
            print "Message not captured"
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
        
        
#Incident Entry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Nursing/tIncidentrpt.aspx")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InIncidentEntry().screenshotonfailure()
InIncidentEntry().selecting_the_frame()
InIncidentEntry().entering_ipno()
InIncidentEntry().selecting_incidentdate('1')
InIncidentEntry().selecting_location()
InIncidentEntry().selecting_nature()
InIncidentEntry().entering_descripofincident('1')
InIncidentEntry().entering_harmresulted('1')
InIncidentEntry().entering_witness('1')
InIncidentEntry().entering_otherstext('1')
InIncidentEntry().selecting_employee()
InIncidentEntry().selecting_notifieddate('1')
InIncidentEntry().selecting_reportingdate('1')
InIncidentEntry().selecting_savebtn()
InIncidentEntry().getmessage_after_save()
InIncidentEntry().unselecting_the_frame()'''

class InHandOverEntryNursing(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
        
        
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "503"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]', 30, "fumigation dept name was not visible")
        self.click_element('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(1)
        try:
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "Approval Pending":
               time.sleep(2)
            else:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingshift(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboShift"]', 30, "Nursing shift was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboShift"]','2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_handoverto(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_select_handoverTo"]/a', 30, "handover to was not visible")
        self.click_element('xpath=//*[@id="s2id_select_handoverTo"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//input', 30, "handoverto text was not visible")
        self.input_text('xpath=//*[@id="select2-drop"]//input', "%%%")
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//ul/li[2]', 30, "handoverto list was not visible")
        self.click_element('xpath=//*[@id="select2-drop"]//ul/li[2]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="chkListID0"]/..//span[3]', 30, "checkbox was not visible")
        self.click_element('xpath=//*[@id="chkListID0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled('xpath=//*[@class="actions"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@class="actions"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 10, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['HandOverEntryNursingMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#HandOverEntry
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("/Ward/Patsearch.html?opt=9")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InHandOverEntryNursing().screenshotonfailure()
InHandOverEntryNursing().selecting_the_frame()
InHandOverEntryNursing().entering_ipno()
InHandOverEntryNursing().selecting_patientdetails()
InHandOverEntryNursing().selecting_nursingshift()
InHandOverEntryNursing().selecting_handoverto()
InHandOverEntryNursing().selecting_checkbox()
InHandOverEntryNursing().selecting_handoverto()
InHandOverEntryNursing().selecting_savebtn()
InHandOverEntryNursing().getmessage_after_save()
InHandOverEntryNursing().unselecting_the_frame()'''      

class InEquipmentBilling(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    #d = Capturing().data_off("Ward_EquipBilling")
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def startdatepicker(self, loc):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(loc, 30, "start date field was not visible")
        self.click_element(loc)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[3]/table/tbody/tr/td[@class="day today active"]', 30, "current start date was not visible")
        self.click_element('xpath=/html/body/div[1]/div[3]/table/tbody/tr/td[@class="day today active"]')
        time.sleep(3)
        #self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]', 30, "hour 0:00 was not visible")
        #selectedhrs = self._get_text('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
        #self.click_element('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]', 30, "hour 0:00 was not visible")
        selectedhrs = self._get_text('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]')
        self.click_element('xpath=/html/body/div[1]/div[2]/table/tbody/tr/td/span[@class="hour active"]/preceding-sibling::span[1]')
        print "selectedhrs", selectedhrs
        time.sleep(3)
        #self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]', 30, "mins 0:00 was not visible")
        #selectedmins = self.get_text('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
        #self.click_element('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]', 30, "mins 0:00 was not visible")
        selectedmins = self.get_text('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]')
        self.click_element('xpath=/html/body/div[1]/div[1]/table/tbody/tr/td/span[@class="minute"][1]')
        print "selectedmins", selectedmins
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()   
    def enddatepicker(self, loc):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(loc, 30, "end date field was not visible")
        self.click_element(loc)
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active"]', 30, "current end date was not visible")
        self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day today active"]')
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]', 30, "hour 1:00 was not visible")
        #selectedhrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]')
        #self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[text()="1:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hour was not visible")
        selectedhrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print "selectedhrs", selectedhrs
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]', 30, "active mins was not visible")
        #selectedmins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]')
        #self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[text()="1:00"]')
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins was not visible")
        selectedmins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print "selectedmins", selectedmins
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser() 
   
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['EQUIPMENTBILLINGIPNO'] = "Ip13908"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPno"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPno"]',self.dict['EQUIPMENTBILLINGIPNO'])
        self.press_key('xpath=//*[@id="txtIPno"]', '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        self.wait_until_element_is_visible('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['EQUIPMENTBILLINGIPNO'])+'"]/..//td[1]', 10, "Patient details not in grid")
        self.click_element('xpath=//*[@id="tblNurseHandover"]//td[text()="'+str(self.dict['EQUIPMENTBILLINGIPNO'])+'"]/..//td[1]')
        time.sleep(1)
        '''try:
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "Approval Pending":
               time.sleep(2)
            else:
                pass
        except:
            pass'''
        self.dict['BROWSER'] = self._current_browser()
    def selecting_services(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboServices"]', 30, "services was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboServices"]','1')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_equipment(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboEquipment"]', 30, "equipment was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboEquipment"]','1')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_addbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="btnAdd"]', 30, "add btn was not visible")
        self.click_button('xpath=//*[@id="btnAdd"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_startdate(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ###############commented below lines for choosing curernt date automatically and not from excel sheet############
        ##r = int(r)
        #time.sleep(1)
        ##date = self.d[r]['startdate']
        #print "date", date
        #self.startdatepicker('xpath=//*[@id="txtSDt0"]')
        ##################################################################################################################
        self.wait_until_element_is_visible('xpath=//*[@id="txtSDt0"]', 30, "start date calender was not visible")
        self.click_element('xpath=//*[@id="txtSDt0"]')
        time.sleep(1)
        self.click_element('xpath=(//*[@class="datetimepicker-days"])[1]//td[@class="day today active"]')
        time.sleep(3)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]/preceding-sibling::span[1]', 30, "hour 0:00 was not visible")
        selectedhrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]/preceding-sibling::span[1]')
        self.click_element('xpath=(//*[@class="datetimepicker-hours"])[1]//span[@class="hour active"]/preceding-sibling::span[1]')
        print "selected start date hrs", selectedhrs
        time.sleep(3)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute"][1]', 30, "mins 0:00 was not visible")
        selectedmins = self.get_text('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute"][1]')
        self.click_element('xpath=(//*[@class="datetimepicker-minutes"])[1]//span[@class="minute"][1]')
        print "selected start date mins", selectedmins
        time.sleep(3)        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_startdatebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnSdate"]', 30, "start date btn was not visible")
        self.click_button('xpath=//*[@id="btnSdate"]')
        time.sleep(2)
        self._handle_alert(True)
        print "after alert"
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_enddate(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #################################### Commented below lines to fetch current date automatically and not from excel sheet##############
        #r = int(r)
        #time.sleep(1)
        #date = self.d[r]['enddate']
        #self.enddatepicker('xpath=//*[@id="txtEDt0"]')
        ##############################################################################################################################
        self.wait_until_element_is_visible('xpath=//*[@id="txtEDt0"]', 30, "end date calender was not visible")
        self.click_element('xpath=//*[@id="txtEDt0"]')
        time.sleep(1)
        self.click_element('xpath=(//*[@class="datetimepicker-days"])[2]//td[@class="day today active"]')
        time.sleep(3)        
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]', 30, "end date hour 0:00 was not visible")
        selectedhrs = self._get_text('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]')
        self.click_element('xpath=(//*[@class="datetimepicker-hours"])[2]//span[@class="hour active"]')
        print "selected end date hrs", selectedhrs
        time.sleep(3)
        self.wait_until_element_is_visible('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]', 30, "end date mins 0:00 was not visible")
        selectedmins = self.get_text('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]')
        self.click_element('xpath=(//*[@class="datetimepicker-minutes"])[2]//span[@class="minute active"]')
        print "selected end date mins", selectedmins
        time.sleep(3)        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_enddatebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnEdate"]', 30, "enddate btn was not visible")
        self.click_button('xpath=//*[@id="btnEdate"]')
        time.sleep(2)
        self._handle_alert(True)
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def getting_totalhrs_after_save(self):    
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_page_contains_element('xpath=//*[@id="lblTohrs0"]', 30, 'total hrs was not visible in page')
         self.wait_until_element_is_visible('xpath=//*[@id="lblTohrs0"]', 30, 'total hrs was not visible')
         self.msg = self.get_text('xpath=//*[@id="lblTohrs0"]')
         print "Total hrs:    ", self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
            
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_page_contains_element('xpath=//*[@class="toast-message"]', 30, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@class="toast-message"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['EquipmentBillingMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser

#EquipmentBilling
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?opt=12")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(2)
InEquipmentBilling().screenshotonfailure()
InEquipmentBilling().selecting_the_frame()
InEquipmentBilling().entering_ipno()
InEquipmentBilling().selecting_patientdetails()
InEquipmentBilling().selecting_services()
InEquipmentBilling().selecting_equipment()
InEquipmentBilling().selecting_addbtn()
InEquipmentBilling().selecting_startdate('1')
InEquipmentBilling().selecting_startdatebtn()
InEquipmentBilling().selecting_enddate('1')
InEquipmentBilling().selecting_enddatebtn()
InEquipmentBilling().getmessage_after_save()
InEquipmentBilling().unselecting_the_frame()'''

        
class InTemplateEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_TemplateEntry")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_newbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnNew"]', 30, "new btn was not visible")
        self.click_button('xpath=//*[@id="btnNew"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000739"
        self.wait_until_element_is_visible('xpath=//*[@id="txtSrch"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtSrch"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtSrch"]', '\\13')
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="toast-message"]', 7, "message was not visible")
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "No Existing Template Found":
               time.sleep(2)
            else:
                pass
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_template(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible('xpath=//*[@class="trTemphdr"]/td[text()="'+self.d[r]['templatename']+'"]', 30, "template name was not visible")
        self.click_element('xpath=//*[@class="trTemphdr"]/td[text()="'+self.d[r]['templatename']+'"]')
        time.sleep(10)
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@class="actions disAction"]//button[@id="btnSave"]', 30, "save btn was not visible")
        self.click_element('xpath=//*[@class="actions disAction"]//button[@id="btnSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['TemplateEntryMsg'] = self.msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 

#Template Entry        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Ward/Patsearch.html?opt=11")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(1)
InTemplateEntry().screenshotonfailure()
InTemplateEntry().selecting_the_frame()
InTemplateEntry().selecting_newbtn()
InTemplateEntry().entering_ipno()
InTemplateEntry().selecting_template('1')
InTemplateEntry().selecting_savebtn()
InTemplateEntry().getmessage_after_save()
InTemplateEntry().unselecting_the_frame()'''

class InDoctorVisitEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(4)
        self.select_frame(self.objects['WARD_MainFrame'])
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13243"
        self.wait_until_element_is_visible('xpath=//*[@id="txtIPNo"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="txtIPNo"]',self.dict['IPNO'])
        self.press_key('xpath=//*[@id="txtIPNo"]', '\\13')
        try:
            self.wait_until_element_is_visible('xpath=//*[@class="toast-message"]', 7, "message was not visible")
            self.msg = self.get_text('xpath=//*[@class="toast-message"]')
            print self.msg
            if self.msg == "No Existing Record(s) Found":
               time.sleep(5)
            else:
                pass
        except:
            pass
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_visitingdoctor(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="cboDoctor"]', 30, "visiting doctor was not visible")
        self.select_from_list_by_index('xpath=//*[@id="cboDoctor"]','2')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_addbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnAdd"]', 30, "add btn was not visible")
        self.click_button('xpath=//*[@id="btnAdd"]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btnVSave"]', 30, "save btn was not visible")
        self.click_button('xpath=//*[@id="btnVSave"]')
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 7, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['DoctorVisitEntryMsg'] = self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser 
#Doctor Visit Entry      
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page(5)
admin.FromConfigFile().logging('ward')
admin.FromConfigFile().loading_menu_of_link("//Nursing/tDocvisitentry.aspx")
print "menu loaded"
admin.FromConfigFile().zoom_in_page(1)
InDoctorVisitEntry().screenshotonfailure()
InDoctorVisitEntry().selecting_the_frame()
InDoctorVisitEntry().entering_ipno()
InDoctorVisitEntry().selecting_visitingdoctor()
InDoctorVisitEntry().selecting_addbtn()
InDoctorVisitEntry().selecting_savebtn()
InDoctorVisitEntry().getmessage_after_save()
InDoctorVisitEntry().unselecting_the_frame()'''
        
class InDischargeSummaryEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00000740"
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_DischargeSummaryEntry_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_DischargeSummaryEntry_IPNo'], '\\13')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_into_dischargesummscreen(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td[1]', 30, "discharge summary screen was not visible")
        self.click_element('xpath=//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//td[1]')
        time.sleep(7)
        try:
            self.wait_until_element_is_visible('xpath=//*[@id="s2id_autogen12_search"]', 200, "template was not visible")
            self.click_element('xpath=//*[@id="s2id_autogen12_search"]')
            self.input_text('xpath=//*[@id="s2id_autogen12_search"]', "%%%")
            self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[1]//span', 200, "template list was not visible")
            self.click_element('xpath=//*[@id="select2-drop"]//li[1]//span')
            time.sleep(2)
            self.wait_until_element_is_enabled(self.objects['WARD_DischargeSummaryEntry_TemplateApplybtn'], 100, "template apply btn was not visible")
            self.click_element(self.objects['WARD_DischargeSummaryEntry_TemplateApplybtn'])
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
        
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['WARD_DischargeSummaryEntry_Savebtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_DischargeSummaryEntry_Savebtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_Message'], 15, 'save message was not visible')
         self.msg = self.get_text(self.objects['WARD_DischargeSummaryEntry_Message'])
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['DischargeSummaryEntryMsg'] = self.msg         
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        pyautogui.click(585,155)
        time.sleep(1)
        pyautogui.click(585,155)
        time.sleep(1)
        pyautogui.click(585,155)  
    def selecting_signbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryEntry_Signbtn'], 30, "sign btn was not visible")
        self.click_button(self.objects['WARD_DischargeSummaryEntry_Signbtn'])
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()        
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser     
    
class InDischargeSummaryView(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00002197"
        #self.dict['IPNO'] = "Ip14307"
        self.wait_until_element_is_visible(self.objects['WARD_DischargeSummaryView_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_DischargeSummaryView_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_DischargeSummaryView_IPNo'], '\\13')
    def selecting_signbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(7)
        #BELOW TWO LINE COMMENTED FOR RELEASE SERVER
        #self.wait_until_element_is_visible('xpath=(//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//button)[3]', 30, "Sign btn was not visible")
        #self.click_button('xpath=(//*[@id="patTableDS"]//td[text()=" '+str(self.dict['IPNO'])+'"]/..//button)[3]')
        self.wait_until_element_is_visible('xpath=(//*[@id="tblPatlist"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//button)[3]', 30, "Sign btn was not visible")
        self.click_button('xpath=(//*[@id="tblPatlist"]//td[text()="'+str(self.dict['IPNO'])+'"]/..//button)[3]')
        
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        pyautogui.click(785,15)
        time.sleep(1)
        pyautogui.click(785,15)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
          
class InDeactivateDischargeSummary(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13281"
        self.wait_until_element_is_visible('xpath=//*[@id="hParamVal"]', 30, "IPNO was not visible")
        self.input_text('xpath=//*[@id="hParamVal"]',self.dict['IPNO'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_gobtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="btngo"]', 30, "go btn was not visible")
        self.click_button('xpath=//*[@id="btngo"]')
        self.dict['BROWSER'] = self._current_browser()
    def getmessage_after_save(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
         self.wait_until_element_is_visible('xpath=//*[@id="toast-container"]', 15, 'save message was not visible')
         self.msg = self.get_text('xpath=//*[@id="toast-container"]')
         print "Message:    ", self.msg
         self.Test_Results[(self.dict['Executed_Test_Name'])]['DeactivateDischargeSummaryMsg'] = self.msg
        except:
            print "message was not visible"
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser  

class InNursingAssessmentVitalsEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off('Ward_NursingAssessment')
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def scroll_web_element_into_view(self, locator):
        self.set_selenium_implicit_wait(15)
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(4)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00002436"
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'], 30, "IPNO was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'],self.dict['IPNO'])
        self.press_key(self.objects['WARD_NursingAssessmentVitalsEntry_IPNo'],'\\13')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_demographicbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_DemographicBtn'], 30, "Demograhic btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_DemographicBtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_demographic_closebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "Ip13281"
        time.sleep(5)
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_Demographic_Closebtn'], 30, "Demograhic close btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_Demographic_Closebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_er_assessmentvitalbtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVitalBtn'], 30, "ERAssessmentVital btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVitalBtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_assessmentframe(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentFrame'])
        time.sleep(1)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def selecting_triagecode(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_triagecode'], 30, "triage code was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_triagecode'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_transportmode(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_transportmode'], 30, "transport mode was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_transportmode'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def entering_idmarks(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_idmarks'], 30, "id marks was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_idmarks'], self.d[r]['idmarks'])
        self.dict['BROWSER'] = self._current_browser()   
    def entering_ervisit(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ERVisit'], 30, "id marks was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ERVisit'], self.d[r]['ervisit'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_complaints(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Complaints'], 30, "complaints was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Complaints'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_presentho(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Presentho'], 30, "presentho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Presentho'], '2')
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_pastho(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Pastho'], 30, "pastho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Pastho'], '2')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_socialho(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Socialho'], 30, "social ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Socialho'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_familyho(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Familyho'], 30, "family ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Familyho'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allergies(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_allergies'], 30, "allergies ho was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_allergies'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_treatmenthistory(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'])      
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'], 30, "treatment history was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentHistory'], self.d[r]['treatmenthistory'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_traumadetails(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'])   
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'], 30, "TraumaDetails was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TraumaDetails'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_general(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_General'], 30, "general was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_General'], self.d[r]['general'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_cardio(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)     
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cardio'], 30, "cardio was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cardio'], self.d[r]['cardio'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_resp(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Resp'], 30, "resp was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Resp'], self.d[r]['resp'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_abdvalue(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Abdvalue'], 30, "abd value was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Abdvalue'], str(self.d[r]['abdvalue']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_cnsvalue(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cnsvalue'], 30, "cns value was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Cnsvalue'], str(self.d[r]['cnsvalue']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_painscore(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-painsore'+self.d[r]['painscore']+'"]', 30, "pain score was not visible")
        self.click_element('xpath=//*[@id="uniform-painsore'+self.d[r]['painscore']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_provisionaldiagnosis(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)      
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ProvisionalDiagnosis'], 30, "provisional diagnosis was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_ProvisionalDiagnosis'], self.d[r]['provisionaldiagnosis'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_treatmentplan(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'], 30, "treatment plan was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_TreatmentPlan'], self.d[r]['treatmentplan'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_investigationplan(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'], 30, "investigation plan was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_InvestigationPlan'], self.d[r]['investigationplan'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_assessingstaff(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'], 30, "assessment staff was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_AssessmentStaff'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_referral(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'], 30, "referral was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Referral'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_assessingdoctor(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'], 30, "referral was not visible")
        self.select_from_list_by_index(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_assessingdoctor'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_status(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'], 30, "status was not visible")
        self.select_from_list_by_label(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_dischargestatus'], self.d[r]['status'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.scroll_web_element_into_view('xpath=//span[text()="ER Assessment "]')       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Savebtn'], 30, "save btn was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def cancelling_print_preview(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(5)
        pyautogui.click(1035,15)
        time.sleep(1)
        pyautogui.click(1035,15)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingtab(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(3)
        #self.scroll_web_element_into_view(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'])       
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'], 30, "nursing tab was not visible")
        self.click_element(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingTab'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_nursingframe(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_NursingFrame'])
        time.sleep(1)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()        
    def entering_medicationdrugs(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-medicdrug'+self.d[r]['medicationdrugs']+'"]', 30, "medication drugs was not visible")
        self.click_element('xpath=//*[@id="uniform-medicdrug'+self.d[r]['medicationdrugs']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_bloodtransfusion(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-bloodtrans'+self.d[r]['bloodtransfusion']+'"]', 30, "bloodtransfusion was not visible")
        self.click_element('xpath=//*[@id=//*[@id="uniform-bloodtrans'+self.d[r]['bloodtransfusion']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_food(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-food'+self.d[r]['food']+'"]', 30, "food was not visible")
        self.click_element('xpath=//*[@id="uniform-food'+self.d[r]['food']+'"]')
        self.dict['BROWSER'] = self._current_browser()    
    def entering_bleeding(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-bleeding'+self.d[r]['bleeding']+'"]', 30, "bleeding was not visible")
        self.click_element('xpath=//*[@id="uniform-bleeding'+self.d[r]['bleeding']+'"]')
        self.dict['BROWSER'] = self._current_browser()        
    def entering_openwound(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-openwound'+self.d[r]['openwound']+'"]', 30, "openwound was not visible")
        self.click_element('xpath=//*[@id="uniform-openwound'+self.d[r]['openwound']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_tobaco(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-tobaco'+self.d[r]['tobaco']+'"]', 30, "tobaco was not visible")
        self.click_element('xpath=//*[@id="uniform-tobaco'+self.d[r]['tobaco']+'"]')
        self.dict['BROWSER'] = self._current_browser() 
    def entering_smoking(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-smokinh'+self.d[r]['smoking']+'"]', 30, "smoking was not visible")
        self.click_element('xpath=//*[@id="uniform-smokinh'+self.d[r]['smoking']+'"]')
        self.dict['BROWSER'] = self._current_browser() 
    def entering_alhocoluse(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible('xpath=//*[@id="uniform-alhocoluse'+self.d[r]['alhocoluse']+'"]', 30, "alhocoluse was not visible")
        self.click_element('xpath=//*[@id="uniform-alhocoluse'+self.d[r]['alhocoluse']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_otherdetails(self,r):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)        
        self.wait_until_element_is_visible(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Otherdetails'], 30, "other details was not visible")
        self.input_text(self.objects['WARD_NursingAssessmentVitalsEntry_ERAssessmentVital_Otherdetails'],self.d[r]['otherdetails'])
        self.dict['BROWSER'] = self._current_browser()                                
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
class InExtraBedDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['WARD_MainFrame'])
        time.sleep(7)
        #this time delay given for page gets loaded        
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "2822"
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_RegNo'], 30, "REGNO was not visible")
        self.input_text(self.objects['WARD_ExtraBED_RegNo'],str(self.dict['REGNO']))
        self.press_key(self.objects['WARD_ExtraBED_RegNo'], '\\13')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_extrabedallocationpage(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@id="patTableDTran"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient details not available in grid")
        self.click_element('xpath=//*[@id="patTableDTran"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()           
    def selecting_radiobtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Radiobtn'], 30, "radio btn was not visible")
        self.click_element(self.objects['WARD_ExtraBED_Radiobtn'])
        time.sleep(0.5)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Savebtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_ExtraBED_Savebtn'])
        self._handle_alert(True)        
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:            
            self.wait_until_page_contains_element(self.objects['WARD_ExtraBED_Message'], 30, 'Record was not saved in page')
            self.wait_until_element_is_visible(self.objects['WARD_ExtraBED_Message'], 30, 'Record was not saved')
            Msg = self._get_text(self.objects['WARD_ExtraBED_Message'])
            print Msg
            self.Test_Results[(self.dict['Executed_Test_Name'])]['ExtraBedDirectMsg'] = Msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
        
        
'''admin.FromConfigFile().driving_browser_and_url()
admin.FromConfigFile().zoom_out_page('5')
admin.FromConfigFile().logging('ward')    
admin.FromConfigFile().loading_menu_of_link_test('//WARD/tFumigationDeptEntry.html','ward')
InFumigationRequest().screenshotonfailure()
InFumigationRequest().selecting_the_frame()
InFumigationRequest().unselecting_the_frame()
admin.FromConfigFile().loading_menu_of_link_test('/Ward/tFumigationsearch.html','ward')
InFumigationScheduleSearch().screenshotonfailure()
InFumigationScheduleSearch().selecting_the_frame() '''  
        
class InIPCashCreditReturnRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()

    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["WARD_MainFrame"])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()  

    def selecting_storename(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['FROMSTORENAME'] = "PHARMACY"
        self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Storename'])
        self.select_from_list_by_label(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Storename'], self.dict['FROMSTORENAME'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()

    def searching_ipno(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.dict['IPNO'] = "IP14225"
        self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_IPNo'])
        self.input_text(self.objects["WARD_IPSalesReturn_CashCreditReturnReq_IPNo"], str(self.dict['IPNO']))
        self.press_key(self.objects["WARD_IPSalesReturn_CashCreditReturnReq_IPNo"], '\\13')
        time.sleep(5)
        self.dict['BROWSER'] =  self._current_browser() 
        
    def fetching_returnpenqty(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00001674"
        self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_ReturnPendQty'])
        returnpendqty = self.get_text(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_ReturnPendQty'])
        print "returnpendqty", returnpendqty
        self.dict['IPSALESRETURNPENDQTY'] = returnpendqty
        self.dict['BROWSER'] =  self._current_browser()
    
    def entering_returnqty(self):
        self.set_selenium_implicit_wait(30)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['IPNO'] = "IP00001674"
        self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_ReturnQty'])
        self.input_text(self.objects["WARD_IPSalesReturn_CashCreditReturnReq_ReturnQty"], str(self.dict['IPSALESRETURNPENDQTY']))
        time.sleep(1)
        self.dict['BROWSER'] =  self._current_browser()  
    def selecting_savebtn(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Savebtn'], 30, "save btn was not visible")
        self.click_button(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()    
    def getting_message(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:            
            self.wait_until_page_contains_element(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Message'], 30, 'Record was not saved in page')
            self.wait_until_element_is_visible(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Message'], 30, 'Record was not saved')
            Msg = self._get_text(self.objects['WARD_IPSalesReturn_CashCreditReturnReq_Message'])
            print Msg
            self.Test_Results[(self.dict['Executed_Test_Name'])]['IPCashCreditReturnReqMsg'] = Msg
        except:
            print "Not able to capture the message"
            pass            
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(15)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser
    