import sys
from Selenium2Library import Selenium2Library
from pip._vendor.distlib.locators import Locator
from openpyxl.cell.cell import TYPE_NULL
import pyautogui
from datetime import datetime
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
sys.path.append('..\..\libraries\Workflow_Specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing
import openpyxl
import pandas as pd 
from datetime import datetime

class in_frountoffice_Validation(Selenium2Library):
        dict = admin.FromConfigFile.dict
        objects = common_reader.Capturing.objects
        d = Capturing().data_off("field_data2")
        def checking_age_date(self):
            FromConfigFile().logging('frontoffice')
            self._cache.current = self.dict['BROWSER']
            self.browser = self._current_browser()
            self.select_frame('xpath=//*[@id="frmMainPage"]')
            self.mouse_down('xpath=//*[@id="HdrTitle"]')
            
            value = "00-00-0000"
            r=2
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('enter')
            pyautogui.hotkey('enter')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
 
            value = "35-02-2009"
            r=3
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
 
            value = "31-02-2000"
            r=4
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
            value = "31-04-2007"
            r=5
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
            value = "29-02-2023"
            r=6
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
             
             
            value = "123-2-2001"
            r=7
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
            value = "25-04-2023"
            r=8
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
            value = "1-12-2010"
            r=9
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
            value = "2-122-2001"
            r=10
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "02-05-2023"
            r=11
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "12-14-2000"
            r=12
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "01-1-2010"
            r=13
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "23-02-2045"
            r=14
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('enter')
            pyautogui.hotkey('shift','tab')
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "21-02-20"
            r=15
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('enter')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "21-02-20"
            r=16
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('enter')
            pyautogui.hotkey('enter')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "01-01-202"
            r=17
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('enter')
            pyautogui.hotkey('enter')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "22"
            r=16
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "10 - 08"
            r=19
            self.input_text('xpath=//*[@id="txtDOB"]', value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
             pyautogui.hotkey('backspace')
             self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = " 08-2023"
            r=20
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
             
            
            value = "12-14-2000"
            r=22
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = ""
            r=23
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "18/04/2023"
            r=24
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "18.04.2023"
            r=25
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "$@$#%&%^"
            r=26
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "qwertyuiop"
            r=27
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "0000000000_"
            r=28
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "21122001"
            r=29
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "12-  -2001"
            r=30
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "18-04-    "
            r=31
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            pyautogui.hotkey('tab')
            pyautogui.hotkey('shift','tab')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            for i in range (1,12):
                pyautogui.hotkey('backspace')
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            value = "2023-12-27"
            r=21
            self.input_text('xpath=//*[@id="txtDOB"]',value )
            a=self.get_value('xpath=//*[@id="txtDOB"]')
            print a
            pyautogui.hotkey('enter')
            pyautogui.hotkey('enter')
            b=self.get_value('xpath=//*[@id="txtAge"]')
            print b
            self.dict['BROWSER'] = self._current_browser()
            wb= openpyxl.load_workbook('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            sheet= wb['field_data2']
            sheet.cell(row=r,column=6).value =a
            sheet.cell(row=r,column=5).value =b
            wb.save('D:\workspace\Automate_BB15_local\datas\Bb_datas.xlsx')
            wb.close()
            
            
   
FromConfigFile().driving_browser_and_url()         
in_frountoffice_Validation().checking_age_date()                
                
                
                
                
                
                
                
                