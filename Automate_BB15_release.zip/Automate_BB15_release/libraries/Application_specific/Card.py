import sys
from Selenium2Library import Selenium2Library
import pyautogui
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from  common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    d = Capturing().data_off("OPBilling")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()

    def entering_into_requestdetailsscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO']= 624519
        #self.dict['CARDIOLOGY_SERVICE'] = "ECG HEART JR"
        if self._is_visible(self.objects['CARD_Request_Approve_RegNo']):
                #time.sleep(1)
                '''self.dict['REGNO']= "2666"
                self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 30, "from date was not visible")
                self.input_text('xpath=//*[@id="txtFromDt"]', "01-09-2023")
                self.press_key('xpath=//*[@id="txtFromDt"]', '\\13')'''
                self.wait_until_element_is_visible(self.objects['CARD_Request_Approve_RegNo'], 30, "Card Request approve reg no was not visible")
                self.input_text(self.objects['CARD_Request_Approve_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Request_Approve_Search'], 30, "Card Request approve search was not visible")
                self.click_button(self.objects['CARD_Request_Approve_Search'])
                time.sleep(1)
                #self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "InRequestApproval Regno in search grid was not visible")
                #self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 30, "InRequestApproval Card service in search grid was not same")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox_old(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        #self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//span[3]', 30, "InRequestApproval check box was not visible")
        #self.page_should_contain_checkbox('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//span[2]', "checkbox was not displayed", 'INFO')
        #self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//span[3]')
        #self.select_checkbox('xpath=//*[@id="chk0"]/../../..//td[text()="'+str(self.dict['REGNO'])+'"]')
        #self.select_checkbox('xpath=//*[@id="chk0"]/..//span[3]')
        #self.click_element('xpath=//*[@id="chk0"]/..//span[3]')
        #self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input[@id="chk0"]/..//span[3]')
        #self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//span[2]', 15, "InRequestApproval checkbox was not selected")
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="chk0"]/..//span[3]', 30, "InRequestApproval check box was not visible")
        self.click_element('xpath=//*[@id="chk0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="chk0"]/..//span[3]', 30, 'checkbox was not visible')
        self.click_element('xpath=//*[@id="chk0"]/..//span[3]')
        element = self._get_checkbox('xpath=//*[@id="chk0"]')
        if not element.is_selected():
            print "element not selected"
            time.sleep(1)
            self.click_element('xpath=//*[@id="chk0"]/..//span[3]')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_requestreceive_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['CARD_Request_Approve_Request_Receive'], 30, "request receive btn was not visible")
        self.click_element(self.objects['CARD_Request_Approve_Request_Receive'])
        #time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message_afterrequestreceive(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(2)
        ###UnexpectedAlertPresentException: Alert Text: Do you want to Print the Request ?
        ##############################    RELEASE SERVER    ###############################################################
        ctrlvalue = self.cs['cs503']
        if (str(ctrlvalue) == '1'):
            #Msg = self.get_alert_message(True)
            #print "Msg", Msg
            print "inside print cancel flow"
            self._handle_alert(True)
            time.sleep(7)
            pyautogui. FAILSAFE = False
            pyautogui.click(1132,672)
            try:
                self.wait_until_element_is_visible(self.objects['CARD_Request_Approve_Message'], 30, 'Record was not saved')
                CardReqReceiveMsg = self._get_text(self.objects['CARD_Request_Approve_Message'])
                print "CardReqReceiveMsg inside print cancel flow", CardReqReceiveMsg
                self.Test_Results[(self.dict['Executed_Test_Name'])]['CardReqReceiveMsg'] = CardReqReceiveMsg
            except:
                pass
        else:
            try:
                self.wait_until_element_is_visible(self.objects['CARD_Request_Approve_Message'], 30, 'Record was not saved')
                CardReqReceiveMsg = self._get_text(self.objects['CARD_Request_Approve_Message'])
                print "CardReqReceiveMsg", CardReqReceiveMsg
                self.Test_Results[(self.dict['Executed_Test_Name'])]['CardReqReceiveMsg'] = CardReqReceiveMsg
            except:
                pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "CArd main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()

    def entering_into_requestdetailsscreen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        if self._is_visible(self.objects['CARD_Result_Entry_RegNo']):
                #time.sleep(2)
                '''self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 30, "from date was not visible")
                self.input_text('xpath=//*[@id="txtFromDt"]', "01-09-2023")
                self.press_key('xpath=//*[@id="txtFromDt"]', '\\13')'''
                self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_RegNo'], 30, "result entry regno. was not visible")
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Entry_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Search'], 30, "card result entry search was not visible")
                self.click_button(self.objects['CARD_Result_Entry_Search'])
                time.sleep(2)
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in result entry search grid")
                self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]')
                time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.dict['CARDIOLOGY_SERVICE'] = "Akash cardiology"
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_page_contains_element('xpath=//*[@id="lblregno_tool"]', 20, 'regno label was not visible')
        #time.sleep(2)
        #Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')  
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_resultentryscreen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #time.sleep(3)
        #self.wait_until_element_is_visible('xpath=//*[@id="tblbdy2"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'")]', 30, "card service name was not visible in result entry screen")
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, "card service name was not visible in result entry screen")
        #self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'card service name was not visible')
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]')
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_cardiologist(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Cardiologist'], 20, 'Cardiologist name was not visible')
        self.select_from_list_by_index(self.objects['CARD_Result_Entry_Cardiologist'], '1')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_template(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Template'], 30, "Result entry template was not visible")
        self.select_from_list_by_index(self.objects['CARD_Result_Entry_Template'], '1')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Save'], 30, "Result entry save button was not visible")
        self.click_element(self.objects['CARD_Result_Entry_Save'])        
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Entry_Message'], 30, 'Record was not saved')    
        CardResMsg = self._get_text(self.objects['CARD_Result_Entry_Message'])
        print CardResMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardResultEntryMsg'] = CardResMsg
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
        
class InResultDispatch(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "Card mainframe was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_resultdispatchscreen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        #self.dict['REGNO'] = 624421
        '''self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 30, "from date was not visible")
        self.input_text('xpath=//*[@id="txtFromDt"]', "01-09-2023")
        self.press_key('xpath=//*[@id="txtFromDt"]', '\\13')'''
        self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_RegNo'], 30, "result dispatch regno. was not visible")
        self.input_text(self.objects['CARD_Result_Dispatch_RegNo'], str(self.dict['REGNO']))
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_Search'], 30, "result dispatch search. was not visible")
        self.click_button(self.objects['CARD_Result_Dispatch_Search'])
        time.sleep(2)
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]', 30, "In result dispatch regno was not visible")
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "In result dispatch regno was not visible")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        print "before"
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="chkid0"]/..//span[3]', 30, "Result dispatch check box was not visible")
        self.click_element('xpath=//*[@id="chkid0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()
        
        
        #time.sleep(2)
        #self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_checkbox'], 30, "Result dispatch check box was not visible")
        #self.wait_until_page_contains_element(self.objects['CARD_Result_Dispatch_checkbox'], 30, "Result dispatch check box was not visible")
        #self.click_element(self.objects['CARD_Result_Dispatch_checkbox'])
        '''checkboxelement = self._element_find('xpath=//*[@id="chkid0"]/..//span[3]', True, False)
        print checkboxelement
        status = checkboxelement.is_selected()
        print status
        if (checkboxelement.is_selected()) == True:
            pass
        else:
            time.sleep(1)
            print "1"
            self.click_element(self.objects['CARD_Result_Dispatch_checkbox'])
            time.sleep(1)
            self.click_element(self.objects['CARD_Result_Dispatch_checkbox'])
            print "2"
        #self.unselect_checkbox(self.objects['CARD_Result_Dispatch_checkbox'])
        #print "2"
        #self.click_element(self.objects['CARD_Result_Dispatch_checkbox'])
        #print "3"
        self.dict['BROWSER'] = self._current_browser()'''
    def selecting_resultdispatchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_ResultDispatchBtn'], 30, "Result dispatch Button was not visible")
        self.click_button(self.objects['CARD_Result_Dispatch_ResultDispatchBtn'])
        #time.sleep(2)
        self._handle_alert(True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Dispatch_Message'], 30, 'Record was not saved')    
        CardDispatchMsg = self._get_text(self.objects['CARD_Result_Dispatch_Message'])
        print CardDispatchMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardResultDispatchMsg'] = CardDispatchMsg
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
class InApprovalrevert(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 20, "InApprovalrevert Card main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def searching_patient_details(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.dict['REGNO']= 624519
        #self.dict['CARDIOLOGY_SERVICE'] = "ECG HEART JR"
        if self._is_visible(self.objects['CARD_Approval_Revert_RegNo']):
                #time.sleep(1)
                self.wait_until_element_is_visible(self.objects['CARD_Approval_Revert_RegNo'], 30, "InApprovalrevert regno was not visible")
                self.input_text(self.objects['CARD_Approval_Revert_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Approval_Revert_Search'], 30, "InApprovalrevert search was not visible")
                self.click_button(self.objects['CARD_Approval_Revert_Search'])
                time.sleep(1)
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "InApprovalrevert Regno in search grid was not visible")
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 15, "InApprovalrevert patient details are not retrieved")
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_checkbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="chk0"]/..//span[3]', 30, "InApprovalrevert check box was not visible")
        self.click_element('xpath=//*[@id="chk0"]/..//span[3]')
        #self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//span[3]', 30, "InApprovalrevert check box was not visible")
        #self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]/..//input[@id="chk0"]/..//span[3]')
        self.dict['BROWSER'] = self._current_browser()

    def selecting_requestrevert_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['CARD_Approval_Revert_Request_Revert'], 30, "InApprovalrevert request revert was not enabled")
        #self.click_element(self.objects['CARD_Approval_Revert_Request_Revert'])
        self.click_button(self.objects['CARD_Approval_Revert_Request_Revert'])
        #time.sleep(2)
        self._handle_alert_with_text("Not applicable", True)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message_afterrequestrevert(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        try:
            self.wait_until_element_is_visible(self.objects['CARD_Approval_Revert_Message'], 30, 'Record was not saved')
            self.page_should_contain_element(self.objects['CARD_Approval_Revert_Message'], 30, 'Record was not saved')
            CardReqRevertMsg = self._get_text(self.objects['CARD_Approval_Revert_Message'])
            print CardReqRevertMsg
            self.Test_Results[(self.dict['Executed_Test_Name'])]['CardReqRevertMsg'] = CardReqRevertMsg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()
class InCancelRequestprint(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['IPNO'] = "Ip13698"
        #self.dict['REGNO'] = "643675"
        #self.dict['CARDIOLOGY_SERVICE'] = "ECG BBB"
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['CARD_Cancel_Request_Print_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_Cancel_Request_Print_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]', 30, "ipno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]')
        time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    
    '''def entering_into_cancelreqprint_screen(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.dict['IPNO'] = "0000012612"
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 30, "InCancelRequest from date was not visible")
        #self.input_text('xpath=//*[@id="txtFromDt"]', "27-01-2023")
        #self.press_key('xpath=//*[@id="txtFromDt"]', '\\09')
        #pyautogui.hotkey('esc')
        if self._is_visible(self.objects['CARD_Cancel_Request_Print_IPNo']):
                self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_IPNo'], 30, "InCancelRequest ipno was not visible")
                self.input_text(self.objects['CARD_Cancel_Request_Print_IPNo'], str(self.dict['IPNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_Searchbtn'], 30, "InCancelRequest search was not visible")
                self.wait_until_element_is_enabled(self.objects['CARD_Cancel_Request_Print_Searchbtn'], 30, "InCancelRequest search was not enabled")
                self.click_button(self.objects['CARD_Cancel_Request_Print_Searchbtn'])
                #self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "InApprovalrevert Regno in search grid was not visible")
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]', 30, "InCancelRequest ipno in search grid was not visible")
                self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()'''
    def validate_patient(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        #self.dict['CARDIOLOGY_SERVICE'] = "Brain ECG updated"
        self.wait_until_page_contains_element('xpath=//*[@id="tbltbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblip_tool"]')
        Patient = Patient[3:13]
        print "str(self.dict['IPNO']).lower()", str(self.dict['IPNO']).lower()
        print "str(Patient).lower()", str(Patient).lower() 
        if str(self.dict['IPNO']).lower() != str(Patient).lower():
            raise AssertionError('Failed Ipno number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_printbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_Printbtn'], 20, 'Print Button was not visible')
        self.wait_until_element_is_enabled(self.objects['CARD_Cancel_Request_Print_Printbtn'], 20, 'Print Button was not enabled')
        self.click_button(self.objects['CARD_Cancel_Request_Print_Printbtn'])        
        self.dict['BROWSER'] = self._current_browser()     
    def getting_message(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Print_Message'], 30, 'Request was not cancelled')    
        CardCanReqPrintMsg = self._get_text(self.objects['CARD_Cancel_Request_Print_Message'])
        print CardCanReqPrintMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardCanReqPrintMsg'] = CardCanReqPrintMsg
        if CardCanReqPrintMsg != "Copy Request Printed Successfully":
            raise AssertionError('Request not printed properly')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InRequestPrintCopy(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['IPNO'] = "IP00002117"
        self.wait_until_element_is_visible(self.objects['CARD_Request_Print_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['CARD_Request_Print_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_Request_Print_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_Request_Print_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]', 30, "ipno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()

    '''def entering_into_reqprint_screen(self,r):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        #self.dict['IPNO'] = "0000012664"
        time.sleep(1)
        #self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 30, "InCancelRequest from date was not visible")
        #self.input_text('xpath=//*[@id="txtFromDt"]', "27-01-2023")
        #self.press_key('xpath=//*[@id="txtFromDt"]', '\\09')
        #pyautogui.hotkey('esc')
        if self._is_visible(self.objects['CARD_Request_Print_IPNo']):
                self.wait_until_element_is_visible(self.objects['CARD_Request_Print_IPNo'], 30, "InCancelRequest ipno was not visible")
                self.input_text(self.objects['CARD_Request_Print_IPNo'], str(self.dict['IPNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Request_Print_Searchbtn'], 30, "InCancelRequest search was not visible")
                self.wait_until_element_is_enabled(self.objects['CARD_Request_Print_Searchbtn'], 30, "InCancelRequest search was not enabled")
                self.click_button(self.objects['CARD_Request_Print_Searchbtn'])
                #self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "InApprovalrevert Regno in search grid was not visible")
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]', 30, "InCancelRequest ipno in search grid was not visible")
                self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="IP '+str(self.dict['IPNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()'''
    def validate_patient(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #r = int(r)
        #self.dict['CARDIOLOGY_SERVICE'] = "Cardio test ip"
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tbltbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 30, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="lblip_tool"]', 30, "IP NO label was not visible")
        Patient = self._get_text('xpath=//*[@id="lblip_tool"]')
        Patient = Patient[3:]
        print "Patient", str(Patient)
        print "Patient", str(Patient).strip()
        Patient = str(Patient).strip()
        print "IPNO", str(self.dict['IPNO'])
        if str(self.dict['IPNO']).lower() != str(Patient).lower():
            raise AssertionError('Failed Ipno number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_printbtn(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Request_Print_Printbtn'], 30, 'Print Button was not visible')
        self.wait_until_element_is_enabled(self.objects['CARD_Request_Print_Printbtn'], 30, 'Print Button was not enabled')
        self.click_button(self.objects['CARD_Request_Print_Printbtn'])        
        self.dict['BROWSER'] = self._current_browser()     
    def getting_message(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Request_Print_Message'], 30, 'Request was not cancelled')    
        CardReqPrintMsg = self._get_text(self.objects['CARD_Request_Print_Message'])
        print CardReqPrintMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardReqPrintMsg'] = CardReqPrintMsg
        if CardReqPrintMsg != "Copy Request Printed Successfully":
            raise AssertionError('Request not printed properly')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(10)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()          
class InResultUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(2)
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "CArd main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        if self._is_visible(self.objects['CARD_Result_Update_RegNo']):
                #time.sleep(2)
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_RegNo'], 30, "result entry regno. was not visible")
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Update_RegNo'], str(self.dict['REGNO']))
                #time.sleep(1)
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_Search'], 30, "card result entry search was not visible")
                self.click_button(self.objects['CARD_Result_Update_Search'])
                time.sleep(4)
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in result entry search grid")
                #self.click_element('xpath=//*[(text()="'+str(self.dict['REGNO'])+'")]')
                self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]')
                time.sleep(4)
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #r = int(r)
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        time.sleep(7)
        print self.dict['CARDIOLOGY_SERVICE']
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        #time.sleep(2)
        #Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')  
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_result_update_screen(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.d = Capturing().data_off("OPBilling")
        #r = int(r)
        #time.sleep(3)
        #self.wait_until_element_is_visible('xpath=//*[@id="tblbdy2"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'")]', 30, "card service name was not visible in result entry screen")
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, "card service name was not visible in result entry screen")
        #self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]')
        self.wait_until_element_is_visible('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'card service name was not visible')
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]')
        #time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_update_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Update_UpdateBtn'], 30, "update btn was not visible")
        self.click_element(self.objects['CARD_Result_Update_UpdateBtn'])        
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Result_Update_Message'], 30, 'Record was not saved')    
        ResultUpdateMsg = self._get_text(self.objects['CARD_Result_Update_Message'])
        print ResultUpdateMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardResultUpdateMsg'] = ResultUpdateMsg
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()        
class InCancelRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "Card main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "609360"
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['CARD_Cancel_Request_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_Cancel_Request_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_request_details_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        '''if self._is_visible(self.objects['CARD_Result_Update_RegNo']):
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_RegNo'], 30, "result entry regno. was not visible")
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Update_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_Search'], 30, "card result entry search was not visible")
                self.click_button(self.objects['CARD_Result_Update_Search'])
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in result entry search grid")
                self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')'''
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        #r = int(r)
        #self.dict['CARDIOLOGY_SERVICE'] = "Brain ECG updated"
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tbldtl"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 30, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_reasonforcancellation(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Reason'], 30, 'reason for cancellation was not visible')
        self.select_from_list_by_index(self.objects['CARD_Cancel_Request_Reason'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Doctor'], 30, 'doctor was not visible')
        self.select_from_list_by_index(self.objects['CARD_Cancel_Request_Doctor'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_checkbox'], 30, 'checkbox was not visible')
        self.click_element(self.objects['CARD_Cancel_Request_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.d = Capturing().data_off("CARD_CancelReq")
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Remarks'], 30, 'remarks was not visible')
        self.input_text(self.objects['CARD_Cancel_Request_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_testcancelreqbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['CARD_Cancel_Request_testcancelreqbtn'], 30, "cancel request btn was not visible")
        self.click_button(self.objects['CARD_Cancel_Request_testcancelreqbtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_message'], 30, 'Record was not saved')    
        TestCancelReqMsg = self._get_text(self.objects['CARD_Cancel_Request_message'])
        print TestCancelReqMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardTestCancelReqMsg'] = TestCancelReqMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()          
class InCancelRequestApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "Card main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "609360"
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Approval_RegNo'], 30, "regno was not visible")
        self.input_text(self.objects['CARD_Cancel_Request_Approval_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Approval_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_Cancel_Request_Approval_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_requestapproval_screen(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        '''if self._is_visible(self.objects['CARD_Result_Update_RegNo']):
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_RegNo'], 30, "result entry regno. was not visible")
                print self.dict['REGNO']
                self.input_text(self.objects['CARD_Result_Update_RegNo'], str(self.dict['REGNO']))
                self.wait_until_element_is_visible(self.objects['CARD_Result_Update_Search'], 30, "card result entry search was not visible")
                self.click_button(self.objects['CARD_Result_Update_Search'])
                self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in result entry search grid")
                self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')'''
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("OPBilling")
        #r = int(r)
        #self.dict['CARDIOLOGY_SERVICE'] = "Brain ECG updated"
        #self.wait_until_element_is_visible('xpath=//*[(text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=//*[@id="tabledtl"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_Approval_checkbox'], 20, 'checkbox was not visible')
        self.click_element(self.objects['CARD_Cancel_Request_Approval_checkbox'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_testcancelapprovebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['CARD_Cancel_Request_Approval_cancelapprovebtn'], 30, "cancel approve btn was not visible")
        self.click_button(self.objects['CARD_Cancel_Request_Approval_cancelapprovebtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_Cancel_Request_message'], 30, 'Record was not saved')    
        TestCancelReqMsg = self._get_text(self.objects['CARD_Cancel_Request_message'])
        print TestCancelReqMsg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CardTestCancelReqMsg'] = TestCancelReqMsg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        #time.sleep(2)   
        self.dict['BROWSER'] = self._current_browser()  
class InResultApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OPBilling")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "Card main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()
    def entering_regno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['REGNO'] = "607657"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtFromDt"]', 10, "fromt date was not visible")
        #self.input_text('xpath=//*[@id="txtFromDt"]', "31-10-2022")
        self.wait_until_element_is_visible(self.objects['CARD_ResultApprove_Regno'], 30, "regno was not visible")
        self.input_text(self.objects['CARD_ResultApprove_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_ResultApprove_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_ResultApprove_Searchbtn'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy2"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #self.dict['CARDIOLOGY_SERVICE'] = "ECG BBB"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_resultapprove(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['CARD_ResultApprove_Approvebtn'], 30, "Approve btn was not visible")
        self.click_button(self.objects['CARD_ResultApprove_Approvebtn']) 
        self.dict['BROWSER'] = self._current_browser()   
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:            
            self.wait_until_element_is_visible(self.objects['CARD_ResultApprove_Message'], 30, 'Record was not saved')    
            Msg = self._get_text(self.objects['CARD_ResultApprove_Message'])
            print Msg
            self.Test_Results[(self.dict['Executed_Test_Name'])]['CardResultApproveMsg'] = Msg
        except:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InRequestCancelDirect(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("Ward_Orders")
    Test_Results = admin.FromConfigFile.Test_Results
    
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_MainFrame'], 30, "Card main frame was not visible")
        self.select_frame(self.objects['CARD_MainFrame'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_ipno(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        #self.dict['IPNO'] = "0000008993"
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['CARD_RequestCancelDirect_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_Searchbtn'], 30, "search btn was not visible")
        self.click_button(self.objects['CARD_RequestCancelDirect_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_patientdetails(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "604709"
        self.wait_until_page_contains_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "regno was not visible in search result grid")
        self.click_element('xpath=//*[@id="tblbdy"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def validate_patient(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #r = int(r)
        time.sleep(2)
        #self.dict['CARDIOLOGY_SERVICE'] = "Brain ECG updated"
        self.wait_until_page_contains_element('xpath=//*[@id="tbldtl"]//td[text()="'+self.dict['CARDIOLOGY_SERVICE']+'"]', 20, 'No Tests available')
        Patient = self.get_text('xpath=//*[@id="lblregno_tool"]')
        print Patient
        if str(self.dict['REGNO']) != Patient:
            raise AssertionError('Failed Reg number is not matching')
        else:
            pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_allcheckbox(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_checkboxall'], 30, "checkbox all was not visible")
        self.click_element(self.objects['CARD_RequestCancelDirect_checkboxall'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_reason(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_reason'], 30, "reason was not visible")
        self.select_from_list_by_index(self.objects['CARD_RequestCancelDirect_reason'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_doctor(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_doctor'], 30, "doctor was not visible")
        self.select_from_list_by_index(self.objects['CARD_RequestCancelDirect_doctor'], '2')
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.d = Capturing().data_off("CARD_ReqCancelDirect")
        r = int(r)
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_remarks'], 30, "doctor was not visible")
        self.input_text(self.objects['CARD_RequestCancelDirect_remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_directtestcancelbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['CARD_RequestCancelDirect_DirectTestCancelbtn'], 30, "direct test cancel btn was not visible")
        self.click_button(self.objects['CARD_RequestCancelDirect_DirectTestCancelbtn']) 
        self._handle_alert(True)       
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['CARD_RequestCancelDirect_Message'], 30, 'Record was not saved')    
        Msg = self._get_text(self.objects['CARD_RequestCancelDirect_Message'])
        print Msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['CARDRequestCancelDirectMsg'] = Msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        
        