from Selenium2Library import Selenium2Library
import sys
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing

class InphysiocompletionEntry_OP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "608467"
        self.wait_until_page_contains_element('xpath=//*[@id="txtregno"]', 10, "regno was not visible")
        self.click_element('xpath=//*[@id="txtregno"]')
        self.input_text('xpath=//*[@id="txtregno"]',str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@class="pull-right"]//button[1]', 10, "search btn was not enabled")
        self.click_button('xpath=//*[@class="pull-right"]//button[1]')
        time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'register number not available')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetailsfromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 15, "patient details was not in grid")
        self.click_element('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_therapist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_OP_Therapist'], 15, "Therapist name was not visible")
        self.wait_until_page_contains_element(self.objects['PHYSIO_Completion_Entry_OP_Therapist'], 15, "Therapist name was not visible")
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_OP_Therapist'], '1')
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_OP_Remarks'], 15, "remarks was not visible")
        self.input_text(self.objects['PHYSIO_Completion_Entry_OP_Remarks'],"Test normal")
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['PHYSIO_Completion_Entry_OP_Save'], 10, "save btn was not enabled")
        self.click_button(self.objects['PHYSIO_Completion_Entry_OP_Save'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['PHYSIO_Completion_Entry_OP_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['PHYSIO_Completion_Entry_OP_Message'])
        print Msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['OPPhysioCompletionEntryMsg'] = Msg
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_OKbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['PHYSIO_Completion_Entry_OP_Msg_OK'], 10, "Ok btn was not enabled")
        self.click_button(self.objects['PHYSIO_Completion_Entry_OP_Msg_OK'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InphysiocompletionEntry_IP(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "611409"
        #self.dict['IPNO'] = "0000011437"
        #self.dict['WARD-NAME']="MALE GENERAL WARD ONE asd asd asd as END"
        #time.sleep(3)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_IP_RegNo'], 15, "regno was not visible")
        self.click_element(self.objects['PHYSIO_Completion_Entry_IP_RegNo'])
        #time.sleep(1)
        self.input_text(self.objects['PHYSIO_Completion_Entry_IP_RegNo'],str(self.dict['REGNO']))
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_search_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['PHYSIO_Completion_Entry_IP_Search'], 15, "search btn was not enabled")
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Search'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'patient details not available in grid')
        self.wait_until_page_contains_element('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, 'patient details not available in grid')
        self.click_element('xpath=//*[@class="table-scrollable"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_therapist_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element(self.objects['PHYSIO_Completion_Entry_IP_Therapist'], 15, "Therapist name was not enabled")
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_IP_Therapist'], 15, "Therapist name was not enabled")
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_IP_Therapist'], '1')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_physio_type(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_IP_Type'], 15, "Physiotype name was not enabled")
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_IP_Type'], '2')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_service_name(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_IP_ServiceName'], 15, "service name was not visible")
        self.select_from_list_by_index(self.objects['PHYSIO_Completion_Entry_IP_ServiceName'], '1')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['PHYSIO_Completion_Entry_IP_Remarks'], 15, "remarks name was not visible")
        self.input_text(self.objects['PHYSIO_Completion_Entry_IP_Remarks'],"Test normal")
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_save_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['PHYSIO_Completion_Entry_IP_Save'], 15, "Save btn was not enabled")
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Save'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def clicking_OK_button(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_element_is_enabled(self.objects['PHYSIO_Completion_Entry_IP_Msg_OK'], 15, "OK btn was not enabled")
        self.click_button(self.objects['PHYSIO_Completion_Entry_IP_Msg_OK'])
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class Inphysiocancelrequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "621537"
        self.wait_until_page_contains_element(self.objects['Physio_CancelRequest_Regno'], 10, "regno was not visible")
        self.click_element(self.objects['Physio_CancelRequest_Regno'])
        self.input_text(self.objects['Physio_CancelRequest_Regno'],str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequest_Searchbtn'], 10, "search btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequest_Searchbtn'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetailsfromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 15, "patient details was not in grid")
        self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['Physio_CancelRequest_Remarks'], 10, "remarks was not visible")
        self.input_text(self.objects['Physio_CancelRequest_Remarks'],"Not Applicable")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequest_Savebtn'], 10, "save btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequest_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['Physio_CancelRequest_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['Physio_CancelRequest_Message'])
        print Msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['PhysioCancelRequestMsg'] = Msg
        self.dict['BROWSER'] = self._current_browser()
    def selecting_OKbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequest_Message_Ok'], 10, "Ok btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequest_Message_Ok'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class Inphysiocancelrequestapprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    Test_Results = admin.FromConfigFile.Test_Results
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects["PHYSIO_MainFrame"])
        time.sleep(3)
        self.dict['BROWSER'] =  self._current_browser()
    def entering_regno_with_data(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "608467"
        self.wait_until_page_contains_element(self.objects['Physio_CancelRequestapprove_Regno'], 10, "regno was not visible")
        self.click_element(self.objects['Physio_CancelRequestapprove_Regno'])
        self.input_text(self.objects['Physio_CancelRequestapprove_Regno'],str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequestapprove_Searchbtn'], 10, "search btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequestapprove_Searchbtn'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientdetailsfromgrid(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 15, "patient details was not in grid")
        self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequestapprove_Approvebtn'], 10, "approve btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequestapprove_Approvebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['Physio_CancelRequestapprove_Message'], 40, 'Message was not visible')
        Msg = self._get_text(self.objects['Physio_CancelRequestapprove_Message'])
        print Msg
        self.Test_Results[(self.dict['Executed_Test_Name'])]['PhysioCancelRequestapproveMsge'] = Msg
        self.dict['BROWSER'] = self._current_browser()   
    def selecting_OKbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['Physio_CancelRequestapprove_Message_Ok'], 10, "Ok btn was not enabled")
        self.click_button(self.objects['Physio_CancelRequestapprove_Message_Ok'])
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()    
    