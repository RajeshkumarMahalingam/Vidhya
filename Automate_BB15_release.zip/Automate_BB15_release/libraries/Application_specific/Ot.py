import sys
from Selenium2Library import Selenium2Library
from Tkconstants import ACTIVE
sys.path.append('..\..\libraries\standard') 
sys.path.append('../../libraries/standard')
sys.path.append('..\..\libraries\Application_specific')
import common_importstatements
from common_importstatements import *
import admin
from admin import FromConfigFile
import common_reader
from common_reader import Capturing


class InTheaterBooking(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    cs = common_reader.Capturing.cs
    #d = Capturing().data_off("OT_TheaterBooking")
    def surgeryfromdatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        todaydate = today.date()
        print "todaydate", todaydate
        picdatedate = picdate.date()
        print "picdatedate", picdatedate
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(5)
        if todaydate == picdatedate:        
            while(True):
                #seldate = self._get_text('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[2]')
                seldate = self._get_text('xpath=(//th[@class="switch"])[3]')
                print "pdate", pdate
                print "seldate", seldate
                if pdate == seldate:
                    print "pdate", pdate
                    print "seldate", seldate
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[3]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr/td[@class="day" or @class="day active"][text()="'+day+'"]')
            time.sleep(2)
            try:
               self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
               activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               print activehrs
               self.dict['TB_FROMDATE_ACTIVEHRS'] = activehrs 
               self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
               time.sleep(2)
            except:
                pass
            try:
               self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
               activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               print activemins
               self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
               time.sleep(2)
            except:
                pass
        else:
            raise AssertionError ("Date should be current or future date")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def surgerytodatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        print "str(self.dict['TB_FROMDATE_ACTIVEHRS'])", str(self.dict['TB_FROMDATE_ACTIVEHRS'])
        if (picdate.date()) == (today.date()):        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    print "pdate == seldate"
                    break
                else:
                    self.click_element('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day" or @class="day active"][text()="'+day+'"]')
            time.sleep(2)
            try:
               if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) != (23:00)"
                   self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]', 30, "active hrs's next timing not visible")
                   nextactivehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print nextactivehrs
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print "enddate hours", nextactivehrs
                   time.sleep(2)
               elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) == (23:00)"
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/thead/tr/th[@class="next"]')
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]', 30, "active hrs's (23:00) next day timing (0:00) was not visible")
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
            except:
                pass
            try:
                if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active minute was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   activeminutetodate = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   print "activeminutetodate", activeminutetodate
                elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]', 30, "active minute(0:00) was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
            except:
                pass
        else:
            raise AssertionError ("Date should be current or future date")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "8308"
        '''self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        self.click_element('xpath=//*[@id="txtfrmdate"]')
        for i in range (1,11):
            pyautogui.hotkey('backspace')
        time.sleep(5)
        self.input_text('xpath=//*[@id="txtfrmdate"]','21-08-2023')
        time.sleep(5)        
        self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')'''
        time.sleep(2)
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_TheaterBooking_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def entering_firstipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626485"
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_IPNo'], 30, 'ipno was not visible' )
        self.input_text(self.objects['OT_TheaterBooking_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_emergencybtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_EmergencyBtn'], 30, 'emergency btn was not visible' )
        self.click_element(self.objects['OT_TheaterBooking_EmergencyBtn'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OT_TheaterBooking_Searchbtn'], 30, 'search btn was not enabled')
        self.click_button(self.objects['OT_TheaterBooking_Searchbtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_firstipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Searchbtn'], 30, 'first ipno was not visible')
        self.dict['FIRSTIPNO'] = self.get_text('xpath=//*[@id="sample_1"]/tbody/tr/td[2]')
        self.dict['BROWSER'] = self._current_browser()
    def getting_secondipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Searchbtn'], 30, 'second ipno was not visible')
        self.dict['SECONDIPNO'] = self.get_text('xpath=//*[@id="sample_1"]/tbody/tr/td[2]')
        self.dict['BROWSER'] = self._current_browser()
    def entering_into_theaterbookingpage(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, 'Patient details not in grid')
        self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
        time.sleep(7)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_theater(self, theaternameindexvalue):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #theaternameindexvalue = int(theaternameindexvalue)
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Theater'], 100, 'theater details was not visible')
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Theater'], str(theaternameindexvalue))
        try:
             self._handle_alert(True)
        except:
             pass
        self.dict['THEATERNAME'] = self.get_selected_list_label(self.objects['OT_TheaterBooking_Theater'])
        print "Theater Name", self.dict['THEATERNAME']
        self.dict['BROWSER'] = self._current_browser()
    def selecting_procedure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        try:
             self._handle_alert(True)
        except:
             pass
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Procedure'], 30, 'procedure was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Procedure'], "3")
        try:
             self._handle_alert(True)
        except:
             pass
        self.dict['BROWSER'] = self._current_browser()
    def selecting_bodyparts(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_BodyParts'], 30, 'body parts was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_BodyParts'], '1')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_addbutton(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        time.sleep(1)
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Addbtn'], 30, 'add button was not visible' )
        self.click_element(self.objects['OT_TheaterBooking_Addbtn'])
        time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeonname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Surgeon'], 30, 'Surgeon name was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_Surgeon'], '0')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_anesthesia(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Anesthesia'], 30, 'anesthesia was not visible' )
        self.select_from_list_by_label(self.objects['OT_TheaterBooking_Anesthesia'], "Yes")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_anesthesiologist(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        ctrlvalue = self.cs['cs507']
        if (str(ctrlvalue) == '1'):
            self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Anesthesiologist'], 30, 'anesthesiologist was not visible' )
            self.select_from_list_by_index(self.objects['OT_TheaterBooking_Anesthesiologist'], '1')
        else:
            print "Anesthesiologist name was not enabled in control panel settings"
            pass
        self.dict['BROWSER'] = self._current_browser()        
    def selecting_surgeryclassification(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_SurgeryClassification'], 30, 'Surgery Classification was not visible' )
        self.select_from_list_by_index(self.objects['OT_TheaterBooking_SurgeryClassification'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeryfromdate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #r = int(r)
        time.sleep(3)
        #self.wait_until_page_contains_element('xpath=//*[@id="txtsurfrmdate"]', 30, "surgery from date was not visible")
        #date = self.d[r]['surgeryfromdate']
        #self.surgeryfromdatepicker('xpath=//*[@id="txtsurfrmdate"]', date)
        self.click_element('xpath=//*[@id="txtsurfrmdate"]')
        time.sleep(1)
        self.click_element('xpath=/html/body/div[2]/div[3]/table/tbody/tr//td[@class="day active"]/preceding-sibling::*[name() = name()][1]')
        time.sleep(2)
        self.wait_until_page_contains_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]', 30, "active hrs not visible")
        activehrs = self._get_text('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        print activehrs
        self.dict['TB_FROMDATE_ACTIVEHRS'] = activehrs 
        self.click_element('xpath=/html/body/div[2]/div[2]/table/tbody/tr/td/span[@class="hour active"]')
        time.sleep(2)
        self.wait_until_element_is_visible('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active mins not visible")
        activemins = self.get_text('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        print activemins
        self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgerytodate(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        #r = int(r)
        time.sleep(1)
        #self.wait_until_page_contains_element('xpath=//*[@id="txtsurtodate"]', 30, "surgery to date was not visible")
        #date = self.d[r]['surgerytodate']
        #self.surgerytodatepicker('xpath=//*[@id="txtsurtodate"]', date)
        self.click_element('xpath=//*[@id="txtsurtodate"]')
        time.sleep(1)
        self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr//td[@class="day active"]/preceding-sibling::*[name() = name()][1]')
        time.sleep(2)
        if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) != (23:00)"
                   self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]', 30, "active hrs's next timing not visible")
                   nextactivehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print nextactivehrs
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print "enddate hours", nextactivehrs
                   time.sleep(2)
        elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) == (23:00)"
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/thead/tr/th[@class="next"]')
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]', 30, "active hrs's (23:00) next day timing (0:00) was not visible")
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
        if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active minute was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   activeminutetodate = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   print "activeminutetodate", activeminutetodate
        elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]', 30, "active minute(0:00) was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_TheaterBooking_Savebtn"], 30, "Save btn was not visible")
         self.click_button(self.objects["OT_TheaterBooking_Savebtn"])
         #time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_TheaterBooking_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_TheaterBooking_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InBookingApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643344"
        self.wait_until_element_is_visible(self.objects['OT_TheaterBooking_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_TheaterBooking_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingApproval_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BookingApproval_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_bookingapprovalpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         time.sleep(10)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_department(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["OT_BookingApproval_Department"], 30, "Department was not visible")
         selecteddepartment = self.get_selected_list_label(self.objects["OT_BookingApproval_Department"])
         print "selecteddepartment: ", selecteddepartment
         if len(selecteddepartment) == 0:
             print "Department needs to select"
             self.select_from_list_by_index(self.objects["OT_BookingApproval_Department"],'3')
         self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["OT_BookingApproval_Approvebtn"], 30, "Approve btn was not visible")
         self.wait_until_element_is_enabled(self.objects["OT_BookingApproval_Approvebtn"], 30, "Approve btn was not enabled")
         self.click_button(self.objects["OT_BookingApproval_Approvebtn"])
         self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_BookingApproval_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_BookingApproval_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InJobEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    '''def patientintimedatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate >= today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[2]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[2]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[2]/div[1]/table/tbody/tr/td[@class="day" or @class="today active selected day"][text()="'+day+'"]')
            time.sleep(2)            
        else:
            raise AssertionError ("Date should be current date")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()'''
    def surgerytodatepicker(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        print "str(self.dict['TB_FROMDATE_ACTIVEHRS'])", str(self.dict['TB_FROMDATE_ACTIVEHRS'])
        if picdate >= today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    print "pdate == seldate"
                    break
                else:
                    self.click_element('xpath=/html/body/div[3]/div[3]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[3]/div[3]/table/tbody/tr/td[@class="day" or @class="day active"][text()="'+day+'"]')
            time.sleep(2)
            try:
               if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) != (23:00)"
                   self.wait_until_page_contains_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]', 10, "active hrs's next timing not visible")
                   nextactivehrs = self._get_text('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print nextactivehrs
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[@class="hour active"]/following-sibling::span[1]')
                   print "enddate hours", nextactivehrs
                   time.sleep(2)
               elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   print "str(self.dict['TB_FROMDATE_ACTIVEHRS']) == (23:00)"
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/thead/tr/th[@class="next"]')
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]', 30, "active hrs's (23:00) next day timing (0:00) was not visible")
                   self.click_element('xpath=/html/body/div[3]/div[2]/table/tbody/tr/td/span[text()="0:00"]')
            except:
                pass
            try:
                if str(self.dict['TB_FROMDATE_ACTIVEHRS']) != "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]', 30, "active minute was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   activeminutetodate = self._get_text('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[@class="minute active"]')
                   print "activeminutetodate", activeminutetodate
                elif str(self.dict['TB_FROMDATE_ACTIVEHRS']) == "23:00":
                   self.wait_until_element_is_visible('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]', 30, "active minute(0:00) was not visible in to date timing")
                   self.click_element('xpath=/html/body/div[3]/div[1]/table/tbody/tr/td/span[text()="0:00"]')
            except:
                pass
        else:
            raise AssertionError ("Date should be current or future date")
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()
    
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "643344"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "30-04-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_Regno'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_JobEntry_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_JobEntry_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_JobEntry_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_jobentrypage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(10)
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 15, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         try:
             self._handle_alert(True)
         except:
             pass
         time.sleep(15)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_anesthesiatype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_JobEntry_AnesthesiaType'], 30, 'Anesthesia was not visible' )
        self.select_from_list_by_index(self.objects['OT_JobEntry_AnesthesiaType'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_patientcondition(self,condition):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        condition = str(condition)
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_PatientCondition'], 30, 'patient condition was not visible' )
        self.select_from_list_by_label(self.objects['OT_JobEntry_PatientCondition'], condition)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgerytype(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_SurgeryType'], 30, 'surgery type was not visible' )
        self.select_from_list_by_index(self.objects['OT_JobEntry_SurgeryType'],'2')
        #time.sleep(1)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_sponge(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.wait_until_element_is_visible(self.objects['OT_JobEntry_Sponge'], 10, 'sponge was not visible' )
        self.wait_until_element_is_visible('xpath=//*[@id="s2id_cbospong"]/a', 30, 'sponge was not visible')
        self.click_element('xpath=//*[@id="s2id_cbospong"]/a')
        self.wait_until_element_is_visible('xpath=//*[@id="select2-drop"]//li[1]', 30, 'sponge list was not visible')
        self.click_element('xpath=//*[@id="select2-drop"]//li[1]')
        #self.select_from_list_by_index(self.objects['OT_JobEntry_Sponge'],'2')
        self.dict['BROWSER'] = self._current_browser()
    
    '''def selecting_patientintimedate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element('xpath=//*[@id="d_Patintime"]', 10, "surgery to date was not visible")
        date = self.d[r]['patientintimedate']
        self.patientintimedatepicker('xpath=//*[@id="d_Patintime"]', date)  '''
    def getting_bookingtotime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_BookingToTime'], 30, 'Booking To Time was not visible' )
        #self.click_element(self.objects['OT_JobEntry_BookingToTime'])
        bookingtotime = self.get_value(self.objects['OT_JobEntry_BookingToTime'])
        bookingtotime = str(bookingtotime)
        self.dict['BOOKINGTOTIME'] = bookingtotime
        print "BookingToTime", self.dict['BOOKINGTOTIME']
        self.dict['BROWSER'] = self._current_browser()
    def entering_patientouttime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_PatientOutTime'], 30, 'patient out time was not visible' )
        self.input_text(self.objects['OT_JobEntry_PatientOutTime'], self.dict['BOOKINGTOTIME'])
        self.dict['BROWSER'] = self._current_browser()
    def entering_surgerytotime(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_SurgeryToTime'], 30, 'surgery to time was not visible' )
        self.input_text(self.objects['OT_JobEntry_SurgeryToTime'], self.dict['BOOKINGTOTIME'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_proceduremethod(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_ProcedureMethod'], 30, 'procedure method was not visible' )
        self.select_from_list_by_index(self.objects['OT_JobEntry_ProcedureMethod'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_videorecord(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntry_VideoRecord'], 30, 'video record was not visible' )
        self.select_from_list_by_index(self.objects['OT_JobEntry_VideoRecord'],'2')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_JobEntry_Savebtn"], 35, "Save btn was not enabled")
         self.click_button(self.objects["OT_JobEntry_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()      
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_JobEntry_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_JobEntry_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
    
class InPACRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OT_PacRequest")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(5)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626529"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "30-04-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_PACRequest_RegNo'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_PACRequest_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PACRequest_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PACRequest_Searchbtn"])
         time.sleep(1)
         try:
             self._handle_alert(True)
         except:
             pass
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_pacrequestpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         try:
             self._handle_alert(True)
         except:
             pass
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]')
         try:
             self._handle_alert(True)
         except:
             pass
         self.dict['BROWSER'] = self._current_browser()
    def selecting_clinicaldiagnosis(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OT_PACRequest_ClinicalDiagnosis'], 30, 'clinical diagnosis was not visible' )
        self.input_text(self.objects['OT_PACRequest_ClinicalDiagnosis'], self.d[r]['clinicaldiagnosis'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_procedurename(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_PACRequest_ProcedureName'], 30, 'procedure name was not visible' )
        self.select_from_list_by_index(self.objects['OT_PACRequest_ProcedureName'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeonname(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_PACRequest_SurgeonName'], 30, 'surgeon name was not visible' )
        self.select_from_list_by_index(self.objects['OT_PACRequest_SurgeonName'], "2")
        self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        r = int(r)
        self.wait_until_element_is_visible(self.objects['OT_PACRequest_Remarks'], 30, 'remarks was not visible' )
        self.input_text(self.objects['OT_PACRequest_Remarks'], self.d[r]['remarks'])
        self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled(self.objects['OT_PACRequest_Savebtn'], 30, 'save btn was not enabled' )
        self.click_button(self.objects['OT_PACRequest_Savebtn'])
        self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self._handle_alert(True)
        self.wait_until_page_contains_element(self.objects['OT_PACRequest_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PACRequest_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
class InPACStatusEntry(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OT_PacStatusEntry")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626491"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "06-07-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_PACStatusEntry_RegNo'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_PACStatusEntry_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PACStatusEntry_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PACStatusEntry_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()   
    def entering_into_pacstatusentrypage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         try:
             self._handle_alert(True)
         except:
             pass
         self.dict['BROWSER'] = self._current_browser()
    def selecting_fitnessbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["OT_PACStatusEntry_Fitness"], 30, "Fitness btn was not visible")
         self.click_element(self.objects["OT_PACStatusEntry_Fitness"])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_checkbox(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         #self.wait_until_element_is_visible(self.objects["OT_PACStatusEntry_Fitness"], 15, "Fitness btn was not visible")
         #self.click_element(self.objects["OT_PACStatusEntry_Fitness"])
         time.sleep(1)
         for i in range(1, 6):
            i = str(i)
            try:
                self.click_element('xpath=(//*[@id="divFitnessPending"]//input[@type="checkbox"]/..//span[3])['+i+']')
            except ValueError:
                break
            else:
                i = int(i)
                i = i + 1
         self.dict['BROWSER'] = self._current_browser()
    def entering_reviewedafter(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.wait_until_element_is_visible(self.objects["OT_PACStatusEntry_reviewedafter"], 30, "reviewed after was not visible")
         self.input_text(self.objects["OT_PACStatusEntry_reviewedafter"],self.d[r]['reviewedafter'])
         self.dict['BROWSER'] = self._current_browser()
    def entering_assessmentadvice(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.wait_until_element_is_visible(self.objects["OT_PACStatusEntry_assessmentadvice"], 30, "reviewed after was not visible")
         self.input_text(self.objects["OT_PACStatusEntry_assessmentadvice"],self.d[r]['assessmentadvice'])
         self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.wait_until_element_is_visible(self.objects["OT_PACStatusEntry_remarks"], 30, "remarks was not visible")
         self.input_text(self.objects["OT_PACStatusEntry_remarks"],self.d[r]['remarks'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PACStatusEntry_Save"], 30, "save btn was not visible")
         self.click_button(self.objects["OT_PACStatusEntry_Save"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PACStatusEntry_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PACStatusEntry_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InPACStatusCancel(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    d = Capturing().data_off("OT_PacStatusCancel")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626491"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "06-07-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_PACStatusCancel_RegNo'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_PACStatusCancel_RegNo'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PACStatusCancel_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PACStatusCancel_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_pacstatuscancelpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self,r):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         r = int(r)
         self.wait_until_element_is_visible(self.objects["OT_PACStatusCancel_Remarks"], 30, "remarks was not visible")
         self.input_text(self.objects["OT_PACStatusCancel_Remarks"],self.d[r]['remarks'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PACStatusCancel_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_PACStatusCancel_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PACStatusCancel_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PACStatusCancel_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InBookingUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "605054"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "30-06-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_BookingUpdate_Regno'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_BookingUpdate_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingUpdate_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BookingUpdate_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_bookingupdatepage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         self.dict['BROWSER'] = self._current_browser()
    def selecting_anesthesiarequired(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(3)
         self.wait_until_element_is_visible(self.objects["OT_BookingUpdate_AnesthesiaRequired"], 30, "Anesthesia required was not visible")
         self.select_from_list_by_label(self.objects["OT_BookingUpdate_AnesthesiaRequired"],"Yes")
         self.dict['BROWSER'] = self._current_browser()
    def selecting_updatebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingUpdate_Updatebtn"], 30, "update btn was not enabled")
         self.click_button(self.objects["OT_BookingUpdate_Updatebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_BookingUpdate_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_BookingUpdate_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()     
         
class InNotesEntrySurgeon(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "605141"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "30-06-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_NotesEntrySurgeon_Regno'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_NotesEntrySurgeon_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_NotesEntrySurgeon_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_NotesEntrySurgeon_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_notesentrysurgeon(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         time.sleep(7)
         self.dict['BROWSER'] = self._current_browser()         
    def selecting_templatetab(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['OT_NotesEntrySurgeon_TemplateTab'], 30, "Template tab was not visible")
         self.click_element(self.objects['OT_NotesEntrySurgeon_TemplateTab'])
         self.dict['BROWSER'] = self._current_browser()    
    def selecting_templatename(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(7)
         self.wait_until_element_is_visible(self.objects['OT_NotesEntrySurgeon_TemplateName'], 30, "Template Name was not visible")
         self.select_from_list_by_index(self.objects['OT_NotesEntrySurgeon_TemplateName'],'1')
         self.dict['BROWSER'] = self._current_browser()  
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(5)
         self.wait_until_page_contains_element(self.objects["OT_NotesEntrySurgeon_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_NotesEntrySurgeon_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_NotesEntrySurgeon_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_NotesEntrySurgeon_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()   
        
class InOTJobEntryModify(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626523"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtfrmdate"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtfrmdate"]', "30-06-2023")
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        #self.press_key('xpath=//*[@id="txtfrmdate"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_JobEntryModify_Regno'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_JobEntryModify_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_JobEntryModify_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_JobEntryModify_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_otjobentryupdate(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_updatebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         time.sleep(5)
         self.wait_until_page_contains_element(self.objects["OT_JobEntryModify_Updatebtn"], 30, "update btn was not enabled")
         self.click_button(self.objects["OT_JobEntryModify_Updatebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_JobEntryModify_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_JobEntryModify_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
    
class InBookingCancelRequest(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626309"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtReqFromDt"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtReqFromDt"]', "07-07-2023")
        #self.press_key('xpath=//*[@id="txtReqFromDt"]', '\\09')
        #self.press_key('xpath=//*[@id="txtReqFromDt"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_BookingCancelRequest_Regno'], 30, "Regno was not visible")
        self.input_text(self.objects['OT_BookingCancelRequest_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingCancelRequest_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BookingCancelRequest_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_bookingcancelrequest(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]')
         time.sleep(4)
         self.dict['BROWSER'] = self._current_browser()     
    def selecting_reason(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["OT_BookingCancelRequest_Reason"], 30, "reason was not visible")
         self.select_from_list_by_index(self.objects["OT_BookingCancelRequest_Reason"],'3')
         self.dict['BROWSER'] = self._current_browser()
    def entering_remarks(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible(self.objects['OT_BookingCancelRequest_Remarks'], 30, "Remarks was not visible")
        self.input_text(self.objects['OT_BookingCancelRequest_Remarks'], "Not Applicable")
        self.dict['BROWSER'] = self._current_browser()     
    def selecting_savebtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingCancelRequest_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_BookingCancelRequest_Savebtn"])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_BookingCancelRequest_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_BookingCancelRequest_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()     

class InBookingCancelApproval(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(2)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_ipno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "626531"
        #self.dict['IPNO'] = "744"
        #self.wait_until_element_is_visible('xpath=//*[@id="txtReqFromDt"]', 10, "from date was not visible")
        #self.input_text('xpath=//*[@id="txtReqFromDt"]', "07-07-2023")
        #self.press_key('xpath=//*[@id="txtReqFromDt"]', '\\09')
        #self.press_key('xpath=//*[@id="txtReqFromDt"]', '\\09')
        self.wait_until_element_is_visible(self.objects['OT_BookingCancelApproval_IPNo'], 30, "ipno was not visible")
        self.input_text(self.objects['OT_BookingCancelApproval_IPNo'], str(self.dict['IPNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingCancelApproval_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BookingCancelApproval_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()  
    def entering_into_bookingcancelapprovalpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient was not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]')
         self.dict['BROWSER'] = self._current_browser()   
    def selecting_cancelapprovebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects["OT_BookingCancelApproval_CancelApprovebtn"], 30, "cancel approve btn was not enabled")
         self.click_button(self.objects["OT_BookingCancelApproval_CancelApprovebtn"])
         self._handle_alert(True)
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_BookingCancelRequest_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_BookingCancelRequest_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser() 
class InPreAnaesthesiaChecklist(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627356"
        self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_PreAnaesthesiaChecklist_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PreAnaesthesiaChecklist_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PreAnaesthesiaChecklist_Searchbtn"])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_preanaesthesiachecklistpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]')
         self.dict['BROWSER'] = self._current_browser()
    def entering_systemicillenssremarks(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element(self.objects['OT_PreAnaesthesiaChecklist_SystemicillnessRemarks'], 30, "illness remarks was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_SystemicillnessRemarks'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()
    def entering_hbpremarks(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_HBPRemarks'], 30, "hbp remarks was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_HBPRemarks'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()
    def entering_historymedicationremarks(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_HistoryMedication'], 30, "history medication  was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_HistoryMedication'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()     
    def entering_complicationremarks(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreAnaesthesiaChecklist_ComplicationRemarks'])
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_ComplicationRemarks'], 30, "history medication  was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_ComplicationRemarks'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()
    def selecting_complicationcheckbox(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreAnaesthesiaChecklist_ComplicationCheckbox'])
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_ComplicationCheckbox'], 30, "complication checkbox was not visible")
         self.click_element(self.objects['OT_PreAnaesthesiaChecklist_ComplicationCheckbox'])
         self.dict['BROWSER'] = self._current_browser()    
    def entering_chiefcomplaint(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreAnaesthesiaChecklist_ChiefComplaint'])
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_ChiefComplaint'], 30, "history medication  was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_ChiefComplaint'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()     
    def entering_remarks(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreAnaesthesiaChecklist_AssessmentRemarks'])
         self.wait_until_element_is_visible(self.objects['OT_PreAnaesthesiaChecklist_AssessmentRemarks'], 30, "history medication  was not visible")
         self.input_text(self.objects['OT_PreAnaesthesiaChecklist_AssessmentRemarks'], "Not Applicable")
         self.dict['BROWSER'] = self._current_browser()        
    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreAnaesthesiaChecklist_Savebtn'])
         self.wait_until_element_is_visible(self.objects["OT_PreAnaesthesiaChecklist_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_PreAnaesthesiaChecklist_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PreAnaesthesiaChecklist_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PreAnaesthesiaChecklist_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()

class InPreOperativeChecklist(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627066"
        self.wait_until_element_is_visible(self.objects['OT_PreOperativeChecklist_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_PreOperativeChecklist_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PreOperativeChecklist_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PreOperativeChecklist_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_preoperativechecklistpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+'"]')
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_ecgradiobtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreOperativeChecklist_ECGRadiobtn'])
         self.wait_until_page_contains_element(self.objects['OT_PreOperativeChecklist_ECGRadiobtn'], 30, "ECG radio btn was not visible")
         self.click_element(self.objects['OT_PreOperativeChecklist_ECGRadiobtn'])
         self.dict['BROWSER'] = self._current_browser()        
    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PreOperativeChecklist_Savebtn'])
         self.wait_until_element_is_visible(self.objects["OT_PreOperativeChecklist_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_PreOperativeChecklist_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PreOperativeChecklist_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PreOperativeChecklist_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()     
class InPreOperativeChecklistApprove(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627066"
        self.wait_until_element_is_visible(self.objects['OT_PreOperativeChecklistApprove_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_PreOperativeChecklistApprove_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PreOperativeChecklistApprove_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PreOperativeChecklistApprove_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_preoperativechecklistapprovepage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+self.dict['REGNO']+"  "'"]')
         time.sleep(3)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_approvebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PreOperativeChecklistApprove_Approvebtn"], 30, "approve btn was not enabled")
         self.click_button(self.objects["OT_PreOperativeChecklistApprove_Approvebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PreOperativeChecklistApprove_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PreOperativeChecklistApprove_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()    
class InWSCBeforeInductionAnaesthesia(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627066"
        self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_WSC_BeforeInduction_Anaesthesia_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_WSC_BeforeInduction_Anaesthesia_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_wscbeforeinductionpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_patientconfirmed(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PatientConfirmed'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PatientConfirmed'], 30, "patient confirmed was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PatientConfirmed'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_sitemarked(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_SiteMarked'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_SiteMarked'], 30, "site marked was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_SiteMarked'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_pulseoximeter(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PulseOximeter'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PulseOximeter'], 30, "pulse oximeter was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_PulseOximeter'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_allergy(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_allergy'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_allergy'], 30, "allergy was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_allergy'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_difficultairway(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Difficultairway'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Difficultairway'], 30, "difficult airway was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Difficultairway'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_risk(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Risk'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Risk'], 30, "risk was not visible")
         self.click_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Risk'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Savebtn'])
         self.wait_until_element_is_enabled(self.objects["OT_WSC_BeforeInduction_Anaesthesia_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_WSC_BeforeInduction_Anaesthesia_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_WSC_BeforeInduction_Anaesthesia_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()  
        

class InWSCBeforeSkinIncision(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627217"
        self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_WSC_BeforeSkinIncision_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_WSC_BeforeSkinIncision_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_WSC_BeforeSkinIncision_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_wscbeforeskinincisionpage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_confirmall(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_ConfirmAll'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_ConfirmAll'], 30, "confirm all was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_ConfirmAll'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_confirmpatientname(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_ConfirmPatientName'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_ConfirmPatientName'], 30, "confirm patient name was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_ConfirmPatientName'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_antibiotic(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_Antibiotic'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_Antibiotic'], 30, "antibiotic was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_Antibiotic'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_surgeon(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_ToSurgeon'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_ToSurgeon'], 30, "surgeon was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_ToSurgeon'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_Aneasthetists(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_ToAneasthetists'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_ToAneasthetists'], 30, "Aneasthetists was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_ToAneasthetists'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_Nursing(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_ToNursing'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_ToNursing'], 30, "Nursing was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_ToNursing'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_Imagedisplayed(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_Imagedisplayed'])
         self.wait_until_element_is_visible(self.objects['OT_WSC_BeforeSkinIncision_Imagedisplayed'], 30, "Image displayed was not visible")
         self.click_element(self.objects['OT_WSC_BeforeSkinIncision_Imagedisplayed'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_WSC_BeforeSkinIncision_Savebtn'])
         self.wait_until_element_is_enabled(self.objects["OT_WSC_BeforeSkinIncision_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_WSC_BeforeSkinIncision_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_WSC_BeforeSkinIncision_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_WSC_BeforeSkinIncision_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
class InBeforePatientLeavesOR(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627217"
        self.wait_until_element_is_visible(self.objects['OT_BeforePatientLeaveOperativeRoom_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_BeforePatientLeaveOperativeRoom_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BeforePatientLeaveOperativeRoom_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BeforePatientLeaveOperativeRoom_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_beforepatientleavepage(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_nurseverbally(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_BeforePatientLeaveOperativeRoom_NurseVerbally'], 30, "NurseVerbally was not visible")
         self.click_element(self.objects['OT_BeforePatientLeaveOperativeRoom_NurseVerbally'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_sancheckbox(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_BeforePatientLeaveOperativeRoom_SANcheckbox'], 30, "SAN checkbox was not visible")
         self.click_element(self.objects['OT_BeforePatientLeaveOperativeRoom_SANcheckbox'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BeforePatientLeaveOperativeRoom_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_BeforePatientLeaveOperativeRoom_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_BeforePatientLeaveOperativeRoom_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_BeforePatientLeaveOperativeRoom_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()        

class InPostOperativeChecklist(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")        
    def screenshotonfailure(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.register_keyword_to_run_on_failure('capturing_screenshot_on_failure')
        self.dict['BROWSER'] = self._current_browser()
    def selecting_the_frame(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.select_frame(self.objects['BB_Mainframe'])
        time.sleep(3)
        self.dict['BROWSER'] = self._current_browser()  
    def scroll_web_element_into_view(self, locator):
        jsFunction = ""
        webElement = self._element_find(locator, True, True)
        print webElement
        try:
            jsFunction = "arguments[0].scrollIntoView(true);"
            self._info("Scrolled Into View Element With locator: " + locator) 
            self.browser.execute_script(jsFunction, webElement)
        except:
            print "Exception in Scroll_Web_Element_Into_View()"
    def entering_regno(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        #self.dict['REGNO'] = "627224"
        self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_Regno'], 30, 'Regno was not visible' )
        self.input_text(self.objects['OT_PostOperativeChecklist_Regno'], str(self.dict['REGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_PostOperativeChecklist_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_PostOperativeChecklist_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()    
    def entering_into_postoperativechecklist(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_page_contains_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]', 30, "patient not in grid")
         self.click_element('xpath=//*[@id="sample_1"]//td[text()="'+str(self.dict['REGNO'])+'"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def selecting_surgerynotes(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_SurgeryNotes_Yes'], 30, "surgery notes was not visible")
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_SurgeryNotes_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_SurgeryNotes_No'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_operativenotes(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_OperativeNotes_Yes'], 30, "operative notes was not visible")
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_OperativeNotes_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_OperativeNotes_No'])
         self.dict['BROWSER'] = self._current_browser()         
    def selecting_anaesthetist(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_Anaesthetist_Yes'], 30, "Anaesthetist notes was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_Anaesthetist_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_Anaesthetist_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_Anaesthetist_No'])
         self.dict['BROWSER'] = self._current_browser()    
    def selecting_implantused(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_ImplantUsed_Yes'], 30, "implant used was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_ImplantUsed_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_ImplantUsed_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_ImplantUsed_No'])
         self.dict['BROWSER'] = self._current_browser()     
    def selecting_specimencollected(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_SpecimentCollected_Yes'], 30, "pecimentCollected was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_SpecimentCollected_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_SpecimentCollected_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_SpecimentCollected_No'])
         self.dict['BROWSER'] = self._current_browser()       
    def selecting_whochecklist(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_WHOChecklist_Yes'], 30, "WHO Checklist used was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_WHOChecklist_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_WHOChecklist_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_WHOChecklist_No'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_dischargecriteria(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_DischargeCriteria_Yes'], 30, "WHO Checklist used was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_DischargeCriteria_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_DischargeCriteria_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_DischargeCriteria_No'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_transferedtoward(self,cond):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_TransferedToWard_Yes'], 30, "transfered to ward was not visible")
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_TransferedToWard_Yes'])
         if cond == "yes":
             self.click_element(self.objects['OT_PostOperativeChecklist_TransferedToWard_Yes'])
         if cond == "no":
             self.click_element(self.objects['OT_PostOperativeChecklist_TransferedToWard_No'])
         self.dict['BROWSER'] = self._current_browser()
    def selecting_reason(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_Reason'])
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_Reason'], 30, "Reason was not visible")
         self.select_from_list_by_index(self.objects['OT_PostOperativeChecklist_Reason'],'2')
         self.dict['BROWSER'] = self._current_browser()
    
    def selecting_icdcode(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_ICDCode'])
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_ICDCode'], 30, "icdcode was not visible")
         self.click_element(self.objects['OT_PostOperativeChecklist_ICDCode'])
         #self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_ICDCodeResultBoxMore'], 10, "icdcode result more was not visible")
         #self.click_element(self.objects['OT_PostOperativeChecklist_ICDCodeResultBoxMore'])
         self.input_text(self.objects['OT_PostOperativeChecklist_ICDCode'], "a")
         time.sleep(2)
         self.wait_until_element_is_visible(self.objects['OT_PostOperativeChecklist_ICDCodeList'], 30, "icd code list was not visible")
         self.click_element(self.objects['OT_PostOperativeChecklist_ICDCodeList'])
         time.sleep(1)
         self.dict['BROWSER'] = self._current_browser()

    def selecting_savebtn(self):
         self.set_selenium_implicit_wait(5)
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.scroll_web_element_into_view(self.objects['OT_PostOperativeChecklist_Savebtn'])
         self.wait_until_element_is_enabled(self.objects["OT_PostOperativeChecklist_Savebtn"], 30, "save btn was not enabled")
         self.click_button(self.objects["OT_PostOperativeChecklist_Savebtn"])
         self.dict['BROWSER'] = self._current_browser()
    def getting_message(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_page_contains_element(self.objects['OT_PostOperativeChecklist_Message'], 30, 'Message was not visible')
        self.msg = self._get_text(self.objects['OT_PostOperativeChecklist_Message'])
        print "MSG    :", self.msg
        self.dict['BROWSER'] = self._current_browser()
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()
        
        
class InBookingOrderUpdate(Selenium2Library):
    dict = admin.FromConfigFile.dict
    objects = common_reader.Capturing.objects
    #d = Capturing().data_off("OT_TheaterBooking")
    def bookingdate(self, loc, date):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(10)
        today = date.today()
        print "today", today.strftime('%d/%B/%Y')
        picdate = date
        print "picdate", picdate.strftime('%d/%B/%Y')
        year = picdate.strftime('%Y')
        month = picdate.strftime('%B')
        day = picdate.strftime('%d').lstrip("0")
        pdate = month+' '+year
        self.click_element(loc)
        time.sleep(2)
        if picdate > today:        
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="next"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
            time.sleep(2)
        else:
            while(True):
                seldate = self._get_text('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[2]')
                print "seldate", seldate
                if pdate == seldate:
                    break
                else:
                    self.click_element('xpath=/html/body/div[4]/div[1]/table/thead/tr[1]/th[@class="prev"]')
            self.click_element('xpath=/html/body/div[4]/div[1]/table/tbody/tr/td[@class="day" and text()="'+day+'"]')
            time.sleep(2)            
        self.dict['BROWSER'] = self._current_browser()  
    def selecting_bookingdate(self,r):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.set_selenium_implicit_wait(5)
        r = int(r)
        time.sleep(1)
        self.wait_until_page_contains_element(self.objects['OT_BookingOrderUpdate_Bookingdate'], 30, "booking date was not visible")
        date = self.d[r]['bookingdate']
        self.bookingdate(self.objects['OT_BookingOrderUpdate_Bookingdate'], date)
        self.dict['BROWSER'] = self._current_browser()
    def selecting_headername(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["OT_BookingOrderUpdate_HeaderName"], 30, "Header name was not visible")
         self.click_element(self.objects["OT_BookingOrderUpdate_HeaderName"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_theatername(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible(self.objects["OT_BookingOrderUpdate_TheaterName"], 30, "Theater name was not visible")
         self.select_from_list_by_label(self.objects["OT_BookingOrderUpdate_TheaterName"],self.dict['THEATERNAME'])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser() 
    def selecting_searchbtn(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_enabled(self.objects["OT_BookingOrderUpdate_Searchbtn"], 30, "Search btn was not enabled")
         self.click_button(self.objects["OT_BookingOrderUpdate_Searchbtn"])
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def getting_firstbookingordernumber(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td[@id="tdBookingOrder1"]', 30, "first booking order was not visible")
         self.dict['FIRSTBOOKINGNO'] = self.get_text('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td[@id="tdBookingOrder1"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def getting_secondbookingordernumber(self):
         self._cache.current = self.dict['BROWSER']
         self.browser = self._current_browser()
         self.wait_until_element_is_visible('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td[@id="tdBookingOrder1"]', 30, "second booking order was not visible")
         self.dict['SECONDBOOKINGNO'] = self.get_text('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td[@id="tdBookingOrder1"]')
         time.sleep(2)
         self.dict['BROWSER'] = self._current_browser()
    def select_firstbookingorder(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td//select[@id="cboBookingOrder1"]', 30, "first booking order dropdown was not visible")
        self.select_from_list_by_label('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td//select[@id="cboBookingOrder1"]',str(self.dict['SECONDBOOKINGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def select_secondbookingorder(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_visible('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td//select[@id="cboBookingOrder1"]', 30, "second booking order dropdown was not visible")
        self.select_from_list_by_label('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td//select[@id="cboBookingOrder1"]',str(self.dict['FIRSTBOOKINGNO']))
        self.dict['BROWSER'] = self._current_browser()
    def selecting_firstbookingorderswapbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td//button', 30, "first booking order swap dropdown was not enabled")
        self.click_button('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['FIRSTIPNO']+"  "'"]/following-sibling::td//button')
        self.dict['BROWSER'] = self._current_browser()    
    def selecting_secondbookingorderswapbtn(self):
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.wait_until_element_is_enabled('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td//button', 30, "second booking order swap dropdown was not enabled")
        self.click_button('xpath=//*[@id="tblOPESCHE"]//td[text()="'+self.dict['SECONDIPNO']+"  "'"]/following-sibling::td//button')
        self.dict['BROWSER'] = self._current_browser()    
    def unselecting_the_frame(self):
        self.set_selenium_implicit_wait(5)
        self._cache.current = self.dict['BROWSER']
        self.browser = self._current_browser()
        self.unselect_frame()
        self.dict['BROWSER'] = self._current_browser()    
